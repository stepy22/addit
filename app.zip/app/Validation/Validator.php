<?php

namespace App\Validation;

/*
 * Some might consider this a particularly awful class. We can neither confirm
 * nor deny that claim.
 */

use App;
use DateTime;
use DB;
use Exception;
use Hshn\Base64EncodedFile\HttpFoundation\File\Base64EncodedFile;
use Illuminate\Validation\Validator as BaseValidator;
use Imagick;
use InvalidArgumentException;
use ReCaptcha\ReCaptcha;
use Str;
use Symfony\Component\HttpFoundation\File\Exception\FileException;
use Symfony\Component\HttpFoundation\File\File;
use wapmorgan\FileTypeDetector\Detector;

class Validator extends BaseValidator
{
    /**
     * Validates whether a slug is valid.
     *
     * The constraints are mostly related to the allowed characters - a slug may
     * only have lowercase ASCII letters, numbers, and dashes, must not start or
     * end with a dash, and must not have two consecutive dashes.
     *
     * @param string $attribute The attribute being checked. Irrelevant for this validation rule.
     * @param string $slug      The slug to validate.
     *
     * @return bool
     */
    public function validateSlug($attribute, $slug)
    {
        return $slug === Str::slug($slug);
    }

    /**
     * Tests whether a given string is a valid integer, meaning it only contains
     * actual digits, and nothing else.
     *
     * This is different from the `numeric` and `integer` validation rules.
     *
     * @param string $attribute The attribute being checked. Irrelevant for this validation rule.
     * @param mixed  $input     The input value being validated.
     *
     * @return bool
     */
    public function validateDigitsOnly($attribute, $input)
    {
        // This pattern only allows digits in the string, and nothing else, and
        // requires at least one digit present.
        $pattern = '/^\d+$/D';

        return (bool) preg_match($pattern, $input);
    }

    /**
     * Validates that a date is correct according to the provided format.
     *
     * @param string $attribute  The attribute being checked. Irrelevant for this validation rule.
     * @param string $date       The date (in string format) to validate.
     * @param array  $parameters Additional parameters.
     *
     * @return bool
     */
    public function validateCustomDateFormat($attribute, $date, array $parameters = [])
    {
        $format = isset($parameters[0]) ? $parameters[0] : 'Y-m-d';

        return (
            ($datetime = DateTime::createFromFormat($format, $date))
            && ($datetime->format($format) === $date)
        );
    }

    /**
     * Validates that the provided password matches the one belonging to the
     * current user.
     *
     * Expects to have 'current_user' in the input data.
     *
     * @param string $attribute The attribute being checked. Irrelevant for this validation rule.
     * @param string $password  The password being validated.
     *
     * @return bool
     */
    public function validateCurrentPassword($attribute, $password)
    {
        $hasher = $this->container->make('sentinel.hasher');

        return $hasher->check($password, $this->data['real_current_password']);
    }

    /**
     * Validates that the passed value is an existing page ID.
     *
     * @param string $attribute  The attribute being checked. Irrelevant for this validation rule.
     * @param mixed  $parentId   The ID of the parent page.
     * @param array  $parameters Additional parameters.
     *
     * @return bool
     */
    public function validateParentId($attribute, $parentId, $parameters)
    {
        $this->requireParameterCount(1, $parameters, 'parent_id');

        $collectionName = $parameters[0];

        $parentId = (int) $parentId;

        if ($parentId === 0) {
            return true;
        }

        $ids = $this->data[$collectionName]->modelKeys();

        return in_array($parentId, $ids, true);
    }

    /**
     * Validates that the provided template is valid.
     *
     * The `templates` must be added to the input data.
     *
     * @param string $attribute  The attribute being checked. Irrelevant for this validation rule.
     * @param mixed  $templateId The ID of the template.
     *
     * @return bool
     */
    public function validateTemplate($attribute, $templateId)
    {
        return array_key_exists($templateId, $this->data['templates']);
    }

    /**
     * Validates that the provided value is not a specific ID.
     *
     * Safer than using `not_in` because it casts to `integer`.
     *
     * @param string $attribute  The attribute being checked. Irrelevant for this validation rule.
     * @param mixed  $input      The ID to check.
     * @param array  $parameters Additional parameters.
     *
     * @return bool
     */
    public function validateNotId($attribute, $input, $parameters)
    {
        $this->requireParameterCount(1, $parameters, 'not_id');

        $input = (int) $input;
        $id = (int) $parameters[0];

        return ($input !== $id);
    }

    /**
     * Validates whether the input is a valid latitude.
     *
     * @param string $attribute The attribute being checked. Irrelevant for this validation rule.
     * @param mixed  $input     The latitude to validate.
     *
     * @return bool
     */
    public function validateLatitude($attribute, $input)
    {
        $regex = '/^'           // String start.
                . '\-?'         // An optional minus in front.
                . '\d{1,2}'     // 1 or 2 digits.
                . '(\.\d+)?'    // An optional dot, and at least 1 digit.
                . '$/D';        // String end.

        if (!preg_match($regex, $input)) {
            return false;
        }

        $input = (int) $input;

        return (abs($input) <= 90);
    }

    /**
     * Validates whether the input is a valid longitude.
     *
     * @param string $attribute The attribute being checked. Irrelevant for this validation rule.
     * @param mixed  $input     The longitude to validate.
     *
     * @return bool
     */
    public function validateLongitude($attribute, $input)
    {
        $regex = '/^'           // String start.
                . '\-?'         // An optional minus in front.
                . '\d{1,3}'     // 1 to 3 digits.
                . '(\.\d+)?'    // An optional dot, and at least 1 digit.
                . '$/D';        // String end.

        if (!preg_match($regex, $input)) {
            return false;
        }

        $input = (int) $input;

        return (abs($input) <= 180);
    }

    /**
     * Validates a unique combination of values.
     *
     * Taken from the linked SO answer and modified a bit.
     *
     * Should be used like this:
     *
     *     Validator::make(
     *         [
     *             'any_name' => ['value1', 'value2', 'value3'],
     *         ],
     *         [
     *             'any_name' => ['unique_combination:table_name,column1,column2,column3'],
     *         ]
     *     );
     *
     * This will pass only if `table_name` doesn't contain a row with columns
     * `column1`, `column2`, and `column3` having values `value1`, `value2`, and
     * `value3`, respectively.
     *
     * @param string $attribute  The attribute being checked. Irrelevant for this validation rule.
     * @param mixed  $value      The value to check.
     * @param array  $parameters Additional parameters.
     *
     * @return bool
     *
     * @link http://stackoverflow.com/a/26684043
     */
    public function validateUniqueCombination($attribute, $value, $parameters)
    {
        // Get table name from first parameter.
        $table = array_shift($parameters);

        // Build the query.
        $query = DB::table($table);

        // Add the field conditions.
        foreach ($parameters as $i => $field) {
            $query->where($field, $value[$i]);
        }

        // Validation result will be false if any rows match the combination.
        return (!$query->exists());
    }

    /**
     * Validates that the input is a properly base64-encoded image.
     *
     * @param string $attribute  The attribute being checked. Irrelevant for this validation rule.
     * @param mixed  $value      The base64-encoded image to validate.
     * @param array  $parameters Additional parameters.
     *
     * @return bool
     */
    public function validateBase64EncodedImage($attribute, $value, $parameters)
    {
        $imageBlob = base64_decode($value, true);

        if (!$imageBlob) {
            return false;
        }

        try {
            $image = new Imagick();
            $image->readImageBlob($imageBlob);

            return $image->valid();
        } catch (Exception $exception) {
            return false;
        }
    }

    /**
     * Validates that the input is a properly base64-encoded file.
     *
     * @param string $attribute  The attribute being checked. Irrelevant for this validation rule.
     * @param mixed  $value      The base64-encoded file to validate.
     * @param array  $parameters Additional parameters.
     *
     * @return bool
     */
    public function validateBase64EncodedFile($attribute, $value, $parameters)
    {
        $fileBlob = base64_decode($value, true);

        try {
            $file = new Base64EncodedFile($value);
        } catch (FileException $e) {
            return false;
        }

        $type = Detector::detectByContent($file->getPathname());

        if ($type && is_array($type) && isset($type[1])) {
            $isValid = in_array($type[1], $parameters);
        } else {
            $file = new File($file->getPathname());
            $isValid = in_array($file->guessExtension(), $parameters);
        }

        return $isValid;
    }

    /**
     * Validates whether an input string can be parsed as a valid price.
     *
     * @param string $attribute The attribute being checked. Irrelevant for this validation rule.
     * @param string $price     The price to check.
     *
     * @return bool
     */
    public function validatePrice($attribute, $price)
    {
        $priceFormatter = App::make('Creitive\Commerce\PriceFormatter');

        return $priceFormatter->isValidPrice($price);
    }

    /**
     * Validates whether an input user group ID is valid.
     *
     * @param string $attribute   The attribute being checked. Irrelevant for this validation rule.
     * @param string $userGroupId The user group ID to validate.
     *
     * @return bool
     */
    public function validatePushNotificationUserGroupId($attribute, $userGroupId)
    {
        $userGroupService = App::make('App\PushNotifications\UserGroupService');

        return $userGroupService->validateUserGroupId($userGroupId);
    }

    /**
     * Validates whether the input is a valid UUIDv4.
     *
     * @param string $attribute  The attribute being checked. Irrelevant for this validation rule.
     * @param mixed  $input      The input value to check.
     * @param array  $parameters Additional parameters.
     *
     * @return bool
     *
     * @throws InvalidArgumentException
     */
    public function validateUuid($attribute, $input, $parameters)
    {
        // Reject non-strings immediately.
        if (!is_string($input)) {
            return false;
        }

        // Parse the UUID version to check against.
        $version = empty($parameters) ? null : $parameters[0];

        if (!in_array($version, [1, 2, 3, 4, 5, '1', '2', '3', '4', '5', null])) {
            throw new InvalidArgumentException('If provided, the UUID version must be a digit from 1 to 5 inclusive,');
        }

        if ($version === null) {
            $version = '[1-5]';
        } else {
            $version = (string) $version;
        }

        // Compile the pattern.
        $regex = '/^'                   // String start.
                . '[0-9A-F]{8}'         // 8 hex digits.
                . '\-'                  // A dash.
                . '[0-9A-F]{4}'         // 4 hex digits.
                . '\-'                  // A dash.
                . $version              // The UUID version.
                . '[0-9A-F]{3}'         // 3 hex digits.
                . '\-'                  // A dash.
                . '[89AB][0-9A-F]{3}'   // One of ["8", "9", "A", "B"] and 3 hex digits.
                . '\-'                  // A dash.
                . '[0-9A-F]{12}'        // 12 hex digits.
                . '$/Di';               // String end, case insensitive, `$` is string end only.

        return preg_match($regex, $input) === 1;
    }

    /**
     * Validates if price is lower than provided minimum.
     *
     * @param string $attribute  The attribute being checked. Irrelevant for this validation rule.
     * @param mixed  $input      The input value to check.
     * @param array  $parameters Additional parameters.
     *
     * @return bool
     */
    public function validateMinPrice($attribute, $input, $parameters)
    {
        $priceFormatter = App::make('Creitive\Commerce\PriceFormatter');

        $price = empty($parameters) ? null : (int) $parameters[0];
        $inputPrice = $priceFormatter->toDatabase($input);

        return $price <= $inputPrice;
    }

    /**
     * Validates a ReCaptcha response.
     *
     * @param string $attribute  Attribute.
     * @param mixed  $input      Input data.
     * @param array  $parameters Validator parameter.
     *
     * @return boolean
     */
    public function validateRecaptcha($attribute, $input, $parameters)
    {
        $recaptcha = app(ReCaptcha::class);

        $response = $recaptcha->verify($input);

        return $response->isSuccess();
    }
}
