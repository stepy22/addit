<?php

namespace App\UrlShortener;

use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerFrontApiRoutes($this->app['router']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers admin API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1/url-shortener',
            'middleware' => ['api'],
            'namespace' => 'App\UrlShortener\Http\Controllers\Api\V1\Front',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->post('shorten', 'Controller@shorten');
        });
    }
}
