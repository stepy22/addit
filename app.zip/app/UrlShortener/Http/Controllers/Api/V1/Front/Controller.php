<?php

namespace App\UrlShortener\Http\Controllers\Api\V1\Front;

use App\Http\Controllers\Admin\Controller as BaseController;
use App\UrlShortener\Http\Requests\Api\V1\Front\ShortenRequest;
use Creitive\UrlShortener\Shortener;
use Mremi\UrlShortener\Exception\InvalidApiResponseException;
use Response;

class Controller extends BaseController
{
    /**
     * Shorten a link.
     *
     * @param ShortenRequest $request   Request instance.
     * @param Shortener      $shortener Url shortener instance.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function shorten(ShortenRequest $request, Shortener $shortener)
    {
        try {
            $short_link = $shortener->shorten($request->get('long_url'));
        } catch (InvalidApiResponseException $exception) {
            return Response::json(['error' => 'Link you provided is not valid URL of is already a Bitly link.']);
        }

        return Response::make([
            'short_link' => $short_link,
        ]);
    }
}
