<?php

namespace App\Http\Controllers\Front;

use App;
use App\Content\Page\Repository as PageRepository;
use App\Http\Controllers\Controller as BaseController;
use Sentinel;
use URL;

class Controller extends BaseController
{
    /**
     * Sets the base assets (scripts and styles).
     *
     * @return void
     */
    public function setBaseAssets()
    {
        $this->assets->loadAssetsForFront();
        $this->setBaseProperties();
        $this->setBaseViewData();
        $this->buildNavigation();
    }

    /**
     * Sets some base controller properties which are needed by the child
     * classes.
     *
     * @return void
     */
    protected function setBaseProperties()
    {
        $pageRepository = App::make(PageRepository::class);
        $this->pages = $pageRepository->getAll();
    }

    /**
     * Sets base view data.
     *
     * @return void
     */
    protected function setBaseViewData()
    {
        $this->viewData->pages = $this->pages;
        $this->viewData->isOptInPage = false;
    }

    /**
     * Builds the front-end navigation.
     *
     * @return void
     */
    public function buildNavigation()
    {
        $navigation = $this->viewData->navigation->get('front.main');

        foreach ($this->pages as $page) {
            if ($page->show_in_navigation) {
                $navigation->addLast(
                    $page->slug,
                    [
                        'href' => URL::action('App\Content\Http\Controllers\Front\Page\Controller@resolveRoute', ['any' => $page->full_slug]),
                        'label' => $page->title,
                        'children' => $page->show_subpages_in_navigation ? $page->children : null,
                        'selectable_in_navigation' => $page->selectable_in_navigation,
                    ]
                );
            }
        }

        $navigation->addLast(
            'contact',
            [
                'href' => URL::action('App\Contact\Http\Controllers\Front\Message\Controller@index'),
                'label' => trans('navigation.contact'),
            ]
        );

        $navigation->setActive('home');
    }
}
