<?php

namespace App\Http\Controllers\Front;

use App\Auth\Login\Manager as LoginManager;
use App\Http\Controllers\Front\Controller as BaseController;
use AssetManager;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Laravel\Socialite\Contracts\Factory as SocialiteFactory;
use Redirect;
use URL;

class LoginController extends BaseController
{
    /**
     * A LoginManager instance.
     *
     * @var LoginManager
     */
    protected $loginManager;

    /**
     * A SocialiteFactory instance.
     *
     * @var SocialiteFactory
     */
    protected $socialite;

    /**
     * @param LoginManager     $loginManager A login manager instance.
     * @param SocialiteFactory $socialite    A socialite factory.
     */
    public function __construct(LoginManager $loginManager, SocialiteFactory $socialite)
    {
        parent::__construct();

        $this->loginManager = $loginManager;
        $this->socialite = $socialite;
    }

    /**
     * Redirect the user to the providers authentication page.
     *
     * @param string $provider The social login provider.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function socialAuthorize($provider)
    {
        if ($provider === 'facebook') {
            return $this->socialite->driver($provider)
                ->scopes(['user_likes'])
                ->redirect();
        }

        return $this->socialite->driver($provider)->redirect();
    }

    /**
     * Redirect the user to the providers authentication page.
     *
     * @param string $provider The social login provider.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function socialAuthenticate($provider)
    {
        $user = $this->socialite->driver($provider)->user();

        $redirection = $this->loginManager->loginSocial($user, $provider);

        if ($redirection instanceof RedirectResponse) {
            return $redirection;
        }

        return Redirect::action('App\Auth\Http\Controllers\Front\Login\Controller@index')
            ->withErrors($this->loginManager->getErrors())
            ->withInput();
    }
}
