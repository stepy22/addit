<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Front\Controller;
use Cartalyst\Sentinel\Sentinel;
use Redirect;

class HomeController extends Controller
{
    /**
     * Displays the website home page.
     *
     * @param Sentinel $sentinel Sentinel instance.
     *
     * @return \Illuminate\View\View
     */
    public function index(Sentinel $sentinel)
    {
        $user = $sentinel->getUser();

        if ($user && !$user->inRole('admin')) {
            if (!$user->profile_completed) {
                return Redirect::action('App\Auth\Http\Controllers\Front\User\Controller@profileCompletion');
            } else {
                return Redirect::action('App\Dashboards\Http\Controllers\Front\Dashboard\Controller@index');
            }
        }

        $data['homeHeader'] = 'header--primary';
        $data['homeNavbar'] = 'navbar--primary';
        $data['homeNavbarNav'] = 'navbar-nav--primary';
        $data['homeNavbarBrand'] = 'navbar-brand--primary';
        $data['homeNavbarNavLinksItem'] = 'navbar-nav-links-item--primary';
        $data['homeNavbarNavLinksItemLink'] = 'navbar-nav-links-item-link--primary';
        $data['homeNavbarSocialIcons'] = 'navbar-socialIcons--primary';
        $data['homeNavbarToggle'] = 'navbar-toggle--primary';
        $data['homeNavbarCollapse'] = 'navbar-collapse--primary';

        return view('home', $data);
    }
}
