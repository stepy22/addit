<?php

namespace App\Http\Controllers\Admin;

use App\Auth\User\Repository as UserRepository;
use App\Http\Controllers\Admin\Controller;
use App\Transactions\Transaction\Repository as TransactionRepository;
use App\Widgets\Widget;
use App\WidgetTypes\WidgetType;
use App\WidgetTypes\WidgetType\Repository as WidgetTypeRepository;
use Illuminate\Config\Repository as Config;

class HomeController extends Controller
{
    /**
     */
    public function __construct()
    {
        parent::__construct();

        $this->viewData->bodyDataPage = 'admin-home';
        $this->viewData->pageTitle->setPage(trans('common.adminPanel'));
    }

    /**
     * Gets the admin panel homepage.
     *
     * @param TransactionRepository $transactionRepository Transaction repository.
     * @param UserRepository        $userRepository        User repository.
     * @param WidgetTypeRepository  $widgetTypeRepository  Widget type repository.
     * @param Config                $config                Config repository.
     *
     * @return \Illuminate\View\View
     */
    public function index(
        TransactionRepository $transactionRepository,
        UserRepository $userRepository,
        WidgetTypeRepository $widgetTypeRepository,
        Config $config
    ) {
        $allUsedWidgets = $widgetTypeRepository->getAllUsed();

        foreach ($allUsedWidgets as $widgetType) {
            $sharedCount = 0;

            foreach ($widgetType->widgets as $widget) {
                if ($widget->users->count() > 1) {
                    $sharedCount++;
                }
            }

            $widgetType->shared_count = $sharedCount;
        };

        $mostSharedWidgetTypes = $allUsedWidgets
            ->sortByDesc('shared_count')
            ->where('shared_count', '>', 0)
            ->take(10);

        $data = [
            'transactions' => $transactionRepository->getByPage(),
            'referrers' => $userRepository->getTopReferrers(),
            'mostUsedWidgetTypes' => $widgetTypeRepository->getmostUsed(),
            'mostUsedProWidgetTypes' => $widgetTypeRepository->getmostUsedPro(),
            'mostUsedPlatinumWidgetTypes' => $widgetTypeRepository->getmostUsedPlatinum(),
            'mostSharedWidgetTypes' => $mostSharedWidgetTypes,
            'googleOauthClientId' => $config->get('services.google.client_id'),
            'analyticsViewId' => $config->get('googleAnalytics.viewId'),
        ];

        return view('admin.home', $data);
    }
}
