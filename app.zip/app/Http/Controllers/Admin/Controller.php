<?php

namespace App\Http\Controllers\Admin;

use App;
use App\Content\Page\Repository as PageRepository;
use App\Http\Controllers\Controller as BaseController;
use Config;
use Creitive\Commerce\PriceFormatter;
use URL;

class Controller extends BaseController
{
    /**
     */
    public function __construct()
    {
        parent::__construct();

        $this->buildNavigation();
        $this->setBaseProperties();
        $this->setBaseViewData();
    }

    /**
     * Sets the base assets (scripts and styles).
     *
     * @return void
     */
    public function setBaseAssets()
    {
        $this->assets->loadAssetsForAdmin();
    }

    /**
     * Sets some base controller properties which are needed by the child
     * classes.
     *
     * @return void
     */
    protected function setBaseProperties()
    {
        $pageRepository = App::make(PageRepository::class);
        $this->pages = $pageRepository->getAll();
    }

    /**
     * Sets base view data.
     *
     * @return void
     */
    protected function setBaseViewData()
    {
        $this->viewData->pages = $this->pages;
        $this->viewData->creitiveNotificationsApiKey = Config::get('creitiveNotifications.apiKey');
    }

    /**
     * Builds the admin panel navigation.
     *
     * @return void
     */
    protected function buildNavigation()
    {
        $navigation = $this->viewData->navigation->get('admin.main');
        $currentUser = $this->viewData->currentUser;

        $navigation->addLast(
            'home',
            [
                'href' => URL::action('App\Http\Controllers\Admin\HomeController@index'),
                'icon' => 'home',
                'label' => trans('admin/navigation.home'),
            ]
        );

        $navigation->addLast(
            'pages',
            [
                'href' => URL::action('App\Content\Http\Controllers\Admin\Page\Controller@index'),
                'icon' => 'file-text-o',
                'label' => trans('admin/navigation.pages'),
            ]
        );

        $navigation->addLast(
            'dashboard-categories',
            [
                'href' => URL::action('App\DashboardCategories\Http\Controllers\Admin\DashboardCategory\Controller@index'),
                'icon' => 'bars',
                'label' => trans('admin/navigation.dashboardCategories'),
            ]
        );

        $navigation->addLast(
            'widget-types',
            [
                'href' => URL::action('App\WidgetTypes\Http\Controllers\Admin\WidgetType\Controller@index'),
                'icon' => 'th-large',
                'label' => trans('admin/navigation.widgetTypes'),
            ]
        );

        $navigation->addLast(
            'widget-backgrounds',
            [
                'href' => URL::action('App\WidgetBackgrounds\Http\Controllers\Admin\WidgetBackground\Controller@index'),
                'icon' => 'tint',
                'label' => trans('admin/navigation.widgetBackgrounds'),
            ]
        );

        $navigation->addLast(
            'facebook-groups',
            [
                'href' => URL::action('App\FacebookGroups\Http\Controllers\Admin\Group\Controller@index'),
                'icon' => 'facebook-official',
                'label' => trans('admin/navigation.facebookGroups'),
            ]
        );

        $navigation->addLast(
            'suggested-links',
            [
                'href' => URL::action('App\SuggestedLinks\Http\Controllers\Admin\SuggestedLink\Controller@index'),
                'icon' => 'link',
                'label' => trans('admin/navigation.suggestedLinks'),
            ]
        );

        $navigation->addLast(
            'announcements',
            [
                'href' => URL::action('App\Notifications\Http\Controllers\Admin\Announcement\Controller@index'),
                'icon' => 'bell',
                'label' => trans('admin/navigation.announcements'),
            ]
        );

        $navigation->addLast(
            'users',
            [
                'href' => URL::action('App\Auth\Http\Controllers\Admin\User\Controller@index'),
                'icon' => 'users',
                'label' => trans('admin/navigation.users'),
            ]
        );

        $navigation->addLast(
            'password',
            [
                'href' => URL::action('App\Auth\Http\Controllers\Admin\Password\Controller@index'),
                'icon' => 'lock',
                'label' => trans('admin/navigation.password'),
            ]
        );

        $navigation->addLast(
            'my-insight-subjects',
            [
                'href' => URL::action('App\MyInsightSubjects\Http\Controllers\Admin\MyInsightSubject\Controller@index'),
                'icon' => 'tags',
                'label' => trans('admin/navigation.myInsightSubjects'),
            ]
        );

        $navigation->addLast(
            'back-to-website',
            [
                'href' => URL::action('App\Http\Controllers\Front\HomeController@index'),
                'icon' => 'globe',
                'label' => trans('admin/navigation.backToWebsite'),
            ]
        );

        $navigation->setActive('home');
    }
}
