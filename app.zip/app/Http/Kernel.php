<?php

namespace App\Http;

use Illuminate\Foundation\Http\Kernel as HttpKernel;

class Kernel extends HttpKernel
{
    /**
     * The application's global HTTP middleware stack.
     *
     * @var array
     */
    protected $middleware = [
        \Illuminate\Foundation\Http\Middleware\CheckForMaintenanceMode::class,
        \Illuminate\Foundation\Http\Middleware\ValidatePostSize::class,
        \Creitive\Http\Middleware\ForceSsl::class,
    ];

    /**
     * The application's route middleware groups.
     *
     * @var array
     */
    protected $middlewareGroups = [
        'web' => [
            \Illuminate\Session\Middleware\StartSession::class,
            \Illuminate\Http\Middleware\FrameGuard::class,
            \App\Http\Middleware\EncryptCookies::class,
            \Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse::class,
            \Illuminate\View\Middleware\ShareErrorsFromSession::class,
            \App\Http\Middleware\VerifyCsrfToken::class,
            \App\ViewData\Middleware\AttachSessionDependentDataToViewData::class,
            \Illuminate\Routing\Middleware\SubstituteBindings::class,
            \App\Http\Middleware\AttachProfileNotCompletedMessage::class,
        ],

        'api' => [
            \Illuminate\Session\Middleware\StartSession::class,
            \App\Http\Middleware\DisableSessionsForApi::class,
            \Illuminate\Routing\Middleware\ThrottleRequests::class . ':60,1',
            \Illuminate\Routing\Middleware\SubstituteBindings::class,
            \Creitive\Api\Middleware\LoginApiUser::class,
            \Creitive\Api\Middleware\Empty200To204Response::class,
        ],
    ];

    /**
     * The application's route middleware.
     *
     * @var array
     */
    protected $routeMiddleware = [
        'auth' => \App\Http\Middleware\Authenticate::class,
        'auth.basic' => \App\Http\Middleware\AuthenticateWithBasicAuth::class,
        'auth.front' => \App\Http\Middleware\FrontAuthenticate::class,
        'guest' => \App\Http\Middleware\RedirectIfAuthenticated::class,
        'profile.completed' => \App\Http\Middleware\RedirectProfileNotCompleted::class,
        'guest.front' => \App\Http\Middleware\RedirectIfAuthenticatedAsUser::class,
        'permissions' => \App\Http\Middleware\AuthorizeRouteAccess::class,
        'dashboard.access' => \App\Dashboards\Http\Middleware\UserDashboardAccess::class,
        'dashboard.ownership' => \App\Dashboards\Http\Middleware\DashboardOwnershipMiddleware::class,
        'widget.ownership' => \App\Widgets\Http\Middleware\WidgetOwnershipMiddleware::class,
        'widget.access' => \App\Widgets\Http\Middleware\WidgetAccessMiddleware::class,
        'widgetLink.access' => \App\Widgets\Http\Middleware\WidgetLinkAccessMiddleware::class,
        'widgetFile.access' => \App\Widgets\Http\Middleware\WidgetFileAccessMiddleware::class,
        'widgetFileItem.access' => \App\Widgets\Http\Middleware\WidgetFileItemAccessMiddleware::class,
        'widgetEvent.access' => \App\Widgets\Http\Middleware\WidgetEventAccessMiddleware::class,
        'widgetChecklist.access' => \App\Widgets\Http\Middleware\WidgetChecklistAccessMiddleware::class,
        'widgetChecklistItem.access' => \App\Widgets\Http\Middleware\WidgetChecklistItemAccessMiddleware::class,
        'widgetGallery.access' => \App\Widgets\Http\Middleware\WidgetGalleryAccessMiddleware::class,
        'widgetGalleryImage.access' => \App\Widgets\Http\Middleware\WidgetGalleryImageAccessMiddleware::class,
        'widgetNote.access' => \App\Widgets\Http\Middleware\WidgetNoteAccessMiddleware::class,
        'widgetBirthday.access' => \App\Widgets\Http\Middleware\WidgetBirthdayAccessMiddleware::class,
        'widgetContact.access' => \App\Widgets\Http\Middleware\WidgetContactAccessMiddleware::class,
        'widgetContactAddress.access' => \App\Widgets\Http\Middleware\WidgetContactAddressAccessMiddleware::class,
        'widgetContactEmail.access' => \App\Widgets\Http\Middleware\WidgetContactEmailAccessMiddleware::class,
        'widgetContactNumber.access' => \App\Widgets\Http\Middleware\WidgetContactNumberAccessMiddleware::class,
        'widgetMyInsightItem.access' => \App\Widgets\Http\Middleware\WidgetMyInsightItemAccessMiddleware::class,
        'widgetMyInsightItemFile.access' => \App\Widgets\Http\Middleware\WidgetMyInsightItemFileAccessMiddleware::class,
        'widgetMyInsightItemPhoto.access' => \App\Widgets\Http\Middleware\WidgetMyInsightItemPhotoAccessMiddleware::class,
        'widgetMyInsightItemLink.access' => \App\Widgets\Http\Middleware\WidgetMyInsightItemLinkAccessMiddleware::class,
        'widgetMyTopTenList.access' => \App\Widgets\Http\Middleware\WidgetMyTopTenListItemAccessMiddleware::class,
        'widgetYoutubeVideo.access' => \App\Widgets\Http\Middleware\WidgetYoutubeVideoAccessMiddleware::class,
        'widgetEmbeddedPage.access' => \App\Widgets\Http\Middleware\WidgetEmbeddedPageAccessMiddleware::class,
        'widgetSchoolScheduleItem.access' => \App\Widgets\Http\Middleware\WidgetSchoolScheduleItemAccessMiddleware::class,
        'widgetSocialBookmark.access' => \App\Widgets\Http\Middleware\WidgetSocialBookmarkAccessMiddleware::class,
        'widgetWorldClockCity.access' => \App\Widgets\Http\Middleware\WidgetWorldClockCityAccessMiddleware::class,
    ];
}
