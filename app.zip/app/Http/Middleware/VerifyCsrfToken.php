<?php

namespace App\Http\Middleware;

use Creitive\Api\ApiDetector;
use Illuminate\Contracts\Encryption\Encrypter;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken as Middleware;

class VerifyCsrfToken extends Middleware
{
    /**
     * The API detector instance.
     *
     * @var ApiDetector
     */
    protected $apiDetector;

    /**
     * Create a new middleware instance.
     *
     * @param Application $application The application instance.
     * @param Encrypter   $encrypter   An Encrypter implementation.
     * @param ApiDetector $apiDetector An API detector instance.
     *
     * @return void
     */
    public function __construct(Application $application, Encrypter $encrypter, ApiDetector $apiDetector)
    {
        parent::__construct($application, $encrypter);

        $this->apiDetector = $apiDetector;
    }

    /**
     * The URIs that should be excluded from CSRF verification.
     *
     * @var array
     */
    protected $except = [
        'payfort-transaction-feedback-handler',
    ];

    /**
     * {@inheritDoc}
     */
    protected function shouldPassThrough($request)
    {
        if (parent::shouldPassThrough($request)) {
            return true;
        }

        if ($this->apiDetector->isApi()) {
            return true;
        }

        return false;
    }
}
