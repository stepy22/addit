<?php

namespace App\Http\Middleware;

use App\Auth\User;
use Cartalyst\Sentinel\Sentinel;
use Closure;
use Creitive\Api\ApiDetector;
use Creitive\ViewData\ViewData;
use Illuminate\Http\Request;
use Illuminate\Support\MessageBag;
use Redirect;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use URL;

class AttachProfileNotCompletedMessage
{
    /**
     * The Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * The ApiDetector instance
     */
    protected $apiDetector;

    /**
     * A ViewData instance.
     *
     * @var ViewData
     */
    protected $viewData;

    /**
     * @param ViewData    $viewData    A ViewData instance.
     * @param Sentinel    $sentinel    Sentinel instance.
     * @param ApiDetector $apiDetector ApiDetector instance.
     */
    public function __construct(ViewData $viewData, Sentinel $sentinel, ApiDetector $apiDetector)
    {
        $this->sentinel = $sentinel;
        $this->apiDetector = $apiDetector;
        $this->viewData = $viewData;
    }

    /**
     * Handle an incoming request.
     *
     * @param Request  $request Request instance.
     * @param \Closure $next    Callback function.
     *
     * @return mixed
     *
     * @throws AccessDeniedHttpException
     */
    public function handle(Request $request, Closure $next)
    {
        $user = $this->sentinel->getUser();
        if ($user instanceof User && !$user->profile_completed) {
            if (!$this->apiDetector->isApi()) {
                $errorMessage = trans('common.errorMessages.profileNotCompleted', [
                    'url' => URL::action('\App\Auth\Http\Controllers\Front\User\Controller@profileCompletion'),
                ]);
                $this->viewData->profileNotCompletedMessage = $errorMessage;
            }
        }

        return $next($request);
    }
}
