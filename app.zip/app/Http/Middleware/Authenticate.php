<?php

namespace App\Http\Middleware;

use Cartalyst\Sentinel\Sentinel;
use Closure;
use Creitive\Api\ApiDetector;
use Illuminate\Http\Request;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

/**
 * Makes sure the user is authenticated.
 *
 * If they are, the request is passed on.
 *
 * Otherwise, the user will be redirected to the `/admin/login` path (this is
 * currently hard-coded), or throws an `AccessDeniedHttpException` in case of an
 * AJAX request.
 */
class Authenticate
{
    /**
     * A Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * The ApiDetector instance
     *
     * @var ApiDetector
     */
    protected $apiDetector;

    /**
     * Create a new middleware instance.
     *
     * @param Sentinel    $sentinel    A Sentinel instance.
     * @param ApiDetector $apiDetector An API detector.
     *
     * @return void
     */
    public function __construct(Sentinel $sentinel, ApiDetector $apiDetector)
    {
        $this->sentinel = $sentinel;
        $this->apiDetector = $apiDetector;
    }

    /**
     * Handle an incoming request.
     *
     * @param Request $request The incoming request.
     * @param Closure $next    The next middleware.
     *
     * @return mixed
     *
     * @throws AccessDeniedHttpException
     */
    public function handle(Request $request, Closure $next)
    {
        if ($this->sentinel->guest()) {
            if ($request->ajax() || $this->apiDetector->isApi()) {
                throw new AccessDeniedHttpException();
            } else {
                return redirect()->guest('/admin/login');
            }
        }

        return $next($request);
    }
}
