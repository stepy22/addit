<?php

namespace App\Http\Middleware;

use Cartalyst\Sentinel\Sentinel;
use Closure;
use Creitive\Api\ApiDetector;
use Illuminate\Http\Request;
use Illuminate\Support\MessageBag;
use Redirect;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

/**
 * Makes sure the user is authenticated.
 *
 * If they are, the request is passed on.
 *
 * Otherwise, the user will be redirected to the login page path, or throws an
 * `AccessDeniedHttpException` in case of an AJAX request.
 */
class FrontAuthenticate
{
    /**
     * The Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * The ApiDetector instance
     */
    protected $apiDetector;

    /**
     * @param Sentinel    $sentinel    Sentinel instance.
     * @param ApiDetector $apiDetector ApiDetector instance.
     */
    public function __construct(Sentinel $sentinel, ApiDetector $apiDetector)
    {
        $this->sentinel = $sentinel;
        $this->apiDetector = $apiDetector;
    }

    /**
     * Handle an incoming request.
     *
     * @param Request  $request Request instance.
     * @param \Closure $next    Callback function.
     *
     * @return mixed
     *
     * @throws AccessDeniedHttpException
     */
    public function handle(Request $request, Closure $next)
    {
        if ($this->sentinel->guest()) {
            if ($request->ajax() || $this->apiDetector->isApi()) {
                throw new AccessDeniedHttpException;
            } else {
                $errorMessage = trans('common.errorMessages.auth');

                return Redirect::action('App\Auth\Http\Controllers\Front\Login\Controller@index')
                    ->with('errorMessages', new MessageBag([$errorMessage]));
            }
        }

        return $next($request);
    }
}
