<?php

namespace App\Http\Middleware;

use Cartalyst\Sentinel\Sentinel;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Routing\Redirector;

class RedirectIfAuthenticated
{
    /**
     * The Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * A Redirector instance.
     *
     * @var Redirector
     */
    protected $redirect;

    /**
     * Create a new middleware instance.
     *
     * @param Sentinel   $sentinel A Sentinel instance.
     * @param Redirector $redirect A redirector instance.
     *
     * @return void
     */
    public function __construct(Sentinel $sentinel, Redirector $redirect)
    {
        $this->sentinel = $sentinel;
        $this->redirect = $redirect;
    }

    /**
     * Handle an incoming request.
     *
     * @param Request $request The incoming request.
     * @param Closure $next    The next middleware to run.
     *
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        if ($this->sentinel->check()) {
            return $this->redirect->action('App\Http\Controllers\Admin\HomeController@index');
        }

        return $next($request);
    }
}
