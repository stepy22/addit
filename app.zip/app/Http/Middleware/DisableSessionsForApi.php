<?php

namespace App\Http\Middleware;

use Closure;
use Creitive\Api\ApiDetector;
use Illuminate\Config\Repository as ConfigRepository;
use Illuminate\Http\Request;

class DisableSessionsForApi
{

    /**
     * The API detector instance.
     *
     * @var ApiDetector
     */
    protected $apiDetector;

    /**
     * A Config repository instance.
     *
     * @var ConfigRepository
     */
    protected $config;

    /**
     * Create a new middleware instance.
     *
     * @param ApiDetector      $apiDetector An API detector.
     * @param ConfigRepository $config      A config repository.
     *
     * @return void
     */
    public function __construct(ApiDetector $apiDetector, ConfigRepository $config)
    {
        $this->apiDetector = $apiDetector;
        $this->config = $config;
    }

    /**
     * Handle an incoming request.
     *
     * @param Request $request The incoming request.
     * @param Closure $next    The next middleware to run.
     *
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        if ($this->apiDetector->isApi()) {
            $this->config->set('session.driver', 'array');
        }

        return $next($request);
    }
}
