<?php

namespace App\Http\Middleware;

use Cartalyst\Sentinel\Sentinel;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Routing\Redirector;

class RedirectIfAuthenticatedAsUser
{
    /**
     * The Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * A Redirector instance.
     *
     * @var Redirector
     */
    protected $redirect;

    /**
     * @param Sentinel   $sentinel Sentinel instance.
     * @param Redirector $redirect Redirector class instance.
     */
    public function __construct(Sentinel $sentinel, Redirector $redirect)
    {
        $this->sentinel = $sentinel;
        $this->redirect = $redirect;
    }

    /**
     * Handle an incoming request.
     *
     * @param Request  $request Request instance.
     * @param \Closure $next    Closure function.
     *
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        if ($this->sentinel->check()) {
            return $this->redirect->action('App\Http\Controllers\Front\HomeController@index');
        }

        return $next($request);
    }
}
