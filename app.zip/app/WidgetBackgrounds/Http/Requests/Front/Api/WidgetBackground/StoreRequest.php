<?php

namespace App\WidgetBackgrounds\Http\Requests\Front\Api\WidgetBackground;

use App\Http\Requests\Request;
use App\Widgets\Widget;

class StoreRequest extends Request
{

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return Widget::find($this->widget_id)->backgrounds->count() !== 5;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'widget_id' => ['required', 'exists:widgets,id'],
            'image_main' => ['required', 'max:'.(10240 * 1024) / 3 * 4],
        ];

        return $rules;
    }
}
