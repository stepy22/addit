<?php

namespace App\WidgetBackgrounds\Http\Requests\Front\Api\WidgetBackground;

use App\Http\Requests\Request;
use Cartalyst\Sentinel\Sentinel;

class DeleteRequest extends Request
{
    /**
     * Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * @param Sentinel $sentinel Sentinel instance.
     */
    public function __construct(Sentinel $sentinel)
    {
        $this->sentinel = $sentinel;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [];

        return $rules;
    }
}
