<?php

namespace App\WidgetBackgrounds\Http\Controllers\Admin\WidgetBackground;

use App\Http\Controllers\Admin\Controller as BaseController;
use App\WidgetBackgrounds\Http\Requests\Admin\WidgetBackground\DeleteRequest;
use App\WidgetBackgrounds\Http\Requests\Admin\WidgetBackground\StoreRequest;
use App\WidgetBackgrounds\Http\Requests\Admin\WidgetBackground\UpdateRequest;
use App\WidgetBackgrounds\WidgetBackground;
use App\WidgetBackgrounds\WidgetBackground\Repository as WidgetBackgroundRepository;
use Illuminate\Http\Request;
use Illuminate\Support\MessageBag;
use Redirect;

class Controller extends BaseController
{
    /**
     * A WidgetBackgroundRepository instance.
     *
     * @var WidgetBackgroundRepository
     */
    protected $widgetBackgroundRepository;

    /**
     * @param WidgetBackgroundRepository $widgetBackgroundRepository A widgetBackground repository instance.
     */
    public function __construct(WidgetBackgroundRepository $widgetBackgroundRepository)
    {
        parent::__construct();

        $this->widgetBackgroundRepository = $widgetBackgroundRepository;

        $this->viewData->bodyDataPage = 'admin-widget-backgrounds';
        $this->viewData->pageTitle->setPage(trans('admin/widgetBackgrounds.module'));
        $this->viewData->navigation->get('admin.main')->setActive('widget-backgrounds');
    }

    /**
     * Shows all widgetBackgounds.
     *
     * @param Request $request The current request.
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $data = [
            'widgetBackgrounds' => $this->widgetBackgroundRepository->getDefaultWidgetBackgrounds(),
        ];

        return view('admin.widget-backgrounds.index', $data);
    }

    /**
     * Displays the create form.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        return view('admin.widget-backgrounds.create');
    }

    /**
     * Saves a new widgetBackground.
     *
     * @param StoreRequest $request A widgetBackground store request.
     *
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function store(StoreRequest $request)
    {
        $suggestedLink = $this->widgetBackgroundRepository->create($request->all());

        $successMessage = trans('admin/widgetBackgrounds.successMessages.create');

        return Redirect::action(static::class.'@edit', ['suggestedLink' => $suggestedLink->id])
            ->with('successMessages', new MessageBag([$successMessage]));
    }

    /**
     * Shows the specified widgetBackgrounds's edit page.
     *
     * @param WidgetBackground $widgetBackground The widgetBackground.
     *
     * @return \Illuminate\View\View
     */
    public function edit(WidgetBackground $widgetBackground)
    {
        $data = [
            'widgetBackground' => $widgetBackground,
        ];

        return view('admin.widget-backgrounds.edit', $data);
    }

    /**
     * Updates the specified widgetBackground.
     *
     * @param UpdateRequest    $request          A widgetBackground update request.
     * @param WidgetBackground $widgetBackground The widgetBackground.
     *
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function update(UpdateRequest $request, WidgetBackground $widgetBackground)
    {
        $this->widgetBackgroundRepository->update($widgetBackground, $request->all());

        $successMessage = trans('admin/widgetBackgrounds.successMessages.edit');

        return Redirect::action(static::class.'@edit', ['widgetBackground' => $widgetBackground->id])
            ->with('successMessages', new MessageBag([$successMessage]));
    }

    /**
     * Displays the widget background deletion confirmation form.
     *
     * @param DeleteRequest    $request          The widget background delete request.
     * @param WidgetBackground $widgetBackground The widget background instance.
     *
     * @return \Illuminate\View\View
     */
    public function confirmDelete(DeleteRequest $request, WidgetBackground $widgetBackground)
    {
        $data = [
            'widgetBackground' => $widgetBackground,
        ];

        return view('admin.widget-backgrounds.delete', $data);
    }

    /**
     * Deletes a widget background.
     *
     * @param DeleteRequest    $request          The widget background delete request.
     * @param WidgetBackground $widgetBackground The widget background instance.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function delete(DeleteRequest $request, WidgetBackground $widgetBackground)
    {
        if ($request->get('action') !== 'confirm') {
            return Redirect::action(static::class.'@index');
        }

        $this->widgetBackgroundRepository->delete($widgetBackground);

        $successMessage = trans('admin/widgetBackgrounds.successMessages.delete');

        return Redirect::action(static::class.'@index')
            ->with('successMessages', new MessageBag([$successMessage]));
    }
}
