<?php

namespace App\WidgetBackgrounds\WidgetBackground;

use App\WidgetBackgrounds\WidgetBackground;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use DaveJamesMiller\Breadcrumbs\Generator as BreadcrumbGenerator;
use DaveJamesMiller\Breadcrumbs\Manager as BreadcrumbManager;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use URL;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerAdminRoutes($this->app['router']);
        $this->registerFrontApiRoutes($this->app['router']);
        $this->registerAdminBreadcrumbs($this->app['breadcrumbs']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers admin panel routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerAdminRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'admin/widget-backgrounds',
            'middleware' => ['web', 'auth', 'permissions'],
            'namespace' => 'App\WidgetBackgrounds\Http\Controllers\Admin\WidgetBackground',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('', 'Controller@index');

            $router->get('/create', 'Controller@create');
            $router->post('', 'Controller@store');

            $router->get('{widgetBackground}/edit', 'Controller@edit');
            $router->put('{widgetBackground}', 'Controller@update');

            $router->get('{widgetBackground}/delete', 'Controller@confirmDelete');
            $router->delete('{widgetBackground}', 'Controller@delete');
        });
    }

    /**
     * Registers front API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1/widget-backgrounds',
            'middleware' => ['api', 'auth'],
            'namespace' => 'App\WidgetBackgrounds\Http\Controllers\Api\V1\Front\WidgetBackground',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->post('', 'Controller@store');
            $router->delete('{widgetBackground}', 'Controller@delete');
        });
    }

    /**
     * Registers breadcrumbs for the admin panel.
     *
     * @param BreadcrumbManager $breadcrumbs A breadcrumb manager.
     *
     * @return void
     * @throws \DaveJamesMiller\Breadcrumbs\Exception
     */
    protected function registerAdminBreadcrumbs(BreadcrumbManager $breadcrumbs)
    {
        $breadcrumbs->register('admin::widgetBackgrounds', function (BreadcrumbGenerator $breadcrumbs) {
            $breadcrumbs->parent('admin::home');

            $url = URL::action('App\WidgetBackgrounds\Http\Controllers\Admin\WidgetBackground\Controller@index');

            $breadcrumbs->push(trans('admin/navigation.widgetBackgrounds'), $url);
        });

        $breadcrumbs->register('admin::widgetBackgrounds.edit', function (BreadcrumbGenerator $breadcrumbs, WidgetBackground $widgetBackground) {
            $breadcrumbs->parent('admin::widgetBackgrounds', $widgetBackground);

            $url = URL::action('App\WidgetBackgrounds\Http\Controllers\Admin\WidgetBackground\Controller@edit', ['widgetBackgound' => $widgetBackground->id]);

            $breadcrumbs->push(trans('admin/widgetBackgrounds.titles.edit'), $url);
        });

        $breadcrumbs->register('admin::widgetBackgrounds.create', function (BreadcrumbGenerator $breadcrumbs) {
            $breadcrumbs->parent('admin::widgetBackgrounds');

            $url = URL::action('App\WidgetBackgrounds\Http\Controllers\Admin\WidgetBackground\Controller@create');

            $breadcrumbs->push(trans('admin/suggestedLinks.titles.create'), $url);
        });

        $breadcrumbs->register('admin::widgetBackgrounds.delete', function (BreadcrumbGenerator $breadcrumbs, WidgetBackground $widgetBackground) {
            $breadcrumbs->parent('admin::widgetBackgrounds');

            $url = URL::action('App\WidgetBackgrounds\Http\Controllers\Admin\WidgetBackground\Controller@confirmDelete', ['widgetBackground' => $widgetBackground->id]);

            $breadcrumbs->push(trans('admin/widgetBackground.titles.delete'), $url);
        });
    }
}
