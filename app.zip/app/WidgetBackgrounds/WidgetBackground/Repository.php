<?php

namespace App\WidgetBackgrounds\WidgetBackground;

use App\WidgetBackgrounds\WidgetBackground;
use Hshn\Base64EncodedFile\HttpFoundation\File\Base64EncodedFile;
use Illuminate\Http\UploadedFile;

class Repository
{
    /**
     * A WidgetBackground model instance.
     *
     * @var WidgetBackground
     */
    protected $widgetBackgroundModel;

    /**
     * @param WidgetBackground $widgetBackground A widgetBackground model instance.
     */
    public function __construct(WidgetBackground $widgetBackground)
    {
        $this->widgetBackgroundModel = $widgetBackground;
    }

    /**
     * Gets all default widget backgrounds.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getDefaultWidgetBackgrounds()
    {
        return $this->getWidgetBackgroundsByWidgetId(null);
    }

    /**
     * Gets all widget backgrounds with widget id.
     *
     * @param int $widgetId Widget id
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getWidgetBackgroundsByWidgetId($widgetId)
    {
        return $this->widgetBackgroundModel
            ->where('widget_id', $widgetId)
            ->get();
    }

    /**
     * Updates the passed widget background and returns it.
     *
     * @param WidgetBackground $widgetBackground The widget background to update.
     * @param array            $inputData        The input data for the update.
     *
     * @return WidgetBackground
     * @throws \Exception
     */
    public function update(WidgetBackground $widgetBackground, array $inputData)
    {
        return $this->populateAndSave($widgetBackground, $inputData);
    }

    /**
     * Creates a widget background and returns it.
     *
     * @param array $inputData The input data for the update.
     *
     * @return WidgetBackground
     * @throws \Exception
     */
    public function create(array $inputData)
    {
        $widgetType = $this->widgetBackgroundModel->newInstance();

        return $this->populateAndSave($widgetType, $inputData);
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param WidgetBackground $widgetBackground The widget background to populate.
     * @param array  $inputData  The input data for the widget type.
     *
     * @return WidgetBackground
     * @throws \Exception
     */
    protected function populate(WidgetBackground $widgetBackground, array $inputData)
    {
        $widgetBackground->color = array_get($inputData, 'color', $widgetBackground->color);
        $widgetBackground->widget_id = array_get($inputData, 'widget_id', $widgetBackground->widget_id);
        $widgetBackground->default = isset($inputData['default']) ? 1 : 0;

        if ($widgetBackground->default) {
            $oldDefault = WidgetBackground::where('default', true)->first();

            if ($oldDefault && $oldDefault->id !== $widgetBackground->id) {
                $oldDefault->default = false;
                $oldDefault->update();
            }
        }

        if (isset($inputData['image_main'])) {
            if ($inputData['image_main'] instanceof UploadedFile) {
                $widgetBackground->uploadImage($inputData['image_main'], 'main');
            } else {
                $file = new Base64EncodedFile($inputData['image_main']);
                $widgetBackground->uploadImage($file->getPathname(), 'main');
            }
        }

        return $widgetBackground;
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param WidgetBackground $widgetBackground  The widgetBackground to populate and save.
     * @param array $inputData The input data.
     *
     * @return WidgetBackground
     * @throws \Exception
     */
    protected function populateAndSave(WidgetBackground $widgetBackground, array $inputData)
    {
        $widgetBackground = $this->populate($widgetBackground, $inputData);

        $widgetBackground->save();

        return $widgetBackground;
    }

    /**
     * Deletes a widget background.
     *
     * @param WidgetBackground $widgetBackground Widget background instance.
     *
     * @return void
     */
    public function delete(WidgetBackground $widgetBackground)
    {
        $widgetBackground->delete();
    }
}
