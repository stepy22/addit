<?php

namespace App\WidgetBackgrounds;

use Creitive\Database\Eloquent\Model;
use Creitive\Image\Transformers\CropThumbnail;
use Creitive\Models\Traits\ImageableTrait;
use URL;

class WidgetBackground extends Model
{
    use ImageableTrait;

    const DEFAULT_MAIN_IMAGE_ORIGINAL = 'images/default/WidgetBackground/main/original.png';
    const DEFAULT_MAIN_IMAGE_SMALL = 'images/default/WidgetBackground/main/small.png';

    /**
     * {@inheritDoc}
     */
    public $timestamps = false;

    /**
     * {@inheritDoc}
     */
    protected $table = 'widget_backgrounds';

    /**
     * {@inheritDoc}
     */
    protected $casts = [
        'default' => 'bool',
    ];

    /**
     * {@inheritDoc}
     */
    protected $visible = [
        'id',
        'color',
        'default',
        'url_image_main_small',
        'url_image_main_original',
        'widget_id',
    ];

    /**
     * {@inheritDoc}
     */
    protected $appends = [
        'url_image_main_small',
        'url_image_main_original',
    ];

    /**
     * {@inheritDoc}
     */
    public function getImageConfiguration()
    {
        return [
            'versions' => [
                'main' => [
                    'original' => [],
                    'small' => [
                        [
                            'transformer' => CropThumbnail::class,
                            'width' => 50,
                            'height' => 50,
                        ],
                    ],
                ],
            ],
        ];
    }

    /**
     * Gets the complete URL to the original main image.
     *
     * @return string
     */
    public function getUrlImageMainOriginalAttribute()
    {
        if ($this->default && ($this->image_main_original === self::DEFAULT_MAIN_IMAGE_ORIGINAL)) {
            return url('/' . $this->image_main_original);
        }

        return $this->image_main_original ? URL::to($this->getImage('main', 'original')) : '';
    }

    /**
     * Gets the complete URL to the small main image.
     *
     * @return string
     */
    public function getUrlImageMainSmallAttribute()
    {
        if ($this->default && ($this->image_main_original === self::DEFAULT_MAIN_IMAGE_ORIGINAL)) {
            return url('/' . $this->image_main_small);
        }

        return $this->image_main_small ? URL::to($this->getImage('main', 'small')) : null;
    }

    /**
     * Gets the css background string.
     *
     * @return string
     */
    public function getBackgroundStrAttribute()
    {
        $str = '';
        if ($this->color) {
            $str .= $this->color . ' ';
        }

        if ($this->image_main_original) {
            $str .= 'url("' .  url('/' . $this->image_main_original) . '")';
        }

        return $str;
    }
}
