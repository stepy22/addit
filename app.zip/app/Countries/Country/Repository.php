<?php

namespace App\Countries\Country;

use App\Countries\Country;

class Repository
{
    /**
     * A Country model instance.
     *
     * @var Country
     */
    protected $countryModel;

    /**
     * @param Country $country A country model instance.
     */
    public function __construct(Country $country)
    {
        $this->countryModel = $country;
    }

    /**
     * Gets all countries.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAll()
    {
        return $this->countryModel->get();
    }

    /**
     * Gets all countries as select options.
     *
     * @return array
     */
    public function getSelectOptions()
    {
        return $this->countryModel
            ->orderBy('name')
            ->get()
            ->pluck('name', 'id')
            ->toArray();
    }

    /**
     * Finds the country by ID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $id The country ID.
     *
     * @return Country|null
     */
    public function find($id)
    {
        return $this->countryModel->find($id);
    }

    /**
     * Finds the country by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The country ID.
     *
     * @return Country
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->countryModel->findOrFail($id);
    }

    /**
     * Creates a new country and returns it.
     *
     * @param array $inputData The country input data.
     *
     * @return Country
     */
    public function create(array $inputData)
    {
        return $this->populateAndSave($this->countryModel->newInstance(), $inputData);
    }

    /**
     * Updates the passed country and returns it.
     *
     * @param Country $country   The country to update.
     * @param array   $inputData The input data for the update.
     *
     * @return Country
     */
    public function update(Country $country, array $inputData)
    {
        return $this->populateAndSave($country, $inputData);
    }

    /**
     * Deletes the passed country from the system.
     *
     * @param Country $country The country to delete.
     *
     * @return bool|null
     */
    public function delete(Country $country)
    {
        return $country->delete();
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param Country $country   The country to populate.
     * @param array   $inputData The input data for the country.
     *
     * @return Country
     */
    protected function populate(Country $country, array $inputData)
    {
        $country->title = array_get($inputData, 'title');
        $country->code = array_get($inputData, 'code');

        return $country;
    }

    /**
     * Sorts countries in the passed order.
     *
     * @param array $inputData The new sort order.
     * @return bool
     */
    public function sort(array $inputData)
    {
        $newOrder = array_map(
            function ($item) {
                return (int) $item['id'];
            },
            $inputData['items']
        );

        return $this->countryModel->updateSortOrder($newOrder);
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param Country $country   The country to populate and save.
     * @param array   $inputData The input data.
     *
     * @return Country
     */
    protected function populateAndSave(Country $country, array $inputData)
    {
        $country = $this->populate($country, $inputData);

        $country->save();

        return $country;
    }
}
