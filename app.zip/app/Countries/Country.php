<?php

namespace App\Countries;

use Creitive\Database\Eloquent\Model;

class Country extends Model
{
    public $timestamps = false;
}
