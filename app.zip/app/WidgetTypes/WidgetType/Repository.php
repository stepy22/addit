<?php

namespace App\WidgetTypes\WidgetType;

use App\Auth\Subscription\Repository as SubscriptionRepository;
use App\Auth\User;
use App\WidgetTypes\WidgetType;
use Carbon\Carbon;
use Creitive\Commerce\PriceFormatter;
use Hshn\Base64EncodedFile\HttpFoundation\File\Base64EncodedFile;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\UploadedFile;
use stdClass;

class Repository
{
    /**
     * A WidgetType model instance.
     *
     * @var WidgetType
     */
    protected $widgetType;

    /**
     * @param WidgetType             $widgetType             A widgetType model instance.
     * @param PriceFormatter         $priceFormatter         The price formatter instance.
     * @param SubscriptionRepository $subscriptionRepository The subscription repository instance.
     */
    public function __construct(WidgetType $widgetType, PriceFormatter $priceFormatter, SubscriptionRepository $subscriptionRepository)
    {
        $this->widgetTypeModel = $widgetType;
        $this->priceFormatter = $priceFormatter;
        $this->subscriptionRepository = $subscriptionRepository;
    }

    /**
     * Gets all widget types.
     *
     * @param array     $inputData Input data array.
     * @param null|User $user      User instance.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAll(array $inputData = [], $user = null)
    {
        $query = $this->widgetTypeModel->select('*');

        if (isset($inputData['is_platinum'])) {
            $query->where(['is_platinum' => $inputData['is_platinum']]);
        }

        if (isset($inputData['dashboard_category_id'])) {
            $query->where(['dashboard_category_id' => $inputData['dashboard_category_id']]);
        }

        if (isset($inputData['user_widgets'])) {
            $query->whereHas('availableToUsers', function (Builder $query) use ($user) {
                return $query->where(['users.id' => $user->id]);
            });
        }

        return $query->get();
    }

    /**
     * Gets n most used widget types.
     *
     * @param int $limit Limit of records to take.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getMostUsed($limit = 10)
    {
        return $this->widgetTypeModel
            ->with('widgets.users')
            ->withCount('widgets')
            ->orderBy('widgets_count', 'desc')
            ->whereHas('widgets')
            ->whereIn('origin', [WidgetType::ORIGIN_CUSTOM, WidgetType::ORIGIN_BASED_ON_BASE])
            ->where('is_pro', false)
            ->where('is_platinum', false)
            ->take($limit)
            ->get();
    }

    /**
     * Gets n most used widget types.
     *
     * @param int $limit Limit of records to take.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getMostUsedPro($limit = 10)
    {
        return $this->widgetTypeModel
            ->with('widgets.users')
            ->withCount('widgets')
            ->orderBy('widgets_count', 'desc')
            ->whereHas('widgets')
            ->whereIn('origin', [WidgetType::ORIGIN_CUSTOM, WidgetType::ORIGIN_BASED_ON_BASE])
            ->where('is_pro', true)
            ->where('is_platinum', false)
            ->take($limit)
            ->get();
    }

    /**
     * Gets n most used widget types.
     *
     * @param int $limit Limit of records to take.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getMostUsedPlatinum($limit = 10)
    {
        return $this->widgetTypeModel
            ->with('widgets.users')
            ->withCount('widgets')
            ->orderBy('widgets_count', 'desc')
            ->whereHas('widgets')
            ->whereIn('origin', [WidgetType::ORIGIN_CUSTOM, WidgetType::ORIGIN_BASED_ON_BASE])
            ->where('is_platinum', true)
            ->where('is_pro', false)
            ->take($limit)
            ->get();
    }

    /**
     * Gets most shared widget types.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAllUsed()
    {
        return $this->widgetTypeModel
            ->with('widgets.users')
            ->whereHas('widgets')
            ->whereIn('origin', [WidgetType::ORIGIN_CUSTOM, WidgetType::ORIGIN_BASED_ON_BASE])
            ->get();
    }

    /**
     * Gets all widget types with origin Default.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getDefaultWidgetTypes()
    {
        return $this->getWidgetTypesByOrigin(WidgetType::ORIGIN_DEFAULT);
    }

    /**
     * Gets all widget types with passed origin.
     *
     * @param string $origin Origin string.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getWidgetTypesByOrigin($origin)
    {
        return $this->widgetTypeModel
            ->where('origin', $origin)
            ->get();
    }

    /**
     * Finds the widget type by ID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $id The widget type ID.
     *
     * @return WidgetType|null
     */
    public function find($id)
    {
        return $this->widgetTypeModel->find($id);
    }

    /**
     * Finds the widget type by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The widget type ID.
     *
     * @return WidgetType
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->widgetTypeModel->findOrFail($id);
    }

    /**
     * Updates the passed widget type and returns it.
     *
     * @param WidgetType $widgetType The widget type to update.
     * @param array      $inputData  The input data for the update.
     *
     * @return WidgetType
     */
    public function update(WidgetType $widgetType, array $inputData)
    {
        return $this->populateAndSave($widgetType, $inputData);
    }

    /**
     * Creates a widget type and returns it.
     *
     * @param array $inputData The input data for the update.
     *
     * @return WidgetType
     */
    public function create(array $inputData)
    {
        $widgetType = $this->widgetTypeModel->newInstance();

        return $this->populateAndSave($widgetType, $inputData);
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param WidgetType $widgetType The widget type to populate.
     * @param array      $inputData  The input data for the widget type.
     *
     * @return WidgetType
     */
    protected function populate(WidgetType $widgetType, array $inputData)
    {
        $widgetType->name = array_get($inputData, 'name', $widgetType->name);
        $widgetType->key = array_get($inputData, 'key', $widgetType->key);

        $widgetType->description = array_get($inputData, 'description');
        $widgetType->is_pro = (bool) array_get($inputData, 'is_pro', false);
        $widgetType->hidden = (bool) array_get($inputData, 'hidden', false);
        $isPlatinum = (bool) array_get($inputData, 'is_platinum', false);

        if ($widgetType->is_platinum && !$isPlatinum) {
            $this->subscriptionRepository->removeActiveWidgetTypeSubscription($widgetType->id);
            $widgetType->subscribedUsers()->detach();
        }

        $widgetType->is_platinum = $isPlatinum;
        $widgetType->dashboard_category_id = array_get($inputData, 'dashboard_category_id');
        $widgetType->origin = array_get($inputData, 'origin', $widgetType->origin);

        if (isset($inputData['price'])) {
            $widgetType->price = $this->priceFormatter->toDatabase($inputData['price']);
        }

        if (!$widgetType->is_platinum) {
            $widgetType->price = null;
        }

        if (isset($inputData['image_main'])) {
            if ($inputData['image_main'] instanceof UploadedFile) {
                $widgetType->uploadImage($inputData['image_main'], 'main');
            } else {
                $file = new Base64EncodedFile($inputData['image_main']);
                $widgetType->uploadImage($file->getPathname(), 'main');
            }
        }

        if (isset($inputData['dashboard_category_ids'])) {
            $widgetType->defaultForDashboardCategories()->sync($inputData['dashboard_category_ids']);
        }

        $widgetType->user_id = array_get($inputData, 'user_id', $widgetType->user_id);
        $widgetType->uses_galleries = array_get($inputData, 'uses_galleries', $widgetType->uses_galleries);
        $widgetType->uses_checklists = array_get($inputData, 'uses_checklists', $widgetType->uses_checklists);
        $widgetType->uses_links = array_get($inputData, 'uses_links', $widgetType->uses_links);
        $widgetType->uses_files = array_get($inputData, 'uses_files', $widgetType->uses_files);
        $widgetType->uses_events = array_get($inputData, 'uses_events', $widgetType->uses_events);
        $widgetType->uses_notes = array_get($inputData, 'uses_notes', $widgetType->uses_notes);
        $widgetType->uses_birthdays = array_get($inputData, 'uses_birthdays', $widgetType->uses_birthdays);
        $widgetType->uses_contacts = array_get($inputData, 'uses_contacts', $widgetType->uses_contacts);

        $widgetType->user_id = array_get($inputData, 'user_id', $widgetType->user_id);

        return $widgetType;
    }

    /**
     * Sorts widget types in the passed order.
     *
     * @param array $inputData The new sort order.
     *
     * @return bool
     */
    public function sort(array $inputData)
    {
        $newOrder = array_map(
            function ($item) {
                return (int) $item['id'];
            },
            $inputData['items']
        );

        return $this->widgetTypeModel->updateSortOrder($newOrder);
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param WidgetType $widgetType     The widgetType to populate and save.
     * @param array $inputData The input data.
     *
     * @return WidgetType
     */
    protected function populateAndSave(WidgetType $widgetType, array $inputData)
    {
        $widgetType = $this->populate($widgetType, $inputData);

        $widgetType->save();

        return $widgetType;
    }

    /**
     * Deletes a widget type.
     *
     * @param WidgetType $widgetType Widget type instance.
     *
     * @return void
     */
    public function delete(WidgetType $widgetType)
    {
        $widgetType->delete();
    }
}
