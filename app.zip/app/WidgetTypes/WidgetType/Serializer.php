<?php

namespace App\WidgetTypes\WidgetType;

use App\Auth\User;
use App\WidgetTypes\WidgetType;
use Creitive\Commerce\PriceFormatter;
use Illuminate\Support\Collection;

class Serializer
{
    /**
     * Price Formatter instance.
     *
     * @var PriceFormatter
     */
    protected $priceFormatter;

    /**
     * @param PriceFormatter $priceFormatter Price formatter instance.
     */
    public function __construct(PriceFormatter $priceFormatter)
    {
        $this->priceFormatter = $priceFormatter;
    }

    /**
     * Serializes a single widget type.
     *
     * @param WidgetType $widgetType Widget type instance.
     * @param User       $user       User instance.
     *
     * @return array
     */
    public function serializeSingle(WidgetType $widgetType, User $user)
    {
        $subscription = $user
                ->subscriptions
                ->where('widget_type_id', $widgetType->id)
                ->where('active', true)
                ->first();

        if ($subscription && $subscription->price !== $widgetType->price) {
            $newPrice = $widgetType->price;
        } else {
            $newPrice = null;
        }

        $unpaidSub = $user->unpaidWidgetTypeSubscription($widgetType->id);
        $unpaidSubPrice = $unpaidSub ? $this->priceFormatter->toString($unpaidSub->price) : null;

        return [
            'id' => $widgetType->id,
            'name' => $widgetType->name,
            'key' => $widgetType->key ?: WidgetType::DEFAULT_KEY,
            'description' => $widgetType->description,
            'is_pro' => $widgetType->is_pro,
            'price' => $widgetType->price,
            'formatted_price' => $this->priceFormatter->toString($widgetType->price),
            'is_platinum' => $widgetType->is_platinum,
            'origin' => $widgetType->origin,
            'url_image_main_original' => $widgetType->url_image_main_original,
            'url_image_main_thumbnail' => $widgetType->url_image_main_thumbnail,
            'url_image_main_large' => $widgetType->url_image_main_large,
            'url_image_main_small' => $widgetType->url_image_main_small,
            'can_use' => $user->canUseWidgetType($widgetType),
            'subscribed' => $user->isSubscribedToWidgetType($widgetType->id),
            'has_unpaid' => $unpaidSub !== null,
            'unpaid_subscription_price' => $unpaidSubPrice,
            'dashboardCategory' => $widgetType->dashboardCategory,
            'uses_galleries' => $widgetType->uses_galleries,
            'uses_checklists' => $widgetType->uses_checklists,
            'uses_links' => $widgetType->uses_links,
            'uses_files' => $widgetType->uses_files,
            'uses_events' => $widgetType->uses_events,
            'configuration' => $widgetType->configuration,
            'subscription_price' => $subscription ? $this->priceFormatter->toString($subscription->price) : null,
            'new_subscription_price' => $newPrice ? $this->priceFormatter->toString($newPrice) : null,
            'subscription_ends_at' => $subscription ? $subscription->ends_at->format(trans('subscriptions.dateFormat')) : null,
        ];
    }

    /**
     * Serializes a widget type collection.
     *
     * @param Collection $widgetTypes Widget type collection.
     * @param User       $user        User instance.
     *
     * @return array
     */
    public function serializeCollection(Collection $widgetTypes, User $user)
    {
        $data = [];

        foreach ($widgetTypes as $widgetType) {
            $data[] = $this->serializeSingle($widgetType, $user);
        }

        return $data;
    }
}
