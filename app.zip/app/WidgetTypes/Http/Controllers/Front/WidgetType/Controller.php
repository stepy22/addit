<?php

namespace App\WidgetTypes\Http\Controllers\Front\WidgetType;

use App\Auth\Exceptions\SubscriptionBillingFailed;
use App\Auth\Subscription\Manager as SubscriptionManager;
use App\Http\Controllers\Front\Controller as BaseController;
use App\WidgetTypes\WidgetType;
use App\WidgetTypes\WidgetType\Repository as WidgetTypeRepository;
use Cartalyst\Sentinel\Sentinel;
use Creitive\Commerce\PriceFormatter;
use Illuminate\Http\Request;
use Illuminate\Support\MessageBag;
use Redirect;

class Controller extends BaseController
{
    /**
     * Unsubscribes a user from a widget type.
     *
     * @param  WidgetType          $widgetType          Widget type instance.
     * @param  Sentinel            $sentinel            Sentinel instance.
     * @param  SubscriptionManager $subscriptionManager Subscription manager.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function unsubscribe(
        WidgetType $widgetType,
        Sentinel $sentinel,
        SubscriptionManager $subscriptionManager
    ) {
        $user = $sentinel->getUser();

        $subscribtion = $subscriptionManager->unsubscribeFromWidgetType($user, $widgetType);

        return Redirect::action('App\Auth\Http\Controllers\Front\Subscription\Controller@index')
            ->with('successMessages', new MessageBag([trans('subscriptions.successMessages.unsubscribedFromWidgetType')]));
    }

    /**
     * Subscribes a user to a widget type.
     *
     * @param  WidgetType          $widgetType          Widget type instance.
     * @param  Request             $request             Subscribe request instance.
     * @param  Sentinel            $sentinel            Sentinel instance.
     * @param  SubscriptionManager $subscriptionManager Subscription manager.
     * @param  PriceFormatter      $priceFormatter      [description]
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function subscribe(
        WidgetType $widgetType,
        Request $request,
        Sentinel $sentinel,
        SubscriptionManager $subscriptionManager,
        PriceFormatter $priceFormatter
    ) {
        $user = $sentinel->getUser();

        if ($widgetType->is_platinum === false) {
            return Redirect::action('App\Auth\Http\Controllers\Front\Subscription\Controller@index')
                ->with('errorMessages', new MessageBag([trans('widgetTypes.errorMessages.notPlatinum')]));
        }

        if ($user->isSubscribedToWidgetType($widgetType->id)) {
            return Redirect::action('App\Auth\Http\Controllers\Front\Subscription\Controller@index')
                ->with('errorMessages', new MessageBag([trans('widgetTypes.errorMessages.alreadySubscribed')]));
        }

        if ($user->stripe_customer_id === null) {
            return Redirect::action('App\Auth\Http\Controllers\Front\Subscription\Controller@index')
                ->with('errorMessages', new MessageBag([trans('widgetTypes.errorMessages.cardNotAdded')]));
        }

        try {
            $subscribtion = $subscriptionManager->subscribeToWidgetType($user, $widgetType);
        } catch (SubscriptionBillingFailed $exception) {
            $subscription = $exception->getSubscription();

            return Redirect::action('App\Auth\Http\Controllers\Front\Subscription\Controller@index')
                ->with('errorMessages', new MessageBag([trans('subscriptions.errorMessages.failedToChargeWidgetType', [
                    'price' => trans('commerce.currency.symbol') . $priceFormatter->toString($subscription->widgetType->price, 0),
                    'startDate' => $subscription->starts_at->setTimezone($user->timezone)->format(trans('subscriptions.dateFormat')),
                    'endDate' => $subscription->ends_at->setTimezone($user->timezone)->format(trans('subscriptions.dateFormat')),
                    'widget' => $subscription->widgetType->name,
                ]), ]));
        }

        return Redirect::action('App\Auth\Http\Controllers\Front\Subscription\Controller@index')
            ->with('successMessages', new MessageBag([trans('subscriptions.successMessages.subscribedToWidgetType')]));
    }
}
