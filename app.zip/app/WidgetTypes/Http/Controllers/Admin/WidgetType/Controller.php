<?php

namespace App\WidgetTypes\Http\Controllers\Admin\WidgetType;

use App\DashboardCategories\DashboardCategory\Repository as DashboardCategoryRepository;
use App\Http\Controllers\Admin\Controller as BaseController;
use App\WidgetTypes\Http\Requests\Admin\WidgetType\StoreRequest;
use App\WidgetTypes\Http\Requests\Admin\WidgetType\UpdateRequest;
use App\WidgetTypes\WidgetType;
use App\WidgetTypes\WidgetType\Repository as WidgetTypeRepository;
use Illuminate\Http\Request;
use Illuminate\Support\MessageBag;
use Redirect;

class Controller extends BaseController
{
    /**
     * A WidgetTypeRepository instance.
     *
     * @var WidgetTypeRepository
     */
    protected $widgetTypeRepository;

    /**
     * @param WidgetTypeRepository $widgetTypeRepository A widgetType repository instance.
     */
    public function __construct(WidgetTypeRepository $widgetTypeRepository)
    {
        parent::__construct();

        $this->widgetTypeRepository = $widgetTypeRepository;

        $this->viewData->bodyDataPage = 'admin-widget-types';
        $this->viewData->pageTitle->setPage(trans('admin/widgetTypes.module'));
        $this->viewData->navigation->get('admin.main')->setActive('widget-types');
    }

    /**
     * Shows all widgetTypes.
     *
     * @param Request $request The current request.
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $widgetTypes = $this->widgetTypeRepository
            ->getAll()
            ->where('origin', '!==', WidgetType::ORIGIN_USER_CUSTOM);

        $data = [
            'widgetTypes' => $widgetTypes,
        ];

        return view('admin.widget-types.index', $data);
    }

    /**
     * Shows the specified widgetType's edit page.
     *
     * @param WidgetType                  $widgetType                  The widgetType.
     * @param DashboardCategoryRepository $dashboardCategoryRepository The dashboard category repository instance.
     *
     * @return \Illuminate\View\View
     */
    public function edit(WidgetType $widgetType, DashboardCategoryRepository $dashboardCategoryRepository)
    {
        $data = [
            'widgetType' => $widgetType,
            'dashboardCategoryOptions' => $dashboardCategoryRepository->getSelectOptions(),
        ];

        return view('admin.widget-types.edit', $data);
    }

    /**
     * Updates the specified widgetType.
     *
     * @param UpdateRequest $request    A widgetType update request.
     * @param WidgetType    $widgetType The widgetType.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(UpdateRequest $request, WidgetType $widgetType)
    {
        if ($request->has('is_pro') && $request->has('is_platinum')) {
            return Redirect::action(static::class.'@edit', ['widgetType' => $widgetType->id])
                ->with('errorMessages', new MessageBag([trans('admin/widgetTypes.proAndPlatinumError')]));
        }

        $this->widgetTypeRepository->update($widgetType, $request->all());

        $successMessage = trans('admin/widgetTypes.successMessages.edit');

        return Redirect::action(static::class.'@edit', ['widgetType' => $widgetType->id])
            ->with('successMessages', new MessageBag([$successMessage]));
    }
}
