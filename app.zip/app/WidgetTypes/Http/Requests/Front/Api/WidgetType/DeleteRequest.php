<?php

namespace App\WidgetTypes\Http\Requests\Front\Api\WidgetType;

use App\Http\Requests\Request;
use App\WidgetTypes\WidgetType;
use Cartalyst\Sentinel\Sentinel;

class DeleteRequest extends Request
{
    /**
     * Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * @param Sentinel $sentinel Sentinel instance.
     */
    public function __construct(Sentinel $sentinel)
    {
        $this->sentinel = $sentinel;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $user = $this->sentinel->getUser();
        $widgetType = $this->route('widgetType');

        if ($widgetType->origin !== WidgetType::ORIGIN_USER_CUSTOM) {
            return false;
        }

        if ($widgetType->user_id !== $user->id) {
            return false;
        }

        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [];
    }
}
