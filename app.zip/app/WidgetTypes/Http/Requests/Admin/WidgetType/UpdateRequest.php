<?php

namespace App\WidgetTypes\Http\Requests\Admin\WidgetType;

use App\Http\Requests\Request;

class UpdateRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'dashboard_category_id' => ['required', 'exists:dashboard_categories,id'],
            'dashboard_category_ids' => ['array', 'exists:dashboard_categories,id'],
            'price' => ['required_with:is_platinum', 'price', 'min_price:50'],
            'image_main' => ['image', 'max:10240'],
        ];

        return $rules;
    }

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array
     */
    public function messages()
    {
        return array_dot(trans('admin/widgetTypes.errorMessages'));
    }
}
