<?php

namespace App\WidgetTypes;

use App\Auth\User;
use App\DashboardCategories\DashboardCategory;
use App\Widgets\Widget;
use Creitive\Database\Eloquent\Model;
use Creitive\Image\Transformers\CropThumbnail;
use Creitive\Models\Traits\CalcFoundRowableTrait;
use Creitive\Models\Traits\ImageableTrait;
use Creitive\Models\Traits\SortableTrait;
use URL;

class WidgetType extends Model
{
    use CalcFoundRowableTrait;
    use ImageableTrait;
    use SortableTrait;

    const ORIGIN_BASED_ON_BASE = 'basedOnBase';
    const ORIGIN_CUSTOM = 'custom';
    const ORIGIN_DEFAULT = 'default';
    const ORIGIN_USER_CUSTOM = 'userCustom';

    /**
     * Resources constants.
     */
    public const RESOURCE_FILES = 'files';
    public const RESOURCE_LINKS = 'links';
    public const RESOURCE_EVENTS = 'events';
    public const RESOURCE_CHECKLISTS = 'checklists';
    public const RESOURCE_GALLERIES = 'galleries';
    public const RESOURCE_NOTES = 'notes';
    public const RESOURCE_BIRTHDAYS = 'birthdays';
    public const RESOURCE_CONTACTS = 'contacts';

    /**
     * We were forced to add this, by mobile devs. They "had a problem parsing
     * null for a widget type key" and key is null for user created widget
     * types, so they need some default value for that field.
     */
    public const DEFAULT_KEY = 'user_custom';

    /**
     * {@inheritDoc}
     */
    protected $casts = [
        'is_pro' => 'bool',
        'is_platinum' => 'bool',
        'uses_galleries' => 'bool',
        'uses_checklists' => 'bool',
        'uses_links' => 'bool',
        'uses_files' => 'bool',
        'uses_events' => 'bool',
        'uses_notes' => 'bool',
        'uses_birthdays' => 'bool',
        'uses_contacts' => 'bool',
        'hidden' => 'bool',
    ];

    /**
     * {@inheritDoc}
     */
    protected $visible = [
        'id',
        'name',
        'key',
        'origin',
        'description',
        'dashboardCategory',
        'is_pro',
        'is_platinum',
        'price',
        'url_image_main_original',
        'url_image_main_thumbnail',
        'url_image_main_large',
        'url_image_main_small',
        'uses_galleries',
        'uses_checklists',
        'uses_links',
        'uses_files',
        'uses_events',
        'uses_notes',
        'uses_birthdays',
        'uses_contacts',
        'configuration',
        'hidden',
    ];

    /**
     * {@inheritDoc}
     */
    protected $appends = [
        'url_image_main_original',
        'url_image_main_thumbnail',
        'url_image_main_large',
        'url_image_main_small',
        'configuration',
    ];

    /**
     * {@inheritDoc}
     */
    public function getImageConfiguration()
    {
        return [
            'versions' => [
                'main' => [
                    'original' => [],
                    'thumbnail' => [
                        [
                            'transformer' => CropThumbnail::class,
                            'width' => 448,
                            'height' => 299,
                        ],
                    ],
                    'large' => [
                        [
                            'transformer' => CropThumbnail::class,
                            'width' => 620,
                            'height' => 260,
                        ],
                    ],
                    'small' => [
                        [
                            'transformer' => CropThumbnail::class,
                            'width' => 175,
                            'height' => 116,
                        ],
                    ],
                ],
            ],
        ];
    }

    /**
     * Gets the complete URL to the original main image.
     *
     * @return string
     */
    public function getUrlImageMainOriginalAttribute()
    {
        return URL::to($this->getImage('main', 'original'));
    }

    /**
     * Gets the complete URL to the thumbnail main image.
     *
     * @return string
     */
    public function getUrlImageMainThumbnailAttribute()
    {
        return URL::to($this->getImage('main', 'thumbnail'));
    }

    /**
     * Gets the complete URL to the large main image.
     *
     * @return string
     */
    public function getUrlImageMainLargeAttribute()
    {
        return URL::to($this->getImage('main', 'large'));
    }

    /**
     * Gets the complete URL to the small main image.
     *
     * @return string
     */
    public function getUrlImageMainSmallAttribute()
    {
        return URL::to($this->getImage('main', 'small'));
    }

    /**
     * Dashboard category widget type belongs to.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function dashboardCategory()
    {
        return $this->belongsTo(DashboardCategory::class);
    }

    /**
     * Eloquent relationship: widget type can be bought by many users.
     *
     * @return BelongsToMany
     */
    public function availableToUsers()
    {
        return $this->belongsToMany(User::class, 'subscriptions')
            ->where(['active' => true]);
    }

    /**
     * Eloquent relationship: widget type can be set as default for many
     * dashboard categories.
     *
     * @return BelongsToMany
     */
    public function defaultForDashboardCategories()
    {
        return $this->belongsToMany(DashboardCategory::class, 'widget_type_dashboard_categories');
    }

    /**
     * Eloquent relationship: Widget type may have may widgets.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function widgets()
    {
        return $this->hasMany(Widget::class);
    }

    /**
     * Gets configuration option.
     *
     * @return array
     */
    public function getConfigurationAttribute()
    {
        $widgetTypesConfig = array_filter(config('widgetTypes'), function ($item) {
            return $item['key'] === $this->key;
        });

        $widgetTypeConfig = array_first($widgetTypesConfig);

        return array_get($widgetTypeConfig, 'manipulationSettings', null);
    }

    /**
     * Checks if a widget type has resource.
     *
     * @param string $resource Resource.
     *
     * @return boolean
     */
    public function hasResource($resource)
    {
        if ($this->origin === WidgetType::ORIGIN_BASED_ON_BASE) {
            if (isset($this->configuration[$resource]) &&
                $this->configuration[$resource]['has_block']
            ) {
                return true;
            }

            return false;
        }

        if ($this->origin === WidgetType::ORIGIN_USER_CUSTOM) {
            $fieldName = "uses_{$resource}";

            return $this->$fieldName;
        }

        return false;
    }

    /**
     * Eloquent relationship: Widget type may have multiple subscribed users.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function subscribedUsers()
    {
        return $this->belongsToMany(WidgetType::class, 'user_widget_types');
    }
}
