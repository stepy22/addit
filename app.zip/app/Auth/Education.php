<?php

namespace App\Auth;

use Creitive\Database\Eloquent\Model;

class Education extends Model
{
    /**
     * {@inheritDoc}
     */
    protected $table = 'user_educations';

    /**
     * {@inheritDoc}
     */
    protected $visible = [
        'key',
    ];
}
