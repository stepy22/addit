<?php

namespace App\Auth\Exceptions;

use App\Auth\Subscription;
use Exception;
use RuntimeException;

class SubscriptionBillingFailed extends RuntimeException
{
    /**
     * Subscription.
     *
     * @var Subscription
     */
    private $subscription;

    /**
     * @param Subscription   $subscription Subscription instance.
     * @param Exception|null $previous     Previous exception.
     * @param integer        $code         Error code.
     */
    public function __construct(Subscription $subscription, Exception $previous = null, $code = 0)
    {
        parent::__construct('Failed to charge a user for a subscription. User ID: ' . $subscription->user_id . ', subscription ID: ' . $subscription->id, $code, $previous);

        $this->subscription = $subscription;
    }

    /**
     * Gets subscription.
     *
     * @return Subscription
     */
    public function getSubscription()
    {
        return $this->subscription;
    }
}
