<?php

namespace App\Auth\Token;

use App\Auth\User;
use App\Auth\User\Repository as UserRepository;
use Cartalyst\Sentinel\Sentinel;
use Creitive\Managers\AbstractBaseManager;
use Log;
use Psr\Log\LoggerInterface;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

class Manager extends AbstractBaseManager
{
    /**
     * A logger implementation.
     *
     * @var LoggerInterface
     */
    protected $log;

    /**
     * A UserRepository instance.
     *
     * @var UserRepository
     */
    protected $userRepository;

    /**
     * A Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * @param LoggerInterface $log            A logger implementation.
     * @param UserRepository  $userRepository A user repository instance.
     * @param Sentinel        $sentinel       A Sentinel instance.
     */
    public function __construct(LoggerInterface $log, UserRepository $userRepository, Sentinel $sentinel)
    {
        parent::__construct();

        $this->log = $log;
        $this->userRepository = $userRepository;
        $this->sentinel = $sentinel;
    }

    /**
     * Gets auth token for the passed user credentials.
     *
     * Logs incorrect login attempts (without logging the attempted password).
     *
     * @param array $inputData Input data.
     *
     * @return bool
     *
     * @throws AccessDeniedHttpException
     */
    public function getTokenByInput(array $inputData)
    {
        $user = null;

        $user = $this->checkWithSentinel($inputData);

        if ($user instanceof User) {
            $this->userRepository->touch($user);

            $this->log->info('User successfully authenticated', ['email' => $user->email]);

            return $user->auth_token;
        } else {
            if (isset($inputData['password'])) {
                unset($inputData['password']);
            }

            $this->log->info('User unsuccessfully authenticated', ['inputData' => $inputData]);

            throw new AccessDeniedHttpException();
        }
    }

    /**
     * Checks user credentials with sentinel library
     *
     * @param array $inputData Input data to check.
     *
     * @return User|bool
     */
    protected function checkWithSentinel(array $inputData)
    {
        return $this->sentinel->authenticate([
            'email' => $inputData['email'],
            'password' => $inputData['password'],
        ]);
    }
}
