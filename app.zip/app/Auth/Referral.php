<?php

namespace App\Auth;

use Creitive\Database\Eloquent\Model;

class Referral extends Model
{
    /**
     * {@inheritDoc}
     */
    protected $table = 'referrals';
}
