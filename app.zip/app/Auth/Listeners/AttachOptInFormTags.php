<?php

namespace App\Auth\Listeners;

use App\Auth\Events\OptInFormPopulated;
use App\Auth\User\TagsAttachingService;

class AttachOptInFormTags
{
    /**
     * TagsAttachingService instance.
     *
     * @var TagsAttachingService
     */
    protected $tagsAttachingService;

    /**
     * @param TagsAttachingService $tagsAttachingService TagsAttachingService instance.
     */
    public function __construct(TagsAttachingService $tagsAttachingService)
    {
        $this->tagsAttachingService = $tagsAttachingService;
    }

    /**
     * Handle the event.
     *
     * @param OptInFormPopulated $event Event instance.
     *
     * @return void
     */
    public function handle(OptInFormPopulated $event)
    {
        $this->tagsAttachingService->attachProfileTags($event->user);
    }
}
