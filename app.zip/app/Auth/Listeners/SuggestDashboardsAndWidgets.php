<?php

namespace App\Auth\Listeners;

use App\Auth\Events\ProfileCompleted;
use App\Dashboards\Dashboard\Manager as DashboardManager;
use App\Widgets\Link\Manager as LinkManager;
use App\Widgets\Widget\Manager as WidgetManager;

class SuggestDashboardsAndWidgets
{
    /**
     * DashboardManager instance.
     *
     * @var DashboardManager
     */
    protected $dashboardManager;

    /**
     * Widget manager instance.
     *
     * @var WidgetManager
     */
    protected $widgetManager;

    /**
     * Link manager instance.
     *
     * @var LinkManager
     */
    protected $linkManager;

    /**
     * @param DashboardManager $dashboardManager Dashboard manager instance.
     * @param WidgetManager    $widgetManager    Widget manager instance.
     * @param LinkManager      $linkManager      Link manager instance.
     */
    public function __construct(
        DashboardManager $dashboardManager,
        WidgetManager $widgetManager,
        LinkManager $linkManager
    ) {
        $this->dashboardManager = $dashboardManager;
        $this->widgetManager = $widgetManager;
        $this->linkManager = $linkManager;
    }

    /**
     * Handle the event.
     *
     * @param ProfileCompleted $event Event instance.
     *
     * @return void
     */
    public function handle(ProfileCompleted $event)
    {
        $this->dashboardManager->suggestDashboards($event->user);
        $this->widgetManager->suggestWidgets($event->user);
        $this->linkManager->suggestLinks($event->user);
        $this->widgetManager->connectInvitations($event->user);
        $this->dashboardManager->connectInvitations($event->user);
    }
}
