<?php

namespace App\Auth\Listeners;

use App\Auth\Events\ProfileCompleted;
use App\Auth\User\Repository as UserRepository;

class MarkProfileAsCompleted
{
    /**
     * UserRepository instance.
     *
     * @var UserRepository
     */
    protected $userRepository;

    /**
     * @param UserRepository $userRepository UserRepository instance.
     */
    public function __construct(UserRepository $userRepository)
    {
        $this->userRepository = $userRepository;
    }

    /**
     * Handle the event.
     *
     * @param ProfileCompleted $event Event instance.
     *
     * @return void
     */
    public function handle(ProfileCompleted $event)
    {
        $this->userRepository->markProfileCompleted($event->user);
    }
}
