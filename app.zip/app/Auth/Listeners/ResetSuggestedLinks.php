<?php

namespace App\Auth\Listeners;

use App\Auth\Events\AnswersEdited;
use App\Auth\Events\FacebookGroupsInterestTagsAttached;
use App\Widgets\Link\Manager as LinkManager;

class ResetSuggestedLinks
{
    /**
     * Link manager instance.
     *
     * @var LinkManager
     */
    protected $linkManager;

    /**
     * @param LinkManager $linkManager Link manager instance.
     */
    public function __construct(LinkManager $linkManager)
    {
        $this->linkManager = $linkManager;
    }

    /**
     * Handle the event.
     *
     * @param AnswersEdited|FacebookGroupsInterestTagsAttached $event Event instance.
     *
     * @return void
     */
    public function handle($event)
    {
        $this->linkManager->removeSuggestedLinks($event->user);
        $this->linkManager->suggestLinks($event->user);
    }
}
