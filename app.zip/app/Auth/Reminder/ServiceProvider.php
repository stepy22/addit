<?php

namespace App\Auth\Reminder;

use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->app->alias('sentinel.reminders', 'Cartalyst\Sentinel\Reminders\IlluminateReminderRepository');
        $this->registerApiRoutes($this->app['router']);
        $this->registerFrontRoutes($this->app['router']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1/reminder',
            'middleware' => ['api'],
            'namespace' => 'App\Auth\Http\Controllers\Api\V1\Reminder',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->post('', 'Controller@store');
        });
    }

    /**
     * Registers front routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'password-reset',
            'middleware' => ['web'],
            'namespace' => 'App\Auth\Http\Controllers\Front\Reminder',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('{reminderToken}', 'Controller@index');
            $router->post('', 'Controller@store');
        });
    }
}
