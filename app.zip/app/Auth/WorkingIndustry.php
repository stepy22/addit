<?php

namespace App\Auth;

use Creitive\Database\Eloquent\Model;

class WorkingIndustry extends Model
{
    /**
     * {@inheritDoc}
     */
    protected $table = 'user_working_industries';

    /**
     * {@inheritDoc}
     */
    protected $visible = [
        'key',
    ];
}
