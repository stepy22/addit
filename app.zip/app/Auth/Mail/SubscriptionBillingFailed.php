<?php

namespace App\Auth\Mail;

use App\Auth\Subscription;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class SubscriptionBillingFailed extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * The Subscription instance.
     *
     * @var Subscription
     */
    public $subscription;

    /**
     * @param Subscription $subscription Subscription instance.
     */
    public function __construct(Subscription $subscription)
    {
        $this->subscription = $subscription;
    }

    /**
     * {@inheritDoc}
     */
    public function build()
    {
        if ($this->subscription->widget_type_id === null) {
            $subject = trans('emails/auth/subscriptionBillingFailed.subject', ['duration' => $this->subscription->duration]);
        } else {
            $subject = trans('emails/auth/subscriptionBillingFailed.subjectWidgetType', ['widget' => $this->subscription->widgetType->name]);
        }

        return $this->view('emails.auth.subscription-billing-failed')
            ->subject($subject)
            ->to($this->subscription->user->email, $this->subscription->user->full_name);
    }
}
