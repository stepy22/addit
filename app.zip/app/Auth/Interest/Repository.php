<?php

namespace App\Auth\Interest;

use App\Auth\Interest;
use App\Auth\User;
use Cartalyst\Support\Collection;

class Repository
{
    /**
     * A Interest model instance.
     *
     * @var Interest
     */
    protected $interestModel;

    /**
     * @param Interest $interestModel A user model instance.
     */
    public function __construct(Interest $interestModel)
    {
        $this->interestModel = $interestModel;
    }

    /**
     * Attach new and detach existing interests from user.
     *
     * @param User  $user      User instance.
     * @param array $inputData Input data array.
     *
     * @return Collection
     */
    public function syncInterests(User $user, array $inputData)
    {
        $interestsForDeletion = [];
        $interestsForCreation = [];
        $existingInterests = [];

        $submitedInterests = array_map(function ($item) {
            return $item['key'];
        }, $inputData);

        foreach ($user->interests as $userInterest) {
            if (!in_array($userInterest->key, $submitedInterests)) {
                $interestsForDeletion[] = $userInterest->key;
            } else {
                $existingInterests[] = $userInterest->key;
            }
        }

        $interestsForCreation = array_diff($submitedInterests, $interestsForDeletion);
        $interestsForCreation = array_diff($submitedInterests, $existingInterests);

        $this->interestModel
            ->where('user_id', $user->id)
            ->whereIn('key', $interestsForDeletion)
            ->delete();

        $createdInterests = collect();

        foreach ($interestsForCreation as $interestForCreation) {
            $interest = $this->interestModel->newInstance();

            $interest->user_id = $user->id;
            $interest->key = $interestForCreation;

            $interest->save();

            $createdInterests->push($interest);
        }

        return $createdInterests;
    }
}
