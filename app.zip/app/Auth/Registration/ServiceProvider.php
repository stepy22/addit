<?php

namespace App\Auth\Registration;

use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerFrontRoutes($this->app['router']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers front routes.
     *
     * @param RegistrarContract $router RegistrarContract instance.
     *
     * @return void
     */
    protected function registerFrontRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => trans('routes.registration.index'),
            'middleware' => ['web', 'guest.front'],
            'namespace' => 'App\Auth\Http\Controllers\Front\Registration',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('', 'Controller@index');
            $router->post('', 'Controller@store');
        });
    }
}
