<?php

namespace App\Auth;

use App\Auth\Education;
use App\Auth\Subscription;
use App\Auth\User\Collection;
use App\Auth\WorkingIndustry;
use App\Countries\Country;
use App\Dashboards\Dashboard;
use App\Dashboards\UserDashboard;
use App\InterestTags\InterestTag;
use App\Notifications\Notification;
use App\Transactions\Transaction;
use App\Widgets\UserWidget;
use App\Widgets\Widget;
use App\WidgetTypes\WidgetType;
use Cartalyst\Sentinel\Users\EloquentUser;
use Creitive\Image\Transformers\CropThumbnail;
use Creitive\Models\Traits\CalcFoundRowableTrait;
use Creitive\Models\Traits\ImageableTrait;
use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use URL;

class User extends EloquentUser
{
    use Authenticatable;
    use CalcFoundRowableTrait;
    use ImageableTrait;

    /**
     * Account plans.
     */
    const ACCOUNT_PLAN_REGULAR = 'regular';
    const ACCOUNT_PLAN_PRO = 'pro';

    /**
     * {@inheritDoc}
     */
    protected $hidden = [
        'auth_token_updated_at',
        'auth_token',
        'password',
        'created_at',
        'updated_at',
        'permissions',
        'facebook_id',
        'last_login',
        'google_id',
        'notifications_status',
        'seen_notifications',
        'referrer',
        'image_main_original',
        'image_main_thumbnail',
        'image_main_large',
        'image_main_small',
    ];

    /**
     * {@inheritDoc}
     */
    protected $appends = [
        'full_name',
        'url_image_main_thumbnail',
        'url_image_main_large',
        'url_image_main_small',
        'regular_referrals_available',
        'pro_referrals_available',
    ];

    /**
     * {@inheritDoc}
     */
    protected $fillable = [
        'email',
        'password',
        'last_name',
        'first_name',
        'permissions',
        'notifications_status',
        'referrer',
        'account_plan',
        'timezone',
    ];

    /**
     * {@inheritDoc}
     */
    protected $casts = [
        'profile_completed' => 'bool',
        'subscribed_to_pro' => 'bool',
    ];

    /**
     * {@inheritDoc}
     */
    public function getImageConfiguration()
    {
        return [
            'versions' => [
                'main' => [
                    'original' => [],
                    'thumbnail' => [
                        [
                            'transformer' => CropThumbnail::class,
                            'width' => 112,
                            'height' => 112,
                        ],
                    ],
                    'large' => [
                        [
                            'transformer' => CropThumbnail::class,
                            'width' => 256,
                            'height' => 256,
                        ],
                    ],
                    'small' => [
                        [
                            'transformer' => CropThumbnail::class,
                            'width' => 36,
                            'height' => 36,
                        ],
                    ],
                ],
            ],
        ];
    }

    /**
     * The maximum auth token age, in seconds.
     *
     * @var int
     */
    protected $maxAge = 0;

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = [
        'auth_token_updated_at',
    ];

    /**
     * Returns a new User collection.
     *
     * @param array $models The instances to include in the collection.
     *
     * @return Collection
     */
    public function newCollection(array $models = [])
    {
        return new Collection($models);
    }

    /**
     * Limits the query to users that don't have roles attached.
     *
     * @param Builder $query The query builder instance.
     *
     * @return Builder
     */
    public function scopeWithoutRoles(Builder $query)
    {
        return $query->has('roles', '=', 0);
    }

    /**
     * Limits the query to users who have never logged-in.
     *
     * @param Builder $query The query builder instance.
     *
     * @return Builder
     */
    public function scopeNeverLoggedIn(Builder $query)
    {
        return $query->whereNull('last_login');
    }

    /**
     * Limits the query to users who have logged-in at least once.
     *
     * @param Builder $query The query builder instance.
     *
     * @return Builder
     */
    public function scopeLoggedInAtLeastOnce(Builder $query)
    {
        return $query->whereNotNull('last_login');
    }

    /**
     * Gets the user's full name.
     *
     * If neither the first nor last name are defined, the user's email address
     * will be returned.
     *
     * @return string
     */
    public function getFullNameAttribute()
    {
        $fullName = trim("{$this->first_name} {$this->last_name}");

        return $fullName ?: $this->email;
    }

    /**
     * Gets the user's first (and only) role.
     *
     * The Sentinel package (which we use for handling users) supports multiple
     * roles per user, but our system just needs one (which is handled at the
     * application level), so we'll return it here.
     *
     * @return EloquentRole
     */
    public function getRoleAttribute()
    {
        return $this->roles()->first();
    }

    /**
     * Checks whether the user's auth token has expired.
     *
     * @return bool
     */
    public function isAuthTokenExpired()
    {
        if ($this->auth_token_updated_at === null) {
            return true;
        }

        if ($this->maxAge === 0) {
            return false;
        }

        $expiresAt = $this->auth_token_updated_at->copy()->addSeconds($this->maxAge);

        return $expiresAt->isPast();
    }

    /**
     * Checks whether the user has never logged in.
     *
     * @return bool
     */
    public function hasNeverLoggedIn()
    {
        return $this->last_login === null;
    }

    /**
     * Checks whether the user has logged in at least once.
     *
     * @return bool
     */
    public function hasLoggedInAtLeastOnce()
    {
        return !$this->hasNeverLoggedIn();
    }

    /**
     * Eloquent relationship: user may have many interest tags.
     *
     * @return BelongsToMany
     */
    public function interestTags()
    {
        return $this->belongsToMany(InterestTag::class, 'user_interest_tags')
            ->withPivot(['source_facebook']);
    }

    /**
     * Eloquent relationship: user may have many user dashboards.
     *
     * This is unconventional relation to pivot table, we need this to take
     * advantage of our image upload system and other stuff that is specific to
     * our CMS and it's not supported on laravel pivots by default (image
     * uploading, sorting...).
     *
     * @return HasMany
     */
    public function userDashboards()
    {
        return $this->hasMany(UserDashboard::class);
    }

    /**
     * Eloquent relationship: user may have many user widgets.
     *
     * This is unconventional relation to pivot table, we need this to take
     * advantage of our image upload system and other stuff that is specific to
     * our CMS and it's not supported on laravel pivots by default (image
     * uploading, sorting...).
     *
     * @return HasMany
     */
    public function userWidgets()
    {
        return $this->hasMany(UserWidget::class);
    }

    /**
     * Eloquent relationship: user may have many dashboards.
     *
     * @return BelongsToMany
     */
    public function dashboards()
    {
        return $this->belongsToMany(Dashboard::class, 'user_dashboards')
            ->withPivot([
                'id',
                'can_edit',
                'is_owner',
                'theme',
                'sort',
            ]);
    }

    /**
     * Eloquent relationship: user many have many widgets.
     *
     * @return BelongsToMany
     */
    public function widgets()
    {
        return $this->belongsToMany(Widget::class, 'user_widgets')
            ->withPivot([
                'id',
                'dashboard_id',
                'can_edit',
                'is_owner',
                'sort',
                'archived_at',
            ]);
    }

    /**
     * Eloquent relationship: user many have many favourite widgets.
     *
     * @return BelongsToMany
     */
    public function favouriteWidgets()
    {
        return $this->belongsToMany(Widget::class, 'favourite_widgets');
    }

    /**
     * Eloquent relationship: user educations.
     *
     * @return HasMany
     */
    public function educations()
    {
        return $this->hasMany(Education::class);
    }

    /**
     * Eloquent relationship: user interests.
     *
     * @return HasMany
     */
    public function interests()
    {
        return $this->hasMany(Interest::class);
    }

    /**
     * Eloquent relationship: user work industry.
     *
     * @return HasMany
     */
    public function workingIndustries()
    {
        return $this->hasMany(WorkingIndustry::class);
    }

    /**
     * Eloquent relationship: user belongs to a country.
     *
     * @return BelongsTo
     */
    public function country()
    {
        return $this->belongsTo(Country::class);
    }

    /**
     * Eloquent relationship: user may have many referrals.
     *
     * @return BelongsToMany
     */
    public function referrals()
    {
        return $this->belongsToMany(User::class, 'referrals', 'referrer_id', 'referred_id')
            ->withPivot('claimed');
    }

    /**
     * Eloquent relationship: user can have referrer.
     *
     * @return BelongsToMany
     */
    public function referrer()
    {
        return $this->belongsTo(User::class, 'referrer_id');
    }

    /**
     * Eloquent relationship: user may have many subscriptions.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function subscriptions()
    {
        return $this->hasMany(Subscription::class);
    }

    /**
     * Eloquent relationship: user may have many notifications.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function notifications()
    {
        return $this->hasMany(Notification::class);
    }

    /**
     * Eloquent relationship: user may have many transactions.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function transactions()
    {
        return $this->hasMany(Transaction::class);
    }

    /**
     * User may be subscribed to multiple widget types.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function subscribedWidgetTypes()
    {
        return $this->belongsToMany(WidgetType::class, 'user_widget_types');
    }

    /**
     * Widget types that user has bought and can use.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function activeWidgetTypes()
    {
        return $this->belongsToMany(WidgetType::class, 'subscriptions')
            ->where(['active' => 1]);
    }

    /**
     * Checks whether user has bought widget type.
     *
     * @param int $widgetTypeId Widget type id.
     *
     * @return boolean
     */
    public function hasActiveWidgetType($widgetTypeId)
    {
        return !$this->activeWidgetTypes->where('id', $widgetTypeId)->isEmpty();
    }

    /**
     * Check if user can use a widget type.
     *
     * @param  WidgetType $widgetType Widget type instance.
     *
     * @return boolean
     */
    public function canUseWidgetType(WidgetType $widgetType)
    {
        if ($widgetType->is_platinum) {
            return $this->hasActiveWidgetType($widgetType->id);
        } else if ($widgetType->is_pro) {
            return $this->account_plan === self::ACCOUNT_PLAN_PRO;
        } else {
            return true;
        }
    }

    /**
     * Checks whether user is subscribed to a widget type.
     *
     * @param int $widgetTypeId Widget type ID.
     *
     * @return boolean
     */
    public function isSubscribedToWidgetType($widgetTypeId)
    {
        return $this->subscribedWidgetTypes->where('id', $widgetTypeId)->count() > 0;
    }

    /**
     * Returns user's unpaid widget type subscription.
     *
     * There is a check on application level that ensures that there can be only
     * one unpaid widget type subscription at a time.
     *
     * @param int $widgetTypeId ID of a widget type.
     *
     * @return Subscription
     */
    public function unpaidWidgetTypeSubscription($widgetTypeId)
    {
        return $this->subscriptions->filter(function (Subscription $sub) use ($widgetTypeId) {
            return $sub->widget_type_id === $widgetTypeId &&
                $sub->paid === false &&
                $sub->active === false;
        })->first();
    }

    /**
     * Gets regular not claimed referrals count.
     *
     * @return int
     */
    public function getRegularReferralsAvailableAttribute()
    {
        return $this->referrals->filter(function (User $user) {
            return !$user->pivot->claimed && $user->account_plan === self::ACCOUNT_PLAN_REGULAR;
        })->count();
    }

    /**
     * Gets PRO not claimed referrals count.
     *
     * @return int
     */
    public function getProReferralsAvailableAttribute()
    {
        return $this->referrals->filter(function (User $user) {
            return !$user->pivot->claimed && $user->account_plan === self::ACCOUNT_PLAN_PRO;
        })->count();
    }

    /**
     * Checks if user has PRO account plan.
     *
     * @return boolean
     */
    public function isPro()
    {
        return $this->account_plan === self::ACCOUNT_PLAN_PRO;
    }

    /**
     * Is user subscribed to PRO.
     *
     * @return boolean
     */
    public function isSubscribedToPro()
    {
        return $this->subscribed_to_pro;
    }

    /**
     * Returns active pro subscription.
     *
     * @return boolean
     */
    public function activeProSubscription()
    {
        return $this->subscriptions->filter(function (Subscription $subscription) {
            return $subscription->active === true && $subscription->widget_type_id === null;
        })->first();
    }

    /**
     * Checks if user has active subscription.
     *
     * @return boolean
     */
    public function hasActiveProSubscription()
    {
        return $this->subscriptions->filter(function (Subscription $subscription) {
            return $subscription->active === true && $subscription->widget_type_id === null;
        })->count() > 0;
    }

    /**
     * Returns user's unpaid PRO subscription.
     *
     * There is a check on application level that ensures that there can be only
     * one unpaid PRO subscription at a time.
     *
     * @return Subscription
     */
    public function unpaidProSubscription()
    {
        return $this->subscriptions->filter(function (Subscription $sub) {
            return $sub->widget_type_id === null && $sub->paid === false && $sub->active === false;
        })->first();
    }

    /**
     * Gets the complete URL to the original main image.
     *
     * @return string
     */
    public function getUrlImageMainOriginalAttribute()
    {
        return URL::to($this->getImage('main', 'original'));
    }

    /**
     * Gets the complete URL to the thumbnail main image.
     *
     * @return string
     */
    public function getUrlImageMainThumbnailAttribute()
    {
        return URL::to($this->getImage('main', 'thumbnail'));
    }

    /**
     * Gets the complete URL to the large main image.
     *
     * @return string
     */
    public function getUrlImageMainLargeAttribute()
    {
        return URL::to($this->getImage('main', 'large'));
    }

    /**
     * Gets the complete URL to the small main image.
     *
     * @return string
     */
    public function getUrlImageMainSmallAttribute()
    {
        return URL::to($this->getImage('main', 'small'));
    }
}
