<?php

namespace App\Auth\WorkingIndustry;

use App\Auth\User;
use App\Auth\WorkingIndustry;
use Cartalyst\Support\Collection;

class Repository
{
    /**
     * A WorkingIndustry model instance.
     *
     * @var WorkingIndustry
     */
    protected $workingIndustryModel;

    /**
     * @param WorkingIndustry $workingIndustryModel A user model instance.
     */
    public function __construct(WorkingIndustry $workingIndustryModel)
    {
        $this->workingIndustryModel = $workingIndustryModel;
    }

    /**
     * Attach new and detach existing workingIndustries from user.
     *
     * @param User  $user      User instance.
     * @param array $inputData Input data array.
     *
     * @return Collection
     */
    public function syncWorkingIndustries(User $user, array $inputData)
    {
        $workingIndustriesForDeletion = [];
        $workingIndustriesForCreation = [];
        $existingWorkingIndustries = [];

        $submitedWorkingIndustries = array_map(function ($item) {
            return $item['key'];
        }, $inputData);

        foreach ($user->workingIndustries as $userWorkingIndustry) {
            if (!in_array($userWorkingIndustry->key, $submitedWorkingIndustries)) {
                $workingIndustriesForDeletion[] = $userWorkingIndustry->key;
            } else {
                $existingWorkingIndustries[] = $userWorkingIndustry->key;
            }
        }

        $workingIndustriesForCreation = array_diff($submitedWorkingIndustries, $workingIndustriesForDeletion);
        $workingIndustriesForCreation = array_diff($submitedWorkingIndustries, $existingWorkingIndustries);

        $this->workingIndustryModel
            ->where('user_id', $user->id)
            ->whereIn('key', $workingIndustriesForDeletion)
            ->delete();

        $createdWorkingIndustries = collect();

        foreach ($workingIndustriesForCreation as $workingIndustryForCreation) {
            $workingIndustry = $this->workingIndustryModel->newInstance();

            $workingIndustry->user_id = $user->id;
            $workingIndustry->key = $workingIndustryForCreation;

            $workingIndustry->save();

            $createdWorkingIndustries->push($workingIndustry);
        }

        return $createdWorkingIndustries;
    }
}
