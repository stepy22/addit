<?php

namespace App\Auth\Http\Controllers\Admin\User;

use App\Auth\Http\Requests\Admin\User\DeleteRequest;
use App\Auth\Http\Requests\Admin\User\StoreRequest;
use App\Auth\Http\Requests\Admin\User\UpdateRequest;
use App\Auth\Role\Repository as RoleRepository;
use App\Auth\User;
use App\Auth\User\Repository as UserRepository;
use App\Http\Controllers\Admin\Controller as BaseController;
use Illuminate\Http\Request;
use Illuminate\Support\MessageBag;
use Redirect;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

class Controller extends BaseController
{
    /**
     * A UserRepository instance.
     *
     * @var UserRepository
     */
    protected $userRepository;

    /**
     * A RoleRepository instance.
     *
     * @var RoleRepository
     */
    protected $roleRepository;

    /**
     * @param UserRepository $userRepository A user repository instance.
     * @param RoleRepository $roleRepository A role repository instance.
     */
    public function __construct(UserRepository $userRepository, RoleRepository $roleRepository)
    {
        parent::__construct();

        $this->userRepository = $userRepository;
        $this->roleRepository = $roleRepository;

        $this->viewData->bodyDataPage = 'admin-users';
        $this->viewData->pageTitle->setPage(trans('admin/users.module'));
        $this->viewData->navigation->get('admin.main')->setActive('users');
    }

    /**
     * Shows all users.
     *
     * @param Request $request The current request instance.
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        if ($request->has('roles')) {
            $users = $this->userRepository->getUsersWithAnyRoles([$request->get('roles')]);
        } else if ($request->has('plan')) {
            $users = $this->userRepository->getUsersWithPlan($request->get('plan'));
        } else {
            $users = $this->userRepository->getAll();
        }

        $data = [
            'users' => $users,
        ];

        return view('admin.users.index', $data);
    }

    /**
     * Displays the user create form.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        $data = [
            'roleOptions' => $this->roleRepository->getOptions(),
            'defaultRoleOption' => 'user',
        ];

        return view('admin.users.create', $data);
    }

    /**
     * Saves a new user.
     *
     * @param StoreRequest $request The user store request.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(StoreRequest $request)
    {
        $data = $request->all();

        if (empty($data['password'])) {
            $data['password'] = $this->userRepository->generatePassword();
        }

        $password = $data['password'];

        $user = $this->userRepository->createAndActivate($data);

        $successMessage = trans('admin/users.successMessages.create');

        return Redirect::action(static::class.'@edit', ['user' => $user->id])
            ->with('successMessages', new MessageBag([$successMessage]));
    }

    /**
     * Shows the specified user.
     *
     * @param User $user The user instance.
     *
     * @return \Illuminate\View\View
     */
    public function edit(User $user)
    {
        $data = [
            'roleOptions' => $this->roleRepository->getOptions(),
            'user' => $user,
        ];

        return view('admin.users.edit', $data);
    }

    /**
     * Updates the specified user.
     *
     * @param UpdateRequest $request The user update request.
     * @param User          $user    The user instance.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(UpdateRequest $request, User $user)
    {
        $this->userRepository->update($user, $request->all());

        $successMessage = trans('admin/users.successMessages.edit');

        return Redirect::action(static::class.'@edit', ['user' => $user->id])
            ->with('successMessages', new MessageBag([$successMessage]));
    }

    /**
     * Displays the user deletion confirmation form.
     *
     * @param DeleteRequest $request The user delete request.
     * @param User          $user    The user instance.
     *
     * @return \Illuminate\View\View
     */
    public function confirmDelete(DeleteRequest $request, User $user)
    {
        $data = [
            'user' => $user,
        ];

        return view('admin.users.delete', $data);
    }

    /**
     * Deletes a user.
     *
     * @param DeleteRequest $request The user delete request.
     * @param User          $user    The user instance.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function delete(DeleteRequest $request, User $user)
    {
        if ($request->get('action') !== 'confirm') {
            return Redirect::action(static::class.'@index');
        }

        $this->userRepository->delete($user);

        $successMessage = trans('admin/users.successMessages.delete', ['fullName' => $user->full_name]);

        return Redirect::action(static::class.'@index')
            ->with('successMessages', new MessageBag([$successMessage]));
    }
}
