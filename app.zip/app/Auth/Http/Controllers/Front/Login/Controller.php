<?php

namespace App\Auth\Http\Controllers\Front\Login;

use App\Auth\Login\Manager as LoginManager;
use App\Auth\User\Repository as UserRepository;
use App\Http\Controllers\Front\Controller as BaseController;
use Cartalyst\Sentinel\Sentinel;
use Illuminate\Http\Request;
use Illuminate\Support\MessageBag;
use Redirect;
use URL;

class Controller extends BaseController
{
    /**
     * A UserRepository instance.
     *
     * @var UserRepository
     */
    protected $userRepository;

    /**
     * A Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * @param UserRepository $userRepository User repository instance.
     * @param Sentinel       $sentinel       Sentinel instance.
     */
    public function __construct(UserRepository $userRepository, Sentinel $sentinel)
    {
        parent::__construct();

        $this->userRepository = $userRepository;
        $this->sentinel = $sentinel;

        $this->viewData->pageTitle->setPage(trans('front-login.title'));
        $this->viewData->navigation->get('front.main')->setActive('login');
    }

    /**
     * Displays the login form.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        return view('login.index');
    }

    /**
     * Attempts to log the user in.
     *
     * @param LoginManager $loginManager Login manager instance.
     * @param Request      $request      Request instance.
     * @param Sentinel     $sentinel     Sentinel instance.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function login(LoginManager $loginManager, Request $request, Sentinel $sentinel)
    {
        if ($loginManager->login($request->all())) {
            $user = $sentinel->getUser();

            if ($user->profile_completed && !$user->inRole('admin')) {
                return Redirect::action('\App\Dashboards\Http\Controllers\Front\Dashboard\Controller@index');
            } else {
                return Redirect::action('App\Http\Controllers\Front\HomeController@index');
            }
        }

        return Redirect::action('App\Auth\Http\Controllers\Front\Login\Controller@index')
            ->withErrors($loginManager->getErrors())
            ->withInput();
    }

    /**
     * Logs the user out, and redirects them back to the login form.
     *
     * @param LoginManager $loginManager Login manager instance.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function logout(LoginManager $loginManager)
    {
        $loginManager->logout();

        return Redirect::action('App\Http\Controllers\Front\HomeController@index')->with('loggedOut', true);
    }
}
