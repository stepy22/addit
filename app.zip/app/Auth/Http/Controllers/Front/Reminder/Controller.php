<?php

namespace App\Auth\Http\Controllers\Front\Reminder;

use App\Auth\Http\Requests\Front\Reminder\StoreRequest;
use App\Auth\User\Repository as UserRepository;
use App\Http\Controllers\Front\Controller as BaseController;
use Cartalyst\Sentinel\Reminders\IlluminateReminderRepository;
use Illuminate\Support\MessageBag;
use Redirect;
use URL;

class Controller extends BaseController
{
    /**
     * A UserRepository instance.
     *
     * @var UserRepository
     */
    protected $userRepository;

    /**
     * An IlluminateReminderRepository instance.
     *
     * @var IlluminateReminderRepository
     */
    protected $reminder;

    /**
     * @param UserRepository               $userRepository A user repository instance.
     * @param IlluminateReminderRepository $reminder       A reminder repository instance.
     */
    public function __construct(UserRepository $userRepository, IlluminateReminderRepository $reminder)
    {
        parent::__construct();

        $this->userRepository = $userRepository;
        $this->reminder = $reminder;
    }

    /**
     * Shows the password reset form.
     *
     * @param string $reminderToken The reminder token to use.
     *
     * @return \Illuminate\View\View
     */
    public function index($reminderToken)
    {
        $data = [
            'reminderToken' => $reminderToken,
        ];

        return view('front.password-reset', $data);
    }

    /**
     * Completes password reminder
     *
     * @param StoreRequest $request A reminder store request.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(StoreRequest $request)
    {
        $inputData = $request->all();

        $user = $this->userRepository->findByEmail($inputData['email']);

        if (!$this->reminder->complete($user, $inputData['reminderToken'], $inputData['password'])) {
            return Redirect::action('App\Auth\Http\Controllers\Front\Reminder\Controller@index', ['reminderToken' => $inputData['reminderToken']])
                ->withErrors(new MessageBag(['email' => trans('reset-password.errors.reminderToken')]))
                ->withInput();
        }

        $successMessage = trans('reset-password.successMessages.index');

        return Redirect::action('App\Auth\Http\Controllers\Front\Login\Controller@index')
            ->with('successMessages', new MessageBag([$successMessage]));
    }
}
