<?php

namespace App\Auth\Http\Controllers\Front\ForgotPassword;

use App\Auth\Http\Requests\Front\ForgotPassword\StoreRequest;
use App\Auth\User\Repository as UserRepository;
use App\Http\Controllers\Front\Controller as BaseController;
use Cartalyst\Sentinel\Reminders\IlluminateReminderRepository;
use Illuminate\Contracts\Mail\Mailer;
use Illuminate\Support\MessageBag;
use Redirect;

class Controller extends BaseController
{
    /**
     * A UserRepository instance.
     *
     * @var UserRepository
     */
    protected $userRepository;

    /**
     * @param UserRepository $userRepository User repository instance.
     */
    public function __construct(UserRepository $userRepository)
    {
        parent::__construct();

        $this->userRepository = $userRepository;
        $this->viewData->pageTitle->setPage(trans('forgot-password.title'));
    }

    /**
     * Displays registration form
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        return view('forgot-password.index');
    }

    /**
     * Attempts to create a new reminder
     *
     * @param StoreRequest                 $request  Request instance.
     * @param IlluminateReminderRepository $reminder Reminder instance.
     * @param Mailer                       $mailer   Mailer instance.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(StoreRequest $request, IlluminateReminderRepository $reminder, Mailer $mailer)
    {
        $user = $this->userRepository->findByEmail($request->get('email'));
        $reminder->removeExpired();

        $foundReminder = $reminder->exists($user);

        if ($foundReminder === false) {
            $createdReminder = $reminder->create($user);
        } else {
            $createdReminder = $foundReminder;
        }

        $mailer->send('emails.auth.reminder', ['reminderToken' => $createdReminder->code], function ($message) use ($request) {
            $message->to($request->get('email'), null);
            $message->subject(trans('forgot-password.emailSubject'));
        });

        $successMessage = trans('forgot-password.successMessages.index');

        return Redirect::action(self::class . '@index')
            ->with('successMessages', new MessageBag([$successMessage]));
    }
}
