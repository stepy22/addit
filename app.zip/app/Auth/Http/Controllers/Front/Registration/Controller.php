<?php

namespace App\Auth\Http\Controllers\Front\Registration;

use App\Auth\Http\Requests\Front\User\StoreRequest;
use App\Auth\User;
use App\Auth\User\MessageManager as UserMessageManager;
use App\Auth\User\Repository as UserRepository;
use App\Http\Controllers\Front\Controller as BaseController;
use Cartalyst\Sentinel\Activations\IlluminateActivationRepository as ActivationRepository;
use Cartalyst\Sentinel\Sentinel;
use Illuminate\Support\MessageBag;
use Redirect;
use URL;

class Controller extends BaseController
{
    /**
     * A UserRepository instance.
     *
     * @var UserRepository
     */
    protected $userRepository;

    /**
     * @param UserRepository $userRepository User repository instance.
     */
    public function __construct(UserRepository $userRepository)
    {
        parent::__construct();

        $this->userRepository = $userRepository;
    }

    /**
     * Displays the registration intro screen.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        $this->viewData->pageTitle->setPage(trans('registration.title.index'));

        return view('registration.index');
    }

    /**
     * Attempts to create a new candidate.
     *
     * @param StoreRequest         $request              User store request instance.
     * @param Sentinel             $sentinel             Sentinel instance.
     * @param ActivationRepository $activationRepository Activation repository instance.
     * @param MessageManager       $userMessageManager   User message manager.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(
        StoreRequest $request,
        Sentinel $sentinel,
        ActivationRepository $activationRepository,
        UserMessageManager $userMessageManager
    ) {
        $data = $request->all();

        $data['role'] = 'user';

        $user = $this->userRepository->create($data);

        $activation = $activationRepository->create($user);
        $userMessageManager->sendWelcomeMail($user);
        $userMessageManager->sendActivationMail($user, $activation);

        return Redirect::action(static::class . '@index')
            ->with('successMessages', new MessageBag([
                trans('activations.successMessages.sent', [
                    'email' => $user->email,
                    'resendUrl' => URL::action('App\Auth\Http\Controllers\Front\Activation\Controller@resendIndex'),
                ]),
            ]));
    }
}
