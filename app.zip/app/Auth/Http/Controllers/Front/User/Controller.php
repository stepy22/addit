<?php

namespace App\Auth\Http\Controllers\Front\User;

use App\Auth\Events\OptInFormPopulated;
use App\Auth\Http\Requests\Front\User\ResetProfileRequest;
use App\Auth\Http\Requests\Front\User\UpdateRequest;
use App\Auth\User\Repository as UserRepository;
use App\Countries\Country\Repository as CountryRepository;
use App\Http\Controllers\Front\Controller as BaseController;
use Cartalyst\Sentinel\Sentinel;
use Illuminate\Config\Repository as Config;
use Illuminate\Support\MessageBag;
use Redirect;

class Controller extends BaseController
{
    /**
     * Shows the opt in form page.
     *
     * @param Config            $config            ConfigRepository.
     * @param CountryRepository $countryRepository Country repository.
     *
     * @return \Illuminate\View\View
     */
    public function profileCompletion(Config $config, CountryRepository $countryRepository)
    {
        $this->viewData->isOptInPage = true;

        $data = [
            'genders' => array_keys(config('user.genders')),
            'ageRanges' => array_keys(config('user.ageRanges')),
            'countries' => $countryRepository->getSelectOptions(),
            'workStatuses' => array_keys(config('user.workStatuses')),
            'relationshipStatuses' => array_keys(config('user.relationshipStatuses')),
            'parentalStatuses' => array_keys(config('user.parentalStatuses')),
            'educations' => array_keys(config('user.educations')),
            'workingIndustries' => array_keys(config('user.workingIndustries')),
            'interests' => array_keys(config('user.interests')),
        ];

        return view('user.profile-completion', $data);
    }

    /**
     * Shows profile page.
     *
     * @return \Illuminate\View\View
     */
    public function profile()
    {
        return view('user.profile-settings');
    }

    /**
     * Displays reset profile page.
     *
     * @param CountryRepository $countryRepository Country repository.
     *
     * @return \Illuminate\View\View
     */
    public function showResetProfile(CountryRepository $countryRepository)
    {
        $data = [
           'genders' => array_keys(config('user.genders')),
           'ageRanges' => array_keys(config('user.ageRanges')),
           'countries' => $countryRepository->getSelectOptions(),
           'workStatuses' => array_keys(config('user.workStatuses')),
           'relationshipStatuses' => array_keys(config('user.relationshipStatuses')),
           'parentalStatuses' => array_keys(config('user.parentalStatuses')),
           'educations' => array_keys(config('user.educations')),
           'workingIndustries' => array_keys(config('user.workingIndustries')),
           'interests' => array_keys(config('user.interests')),
        ];

        return view('user.reset-profile', $data);
    }

    /**
     * Handles reset profile request.
     *
     * @param ResetProfileRequest $request        Form request instance.
     * @param Sentinel            $sentinel       Sentinel instance.
     * @param UserRepository      $userRepository User repository instance.
     *
     * @return \Illuminate\View\View
     */
    public function resetProfile(ResetProfileRequest $request, Sentinel $sentinel, UserRepository $userRepository)
    {
        $user = $sentinel->getUser();

        $inputData = $request->all();

        if ($request->has('educations') && !empty($request->get('educations'))) {
            $educations = [];

            foreach ($request->get('educations') as $education) {
                $educations[] = ['key' => $education];
            }

            $inputData['educations'] = $educations;
        }

        if ($request->has('working_industries') && !empty($request->get('working_industries'))) {
            $workingIndustries = [];

            foreach ($request->get('working_industries') as $education) {
                $workingIndustries[] = ['key' => $education];
            }

            $inputData['working_industries'] = $workingIndustries;
        }

        if ($request->has('interests') && !empty($request->get('interests'))) {
            $interests = [];

            foreach ($request->get('interests') as $education) {
                $interests[] = ['key' => $education];
            }

            $inputData['interests'] = $interests;
        }

        $userRepository->completeProfile($user, $inputData);

        event(new OptInFormPopulated($user));

        return Redirect::action(static::class.'@showResetProfile')
            ->with('successMessages', new MessageBag([
                trans('profile-settings.successMessages.profileReset'),
            ]));
    }

    /**
     * Updates a user's profile settings.
     *
     * @param  UpdateRequest  $request        Update request instance.
     * @param  UserRepository $userRepository User repository instance.
     * @param  Sentinel       $sentinel       Sentinel instance.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(
        UpdateRequest $request,
        UserRepository $userRepository,
        Sentinel $sentinel
    ) {
        $user = $sentinel->getUser();
        $inputData = $request->except([
            'role',
            'password',
        ]);

        $userRepository->update($user, $inputData);

        return Redirect::action(static::class . '@profile')
            ->with('successMessages', new MessageBag([
                trans('profile-settings.successMessages.updated'),
            ]));
    }
}
