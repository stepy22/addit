<?php

namespace App\Auth\Http\Controllers\Front\Subscription;

use App\Auth\Exceptions\SubscriptionBillingFailed;
use App\Auth\Http\Requests\Front\Subscription\SaveCardRequest;
use App\Auth\Http\Requests\Front\Subscription\SubscribeRequest;
use App\Auth\Subscription;
use App\Auth\Subscription\Manager as SubscriptionManager;
use App\Auth\User\Repository as UserRepository;
use App\Http\Controllers\Front\Controller as BaseController;
use Cartalyst\Sentinel\Sentinel;
use Creitive\Commerce\PriceFormatter;
use Creitive\Stripe\FormRenderer as StripeFormRenderer;
use Creitive\Stripe\Stripe;
use Illuminate\Support\MessageBag;
use Log;
use Redirect;
use URL;

class Controller extends BaseController
{
    /**
     * Class constructor.
     */
    public function __construct()
    {
        parent::__construct();

        $this->viewData->pageTitle->setPage(trans('subscriptions.title'));
    }

    /**
     * Displays subscriptions page.
     *
     * @param StripeFormRenderer  $stripeFormRenderer  Stripe form renderer instance.
     * @param Sentinel            $sentinel            Sentinel instance.
     * @param SubscriptionManager $subscriptionManager Subscription manager.
     *
     * @return \Illuminate\View\View
     */
    public function index(
        StripeFormRenderer $stripeFormRenderer,
        Sentinel $sentinel,
        SubscriptionManager $subscriptionManager
    ) {
        $user = $sentinel->getUser();

        $data = [
            'stripeForm' => $stripeFormRenderer->loadSaveCardForm(
                $user->email,
                URL::action(static::class.'@saveCard')
            ),
            'yearlyPrice' => $subscriptionManager->getProPriceYearly(),
            'monthlyPrice' => $subscriptionManager->getProPriceMonthly(),
            'yearlyDiscount' => $subscriptionManager->getYearlyPriceDiscount(),
        ];

        return view('user.subscriptions', $data);
    }

    /**
     * Saves card for a user.
     *
     * @param SaveCardRequest $request        Request instance.
     * @param Stripe          $stripe         Stripe instance.
     * @param Sentinel        $sentinel       Sentinel instance.
     * @param UserRepository  $userRepository User repository instance.
     *
     * @return \Illuminate\View\View
     */
    public function saveCard(
        SaveCardRequest $request,
        Stripe $stripe,
        Sentinel $sentinel,
        UserRepository $userRepository
    ) {
        $user = $sentinel->getUser();
        $stripeToken = $request->get('stripeToken');

        $customer = $stripe->createCustomer($stripeToken, $user->email);

        $customerData = [
            'stripe_customer_id' => $customer->id,
            'stripe_card_brand' => $customer->sources->data[0]->brand,
            'stripe_card_last4' => $customer->sources->data[0]->last4,
        ];

        $userRepository->attachStripeCustomerDataToUser($user, $customerData);

        return Redirect::action(self::class.'@index')
            ->with('successMessages', new MessageBag([trans('subscriptions.successMessages.cardSaved')]));
    }

    /**
     * Deletes a user's card.
     *
     * @param Stripe         $stripe         Stripe instance.
     * @param Sentinel       $sentinel       Sentinel instance.
     * @param UserRepository $userRepository User repository instance.
     *
     * @return \Illuminate\View\View
     */
    public function deleteCard(
        Stripe $stripe,
        Sentinel $sentinel,
        UserRepository $userRepository
    ) {
        $user = $sentinel->getUser();

        $stripe->deleteCustomer($user->stripe_customer_id);

        $userRepository->dettachStripeCustomerDataToUser($user);

        return Redirect::action(self::class.'@index')
            ->with('successMessages', new MessageBag([trans('subscriptions.successMessages.cardDeleted')]));
    }

    /**
     * Subscribe a user to a PRO plan.
     *
     * @param SubscribeRequest    $request             Request instance.
     * @param Sentinel            $sentinel            Sentinel instance.
     * @param SubscriptionManager $subscriptionManager Subscription manager.
     * @param PriceFormatter      $priceFormatter      PriceFormatter instance.
     *
     * @return RedirectResponse
     */
    public function subscribe(
        SubscribeRequest $request,
        Sentinel $sentinel,
        SubscriptionManager $subscriptionManager,
        PriceFormatter $priceFormatter
    ) {
        $user = $sentinel->getUser();

        if ($user->isSubscribedToPro()) {
            return Redirect::action(self::class.'@index')
                ->with('errorMessages', new MessageBag([trans('subscriptions.errorMessages.alreadySubscribed')]));
        }

        try {
            $subscriptionManager->subscribeToPro($user, $request->get('duration'));
        } catch (SubscriptionBillingFailed $exception) {
            Log::error($exception);

            $subscription = $exception->getSubscription();

            return Redirect::action(self::class.'@index')
                ->with('errorMessages', new MessageBag([trans('subscriptions.errorMessages.failedToCharge', [
                    'price' => trans('commerce.currency.symbol') . $priceFormatter->toString($subscriptionManager->getProPriceMonthly(), 0),
                    'startDate' => $subscription->starts_at->setTimezone($user->timezone)->format(trans('subscriptions.dateFormat')),
                    'endDate' => $subscription->ends_at->setTimezone($user->timezone)->format(trans('subscriptions.dateFormat')),
                    'duration' => $subscription->duration,
                ]), ]));
        }

        return Redirect::action(self::class.'@index')
            ->with('successMessages', new MessageBag([trans('subscriptions.successMessages.subscribed')]));
    }

    /**
     * Unsubscribe a user from a PRO plan subscription.
     *
     * @param Sentinel            $sentinel            Sentinel instance.
     * @param SubscriptionManager $subscriptionManager Subscription manager.
     *
     * @return RedirectResponse
     */
    public function unsubscribe(
        Sentinel $sentinel,
        SubscriptionManager $subscriptionManager
    ) {
        $user = $sentinel->getUser();

        if (!$user->isSubscribedToPro()) {
            return Redirect::action(self::class.'@index')
                ->with('errorMessages', new MessageBag([trans('subscriptions.errorMessages.notSubscribed')]));
        }

        $subscriptionManager->unsubscribeFromPro($user);

        return Redirect::action(self::class.'@index')
            ->with('successMessages', new MessageBag([trans('subscriptions.successMessages.unsubscribed')]));
    }
}
