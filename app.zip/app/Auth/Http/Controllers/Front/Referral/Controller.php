<?php

namespace App\Auth\Http\Controllers\Front\Referral;

use App\Auth\Referral\Repository as ReferralRepository;
use App\Auth\User;
use App\Auth\User\Repository as UserRepository;
use App\Http\Controllers\Front\Controller as BaseController;
use Cartalyst\Sentinel\Sentinel;
use Illuminate\Config\Repository as Config;
use Illuminate\Support\MessageBag;
use Redirect;

class Controller extends BaseController
{
    /**
     * Class constructor.
     */
    public function __construct()
    {
        parent::__construct();

        $this->viewData->pageTitle->setPage(trans('affiliate-board.titles.pageTab'));
    }

    /**
     * Displays affiliate board form.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        return view('user.affiliate-board');
    }

    /**
     * Claims regular users referrals prize.
     *
     * @param Sentinel           $sentinel           Sentinel instance.
     * @param ReferralRepository $referralRepository Referral repository instance.
     * @param Config             $config             SconfigRepository instance.
     * @param UserRepository     $userRepository     User repository.
     *
     * @return \Illuminate\View\View
     */
    public function claimRegular(
        Sentinel $sentinel,
        ReferralRepository $referralRepository,
        Config $config,
        UserRepository $userRepository
    ) {
        $regularRefferalsForPrize = $config->get('referrals.regularRefferalsForPrize');
        $user = $sentinel->getUser();
        $freeMonths = floor($user->regular_referrals_available / $regularRefferalsForPrize);
        $numberOfReferalsUsed = $freeMonths * $regularRefferalsForPrize;
        $userRepository->addFreeMonths($user, $freeMonths);

        // Mark referrals as used.
        $referralRepository->markRegularReferralsAsClaimed($numberOfReferalsUsed, $user);

        return Redirect::action(self::class.'@index')
            ->with('successMessages', new MessageBag([trans('affiliate-board.successMessages.claimedRegular', ['freeMonths' => $freeMonths])]));
    }

    /**
     * Claims pro users referrals prize.
     *
     * @param Sentinel           $sentinel           Sentinel instance.
     * @param ReferralRepository $referralRepository Referral repository instance.
     * @param UserRepository     $userRepository     User repository.
     *
     * @return \Illuminate\View\View
     */
    public function claimPro(Sentinel $sentinel, ReferralRepository $referralRepository, UserRepository $userRepository)
    {
        $user = $sentinel->getUser();
        $freeMonths = $user->pro_referrals_available;
        $userRepository->addFreeMonths($user, $freeMonths);

        // Mark referrals as used.
        $referralRepository->markProReferralsAsClaimed($user->id);

        return Redirect::action(self::class.'@index')
            ->with('successMessages', new MessageBag([trans('affiliate-board.successMessages.claimedPro', ['freeMonths' => $freeMonths])]));
    }
}
