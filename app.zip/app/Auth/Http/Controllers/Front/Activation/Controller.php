<?php

namespace App\Auth\Http\Controllers\Front\Activation;

use App\Auth\Http\Requests\Front\Activation\SendRequest;
use App\Auth\User\MessageManager as UserMessageManager;
use App\Auth\User\Repository as UserRepository;
use App\Http\Controllers\Front\Controller as BaseController;
use App\Notifications\Notification;
use App\Notifications\Notification\Notifier;
use Cartalyst\Sentinel\Activations\IlluminateActivationRepository as ActivationRepository;
use Illuminate\Support\MessageBag;
use Redirect;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use URL;

class Controller extends BaseController
{
    /**
     * Attempts to activate the user account.
     *
     * @param string               $activationCode       Activation code.
     * @param UserRepository       $userRepository       User repository instance.
     * @param ActivationRepository $activationRepository Activation repository instance.
     * @param UserMessageManager   $userMessageManager   User message manager.
     * @param Notifier             $notifier             Notifier instance.
     *
     * @return \Illuminate\Http\RedirectResponse
     *
     * @throws NotFoundHttpException
     */
    public function activate(
        $activationCode,
        UserRepository $userRepository,
        ActivationRepository $activationRepository,
        UserMessageManager $userMessageManager,
        Notifier $notifier
    ) {
        $user = $userRepository->findByActivationCode($activationCode);

        if ($user === null) {
            throw new NotFoundHttpException();
        }

        $activation = $activationRepository->exists($user);

        if ($activation === false ||
            $activation->code !== $activationCode ||
            $activationRepository->complete($user, $activationCode) === false) {
            throw new NotFoundHttpException();
        }

        if ($user->referrer) {
            $referrer = $userRepository->findOrFail($user->referrer);
            $referrer->referrals()->attach($user->id);
            $userMessageManager->sendReferralAcquiredMail($referrer, $user);

            $notifier->notify(
                trans('affiliate-board.notifications.'.Notification::TYPE_AFFILIATE_ACQUIRED, [
                    'user' => $user->full_name,
                ]),
                Notification::TYPE_AFFILIATE_ACQUIRED,
                $referrer,
                null,
                URL::action('App\Auth\Http\Controllers\Front\Referral\Controller@index', [], false)
            );
        }

        return Redirect::action('App\Auth\Http\Controllers\Front\Login\Controller@index')
            ->with('successMessages', new MessageBag([trans('activations.successMessages.activated')]));
    }

    /**
     * Shows the form for an activation email resending.
     *
     * @return \Illuminate\View\View
     */
    public function resendIndex()
    {
        return view('activations.resend-index');
    }

    /**
     * Resends the activation email for the user associated with the given email address.
     *
     * @param SendRequest          $request              Send request instance.
     * @param MessageManager       $userMessageManager   Message manager instance.
     * @param UserRepository       $userRepository       User repository instance.
     * @param ActivationRepository $activationRepository Activation repository instance.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function resend(
        SendRequest $request,
        UserMessageManager $userMessageManager,
        UserRepository $userRepository,
        ActivationRepository $activationRepository
    ) {
        $email = $request->get('email');
        $user = $userRepository->findByEmail($email);

        if ($activationRepository->completed($user)) {
            return Redirect::action(static::class . '@resendIndex')
                ->with('warningMessages', new MessageBag([trans('activations.successMessages.alreadyActivated')]));
        }

        $activation = $activationRepository->exists($user);

        if ($activation !== false) {
            $activation->delete();
        }

        $activation = $activationRepository->create($user);

        $userMessageManager->sendActivationMail($user, $activation);

        return Redirect::action(static::class . '@resendIndex')
            ->with('successMessages', new MessageBag(
                [
                    trans('activations.successMessages.resent', ['email' => $user->email]),
                ]
            ));
    }
}
