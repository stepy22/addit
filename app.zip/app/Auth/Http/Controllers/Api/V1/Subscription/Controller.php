<?php

namespace App\Auth\Http\Controllers\Api\V1\Subscription;

use App\Auth\Http\Requests\Api\Subscription\SubscribeRequest;
use App\Auth\Subscription;
use App\Auth\Subscription\Manager as SubscriptionManager;
use Cartalyst\Sentinel\Sentinel;
use Creitive\Commerce\PriceFormatter;
use Illuminate\Routing\Controller as BaseController;

class Controller extends BaseController
{
    /**
     * Returns status of a subscription and prices.
     *
     * @param SubscriptionManager $subscriptionManager Subscription manager.
     * @param Sentinel            $sentinel            Sentinel instance.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index(
        SubscriptionManager $subscriptionManager,
        Sentinel $sentinel
    ) {
        $user = $sentinel->getUser();

        return response([
            'account_plan' => $user->account_plan,
            'subscribed_to_pro' => $user->subscribed_to_pro,
            'subscription_duration' => $user->subscription_duration,
            'durations' => [
                [
                    'title' => trans('subscriptions.subscriptionDuration')[Subscription::DURATION_MONTHLY],
                    'price' => $subscriptionManager->getProPriceMonthly(),
                    'discount' => null,
                ],
                [
                    'title' => trans('subscriptions.subscriptionDuration')[Subscription::DURATION_YEARLY],
                    'price' => $subscriptionManager->getProPriceYearly(),
                    'discount' => $subscriptionManager->getYearlyPriceDiscount(),
                ],
            ],
            'current_subscription' => $user->subscriptions->where('active', 1)->where('widget_type_id', null)->first(),
        ], 200);
    }

    /**
     * Subscribe a user to a PRO plan.
     *
     * @param SubscribeRequest    $request             Request instance.
     * @param Sentinel            $sentinel            Sentinel instance.
     * @param SubscriptionManager $subscriptionManager Subscription manager.
     * @param PriceFormatter      $priceFormatter      PriceFormatter instance.
     *
     * @return RedirectResponse
     */
    public function subscribe(
        SubscribeRequest $request,
        Sentinel $sentinel,
        SubscriptionManager $subscriptionManager,
        PriceFormatter $priceFormatter
    ) {
        $user = $sentinel->getUser();

        if ($user->isSubscribedToPro()) {
            return response([
                'error' => trans('subscriptions.errorMessages.alreadySubscribed'),
            ]);
        }

        try {
            $subscriptionManager->subscribeToPro($user, $request->get('duration'));
        } catch (SubscriptionBillingFailed $exception) {
            Log::error($exception);

            $subscription = $exception->getSubscription();

            return response([
                'error' => trans('subscriptions.errorMessages.failedToCharge', [
                    'price' => trans('commerce.currency.symbol') . $priceFormatter->toString($subscriptionManager->getProPriceMonthly(), 0),
                    'startDate' => $subscription->starts_at->setTimezone($user->timezone)->format(trans('subscriptions.dateFormat')),
                    'endDate' => $subscription->ends_at->setTimezone($user->timezone)->format(trans('subscriptions.dateFormat')),
                    'duration' => $subscription->duration,
                ]),
            ]);
        }

        $subscription = $user->subscriptions
            ->where('active', 1)
            ->where('widget_type_id', null)
            ->first();

        return response([
            'account_plan' => $user->account_plan,
            'subscribed_to_pro' => $user->subscribed_to_pro,
            'subscription_duration' => $user->subscription_duration,
            'subscription' => $subscription,
        ], 201);
    }

    /**
     * Unsubscribe a user from a PRO plan subscription.
     *
     * @param Sentinel            $sentinel            Sentinel instance.
     * @param SubscriptionManager $subscriptionManager Subscription manager.
     *
     * @return RedirectResponse
     */
    public function unsubscribe(
        Sentinel $sentinel,
        SubscriptionManager $subscriptionManager
    ) {
        $user = $sentinel->getUser();

        if (!$user->isSubscribedToPro()) {
            return response([
                'error' => trans('subscriptions.errorMessages.notSubscribed'),
            ], 400);
        }

        $subscriptionManager->unsubscribeFromPro($user);

        return response([], 204);
    }
}
