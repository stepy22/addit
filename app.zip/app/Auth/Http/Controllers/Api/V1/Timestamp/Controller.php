<?php

namespace App\Auth\Http\Controllers\Api\V1\Timestamp;

use DateTime;
use Illuminate\Routing\Controller as BaseController;

class Controller extends BaseController
{
    /**
     * Returns the server timestamp.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
        $datetime = new DateTime();

        return [
            'timestamp' => $datetime->format('U'),
        ];
    }
}
