<?php

namespace App\Auth\Http\Controllers\Api\V1\Password;

use App\Auth\Http\Requests\Api\Password\UpdateRequest;
use App\Auth\User\Repository as UserRepository;
use Cartalyst\Sentinel\Sentinel;
use Illuminate\Routing\Controller as BaseController;

class Controller extends BaseController
{
    /**
     * Updates the currently authenticated user's data.
     *
     * @param UpdateRequest  $request        The update request instance.
     * @param UserRepository $userRepository A user repository instance.
     * @param Sentinel       $sentinel       A Sentinel instance.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(UpdateRequest $request, UserRepository $userRepository, Sentinel $sentinel)
    {
        $user = $sentinel->getUser();

        $userRepository->setPassword($sentinel->getUser(), $request->get('new_password'));

        $sentinel->logout(null, true);
        $sentinel->login($user);

        return response([], 204) ;
    }
}
