<?php

namespace App\Auth\Http\Controllers\Api\V1\Referral;

use App\Auth\Referral\Repository as ReferralRepository;
use App\Auth\User;
use App\Auth\User\Repository as UserRepository;
use Cartalyst\Sentinel\Sentinel;
use Illuminate\Config\Repository as Config;
use Illuminate\Routing\Controller as BaseController;

class Controller extends BaseController
{
    /**
     * Claims regular users referrals prize.
     *
     * @param Sentinel           $sentinel           Sentinel instance.
     * @param ReferralRepository $referralRepository Referral repository instance.
     * @param Config             $config             SconfigRepository instance.
     * @param UserRepository     $userRepository     User repository.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function claimRegular(
        Sentinel $sentinel,
        ReferralRepository $referralRepository,
        Config $config,
        UserRepository $userRepository
    ) {
        $regularRefferalsForPrize = $config->get('referrals.regularRefferalsForPrize');
        $user = $sentinel->getUser();
        $freeMonths = floor($user->regular_referrals_available / $regularRefferalsForPrize);
        $numberOfReferalsUsed = $freeMonths * $regularRefferalsForPrize;

        if ($freeMonths === 0) {
            return response([
                'error' => 'There is not enough referrals to claim a prize.',
            ], 400);
        }

        $userRepository->addFreeMonths($user, $freeMonths);

        // Mark referrals as used.
        $referralRepository->markRegularReferralsAsClaimed($numberOfReferalsUsed, $user);

        return response([], 201);
    }

    /**
     * Claims pro users referrals prize.
     *
     * @param Sentinel           $sentinel           Sentinel instance.
     * @param ReferralRepository $referralRepository Referral repository instance.
     * @param UserRepository     $userRepository     User repository.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function claimPro(Sentinel $sentinel, ReferralRepository $referralRepository, UserRepository $userRepository)
    {
        $user = $sentinel->getUser();
        $freeMonths = $user->pro_referrals_available;

        if ($freeMonths === 0) {
            return response([
                'error' => 'There is not enough referrals to claim a prize.',
            ], 400);
        }

        $userRepository->addFreeMonths($user, $freeMonths);

        // Mark referrals as used.
        $referralRepository->markProReferralsAsClaimed($user->id);

        return response([], 201);
    }
}
