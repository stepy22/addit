<?php

namespace App\Auth\Http\Controllers\Api\V1\CreditCard;

use App\Auth\Http\Requests\Api\CreditCard\SaveCardRequest;
use App\Auth\User\Repository as UserRepository;
use Cartalyst\Sentinel\Sentinel;
use Creitive\Stripe\Stripe;
use Illuminate\Routing\Controller as BaseController;
use Log;
use Stripe\Error\InvalidRequest;

class Controller extends BaseController
{
    /**
     * Returns card info.
     *
     * @param Sentinel $sentinel Sentinel instance.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function show(Sentinel $sentinel)
    {
        $user = $sentinel->getUser();

        if ($user->stripe_customer_id === null) {
            return response([], 404);
        }

        return response([
            'stripe_card_brand' => $user->stripe_card_brand,
            'stripe_card_last4' => $user->stripe_card_last4,
        ], 200);
    }

    /**
     * Saves card for a user.
     *
     * @param SaveCardRequest $request        Request instance.
     * @param Stripe          $stripe         Stripe instance.
     * @param Sentinel        $sentinel       Sentinel instance.
     * @param UserRepository  $userRepository User repository instance.
     *
     * @return \Illuminate\View\View
     */
    public function store(
        SaveCardRequest $request,
        Stripe $stripe,
        Sentinel $sentinel,
        UserRepository $userRepository
    ) {
        $user = $sentinel->getUser();
        $stripeToken = $request->get('stripeToken');

        $customer = $stripe->createCustomer($stripeToken, $user->email);

        if (!$customer) {
            return response([
                'error' => 'Failed to save card data. Check entered data and try again.',
            ], 400);
        }

        $customerData = [
            'stripe_customer_id' => $customer->id,
            'stripe_card_brand' => $customer->sources->data[0]->brand,
            'stripe_card_last4' => $customer->sources->data[0]->last4,
        ];

        $userRepository->attachStripeCustomerDataToUser($user, $customerData);

        return response([
            'stripe_card_brand' => $user->stripe_card_brand,
            'stripe_card_last4' => $user->stripe_card_last4,
        ], 201);
    }

    /**
     * Deletes a user's card.
     *
     * @param Stripe         $stripe         Stripe instance.
     * @param Sentinel       $sentinel       Sentinel instance.
     * @param UserRepository $userRepository User repository instance.
     *
     * @return \Illuminate\View\View
     */
    public function delete(
        Stripe $stripe,
        Sentinel $sentinel,
        UserRepository $userRepository
    ) {
        $user = $sentinel->getUser();

        $stripe->deleteCustomer($user->stripe_customer_id);

        $userRepository->dettachStripeCustomerDataToUser($user);

        return response([], 204);
    }
}
