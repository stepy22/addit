<?php

namespace App\Auth\Http\Controllers\Api\V1\Reminder;

use App\Auth\Http\Requests\Api\Reminder\StoreRequest;
use App\Auth\User;
use App\Auth\User\Repository as UserRepository;
use Cartalyst\Sentinel\Reminders\IlluminateReminderRepository;
use Illuminate\Contracts\Mail\Mailer;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller as BaseController;

class Controller extends BaseController
{
    /**
     * A UserRepository instance.
     *
     * @var UserRepository
     */
    protected $userRepository;

    /**
     * A IlluminateReminderRepository instance.
     *
     * @var IlluminateReminderRepository
     */
    protected $reminder;

    /**
     * A Mailer implementation.
     *
     * @var Mailer
     */
    protected $mailer;

    /**
     * @param UserRepository               $userRepository A UserRepository instance.
     * @param IlluminateReminderRepository $reminder       A reminder repository instance.
     * @param Mailer                       $mailer         A Mailer implementation.
     */
    public function __construct(
        UserRepository $userRepository,
        IlluminateReminderRepository $reminder,
        Mailer $mailer
    ) {
        $this->userRepository = $userRepository;
        $this->reminder = $reminder;
        $this->mailer = $mailer;
    }

    /**
     * Creates a password reminder for the requested user.
     *
     * @param StoreRequest $request A StoreRequest instance.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(StoreRequest $request)
    {
        $user = $this->userRepository->findByEmail($request->get('email'));
        $this->reminder->removeExpired();

        $reminder = $this->reminder->exists($user);

        if ($reminder === false) {
            $reminder = $this->reminder->create($user);
        }

        $this->mailer->send('emails.auth.reminder', ['reminderToken' => $reminder->code], function ($message) use ($request) {
            $message->to($request->get('email'), null);
            $message->subject('Password Reminder');
        });

        return response([], 204);
    }
}
