<?php

namespace App\Auth\Http\Controllers\Api\V1\Transaction;

use Cartalyst\Sentinel\Sentinel;
use Illuminate\Routing\Controller as BaseController;

class Controller extends BaseController
{
    /**
     * Returns all users transactions.
     *
     * @param Sentinel $sentinel Sentinel instance.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index(Sentinel $sentinel)
    {
        $user = $sentinel->getUser();

        return response([
            'transactions' => $user->transactions,
        ], 200);
    }
}
