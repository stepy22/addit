<?php

namespace App\Auth\Http\Controllers\Api\V1\Token;

use App\Auth\Http\Requests\Api\Token\StoreRequest;
use App\Auth\Token\Manager as TokenManager;
use Cartalyst\Sentinel\Sentinel;
use Illuminate\Routing\Controller as BaseController;

class Controller extends BaseController
{
    /**
     * A TokenManager instance.
     *
     * @var TokenManager
     */
    protected $tokenManager;

    /**
     * @param TokenManager $tokenManager A TokenManager instance.
     */
    public function __construct(TokenManager $tokenManager)
    {
        $this->tokenManager = $tokenManager;
    }

    /**
     * Creates a token for the currently authenticated user and returns it.
     *
     * Also returns the user's role.
     *
     * @param StoreRequest $request  A token store request instance.
     * @param Sentinel     $sentinel A Sentinel instance.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(StoreRequest $request, Sentinel $sentinel)
    {
        $data = [
            'token' => $this->tokenManager->getTokenByInput($request->all()),
            'role' => $sentinel->getUser()->role->slug,
            'profile_completed' => $sentinel->getUser()->profile_completed,
        ];

        return response($data, 201);
    }
}
