<?php

namespace App\Auth\Http\Controllers\Api\V1\User;

use App\Auth\Events\OptInFormPopulated;
use App\Auth\Http\Requests\Api\User\CompleteProfileRequest;
use App\Auth\Http\Requests\Api\User\RegisterRequest;
use App\Auth\Http\Requests\Api\User\ResetProfileRequest;
use App\Auth\Http\Requests\Api\User\UpdateRequest;
use App\Auth\User;
use App\Auth\User\Manager as UserManager;
use App\Auth\User\MessageManager as UserMessageManager;
use App\Auth\User\Repository as UserRepository;
use Camroncade\Timezone\Timezone;
use Cartalyst\Sentinel\Activations\IlluminateActivationRepository as ActivationRepository;
use Cartalyst\Sentinel\Sentinel;
use Creitive\Api\Exceptions\InvalidFacebookIdException;
use Creitive\Api\Exceptions\InvalidFacebookTokenException;
use Creitive\Facebook\Facebook;
use Illuminate\Contracts\Mail\Mailer;
use Illuminate\Http\Request;
use Illuminate\Mail\Message;
use Illuminate\Routing\Controller as BaseController;
use Log;
use stdClass;

class Controller extends BaseController
{
    /**
     * A UserRepository instance.
     *
     * @var UserRepository
     */
    protected $userRepository;

    /**
     * A Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * A Request instance.
     *
     * @var Request
     */
    protected $request;

    /**
     * A Facebook instance.
     *
     * @var Facebook
     */
    protected $facebookApiClient;

    /**
     * A user manager instance.
     *
     * @var UserManager
     */
    protected $userManager;

    /**
     * @param UserRepository $userRepository    A user repository instance.
     * @param Sentinel       $sentinel          A Sentinel instance.
     * @param Request        $request           The current request instance.
     * @param Facebook       $facebookApiClient A facebook API instance.
     * @param UserManager    $userManager       A user manager instance.
     */
    public function __construct(
        UserRepository $userRepository,
        Sentinel $sentinel,
        Request $request,
        Facebook $facebookApiClient,
        UserManager $userManager
    ) {
        $this->userRepository = $userRepository;
        $this->sentinel = $sentinel;
        $this->request = $request;
        $this->facebookApiClient = $facebookApiClient;
        $this->userManager = $userManager;
    }

    /**
     * Lists all users from role 'user', and allows search by fields defined in
     * user model
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
        $user = $this->sentinel->getUser();

        $users = $this->userRepository->searchUsers($this->request->all(), $user);

        return response(['users' => $users->all()], 200);
    }

    /**
     * Lists all with whom passed user shared something.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function sharingBuddies()
    {
        $user = $this->sentinel->getUser();

        $users = $this->userRepository->getSharingBuddies($user);

        $formatterdUsers = $users->map(function (User $user) {
            return [
                'email' => $user->email,
                'full_name' => $user->full_name,
            ];
        })->toArray();

        return response(['users' => array_values($formatterdUsers)]);
    }

    /**
     * Register a new user.
     *
     * @param RegisterRequest      $request              A register request instance.
     * @param ActivationRepository $activationRepository Activation repository instance.
     * @param MessageManager       $userMessageManager   User message manager.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function register(
        RegisterRequest $request,
        ActivationRepository $activationRepository,
        UserMessageManager $userMessageManager
    ) {
        $inputData = $request->all();
        $inputData['role'] = 'user';

        if (isset($inputData['facebook_id']) && $inputData['facebook_id']) {
            return $this->userManager->handleFacebookSignInViaAPI($inputData);
        }

        if (isset($inputData['id_token']) && !empty($inputData['id_token'])) {
            return $this->userManager->handleGoogleSignInViaAPI($inputData['id_token']);
        }

        $user = $this->userRepository->create($inputData);

        $activation = $activationRepository->create($user);
        $userMessageManager->sendActivationMail($user, $activation);
        $userMessageManager->sendWelcomeMail($user);

        $this->userRepository->touch($user);

        return response([
            'token' => $user->auth_token,
            'profile_completed' => false,
        ], 201);
    }

    /**
     * Returns the currently authenticated user's data.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function show()
    {
        $user = $this->sentinel->getUser();
        $user->load('educations', 'interests', 'workingIndustries', 'country');

        return response([
            'user' => $user->toArray(),
        ], 200);
    }

    /**
     * Updates the currently authenticated user's data.
     *
     * @param UpdateRequest $request The update request instance.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(UpdateRequest $request)
    {
        $user = $this->sentinel->getUser();
        $inputData = $request->except([
            'role',
            'password',
        ]);

        $user = $this->userRepository->update($user, $inputData);

        $user->load('educations', 'interests', 'workingIndustries', 'country');

        return response([
            'user' => $user->toArray(),
        ], 200);
    }

    /**
     * Resets the user's password.
     *
     * @param Request $request The current request instance.
     * @param Mailer  $mailer  A Mailer implementation.
     * @param User    $user    The user whose password is being reset.
     *
     * @return \Illuminate\Http\Response
     */
    public function resetPassword(Request $request, Mailer $mailer, User $user)
    {
        $manuallySetPassword = $request->get('manuallySetPassword');
        $newPassword = $request->get('newPassword');

        if ($manuallySetPassword && $newPassword !== '') {
            $password = $newPassword;
        } else {
            $password = $this->userRepository->generatePassword();
        }

        $user = $this->userRepository->setPassword($user, $password);

        if ($request->get('sendAnEmailWithReset')) {
            $mailer->send(
                'emails.user.passwordReset',
                [
                    'user' => $user,
                    'password' => $password,
                ],
                function (Message $message) use ($user) {
                    $message
                        ->to($user->email, $user->full_name)
                        ->subject(trans('emails/user/passwordReset.subject'));
                }
            );
        }

        return [
            'email' => $user->email,
            'password' => $password,
        ];
    }

    /**
     * Completes a user profile.
     *
     * @param CompleteProfileRequest $request Profile completion request.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function completeProfile(CompleteProfileRequest $request)
    {
        $user = $this->sentinel->getUser();
        $inputData = $request->except('role');
        $user = $this->userRepository->completeProfile($user, $inputData);

        event(new OptInFormPopulated($user));

        return response(['user' => [
            'country' => $user->country,
            'gender' => $user->gender,
            'work_status' => $user->work_status,
            'relationship_status' => $user->relationship_status,
            'parental_status' => $user->parental_status,
            'educations' => $user->educations->toArray(),
            'working_industries' => $user->workingIndustries->toArray(),
            'interests' => $user->interests->toArray(),
        ], ], 200);
    }

    /**
     * Resets a user profile.
     *
     * @param ResetProfileRequest $request Profile reset request.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function resetProfile(ResetProfileRequest $request)
    {
        $user = $this->sentinel->getUser();
        $inputData = $request->except('role');
        $user = $this->userRepository->completeProfile($user, $inputData);

        event(new OptInFormPopulated($user));

        return response(['user' => [
            'country' => $user->country,
            'gender' => $user->gender,
            'work_status' => $user->work_status,
            'relationship_status' => $user->relationship_status,
            'parental_status' => $user->parental_status,
            'educations' => $user->educations->toArray(),
            'working_industries' => $user->workingIndustries->toArray(),
            'interests' => $user->interests->toArray(),
        ], ], 200);
    }

    /**
     * Returns all genders.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function genders()
    {
        $genders = [];

        foreach (trans('userSelects.genders') as $genderKey => $translation) {
            $gender = new stdClass();

            $gender->id = $genderKey;
            $gender->title = $translation;

            $genders[] = $gender;
        }

        return [
            'genders' => $genders,
        ];
    }

    /**
     * Returns all age ranges.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function ageRanges()
    {
        $ageRanges = [];

        foreach (trans('userSelects.ageRanges') as $ageRangeKey => $translation) {
            $ageRange = new stdClass();

            $ageRange->id = $ageRangeKey;
            $ageRange->title = $translation;

            $ageRanges[] = $ageRange;
        }

        return [
            'ageRanges' => $ageRanges,
        ];
    }

    /**
     * Returns all educations.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function educations()
    {
        $educations = [];

        foreach (trans('userSelects.educations') as $educationKey => $translation) {
            $education = new stdClass();

            $education->id = $educationKey;
            $education->title = $translation;

            $educations[] = $education;
        }

        return [
            'educations' => $educations,
        ];
    }

    /**
     * Returns all interests.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function interests()
    {
        $interests = [];

        foreach (trans('userSelects.interests') as $interestKey => $translation) {
            $interest = new stdClass();

            $interest->id = $interestKey;
            $interest->title = $translation;

            $interests[] = $interest;
        }

        return [
            'interests' => $interests,
        ];
    }

    /**
     * Returns all relationship statuses.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function relationshipStatuses()
    {
        $relationshipStatuses = [];

        foreach (trans('userSelects.relationshipStatuses') as $relationshipStatusKey => $translation) {
            $relationshipStatus = new stdClass();

            $relationshipStatus->id = $relationshipStatusKey;
            $relationshipStatus->title = $translation;

            $relationshipStatuses[] = $relationshipStatus;
        }

        return [
            'relationshipStatuses' => $relationshipStatuses,
        ];
    }

    /**
     * Returns all work statuses.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function workStatuses()
    {
        $workStatuses = [];

        foreach (trans('userSelects.workStatuses') as $workStatusKey => $translation) {
            $workStatus = new stdClass();

            $workStatus->id = $workStatusKey;
            $workStatus->title = $translation;

            $workStatuses[] = $workStatus;
        }

        return [
            'workStatuses' => $workStatuses,
        ];
    }

    /**
     * Returns all work industries.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function workingIndustries()
    {
        $workingIndustries = [];

        foreach (trans('userSelects.workingIndustries') as $workingIndustryKey => $translation) {
            $workingIndustry = new stdClass();

            $workingIndustry->id = $workingIndustryKey;
            $workingIndustry->title = $translation;

            $workingIndustries[] = $workingIndustry;
        }

        return [
            'workingIndustries' => $workingIndustries,
        ];
    }

    /**
     * Returns all parental statuses.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function parentalStatuses()
    {
        $parentalStatuses = [];

        foreach (trans('userSelects.parentalStatuses') as $parentalStatusKey => $translation) {
            $parentalStatus = new stdClass();

            $parentalStatus->id = $parentalStatusKey;
            $parentalStatus->title = $translation;

            $parentalStatuses[] = $parentalStatus;
        }

        return [
            'parentalStatuses' => $parentalStatuses,
        ];
    }

    /**
     * Timezones for selection.
     *
     * @param Timezone $timezone Timezone helper class.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function timezones(Timezone $timezone)
    {
        $timezones = [];

        foreach ($timezone->timezoneList as $key => $value) {
            $row = [];
            $row['key'] = $key;
            $row['value'] = $value;

            $timezones[] = $row;
        }

        return response([
            'timezones' => $timezones,
        ]);
    }
}
