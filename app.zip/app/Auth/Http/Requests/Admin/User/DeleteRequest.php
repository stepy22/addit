<?php

namespace App\Auth\Http\Requests\Admin\User;

use App\Auth\Role\Repository as RoleRepository;
use App\Http\Requests\Request;
use Cartalyst\Sentinel\Sentinel;

class DeleteRequest extends Request
{
    /**
     * A Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * @param Sentinel $sentinel A Sentinel instance.
     */
    public function __construct(Sentinel $sentinel)
    {
        parent::__construct();

        $this->sentinel = $sentinel;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return $this->route('user')->id !== $this->sentinel->getUser()->id;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @param RoleRepository $roleRepository A role repository instance.
     *
     * @return array
     */
    public function rules(RoleRepository $roleRepository)
    {
        return [];
    }
}
