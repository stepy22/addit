<?php

namespace App\Auth\Http\Requests\Api\Reminder;

use App\Http\Requests\Request;
use Illuminate\Validation\Factory as ValidationFactory;

class StoreRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
           'email' => ['required', 'email', 'exists:users,email'],
        ];

        return $rules;
    }

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array
     */
    public function messages()
    {
        return array_dot(trans('forgot-password.errorMessages'));
    }
}
