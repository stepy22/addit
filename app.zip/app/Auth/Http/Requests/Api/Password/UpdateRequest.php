<?php

namespace App\Auth\Http\Requests\Api\Password;

use App\Http\Requests\Request;
use Cartalyst\Sentinel\Sentinel;
use Illuminate\Validation\Factory as ValidationFactory;

class UpdateRequest extends Request
{
    /**
     * A Sentinel instance
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * @param Sentinel $sentinel A Sentinel instance.
     */
    public function __construct(Sentinel $sentinel)
    {
        parent::__construct();

        $this->sentinel = $sentinel;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $currentUser = $this->sentinel->getUser();
        $rules = [
            'password' => ['required', 'current_password'],
            'new_password' => ['required', 'confirmed', 'case_diff', 'numbers', 'letters'],
        ];

        return $rules;
    }

    /**
     * {@inheritDoc}
     */
    public function validator(Sentinel $sentinel, ValidationFactory $factory)
    {
        $input = $this->all();

        // We need the user's current hashed password in order for the
        // validator to be able to perform validation on that. This wouldn't be
        // solved by some kind of authorization middleware, as we should be able
        // to display a useful error message for this.
        //
        // The way we handle it isn't really ideal, but it does the job for now.
        $input['real_current_password'] = $sentinel->getUser()->password;

        return $factory->make(
            $input,
            $this->container->call([$this, 'rules']),
            $this->messages(),
            $this->attributes()
        );
    }

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array
     */
    public function messages()
    {
        return array_dot(trans('change-password.errorMessages'));
    }
}
