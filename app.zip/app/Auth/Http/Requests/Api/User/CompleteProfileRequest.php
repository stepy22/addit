<?php

namespace App\Auth\Http\Requests\Api\User;

use App\Http\Requests\Request;
use Cartalyst\Sentinel\Sentinel;
use Illuminate\Validation\Factory as ValidationFactory;
use Illuminate\Validation\Rule;

class CompleteProfileRequest extends Request
{
    /**
     * A Sentinel instance
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * @param Sentinel $sentinel A Sentinel instance.
     */
    public function __construct(Sentinel $sentinel)
    {
        parent::__construct();

        $this->sentinel = $sentinel;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $currentUser = $this->sentinel->getUser();

        $rules = [
            'gender' => ['in:'. implode(',', array_keys(config('user.genders')))],
            'age_range' => ['in:'. implode(',', array_keys(config('user.ageRanges')))],
            'country' => ['in:'. implode(',', config('user.countries'))],
            'work_status' => ['in:'. implode(',', array_keys(config('user.workStatuses')))],
            'relationship_status' => ['in:'. implode(',', array_keys(config('user.relationshipStatuses')))],
            'parental_status' => ['in:'. implode(',', array_keys(config('user.parentalStatuses')))],
            'educations.*.id' => ['in:'. implode(',', array_keys(config('user.educations')))],
            'working_industries.*.id' => ['in:'. implode(',', array_keys(config('user.workingIndustries')))],
            'interests.*.id' => ['in:'. implode(',', array_keys(config('user.interests')))],
        ];

        return $rules;
    }
}
