<?php

namespace App\Auth\Http\Requests\Api\User;

use App\Http\Requests\Request;
use Cartalyst\Sentinel\Sentinel;
use Illuminate\Validation\Factory as ValidationFactory;
use Illuminate\Validation\Rule;

class UpdateRequest extends Request
{
    /**
     * A Sentinel instance
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * @param Sentinel $sentinel A Sentinel instance.
     */
    public function __construct(Sentinel $sentinel)
    {
        parent::__construct();

        $this->sentinel = $sentinel;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $currentUser = $this->sentinel->getUser();

        $rules = [
            'email' => [
                'email',
                Rule::unique('users')->ignore($currentUser->id),
            ],
            // Base 64 encoding needs ~ 8 bits for each 6 bits of the original
            // data (or 4 bytes to store 3).
            // Since laravel detects base64 encoded file as a string and expects
            // number of characters to be given as file size limit we first
            // multiply our limit (10240 - 10mb) by 1024 to get value in
            // bytes and then calculate size of a encoded file for that limit.
            'image_main' => ['base_64_encoded_image', 'max:'.(10240 * 1024) / 3 * 4],
        ];

        return $rules;
    }

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array
     */
    public function messages()
    {
        return array_dot(trans('profile-settings.errorMessages'));
    }
}
