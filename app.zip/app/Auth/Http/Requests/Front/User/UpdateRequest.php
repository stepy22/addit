<?php

namespace App\Auth\Http\Requests\Front\User;

use App\Http\Requests\Request;
use Cartalyst\Sentinel\Sentinel;

class UpdateRequest extends Request
{

    /**
     * Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * @param Sentinel $sentinel Sentinel instance.
     */
    public function __construct(Sentinel $sentinel)
    {
        $this->sentinel = $sentinel;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
           'email' => ['required', 'email', 'unique:users,email,'.$this->sentinel->getUser()->id],
           'first_name' => ['required'],
           'last_name' => ['required'],
           'image_main' => ['image', 'max:10240'],
        ];

        return $rules;
    }

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array
     */
    public function messages()
    {
        return array_dot(trans('profile-settings.errorMessages'));
    }
}
