<?php

namespace App\Auth\Http\Requests\Front\User;

use App\Http\Requests\Request;

class StoreRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
           'email' => ['required', 'email', 'unique:users,email'],
           'password' => ['required', 'confirmed', 'case_diff', 'numbers', 'letters', 'min:6'],
           'first_name' => ['required'],
           'last_name' => ['required'],
           'image_main' => ['image', 'max:10240'],
           'referrer' => ['exists:users,id'],
           'agree' => ['accepted'],
        ];

        return $rules;
    }

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array
     */
    public function messages()
    {
        return array_dot(trans('registration.errorMessages'));
    }
}
