<?php

namespace App\Auth\Http\Requests\Front\Subscription;

use App\Auth\Subscription;
use App\Http\Requests\Request;

class SubscribeRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'duration' => ['required', 'in:'.Subscription::DURATION_MONTHLY.','.Subscription::DURATION_YEARLY],
        ];

        return $rules;
    }
}
