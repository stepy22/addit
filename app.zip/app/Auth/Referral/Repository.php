<?php

namespace App\Auth\Referral;

use App\Auth\Referral;
use App\Auth\User;
use App\Auth\User\Repository as UserRepository;
use Illuminate\Database\Query\Builder;

class Repository
{
    /**
     * A referral model.
     *
     * @var Referral
     */
    protected $referralModel;

    /**
     * A user repository.
     *
     * @var UserRepository
     */
    protected $userRepository;

    /**
     * @param Referral       $referralModel  A referral model instance.
     * @param UserRepository $userRepository A user repository instance.
     */
    public function __construct(Referral $referralModel, UserRepository $userRepository)
    {
        $this->referralModel = $referralModel;
        $this->userRepository = $userRepository;
    }

    /**
     * Mark used regular referrals.
     *
     * @param int  $numberOfUsers Number of referrals to mark as claimed.
     * @param User $referrer      Referrer.
     *
     * @return boolean
     */
    public function markRegularReferralsAsClaimed($numberOfUsers, $referrer)
    {
        $referrals = $referrer->referrals->filter(function (User $user) {
            return $user->account_plan === User::ACCOUNT_PLAN_REGULAR && !$user->pivot->claimed;
        })->sortBy('created_at')->take($numberOfUsers);

        return $this->referralModel
            ->join('users', 'referrals.referred_id', '=', 'users.id')
            ->where('referrals.referrer_id', $referrer->id)
            ->whereIn('users.id', $referrals->pluck('id')->toArray())
            ->update(['claimed' => 1]);
    }

    /**
     * Mark used pro referrals.
     *
     * @param int $referrerId ID of a referrer.
     *
     * @return boolean
     */
    public function markProReferralsAsClaimed($referrerId)
    {
        return $this->referralModel
            ->join('users', 'referrals.referred_id', '=', 'users.id')
            ->where('users.account_plan', User::ACCOUNT_PLAN_PRO)
            ->where('referrals.referrer_id', $referrerId)
            ->update(['claimed' => 1]);
    }
}
