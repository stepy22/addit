<?php

namespace App\Auth\Referral;

use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Creitive\Routing\LocaleResolver;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerFrontRoutes($this->app['router']);
        $this->registerFrontApiRoutes($this->app['router']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers front routes.
     *
     * @param RegistrarContract $router Registrar instance.
     *
     * @return void
     */
    protected function registerFrontRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => trans('routes.affiliateBoard'),
            'middleware' => ['web', 'auth.front'],
            'namespace' => 'App\Auth\Http\Controllers\Front\Referral',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('', 'Controller@index');
            $router->post('claim-regular', 'Controller@claimRegular');
            $router->post('claim-pro', 'Controller@claimPro');
        });
    }

    /**
     * Registers front api routes.
     *
     * @param RegistrarContract $router Registrar instance.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1/affiliates',
            'middleware' => ['api', 'auth'],
            'namespace' => 'App\Auth\Http\Controllers\Api\V1\Referral',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->post('claim-regular', 'Controller@claimRegular');
            $router->post('claim-pro', 'Controller@claimPro');
        });
    }
}
