<?php

namespace App\Auth\Console;

use App\Auth\Subscription\Manager as SubscriptionManager;
use Illuminate\Console\Command;

class CheckExpiringProSubscriptions extends Command
{
    /**
     * The console command name.
     *
     * @var string
     */
    protected $name = 'subscription:check-expiring-pro-subscriptions';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Checks expiring pro subscriptions';

    /**
     * A subscription manager.
     *
     * @var SubscriptionManager
     */
    protected $subscriptionManager;

    /**
     * @param SubscriptionManager $subscriptionManager A subscription manager.
     */
    public function __construct(SubscriptionManager $subscriptionManager)
    {
        parent::__construct();

        $this->subscriptionManager = $subscriptionManager;
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        $output = $this->subscriptionManager->checkExiringProSubscriptions();

        print_r($output);
    }
}
