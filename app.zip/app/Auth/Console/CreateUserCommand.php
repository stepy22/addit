<?php

namespace App\Auth\Console;

use App\Auth\User;
use Cartalyst\Sentinel\Roles\EloquentRole;
use Cartalyst\Sentinel\Sentinel;
use Illuminate\Console\Command;
use Str;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputOption;

class CreateUserCommand extends Command
{
    /**
     * The console command name.
     *
     * @var string
     */
    protected $name = 'user:create';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Creates a new user';

    /**
     * A Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * A User model instance.
     *
     * @var User
     */
    protected $userModel;

    /**
     * A role model instance.
     *
     * @var EloquentRole
     */
    protected $roleModel;

    /**
     * @param Sentinel     $sentinel  A Sentinel instance.
     * @param User         $userModel A User model instance.
     * @param EloquentRole $roleModel An EloquentRole model instance.
     */
    public function __construct(Sentinel $sentinel, User $userModel, EloquentRole $roleModel)
    {
        parent::__construct();

        $this->sentinel = $sentinel;
        $this->userModel = $userModel;
        $this->roleModel = $roleModel;
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function fire()
    {
        if ($this->userModel->whereEmail($this->argument('email'))->exists()) {
            $this->error('The user with the specified email already exists!');

            return 1;
        }

        if (!filter_var($this->argument('email'), FILTER_VALIDATE_EMAIL)) {
            $this->error('The provided email address is not valid!');

            return 1;
        }

        $roleSlugs = $this->roleModel->all()->pluck('slug')->toArray();

        if ($this->option('role') && !in_array($this->option('role'), $roleSlugs)) {
            $this->error(sprintf('No role found for the provided role slug! Available options: %s', implode(', ', $roleSlugs)));

            return 1;
        }

        return $this->registerUser(
            $this->argument('email'),
            $this->argument('password'),
            !$this->option('inactive'),
            $this->option('role')
        );
    }

    /**
     * Registers the user with the provided credentials.
     *
     * If `$password` is set to `null`, a random 32-character password will be
     * generated.
     *
     * If `$activate` is set to `true`, the user will be automatically
     * activated; otherwise, they will have to manually go through the
     * activation process.
     *
     * If `null` is passed as the role slug, no role will be assigned to the
     * user.
     *
     * @param string      $email    The email address of the new user.
     * @param string|null $password The new password for the user.
     * @param bool        $activate Whether to immediately activate the user.
     * @param string|null $roleSlug The slug of the role to assign to the user.
     *
     * @return int
     */
    public function registerUser($email, $password = null, $activate = true, $roleSlug = null)
    {
        $password = $password ?: Str::random(32);

        $credentials = [
            'email' => $email,
            'password' => $password,
        ];

        $user = $this->sentinel->register($credentials, $activate);

        if ($roleSlug) {
            $role = $this->roleModel->where('slug', $roleSlug)->first();
            $user->roles()->attach($role);
        }

        if ($user) {
            $this->info(sprintf('Created user %s', $email));
            $this->info(sprintf('Password:  %s', $password));
            $this->info(sprintf('Role:      %s', isset($role) ? $role->name : '- none -'));
            $this->info(sprintf('Activated: %s', $activate ? 'Yes' : 'No'));

            if (!$activate) {
                $this->info('Please activate the user manually.');
            }
        } else {
            $this->error('Unable to create the specified user.');
        }

        return $user ? 0 : 1;
    }

    /**
     * Get the console command arguments.
     *
     * @return array
     */
    protected function getArguments()
    {
        return [
            ['email', InputArgument::REQUIRED, 'Email address'],
            ['password', InputArgument::OPTIONAL, 'Password (if one is not provided, a random 32-character string will be generated)'],
        ];
    }

    /**
     * Get the console command options.
     *
     * @return array
     */
    protected function getOptions()
    {
        return [
            ['inactive', null, InputOption::VALUE_NONE, 'Use this flag to force manual user activation'],
            ['role', null, InputOption::VALUE_OPTIONAL, 'Use this option to set the user\'s role.'],
        ];
    }
}
