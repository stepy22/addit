<?php

namespace App\Auth;

use Creitive\Database\Eloquent\Model;

class Interest extends Model
{
    /**
     * {@inheritDoc}
     */
    protected $table = 'user_interests';

    /**
     * {@inheritDoc}
     */
    protected $visible = [
        'key',
    ];
}
