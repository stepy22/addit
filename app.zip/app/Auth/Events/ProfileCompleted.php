<?php

namespace App\Auth\Events;

use App\Auth\User;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class ProfileCompleted
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    /**
     * User instance.
     *
     * @var \App\Auth\User
     */
    public $user;

    /**
     * Create a new event instance.
     *
     * @param User $user User instance.
     */
    public function __construct(User $user)
    {
        $this->user = $user;
    }
}
