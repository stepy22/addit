<?php

namespace App\Auth\Login;

use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerFrontRoutes($this->app['router']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers front routes.
     *
     * @param RegistrarContract $router Register contract instance.
     *
     * @return void
     */
    protected function registerFrontRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => trans('routes.login'),
            'middleware' => ['web', 'guest.front'],
            'namespace' => 'App\Auth\Http\Controllers\Front\Login',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('', 'Controller@index');
            $router->post('', 'Controller@login');
        });

        $attributes = [
            'prefix' => trans('routes.logout'),
            'middleware' => ['web', 'auth.front'],
            'namespace' => 'App\Auth\Http\Controllers\Front\Login',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->post('', 'Controller@logout');
        });
    }
}
