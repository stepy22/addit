<?php

namespace App\Auth\Login;

use App\Auth\User\Manager as UserManager;
use App\Auth\User\MessageManager as UserMessageManager;
use App\Auth\User\Repository as UserRepository;
use Cartalyst\Sentinel\Checkpoints\NotActivatedException;
use Cartalyst\Sentinel\Checkpoints\ThrottlingException;
use Cartalyst\Sentinel\Sentinel;
use Creitive\Managers\AbstractBaseManager;
use Illuminate\Session\Store as Session;
use Illuminate\Support\MessageBag;
use Illuminate\Translation\Translator;
use Laravel\Socialite\AbstractUser;
use Laravel\Socialite\Two\User as SocialiteUser;
use Redirect;
use URL;

class Manager extends AbstractBaseManager
{
    /**
     * A Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * A Translator instance.
     *
     * @var Translator
     */
    protected $translator;

    /**
     * A Session store instance.
     *
     * @var Session
     */
    protected $session;

    /**
     * A UserRepository instance.
     *
     * @var UserRepository
     */
    protected $userRepository;

    /**
     * A UserManager instance.
     *
     * @var UserManager
     */
    protected $userManager;

    /**
     * @param Sentinel           $sentinel           A Sentinel instance.
     * @param Translator         $translator         A translator.
     * @param Session            $session            A session store.
     * @param UserRepository     $userRepository     A user repository instance.
     * @param UserMessageManager $userMessageManager A user manager instance.
     * @param UserManager        $userManager        A user manager instance instance.
     */
    public function __construct(
        Sentinel $sentinel,
        Translator $translator,
        Session $session,
        UserRepository $userRepository,
        UserMessageManager $userMessageManager,
        UserManager $userManager
    ) {
        parent::__construct();

        $this->sentinel = $sentinel;
        $this->translator = $translator;
        $this->session = $session;
        $this->userRepository = $userRepository;
        $this->userMessageManager = $userMessageManager;
        $this->userManager = $userManager;
    }

    /**
     * Attempts to log the user in.
     *
     * Returns `true` on success and `false` on failure.
     *
     * If successful, the user's CSRF token will be regenerated for security
     * purposes.
     *
     * If unsuccessful, the authentication errors will be stored in
     * `$this->errors`.
     *
     * @param array $inputData The input data.
     *
     * @return bool
     */
    public function login(array $inputData)
    {
        $credentials = [
            'email' => $inputData['email'],
            'password' => $inputData['password'],
        ];

        $rememberMe = array_key_exists('remember_me', $inputData);

        try {
            if ($this->sentinel->authenticate($credentials, $rememberMe)) {
                $this->session->regenerateToken();

                return true;
            }
        } catch (NotActivatedException $exception) {
            $this->errors->add('email', $this->translator->get('login.errors.email.notActivated'));

            return false;
        } catch (ThrottlingException $exception) {
            $this->errors->add('email', $this->translator->get('login.errors.email.suspended'));

            return false;
        }

        $this->errors->add('email', $this->translator->get('login.errors.email.unregistered'));

        return false;
    }

    /**
     * Checks if user exists and log the user in.
     *
     * Returns `true` on success and `false` on failure.
     *
     * If successful, the user's CSRF token will be regenerated for security
     *
     * @param AbstractUser $user     A user instance.
     * @param string       $provider Used provider.
     *
     * @return bool
     */
    public function loginSocial(SocialiteUser $user, $provider)
    {
        // Return error if Facebook don't return email address (Google will always do).
        if (!$user->getEmail()) {
            $this->errors->add('social_login', $this->translator->get('login.errors.email.permission'));

            return false;
        }

        $foundUser = $this->userRepository->findByEmail($user->getEmail());

        if (!$foundUser) {
            $foundUser = $this->userRepository->createFromSocialUser($user);
            $this->userMessageManager->sendWelcomeMail($foundUser);
        }

        if ($foundUser->facebook_id === null && $provider === 'facebook') {
            $this->userManager->attachInterestTagsByFacebookLikes($foundUser, $user->token);

            $foundUser->facebook_id = $user->getId();
            $foundUser->save();

            if ($this->sentinel->getUser()) {
                return Redirect::action('App\Contact\Http\Controllers\Front\Message\Controller@index')
                    ->with('successMessages', new MessageBag([$this->translator->get('login.facebookConnected')]));
            }
        }

        if ($foundUser->google_id === null && $provider === 'google') {
            $foundUser->google_id = $user->getId();
            $foundUser->save();

            if ($this->sentinel->getUser()) {
                return Redirect::action('App\Contact\Http\Controllers\Front\Message\Controller@index')
                    ->with('successMessages', new MessageBag([$this->translator->get('login.googleConnected')]));
            }
        }

        try {
            if ($this->sentinel->login($foundUser, false)) {
                $this->session->regenerateToken();

                $this->session->put('avatar', $user->avatar);

                if ($foundUser->inRole('admin')) {
                    $default = URL::action('App\Http\Controllers\Admin\HomeController@index');
                } else {
                    if ($foundUser->profile_completed && !$foundUser->inRole('admin')) {
                        $default = URL::action('App\Dashboards\Http\Controllers\Front\Dashboard\Controller@index');
                    } else {
                        $default = URL::action('App\Http\Controllers\Front\HomeController@index');
                    }
                }

                return Redirect::intended($default);
            }
        } catch (NotActivatedException $exception) {
            $this->errors->add('social_login', $this->translator->get('login.errors.email.notActivated'));

            return false;
        } catch (ThrottlingException $exception) {
            $this->errors->add('social_login', $this->translator->get('login.errors.email.suspended'));

            return false;
        }

        return false;
    }

    /**
     * Logs the current user out.
     *
     * The user's CSRF token will be regenerated for security purposes.
     *
     * @return bool
     */
    public function logout()
    {
        $this->sentinel->logout();
        $this->session->regenerateToken();

        return true;
    }
}
