<?php

namespace App\Auth\User;

use App\Auth\User;
use App\Auth\User\Repository as UserRepository;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use DaveJamesMiller\Breadcrumbs\Generator as BreadcrumbGenerator;
use DaveJamesMiller\Breadcrumbs\Manager as BreadcrumbManager;
use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Routing\Router;
use URL;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerRoutePatterns($this->app['router'], $this->app);
        $this->registerAdminRoutes($this->app['router']);
        $this->registerApiRoutes($this->app['router']);
        $this->registerFrontRoutes($this->app['router']);
        $this->registerAdminBreadcrumbs($this->app['breadcrumbs']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers the route patterns.
     *
     * @param Router    $router    A router instance.
     * @param Container $container A dependency container implementation.
     *
     * @return void
     */
    protected function registerRoutePatterns(Router $router, Container $container)
    {
        $idRegex = $this->routePatternRegexes['id'];

        $router->pattern('user', $idRegex);

        $router->bind('user', function ($value) use ($container) {
            return $container->make(UserRepository::class)->findOrFail($value);
        });
    }

    /**
     * Registers admin panel routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerAdminRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'admin/users',
            'middleware' => ['web', 'auth', 'permissions'],
            'namespace' => 'App\Auth\Http\Controllers\Admin\User',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('', 'Controller@index');

            $router->get('create', 'Controller@create');
            $router->post('', 'Controller@store');

            $router->get('{user}/edit', 'Controller@edit');
            $router->put('{user}', 'Controller@update');

            $router->get('{user}/delete', 'Controller@confirmDelete');
            $router->delete('{user}', 'Controller@delete');
        });
    }

    /**
     * Registers admin panel routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontRoutes(RegistrarContract $router)
    {
        $attributes = [
            'middleware' => ['web', 'auth.front'],
            'namespace' => 'App\Auth\Http\Controllers\Front\User',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get(trans('routes.profileCompletion'), 'Controller@profileCompletion');
            $router->get(trans('routes.profile'), 'Controller@profile');
            $router->put(trans('routes.profile'), 'Controller@update');
            $router->get(trans('routes.resetProfile'), 'Controller@showResetProfile');
            $router->put(trans('routes.resetProfile'), 'Controller@resetProfile');
        });
    }

    /**
     * Registers API routes.
     *
     * @param Registrar $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1/users',
            'namespace' => 'App\Auth\Http\Controllers\Api\V1\User',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->post('register', 'Controller@register');
            $router->get('genders', 'Controller@genders');
            $router->get('age-ranges', 'Controller@ageRanges');
            $router->get('educations', 'Controller@educations');
            $router->get('countries', 'Controller@countries');
            $router->get('interests', 'Controller@interests');
            $router->get('relationship-statuses', 'Controller@relationshipStatuses');
            $router->get('work-statuses', 'Controller@workStatuses');
            $router->get('working-industries', 'Controller@workingIndustries');
            $router->get('parental-statuses', 'Controller@parentalStatuses');
            $router->get('timezones', 'Controller@timezones');
        });

        $attributes = [
            'prefix' => 'api/v1/users',
            'middleware' => ['api', 'auth'],
            'namespace' => 'App\Auth\Http\Controllers\Api\V1\User',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('me', 'Controller@show');
            $router->put('me', 'Controller@update');
            $router->put('complete-profile', 'Controller@completeProfile');
            $router->put('reset-profile', 'Controller@resetProfile');
            $router->get('sharing-buddies', 'Controller@sharingBuddies');
        });

        $attributes = [
            'prefix' => 'api/v1/users',
            'middleware' => ['api', 'auth', 'permissions'],
            'namespace' => 'App\Auth\Http\Controllers\Api\V1\User',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('', 'Controller@index');
            $router->post('{user}/actions/reset-password', 'Controller@resetPassword');
        });
    }

    /**
     * Registers breadcrumbs for the admin panel.
     *
     * @param BreadcrumbManager $breadcrumbs A breadcrumb manager.
     *
     * @return void
     */
    protected function registerAdminBreadcrumbs(BreadcrumbManager $breadcrumbs)
    {
        $breadcrumbs->register('admin::users', function (BreadcrumbGenerator $breadcrumbs) {
            $breadcrumbs->parent('admin::home');

            $url = URL::action('App\Auth\Http\Controllers\Admin\User\Controller@index');

            $breadcrumbs->push(trans('admin/navigation.users'), $url);
        });

        $breadcrumbs->register('admin::users.show', function (BreadcrumbGenerator $breadcrumbs, User $user) {
            $breadcrumbs->parent('admin::users');

            $breadcrumbs->push($user->full_name);
        });

        $breadcrumbs->register('admin::users.create', function (BreadcrumbGenerator $breadcrumbs) {
            $breadcrumbs->parent('admin::users');

            $url = URL::action('App\Auth\Http\Controllers\Admin\User\Controller@create');

            $breadcrumbs->push(trans('admin/users.titles.create'), $url);
        });

        $breadcrumbs->register('admin::users.edit', function (BreadcrumbGenerator $breadcrumbs, User $user) {
            $breadcrumbs->parent('admin::users.show', $user);

            $url = URL::action('App\Auth\Http\Controllers\Admin\User\Controller@edit', ['user' => $user->id]);

            $breadcrumbs->push(trans('admin/users.titles.edit'), $url);
        });

        $breadcrumbs->register('admin::users.delete', function (BreadcrumbGenerator $breadcrumbs, User $user) {
            $breadcrumbs->parent('admin::users.show', $user);

            $url = URL::action('App\Auth\Http\Controllers\Admin\User\Controller@confirmDelete', ['user' => $user->id]);

            $breadcrumbs->push(trans('admin/users.titles.delete'), $url);
        });
    }
}
