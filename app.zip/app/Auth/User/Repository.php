<?php

namespace App\Auth\User;

use App\Auth\Education\Repository as EducationRepository;
use App\Auth\Interest\Repository as InterestRepository;
use App\Auth\User;
use App\Auth\WorkingIndustry\Repository as WorkingIndustryRepository;
use App\WidgetTypes\WidgetType;
use Carbon\Carbon;
use Cartalyst\Sentinel\Sentinel;
use Hshn\Base64EncodedFile\HttpFoundation\File\Base64EncodedFile;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\UploadedFile;
use Laravel\Socialite\AbstractUser;
use Laravel\Socialite\Two\User as SocialiteUser;
use Stripe\Customer;

class Repository
{
    /**
     * A User model instance.
     *
     * @var User
     */
    protected $userModel;

    /**
     * A Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * A Education repository instance.
     *
     * @var EducationRepository
     */
    protected $educationRepository;

    /**
     * A Interest repository instance.
     *
     * @var InterestRepository
     */
    protected $interestRepository;

    /**
     * A Work industry repository instance.
     *
     * @var WorkingIndustryRepository
     */
    protected $workIndustryRepository;

    /**
     * @param User                      $userModel              A user model instance.
     * @param Sentinel                  $sentinel               A Sentinel instance.
     * @param EducationRepository       $educationRepository    A Education repository instance.
     * @param InterestRepository        $interestRepository     A Interest repository instance.
     * @param WorkingIndustryRepository $workIndustryRepository A Work industry repository instance.
     */
    public function __construct(
        User $userModel,
        Sentinel $sentinel,
        EducationRepository $educationRepository,
        InterestRepository $interestRepository,
        WorkingIndustryRepository $workIndustryRepository
    ) {
        $this->userModel = $userModel;
        $this->educationRepository = $educationRepository;
        $this->interestRepository = $interestRepository;
        $this->workIndustryRepository = $workIndustryRepository;
        $this->sentinel = $sentinel;
    }

    /**
     * Gets all users.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAll()
    {
        return $this->userModel->all();
    }

    /**
     * Gets sharing buddies of a passed user.
     *
     * @param User $user User instance.
     *
     * @return Collection
     */
    public function getSharingBuddies(User $user)
    {
        $userWidgets = $user->widgets->where('pivot.is_owner', true);
        $userDashboards = $user->dashboards->where('pivot.is_owner', true);

        return $this->userModel
            ->whereHas('widgets', function (Builder $query) use ($userWidgets) {
                $query->whereIn('user_widgets.widget_id', $userWidgets->pluck('id')->toArray())
                    ->where(['user_widgets.is_owner' => false]);
            })->orWhereHas('dashboards', function (Builder $query) use ($userDashboards) {
                $query->whereIn('user_dashboards.dashboard_id', $userDashboards->pluck('id')->toArray())
                    ->where(['user_dashboards.is_owner' => false]);
            })->get();
    }

    /**
     * Get users with max number of referrals.
     *
     * @param int $limit Limit of users to get.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getTopReferrers($limit = 10)
    {
        return $this->userModel
            ->withCount('referrals')
            ->orderBy('referrals_count', 'desc')
            ->whereHas('referrals')
            ->take($limit)
            ->get();
    }

    /**
     * Gets user by token.
     *
     * @param string $token Token string.
     *
     * @return User
     */
    public function findByToken($token)
    {
        return $this->userModel->where('auth_token', $token)->get()->first();
    }

    /**
     * Gets all users with the 'user' role and filters them by input.
     *
     * @param array     $inputData   The input data for filtering.
     * @param User|null $ignoredUser Optional user to ignore. This will usually be the currently authenticated user.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function filterByInput(array $inputData, User $ignoredUser = null)
    {
        $users = $this->userModel->whereHas('roles', function (Builder $query) {
            return $query->where(function (Builder $query) {
                return $query->orWhere('slug', 'user');
            });
        });

        if ($ignoredUser !== null) {
            $users->where('id', '<>', $ignoredUser->id);
        }

        if (isset($inputData['email']) && $inputData['email']) {
            $users->where(['email' => $inputData['email']]);

            return $users->get();
        }

        if (isset($inputData['gender']) &&
            !empty($inputData['gender'])
        ) {
            $users->whereIn('gender', $inputData['gender']);
        }

        if (isset($inputData['age_range']) &&
            !empty($inputData['age_range'])
        ) {
            $users->whereIn('age_range', $inputData['age_range']);
        }

        if (isset($inputData['work_status']) &&
            !empty($inputData['work_status'])
        ) {
            $users->whereIn('work_status', $inputData['work_status']);
        }

        if (isset($inputData['relationship_status']) &&
            !empty($inputData['relationship_status'])
        ) {
            $users->whereIn('relationship_status', $inputData['relationship_status']);
        }

        if (isset($inputData['parental_status']) &&
            !empty($inputData['parental_status'])
        ) {
            $users->whereIn('parental_status', $inputData['parental_status']);
        }

        if (isset($inputData['educations']) &&
            !empty($inputData['educations'])
        ) {
            $users->whereHas('educations', function (Builder $query) use ($inputData) {
                $query->whereIn('key', $inputData['educations']);
            });
        }

        if (isset($inputData['working_industries']) &&
            !empty($inputData['working_industries'])
        ) {
            $users->whereHas('workingIndustries', function (Builder $query) use ($inputData) {
                $query->whereIn('key', $inputData['working_industries']);
            });
        }

        if (isset($inputData['interests']) &&
            !empty($inputData['interests'])
        ) {
            $users->whereHas('interests', function (Builder $query) use ($inputData) {
                $query->whereIn('key', $inputData['interests']);
            });
        }

        if (isset($inputData['country_ids']) &&
            !empty($inputData['country_ids'])
        ) {
            $users->whereIn('country_id', $inputData['country_ids']);
        }

        return $users->get();
    }

    /**
     * Gets all users with the 'user' role by IDs.
     *
     * @param array $userIds The user IDs to find.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function findUsersByIds($userIds)
    {
        $users = $this->userModel->whereHas('roles', function (Builder $query) {
            return $query->where(function (Builder $query) {
                return $query->orWhere('slug', 'user');
            });
        });

        $users->whereIn('id', $userIds);

        return $users->get();
    }

    /**
     * Gets a user by email.
     *
     * @param string $email The email address.
     *
     * @return User
     */
    public function findByEmail($email)
    {
        return $this->userModel->where('email', $email)->get()->first();
    }

    /**
     * Gets a user by their Facebook ID.
     *
     * @param string $facebookId The Facebook ID to look for.
     *
     * @return User
     */
    public function findByFacebookId($facebookId)
    {
        return $this->userModel->where('facebook_id', $facebookId)->get()->first();
    }

    /**
     * Gets a user by their Google ID.
     *
     * @param string $googleId The Google ID to look for.
     *
     * @return User
     */
    public function findByGoogleId($googleId)
    {
        return $this->userModel->where('google_id', $googleId)->get()->first();
    }

    /**
     * Finds the user by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The user's ID.
     *
     * @return User
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->userModel->findOrFail($id);
    }

    /**
     * Gets user by a not completed activation code.
     *
     * @param string $activationCode Activation code.
     *
     * @return User|null
     */
    public function findByActivationCode($activationCode)
    {
        return $this->userModel
            ->select('users.*')
            ->join('activations', 'activations.user_id', '=', 'users.id')
            ->where('activations.code', $activationCode)
            ->where('activations.completed', 0)
            ->get()
            ->first();
    }

    /**
     * Gets all users with any of the specified roles.
     *
     * @param array $roles An array of role slugs. If empty, only users without roles will be returned.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getUsersWithAnyRoles(array $roles = [])
    {
        if (empty($roles)) {
            return $this->getUsersWithoutRoles();
        }

        // The nesting below may seem a bit weird, but it's actually there so as
        // to generate the correct query with regards to the grouping of `AND`
        // and `OR` conditions.
        return $this->userModel->whereHas('roles', function (Builder $query) use ($roles) {
            return $query->where(function (Builder $query) use ($roles) {
                foreach ($roles as $role) {
                    $query->orWhere('slug', $role);
                }

                return $query;
            });
        })->get();
    }

    /**
     * Gets users with given plan.
     *
     * @param  string $plan Plan.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getUsersWithPlan($plan)
    {
        return $this->userModel->whereAccountPlan($plan)->get();
    }

    /**
     * Returns all users that have no roles.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getUsersWithoutRoles()
    {
        return $this->userModel->withoutRoles()->get();
    }

    /**
     * Gets all admins.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAdmins()
    {
        // The nesting below may seem a bit weird, but it's actually there so as
        // to generate the correct query with regards to the grouping of `AND`
        // and `OR` conditions.
        return $this->userModel->whereHas('roles', function (Builder $query) {
            return $query->where(function (Builder $query) {
                return $query->orWhere('slug', 'admin');
            });
        })->get();
    }

    /**
     * Creates and activates a new user and returns it.
     *
     * @param array $inputData The input data for the new user.
     *
     * @return User
     */
    public function createAndActivate(array $inputData)
    {
        $userConfig = [
            'email' => array_get($inputData, 'email', ''),
            'password' => array_get($inputData, 'password', $this->generatePassword()),
            'first_name' => array_get($inputData, 'first_name', ''),
            'last_name' => array_get($inputData, 'last_name', ''),
        ];

        $user = $this->sentinel->registerAndActivate($userConfig);

        $user->save();

        $role = $this->sentinel->findRoleBySlug($inputData['role']);
        $role->users()->attach($user);

        return $user;
    }

    /**
     * Creates a new user and returns it.
     *
     * @param array $inputData The input data for the new user.
     *
     * @return User
     */
    public function create(array $inputData)
    {
        $userConfig = [
            'email' => array_get($inputData, 'email', ''),
            'password' => array_get($inputData, 'password', $this->generatePassword()),
            'first_name' => array_get($inputData, 'first_name', ''),
            'last_name' => array_get($inputData, 'last_name', ''),
            'referrer' => array_get($inputData, 'referrer', null),
            'account_plan' => User::ACCOUNT_PLAN_REGULAR,
        ];

        $user = $this->sentinel->register($userConfig);

        $user->save();

        if (isset($inputData['image_main'])) {
            if ($inputData['image_main'] instanceof UploadedFile) {
                $user->uploadImage($inputData['image_main'], 'main');
            } else {
                $file = new Base64EncodedFile($inputData['image_main']);
                $user->uploadImage($file->getPathname(), 'main');
            }

            $user->save();
        }

        $role = $this->sentinel->findRoleBySlug(array_get($inputData, 'role', 'user'));
        $role->users()->attach($user);

        return $user;
    }

    /**
     * Creates and activates a new user from social user and returns it.
     *
     * @param SocialiteUser $socialiteUser SocialiteUser instance.
     *
     * @return User
     */
    public function createFromSocialUser(AbstractUser $socialiteUser)
    {
        $socialName = $socialiteUser->getName();
        $nameSegments = explode(' ', $socialName);

        if (count($nameSegments) > 1) {
            $firstName = array_shift($nameSegments);
            $lastName = implode(' ', $nameSegments);
        } else {
            $firstName = $socialName;
            $lastName = '';
        }

        $userConfig = [
            'email' => $socialiteUser->getEmail(),
            'password' => $this->generatePassword(),
            'first_name' => $firstName,
            'last_name' => $lastName,
            'account_plan' => User::ACCOUNT_PLAN_REGULAR,
        ];

        $user = $this->sentinel->registerAndActivate($userConfig);

        $user->save();

        $role = $this->sentinel->findRoleBySlug('user');
        $role->users()->attach($user);

        return $user;
    }

    /**
     * Updates the passed user and returns it.
     *
     * @param User  $user      The user to update.
     * @param array $inputData Input data for the update.
     *
     * @return User
     */
    public function update(User $user, array $inputData)
    {
        $userConfig = [
            'email' => array_get($inputData, 'email', $user->email),
            'first_name' => array_get($inputData, 'first_name', $user->first_name),
            'last_name' => array_get($inputData, 'last_name', $user->last_name),
            'timezone' => array_get($inputData, 'timezone', $user->timezone),
        ];

        if (!empty($inputData['password'])) {
            $userConfig['password'] = $inputData['password'];
        }

        if (isset($inputData['image_main'])) {
            if ($inputData['image_main'] instanceof UploadedFile) {
                $user->uploadImage($inputData['image_main'], 'main');
            } else {
                $file = new Base64EncodedFile($inputData['image_main']);
                $user->uploadImage($file->getPathname(), 'main');
            }
        }

        $this->sentinel->update($user, $userConfig);

        if (!empty($inputData['role'])) {
            $role = $this->sentinel->findRoleBySlug($inputData['role']);
            $user->roles()->sync([$role->id]);
        }

        return $user;
    }

    /**
     * Completes a profile.
     *
     * @param User  $user      The user to update.
     * @param array $inputData Input data for the update.
     *
     * @return User
     */
    public function completeProfile(User $user, array $inputData)
    {
        $user->gender = array_get($inputData, 'gender', $user->gender);
        $user->age_range = array_get($inputData, 'age_range', $user->age_range);
        $user->country_id = array_get($inputData, 'country_id', $user->country_id);
        $user->work_status = array_get($inputData, 'work_status', $user->work_status);
        $user->relationship_status = array_get($inputData, 'relationship_status', $user->relationship_status);
        $user->parental_status = array_get($inputData, 'parental_status', $user->parental_status);

        if (isset($inputData['educations']) && !empty($inputData['educations'])) {
            $this->educationRepository->syncEducations($user, $inputData['educations']);
        }

        if (isset($inputData['interests']) && !empty($inputData['interests'])) {
            $this->interestRepository->syncInterests($user, $inputData['interests']);
        }

        if (isset($inputData['working_industries']) && !empty($inputData['working_industries'])) {
            $this->workIndustryRepository->syncWorkingIndustries($user, $inputData['working_industries']);
        }

        $user->save();

        return $user;
    }

    /**
     * Deletes the passed user from the system.
     *
     * @param User $user The user to delete.
     *
     * @return bool|null
     */
    public function delete(User $user)
    {
        return $user->delete();
    }

    /**
     * Partialy updates the passed user and returns it.
     *
     * Same as the regular update, but doesn't ever update the password, no
     * matter what's passed in the input data.
     *
     * @param User  $user      The user to update.
     * @param array $inputData Input data for the update.
     *
     * @return User
     */
    public function partialUpdate(User $user, array $inputData)
    {
        $userConfig = [
            'email' => $inputData['email'],
            'first_name' => $inputData['first_name'],
            'last_name' => $inputData['last_name'],
        ];

        $this->sentinel->update($user, $userConfig);

        return $user;
    }

    /**
     * Marks user as completed profile.
     *
     * @param User $user User instance.
     *
     * @return User
     */
    public function markProfileCompleted(User $user)
    {
        $user->profile_completed = true;
        $user->save();

        return $user;
    }

    /**
     * Attaches a stripe customer data to a user.
     *
     * @param  User  $user         User instance.
     * @param  array $customerData Stripe customer data.
     *
     * @return User
     */
    public function attachStripeCustomerDataToUser(User $user, array $customerData)
    {
        $user->stripe_customer_id = $customerData['stripe_customer_id'];
        $user->stripe_card_brand = $customerData['stripe_card_brand'];
        $user->stripe_card_last4 = $customerData['stripe_card_last4'];

        $user->save();

        return $user;
    }

    /**
     * Detaches a stripe customer data from a user.
     *
     * @param User $user User instance.
     *
     * @return User
     */
    public function dettachStripeCustomerDataToUser(User $user)
    {
        $user->stripe_customer_id = null;
        $user->stripe_card_brand = null;
        $user->stripe_card_last4 = null;

        $user->save();

        return $user;
    }

    /**
     * Subscribes a user to a PRO plan.
     *
     * @param User   $user     User instance.
     * @param string $duration Duration string.
     *
     * @return User
     */
    public function subscribeToPro($user, $duration)
    {
        $user->subscribed_to_pro = true;
        $user->subscription_duration = $duration;

        $user->save();

        return $user;
    }

    /**
     * Unsubscribes a user from a PRO plan.
     *
     * @param User $user User instance.
     *
     * @return User
     */
    public function unsubscribeFromPro(User $user)
    {
        $user->subscribed_to_pro = false;
        $user->subscription_duration = null;

        $user->save();

        return $user;
    }

    /**
     * Unsubscribes user from a widget type.
     *
     * @param User       $user       User instance.
     * @param WidgetType $widgetType Widget type instance.
     *
     * @return User
     */
    public function unsubscribeFromWidgetType(User $user, WidgetType $widgetType)
    {
        $user->subscribedWidgetTypes()->detach($widgetType->id);

        return $user;
    }

    /**
     * Upgrades a user to PRO.
     *
     * @param  User $user User instance.
     *
     * @return User
     */
    public function upgrateToPro($user)
    {
        $user->account_plan = User::ACCOUNT_PLAN_PRO;
        $user->save();

        return $user;
    }

    /**
     * Downgrades a user to REGULAR.
     *
     * @param  User $user User instance.
     *
     * @return User
     */
    public function downgradeToRegular($user)
    {
        $user->account_plan = User::ACCOUNT_PLAN_REGULAR;
        $user->save();

        return $user;
    }

    /**
     * Adds free months to total count of free months for user.
     *
     * @param User    $user            User instance.
     * @param integer $freeMonthsCount Free month count.
     *
     * @return User
     */
    public function addFreeMonths(User $user, $freeMonthsCount)
    {
        $user->free_months_count = $user->free_months_count + $freeMonthsCount;
        $user->save();

        return $user;
    }

    /**
     * Sub free months.
     *
     * @param User $user User instance.
     *
     * @return User
     */
    public function subFreeMonth(User $user)
    {
        $user->free_months_count = $user->free_months_count - 1;
        $user->save();

        return $user;
    }

    /**
     * Changes the password for a user and returns it.
     *
     * @param User   $user     The user whose password should be updated.
     * @param string $password The new password.
     *
     * @return User
     */
    public function setPassword(User $user, $password)
    {
        $credentials = [
            'password' => $password,
        ];

        $this->sentinel->update($user, $credentials);

        return $user;
    }

    /**
     * Updates a user's auth token if needed.
     *
     * An auth token update is needed only when the auth token has expired.
     *
     * @param User $user The user whose token should be updated.
     *
     * @return bool
     */
    public function touch(User $user)
    {
        if ($user->isAuthTokenExpired()) {
            return $this->updateAuthToken($user);
        }

        return true;
    }

    /**
     * Generates a new auth token for a user, and updates their timestamp.
     *
     * @param User $user The user whose token should be updated.
     *
     * @return bool
     */
    protected function updateAuthToken(User $user)
    {
        $user->auth_token = $this->generateAuthToken();
        $user->auth_token_updated_at = Carbon::now();

        return $user->save();
    }

    /**
     * Generates a cryptographically secure token for accessing the API.
     *
     * @return string
     */
    protected function generateAuthToken()
    {
        return bin2hex(openssl_random_pseudo_bytes(64));
    }

    /**
     * Generates a numeric password with a specific length.
     *
     * The default length is 6 digits.
     *
     * This is not meant to be secure in any way.
     *
     * @param int $length The length of the generated password.
     *
     * @return string
     */
    public function generatePassword($length = 6)
    {
        $pool = '0123456789';

        return substr(str_shuffle(str_repeat($pool, $length)), 0, $length);
    }
}
