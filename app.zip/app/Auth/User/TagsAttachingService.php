<?php

namespace App\Auth\User;

use App\Auth\Events\AnswersEdited;
use App\Auth\Events\ProfileCompleted;
use App\Auth\User;
use App\InterestTags\InterestTag\Repository as InterestTagRepository;
use Illuminate\Config\Repository as Config;

class TagsAttachingService
{
    /**
     * A Interest tags repository instance.
     *
     * @var interestTagRepository
     */
    protected $interestTagRepository;

    /**
     * A Config repository instance.
     *
     * @var Config
     */
    protected $config;

    /**
     * @param InterestTagRepository $interestTagRepository A interest tags repository instance.
     * @param Config                $config                A config repository instance.
     */
    public function __construct(InterestTagRepository $interestTagRepository, Config $config)
    {
        $this->interestTagRepository = $interestTagRepository;
        $this->config = $config;
    }

    /**
     * Attaches tags to a user instance, based on opt in form fields.
     *
     * @param User $user User instance.
     *
     * @return User
     */
    public function attachProfileTags(User $user)
    {
        $tags = [];

        if ($user->gender) {
            $propertyTags = $this->config->get('user.genders')[$user->gender]['tags'];
            $tags = array_merge($tags, $propertyTags);
        }

        if ($user->age_range) {
            $propertyTags = $this->config->get('user.ageRanges')[$user->age_range]['tags'];
            $tags = array_merge($tags, $propertyTags);
        }

        if ($user->work_status) {
            $propertyTags = $this->config->get('user.workStatuses')[$user->work_status]['tags'];
            $tags = array_merge($tags, $propertyTags);
        }

        if ($user->relationship_status) {
            $propertyTags = $this->config->get('user.relationshipStatuses')[$user->relationship_status]['tags'];
            $tags = array_merge($tags, $propertyTags);
        }

        if ($user->parental_status) {
            $propertyTags = $this->config->get('user.parentalStatuses')[$user->parental_status]['tags'];
            $tags = array_merge($tags, $propertyTags);
        }

        if (!$user->educations->isEmpty()) {
            $propertyTags = [];

            foreach ($user->educations as $education) {
                $educationTags = $this->config->get('user.educations')[$education->key]['tags'];
                $propertyTags = array_merge($propertyTags, $educationTags);
            }

            $tags = array_merge($tags, $propertyTags);
        }

        if (!$user->interests->isEmpty()) {
            $propertyTags = [];

            foreach ($user->interests as $interest) {
                $interestTags = $this->config->get('user.interests')[$interest->key]['tags'];
                $propertyTags = array_merge($propertyTags, $interestTags);
            }

            $tags = array_merge($tags, $propertyTags);
        }

        if (!$user->workingIndustries->isEmpty()) {
            $propertyTags = [];

            foreach ($user->workingIndustries as $workingIndustry) {
                $workingIndustryTags = $this->config->get('user.workingIndustries')[$workingIndustry->key]['tags'];
                $propertyTags = array_merge($propertyTags, $workingIndustryTags);
            }

            $tags = array_merge($tags, $propertyTags);
        }

        $tags = array_unique($tags);

        $interestTags = $this->interestTagRepository->getByTitleAndCreateNonExistent($tags);
        $interestTagsIds = $interestTags->pluck('id')->toArray();

        if (!$user->profile_completed) {
            // If user already has interest tags it will be from facebook sign
            // in. We will detach those tags and attach them without
            // `source_facebook` flag on pivot table so it will be used in
            // suggesting dashboards.
            $facebookInterestTagsIds = $user->interestTags->pluck('id')->toArray();
            $tagsForDetaching = array_intersect($facebookInterestTagsIds, $interestTagsIds);

            if (!empty($tagsForDetaching)) {
                $user->interestTags()->detach($tagsForDetaching);
            }

            $user->interestTags()->attach($interestTagsIds);

            event(new ProfileCompleted($user));
        } else {
            // Detach all non `source_facebook` tags.
            $nonFacebookTagsIds = $user->interestTags->where('pivot.source_facebook', 0)->pluck('id')->toArray();

            if (!empty($nonFacebookTagsIds)) {
                $user->interestTags()->detach($nonFacebookTagsIds);
            }

            // If there is any tag left in a facebook provided tags, that is
            // present in new set, detach it.
            $facebookInterestTagsIds = $user->interestTags->where('pivot.source_facebook', 1)->pluck('id')->toArray();
            $tagsForDetaching = array_intersect($facebookInterestTagsIds, $interestTagsIds);

            if (!empty($tagsForDetaching)) {
                $user->interestTags()->detach($tagsForDetaching);
            }

            // And finally attach new set of tags.
            $user->interestTags()->attach($interestTagsIds);

            event(new AnswersEdited($user));
        }
    }
}
