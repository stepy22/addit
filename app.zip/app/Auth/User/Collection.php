<?php

namespace App\Auth\User;

use App\Auth\User;
use Creitive\Database\Eloquent\Collection as BaseCollection;

class Collection extends BaseCollection
{
    /**
     * Returns an array with the users' full names, keyed by their email
     * addresses.
     *
     * @return array
     */
    public function toEmailAndFullName()
    {
        return $this->toKeyedArray(
            function (User $user) {
                return $user->email;
            },
            function (User $user) {
                return $user->full_name;
            }
        );
    }
}
