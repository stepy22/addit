<?php

namespace App\Auth\User;

use App\Auth\Events\FacebookGroupsInterestTagsAttached;
use App\Auth\User;
use App\Auth\User\MessageManager as UserMessageManager;
use App\Auth\User\Repository as UserRepository;
use App\FacebookGroups\Group\Repository as FacebookGroupRepository;
use Cartalyst\Sentinel\Activations\EloquentActivation as Activation;
use Creitive\Api\Exceptions\InvalidFacebookIdException;
use Creitive\Api\Exceptions\InvalidFacebookTokenException;
use Creitive\Facebook\Facebook;
use Creitive\Google\Google;
use Illuminate\Contracts\Mail\Mailer;
use URL;

class Manager
{
    /**
     * Facebook API instance.
     *
     * @var Facebook
     */
    protected $facebookApiClient;

    /**
     * Google API instance.
     *
     * @var Google
     */
    protected $googleApiClient;

    /**
     * Facebook groups repository instance.
     *
     * @var FacebookGroupRepository
     */
    protected $facebookGroupRepository;

    /**
     * User repository instance.
     *
     * @var UserRepository
     */
    protected $userRepository;

    /**
     * User message manager instance.
     *
     * @var UserMessageManager
     */
    protected $userMessageManager;

    /**
     * @param Facebook                $facebookApiClient       Facebook API instance.
     * @param Google                  $googleApiClient         Google API instance.
     * @param FacebookGroupRepository $facebookGroupRepository Facebook groups repository instance.
     * @param UserRepository          $userRepository          User repository instance.
     * @param UserMessageManager      $userMessageManager      User message manager.
     */
    public function __construct(
        Facebook $facebookApiClient,
        Google $googleApiClient,
        FacebookGroupRepository $facebookGroupRepository,
        UserRepository $userRepository,
        UserMessageManager $userMessageManager
    ) {
        $this->userRepository = $userRepository;
        $this->facebookApiClient = $facebookApiClient;
        $this->googleApiClient = $googleApiClient;
        $this->facebookGroupRepository = $facebookGroupRepository;
        $this->userMessageManager = $userMessageManager;
    }

    /**
     * Attaches interest tags by facebook groups.
     *
     * @param  User   $user        User instance.
     * @param  string $accessToken Access token.
     *
     * @return Void
     */
    public function attachInterestTagsByFacebookLikes($user, $accessToken)
    {
        // Get user's likes.
        $groupsData = $this->facebookApiClient->getLikes($accessToken);
        $groupsArray = array_get($groupsData, 'data', []);

        $facebookIds = $groupsArray;

        array_map(function ($item) {
            return $item['id'];
        }, $facebookIds);

        $existingGroups = $this->facebookGroupRepository->getByFacebookIds($facebookIds);
        $this->facebookGroupRepository->batchCreate($groupsArray);

        $tagsIds = [];

        foreach ($existingGroups as $group) {
            $tagsIds = array_merge($tagsIds, $group->interestTags->pluck('id')->toArray());
        }

        $tagsIds = array_unique($tagsIds);
        $formattedTagIds = [];

        foreach ($tagsIds as $id) {
            $formattedTagIds[$id] = ['source_facebook' => true];
        }

        $user->interestTags()->attach($formattedTagIds);

        // If user's profile is completed and later connected to facebook this event is fired.
        if ($user->profile_completed) {
            event(new FacebookGroupsInterestTagsAttached($user));
        }
    }

    /**
     * Handles Google login/registration
     *
     * @param string $idToken Google ID token.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function handleGoogleSignInViaAPI($idToken)
    {
        $payload = $this->googleApiClient->getProfileData($idToken);

        // User is already registered via Facebook.
        $user = $this->userRepository->findByGoogleId($payload['sub']);

        if ($user) {
            $this->userRepository->touch($user);

            return $this->getSuccessfulRegistrationResponse($user);
        }

        // User is registered via email but not via Google. In this case we
        // only need to connect their accounts.
        $user = $this->userRepository->findByEmail($payload['email']);

        if ($user) {
            $user->google_id = $payload['sub'];
            $user->save();

            $this->userRepository->touch($user);

            return $this->getSuccessfulRegistrationResponse($user);
        }

        $inputData = [];

        $inputData['email'] = $payload['email'];
        $inputData['first_name'] = $payload['given_name'];
        $inputData['last_name'] = $payload['family_name'];
        $inputData['google_id'] = $payload['sub'];

        $user = $this->userRepository->create($inputData);
        $this->userRepository->touch($user);
        $this->userMessageManager->sendWelcomeMail($user);

        return $this->getSuccessfulRegistrationResponse($user);
    }

    /**
     * Handles facebook login/registration
     *
     * @param Input data $inputData Input data array.
     *
     * @return \Illuminate\Http\RedirectResponse
     *
     * @throws InvalidFacebookIdException
     * @throws InvalidFacebookTokenException
     */
    public function handleFacebookSignInViaAPI($inputData)
    {
        $facebookUserData = $this->facebookApiClient->getProfileData($inputData['access_token']);

        if (!$facebookUserData) {
            throw new InvalidFacebookTokenException;
        }

        $inputData['email'] = $facebookUserData->getEmail();

        if ($facebookUserData->getId() !== $inputData['facebook_id']) {
            throw new InvalidFacebookIdException;
        }

        // User is already registered via Facebook.
        $user = $this->userRepository->findByFacebookId($inputData['facebook_id']);

        if ($user) {
            $this->userRepository->touch($user);

            return $this->getSuccessfulRegistrationResponse($user);
        }

        // User is registered via email but not via Facebook. In this case we
        // only need to connect their accounts.
        $user = $this->userRepository->findByEmail($inputData['email']);

        if ($user) {
            $user->facebook_id = $inputData['facebook_id'];

            $user->save();
            $this->attachInterestTagsByFacebookLikes($user, $inputData['access_token']);
            $this->userRepository->touch($user);

            return $this->getSuccessfulRegistrationResponse($user);
        }

        $inputData['first_name'] = $facebookUserData->getFirstName();
        $inputData['last_name'] = $facebookUserData->getLastName();
        $inputData['role'] = 'user';

        $user = $this->userRepository->create($inputData);

        $this->userRepository->touch($user);
        $this->attachInterestTagsByFacebookLikes($user, $inputData['access_token']);
        $this->userMessageManager->sendWelcomeMail($user);

        return $this->getSuccessfulRegistrationResponse($user);
    }

    /**
     * Get successful registration response.
     *
     * @param  User   $user [description]
     * @return \Illuminate\Http\Response
     */
    protected function getSuccessfulRegistrationResponse(User $user)
    {
        return response([
            'token' => $user->auth_token,
            'profile_completed' => $user->profile_completed,
        ], 201);
    }
}
