<?php

namespace App\Auth\User;

use App\Auth\User;
use Cartalyst\Sentinel\Activations\EloquentActivation as Activation;
use Illuminate\Contracts\Mail\Mailer;
use URL;

class MessageManager
{
    /**
     * A Mailer instance.
     *
     * @var Mailer
     */
    protected $mailer;

    /**
     * @param Mailer $mailer Mailer class instance.
     */
    public function __construct(Mailer $mailer)
    {
        $this->mailer = $mailer;
    }

    /**
     * Sends an activation email to the newly registered user.
     *
     * @param User               $user       User instance.
     * @param EloquentActivation $activation Activation instance.
     *
     * @return void
     */
    public function sendActivationMail(User $user, Activation $activation)
    {
        $data = [
            'full_name' => $user->full_name,
            'url' => URL::action(
                'App\Auth\Http\Controllers\Front\Activation\Controller@activate',
                [
                    'activationCode' => $activation->code,
                ]
            ),
        ];

        $this->mailer->send(
            'emails.auth.activation',
            $data,
            function ($message) use ($user) {
                $message
                    ->to($user->email, $user->full_name)
                    ->subject(trans('activations.email.subject'));
            }
        );
    }

    /**
     * Sends referral completed email.
     *
     * @param User $referrer     Referrer user instance.
     * @param User $referredUser Referred user instance.
     *
     * @return void
     */
    public function sendReferralAcquiredMail(User $referrer, User $referredUser)
    {
        $data = [
            'referredUser' => $referredUser,
        ];

        $this->mailer->send(
            'emails.auth.referral-acquired',
            $data,
            function ($message) use ($referrer) {
                $message
                    ->to($referrer->email, $referrer->full_name)
                    ->subject(trans('emails/auth/referralAcquired.subject'));
            }
        );
    }

    /**
     * Sends welcome message to a user.
     *
     * @param User $user User instance.
     *
     * @return void
     */
    public function sendWelcomeMail(User $user)
    {
        $data = [
            'user' => $user,
        ];

        $this->mailer->send(
            'emails.auth.welcome',
            $data,
            function ($message) use ($user) {
                $message
                    ->to($user->email, $user->full_name)
                    ->subject(trans('emails/auth/welcome.subject'));
            }
        );
    }
}
