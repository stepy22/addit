<?php

namespace App\Auth\Education;

use App\Auth\Education;
use App\Auth\User;
use Cartalyst\Support\Collection;

class Repository
{
    /**
     * A Education model instance.
     *
     * @var Education
     */
    protected $educationModel;

    /**
     * @param Education $educationModel A user model instance.
     */
    public function __construct(Education $educationModel)
    {
        $this->educationModel = $educationModel;
    }

    /**
     * Attach new and detach existing educations from user.
     *
     * @param User  $user      User instance.
     * @param array $inputData Input data array.
     *
     * @return Collection
     */
    public function syncEducations(User $user, array $inputData)
    {
        $educationsForDeletion = [];
        $educationsForCreation = [];
        $existingEducations = [];

        $submitedEducations = array_map(function ($item) {
            return $item['key'];
        }, $inputData);

        foreach ($user->educations as $userEducation) {
            if (!in_array($userEducation->key, $submitedEducations)) {
                $educationsForDeletion[] = $userEducation->key;
            } else {
                $existingEducations[] = $userEducation->key;
            }
        }

        $educationsForCreation = array_diff($submitedEducations, $educationsForDeletion);
        $educationsForCreation = array_diff($submitedEducations, $existingEducations);

        $this->educationModel
            ->where('user_id', $user->id)
            ->whereIn('key', $educationsForDeletion)
            ->delete();

        $createdEducations = collect();

        foreach ($educationsForCreation as $educationForCreation) {
            $education = $this->educationModel->newInstance();

            $education->user_id = $user->id;
            $education->key = $educationForCreation;

            $education->save();

            $createdEducations->push($education);
        }

        return $createdEducations;
    }
}
