<?php

namespace App\Auth;

use App\WidgetTypes\WidgetType;
use Creitive\Database\Eloquent\Model;

class Subscription extends Model
{
    /**
     * Duration constants. Duration is chosen only for pro account subscription
     * type, widget type subscription is available only for one month period.
     */
    const DURATION_MONTHLY = 'monthly';
    const DURATION_YEARLY = 'yearly';

    /**
     * Subscription types constants.
     */
    const TYPE_PRO_ACCOUNT = 'pro_account';
    const TYPE_WIDGET_TYPE = 'widget_type';

    /**
     * {@inheritDoc}
     */
    protected $casts = [
        'paid' => 'bool',
        'notified' => 'bool',
        'billing_failed' => 'bool',
        'active' => 'bool',
    ];

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = ['starts_at', 'ends_at'];

    /**
     * Eloquent relation: Subscription belongs to a user.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Eloquent relation: Subscription may have one widget type.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function widgetType()
    {
        return $this->belongsTo(WidgetType::class);
    }
}
