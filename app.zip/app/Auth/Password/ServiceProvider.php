<?php

namespace App\Auth\Password;

use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Creitive\Routing\LocaleResolver;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerFrontApiRoutes($this->app['router']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers front API routes.
     *
     * @param RegistrarContract $router Registrar instance.
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => '/api/v1/password',
            'middleware' => ['api', 'auth'],
            'namespace' => 'App\Auth\Http\Controllers\Api\V1\Password',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->post('', 'Controller@update');
        });
    }
}
