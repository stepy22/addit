<?php

namespace App\Auth\Subscription;

use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Creitive\Routing\LocaleResolver;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerFrontRoutes($this->app['router']);
        $this->registerFrontApiRoutes($this->app['router']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers front routes.
     *
     * @param RegistrarContract $router Registrar instance.
     * @return void
     */
    protected function registerFrontRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => trans('routes.subscriptions'),
            'middleware' => ['web', 'auth.front'],
            'namespace' => 'App\Auth\Http\Controllers\Front\Subscription',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('', 'Controller@index');
            // These routes are not language specific since they're not get
            // routes, and they're all redirect back to index method.
            $router->post('save-card', 'Controller@saveCard');
            $router->delete('delete-card', 'Controller@deleteCard');
            $router->post('subscribe', 'Controller@subscribe');
            $router->post('unsubscribe', 'Controller@unsubscribe');
        });
    }

    /**
     * Registers front API routes.
     *
     * @param RegistrarContract $router Registrar instance.
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1/subscriptions',
            'middleware' => ['api', 'auth.front'],
            'namespace' => 'App\Auth\Http\Controllers\Api\V1\Subscription',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('', 'Controller@index');
            $router->post('subscribe', 'Controller@subscribe');
            $router->post('unsubscribe', 'Controller@unsubscribe');
        });
    }
}
