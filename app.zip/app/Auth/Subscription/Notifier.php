<?php

namespace App\Auth\Subscription;

use App\Auth\Mail\BilledForSubscription;
use App\Auth\Mail\ExpiringSubscription;
use App\Auth\Mail\FreeMonthsUsed;
use App\Auth\Mail\SubscriptionBillingFailed;
use App\Auth\Subscription;
use App\Jobs\NotifyUser;
use App\Notifications\Notification;
use App\Notifications\Notification\Notifier as BaseNotifier;
use Illuminate\Contracts\Mail\Mailer;
use URL;

class Notifier
{
    /**
     * A Mailer instance.
     *
     * @var Mailer
     */
    protected $mailer;

    /**
     * A base notifier service..
     *
     * @var BaseNotifier
     */
    protected $baseNotifier;

    /**
     * @param Mailer       $mailer       Mailer class instance.
     * @param BaseNotifier $baseNotifier Base notifier instance.
     */
    public function __construct(Mailer $mailer, BaseNotifier $baseNotifier)
    {
        $this->mailer = $mailer;
        $this->baseNotifier = $baseNotifier;
    }

    /**
     * Notifies a user about expiring subscription.
     *
     * @param Subscription $subscription Subscription instance.
     *
     * @return void
     */
    public function notify(Subscription $subscription)
    {
        $this->mailer->queue(new ExpiringSubscription($subscription));

        if ($subscription->widget_type_id) {
            $notificationMessage = trans('subscriptions.notifications.'.Notification::TYPE_SUBSCRIPTION_EXPIRING.'.widgetType', [
                'endDate' => $subscription->ends_at->setTimezone($subscription->user->timezone)->format(trans('common.dateFormat')),
                'widgetType' => $subscription->widgetType->name,
            ]);
        } else {
            $notificationMessage = trans('subscriptions.notifications.'.Notification::TYPE_SUBSCRIPTION_EXPIRING.'.proAccount', [
                'endDate' => $subscription->ends_at->setTimezone($subscription->user->timezone)->format(trans('common.dateFormat')),
            ]);
        }

        NotifyUser::dispatch(
            $this->baseNotifier,
            $notificationMessage,
            Notification::TYPE_SUBSCRIPTION_EXPIRING,
            $subscription->user,
            null,
            URL::action('App\Auth\Http\Controllers\Front\Subscription\Controller@index', [], false)
        );
    }

    /**
     * Notifies a user about failed subscription billing.
     *
     * @param Subscription $subscription Subscription instance.
     *
     * @return void
     */
    public function notifyBillingFailed(Subscription $subscription)
    {
        $this->mailer->queue(new SubscriptionBillingFailed($subscription));

        if ($subscription->widget_type_id) {
            $notificationMessage = trans('subscriptions.notifications.'.Notification::TYPE_SUBSCRIPTION_BILLING_FAILED.'.widgetType', [
                'widgetType' => $subscription->widgetType->name,
            ]);
        } else {
            $notificationMessage = trans('subscriptions.notifications.'.Notification::TYPE_SUBSCRIPTION_BILLING_FAILED.'.proAccount', [
                'duration' => $subscription->duration,
            ]);
        }

        NotifyUser::dispatch(
            $this->baseNotifier,
            $notificationMessage,
            Notification::TYPE_SUBSCRIPTION_BILLING_FAILED,
            $subscription->user,
            null,
            URL::action('App\Auth\Http\Controllers\Front\Subscription\Controller@index', [], false)
        );
    }

    /**
     * Notifies a user about subscription billing.
     *
     * @param Subscription $subscription Subscription instance.
     *
     * @return void
     */
    public function notifyBilled(Subscription $subscription)
    {
        $this->mailer->queue(new BilledForSubscription($subscription));

        if ($subscription->widget_type_id) {
            $notificationMessage = trans('subscriptions.notifications.'.Notification::TYPE_SUBSCRIPTION_CHARGED.'.widgetType', [
                'widgetType' => $subscription->widgetType->name,
            ]);
        } else {
            $notificationMessage = trans('subscriptions.notifications.'.Notification::TYPE_SUBSCRIPTION_CHARGED.'.proAccount', [
                'duration' => $subscription->duration,
            ]);
        }

        NotifyUser::dispatch(
            $this->baseNotifier,
            $notificationMessage,
            Notification::TYPE_SUBSCRIPTION_CHARGED,
            $subscription->user,
            null,
            URL::action('App\Auth\Http\Controllers\Front\Subscription\Controller@index', [], false)
        );
    }

    /**
     * Notifies a user that their subscription is paid with free months.
     *
     * @param Subscription $subscription Subscription instance.
     *
     * @return void
     */
    public function notifyFreeMonthUsed(Subscription $subscription)
    {
        $this->mailer->queue(new FreeMonthsUsed($subscription));

        NotifyUser::dispatch(
            $this->baseNotifier,
            trans('subscriptions.notifications.'.Notification::TYPE_SUBSCRIPTION_FREE_MONTHS_USED, [
                'startDate' => $subscription->starts_at->setTimezone($subscription->user->timezone)->format(trans('common.dateFormat')),
                'endDate' => $subscription->ends_at->setTimezone($subscription->user->timezone)->format(trans('common.dateFormat')),
            ]),
            Notification::TYPE_SUBSCRIPTION_FREE_MONTHS_USED,
            $subscription->user,
            null,
            URL::action('App\Auth\Http\Controllers\Front\Subscription\Controller@index', [], false)
        );
    }
}
