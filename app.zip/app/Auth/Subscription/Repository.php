<?php

namespace App\Auth\Subscription;

use App\Auth\Subscription;
use App\Auth\User;
use App\Transactions\Transaction;
use App\Transactions\Transaction\Repository as TransactionRepository;
use Carbon\Carbon;
use Cartalyst\Support\Collection;
use Creitive\Stripe\Stripe;

class Repository
{
    /**
     * A Subscription model instance.
     *
     * @var Subscription
     */
    protected $subscriptionModel;

    /**
     * @param Subscription $subscriptionModel A subscription model instance.
     */
    public function __construct(Subscription $subscriptionModel)
    {
        $this->subscriptionModel = $subscriptionModel;
    }

    /**
     * Create pro subscription.
     *
     * This may never be used, we thought that it might come in handy to have
     * separate functions for creating subscription and creating it and
     * activating it right away.
     *
     * @param  User   $user                 User instance.
     * @param  string $subscriptionDuration Subscription duration.
     * @return Subscription
     */
    public function createProSubscription(User $user, $subscriptionDuration)
    {
        $subscription = $this->subscriptionModel->newInstance();

        $subscription->user_id = $user->id;
        $subscription->starts_at = Carbon::now();
        $subscription->duration = $subscriptionDuration;

        if ($subscriptionDuration === Subscription::DURATION_MONTHLY) {
            $subscription->ends_at = Carbon::now()->addMonths(1);
        } else {
            $subscription->ends_at = Carbon::now()->addYears(1);
        }

        $subscription->save();

        return $subscription;
    }

    /**
     * Create pro subscription and activate it.
     *
     * @param  User   $user                 User instance.
     * @param  string $subscriptionDuration Subscription duration.
     *
     * @return Subscription
     */
    public function createProSubscriptionAndActivate(User $user, $subscriptionDuration)
    {
        $subscription = $this->createProSubscription($user, $subscriptionDuration);

        $subscription->active = true;

        $subscription->save();

        return $subscription;
    }

    /**
     * Creates a widget type subscription.
     *
     * @param User $user            User instance.
     * @param int  $widgetTypeId    Widget type ID.
     * @param int  $widgetTypePrice Widget type price.
     *
     * @return Subscription
     */
    public function createWidgetTypeSubscription(User $user, $widgetTypeId, $widgetTypePrice)
    {
        $subscription = $this->subscriptionModel->newInstance();

        $subscription->user_id = $user->id;
        $subscription->starts_at = Carbon::now();
        $subscription->ends_at = Carbon::now()->addMonths(1);
        $subscription->widget_type_id = $widgetTypeId;
        $subscription->duration = Subscription::DURATION_MONTHLY;
        $subscription->price = $widgetTypePrice;

        $subscription->save();

        return $subscription;
    }

    /**
     * Create widget type subscription and activate it.
     *
     * @param User $user            User instance.
     * @param int  $widgetTypeId    Widget type id.
     * @param int  $widgetTypePrice Widget type price.
     *
     * @return Subscription
     */
    public function createWidgetTypeSubscriptionAndActivate(User $user, $widgetTypeId, $widgetTypePrice)
    {
        $subscription = $this->createWidgetTypeSubscription($user, $widgetTypeId, $widgetTypePrice);

        $subscription->active = true;

        $subscription->save();

        return $subscription;
    }

    /**
     * Removes all active subscriptions for a passed widget type id.
     *
     * @param int $widgetTypeId Widget type id.
     *
     * @return void
     */
    public function removeActiveWidgetTypeSubscription($widgetTypeId)
    {
        $this->subscriptionModel
            ->where([
                'widget_type_id' => $widgetTypeId,
                'active' => 1,
            ])
            ->delete();
    }

    /**
     * Marks subscription as notified.
     *
     * @param Subscription $subscription Subscription instance.
     *
     * @return Subscription
     */
    public function markNotified(Subscription $subscription)
    {
        $subscription->notified = 1;
        $subscription->save();

        return $subscription;
    }

    /**
     * Marks subscription as paid.
     *
     * @param Subscription $subscription Subscription instance.
     *
     * @return Subscription
     */
    public function markPaid(Subscription $subscription)
    {
        $subscription->paid = 1;
        $subscription->save();

        return $subscription;
    }

    /**
     * Sets billing failed flag on subscription.
     *
     * @param Subscription $subscription Subscription instance.
     *
     * @return Subscription
     */
    public function markBillingFailed(Subscription $subscription)
    {
        $subscription->billing_failed = 1;
        $subscription->save();

        return $subscription;
    }

    /**
     * Deactivates a subscription.
     *
     * @param Subscription $subscription Subscription instance.
     *
     * @return Subscription
     */
    public function deactivate(Subscription $subscription)
    {
        $subscription->active = 0;
        $subscription->save();

        return $subscription;
    }

    /**
     * Deletes a subscription.
     *
     * @param Subscription $subscription Subscription instance.
     *
     * @return Subscription
     */
    public function delete(Subscription $subscription)
    {
        return $subscription->delete();
    }
}
