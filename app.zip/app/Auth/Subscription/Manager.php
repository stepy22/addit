<?php

namespace App\Auth\Subscription;

use App\Auth\Exceptions\SubscriptionBillingFailed;
use App\Auth\Subscription;
use App\Auth\Subscription\Notifier as SubscriptionNotifier;
use App\Auth\Subscription\Repository as SubscriptionRepository;
use App\Auth\User;
use App\Auth\User\Repository as UserRepository;
use App\Transactions\Transaction;
use App\Transactions\Transaction\Repository as TransactionRepository;
use App\WidgetTypes\WidgetType;
use Carbon\Carbon;
use Creitive\Stripe\Stripe;
use Illuminate\Config\Repository as Config;
use Log;
use Stripe\Error\InvalidRequest;

class Manager
{
    /**
     * A Subscription repository instance.
     *
     * @var SubscriptionRepository
     */
    protected $subscriptionRepository;

    /**
     * A config repository.
     *
     * @var Config
     */
    protected $config;

    /**
     * A user repository.
     *
     * @var UserRepository
     */
    protected $userRepository;

    /**
     * A subscription notifier.
     *
     * @var SubscriptionNotifier
     */
    protected $subscriptionNotifier;

    /**
     * A Stripe instance.
     *
     * @var Subscription
     */
    protected $stripe;

    /**
     * A Transaction repository.
     *
     * @var TransactionRepository
     */
    protected $transactionRepository;

    /**
     * @param SubscriptionRepository $subscriptionRepository Subscription repository instance.
     * @param Config                 $config                 Config repository.
     * @param UserRepository         $userRepository         User repository instance.
     * @param SubscriptionNotifier   $subscriptionNotifier   Subscription notifier instance.
     * @param Stripe                 $stripe                 A stripe instance.
     * @param TransactionRepository  $transactionRepository  A transaction repository instance.
     */
    public function __construct(
        SubscriptionRepository $subscriptionRepository,
        Config $config,
        UserRepository $userRepository,
        SubscriptionNotifier $subscriptionNotifier,
        Stripe $stripe,
        TransactionRepository $transactionRepository
    ) {
        $this->subscriptionRepository = $subscriptionRepository;
        $this->config = $config;
        $this->userRepository = $userRepository;
        $this->subscriptionNotifier = $subscriptionNotifier;
        $this->stripe = $stripe;
        $this->transactionRepository = $transactionRepository;
    }

    /**
     * Get monthly price of a PRO subscription.
     *
     * @return integer
     */
    public function getProPriceMonthly()
    {
        return (int) $this->config->get('subscription.prices')[Subscription::DURATION_MONTHLY];
    }

    /**
     * Get yearly price of a PRO subscription.
     *
     * @return integer
     */
    public function getProPriceYearly()
    {
        return (int) $this->config->get('subscription.prices')[Subscription::DURATION_YEARLY];
    }

    /**
     * Get monthly and yearly price difference.
     *
     * @return integer
     */
    public function getYearlyPriceDiscount()
    {
        return $this->getProPriceMonthly() * 12 - $this->getProPriceYearly();
    }

    /**
     * Subscribes a user to a PRO plan.
     *
     * @param User   $user     User instance.
     * @param string $duration Duration string.
     *
     * @throws SubscriptionBillingFailed
     *
     * @return Subscription
     */
    public function subscribeToPro($user, $duration)
    {
        // If user is already subscribed just return.
        if ($user->isSubscribedToPro()) {
            return;
        }

        // If user have unpaid subscription charge for that subscription first
        // before moving on.
        if ($user->unpaidProSubscription()) {
            if (!$this->chargeForProSubscription($user->unpaidProSubscription())) {
                throw new SubscriptionBillingFailed($user->unpaidProSubscription());
            }
        }

        // If user don't have active subscription create one for them and
        // upgrade them to PRO. Also charge if yearly plan is selected.
        if (!$user->isPro()) {
            $subscription = $this->subscriptionRepository->createProSubscriptionAndActivate($user, $duration);

            // If it's yearly subscription charge right away.
            if ($subscription->duration === Subscription::DURATION_YEARLY) {
                if (!$this->chargeForProSubscription($subscription)) {
                    $this->subscriptionRepository->delete($subscription);

                    throw new SubscriptionBillingFailed($subscription);
                }
            }

            $this->userRepository->upgrateToPro($user, $duration);
        }

        // Subscribes user to a plan (sets flag that user is subscribed and for
        // which plan). If user already have subscription this setting will
        // determine which plan will be used in next billing period.
        $this->userRepository->subscribeToPro($user, $duration);

        if (!isset($subscription)) {
            $subscription = $user->subscriptions->filter(function (Subscription $subscription) {
                return $subscription->active === true && $subscription->widget_type_id === null;
            })->first();
        }

        return $subscription;
    }

    /**
     * Unsubscribes a user from a PRO account plan.
     *
     * @param  User $user User instance.
     *
     * @return void
     */
    public function unsubscribeFromPro(User $user)
    {
        $this->userRepository->unsubscribeFromPro($user);
    }

    /**
     * Subscribes user to a widget type.
     *
     * @param  User       $user       User instance.
     * @param  WidgetType $widgetType Widget type instance.
     *
     * @throws SubscriptionBillingFailed
     *
     * @return Subscription
     */
    public function subscribeToWidgetType(User $user, WidgetType $widgetType)
    {
        $unpaidSubscription = $user->unpaidWidgetTypeSubscription($widgetType->id);

        // If user have unpaid widget type subscription charge for that
        // subscription first before moving on.
        if ($unpaidSubscription) {
            if (!$this->chargeForWidgetTypeSubscription($unpaidSubscription)) {
                throw new SubscriptionBillingFailed($unpaidSubscription);
            }
        }

        // If user hasn't subscribe to passed widget type add it to a list of
        // user's widget types.
        $user->subscribedWidgetTypes()->attach($widgetType->id);

        if (!$user->hasActiveWidgetType($widgetType->id)) {
            $subscription = $this->subscriptionRepository->createWidgetTypeSubscriptionAndActivate($user, $widgetType->id, $widgetType->price);
        }

        if (!isset($subscription)) {
            $subscription = $user->subscriptions->filter(function (Subscription $subscription) use ($widgetType) {
                return $subscription->active === true && $subscription->widget_type_id === $widgetType->id;
            })->first();
        }

        return $subscription;
    }

    /**
     * Unsubscribes a user from a widget type.
     *
     * @param User       $user       User instance.
     * @param WidgetType $widgetType Widget type instance.
     *
     * @return void
     */
    public function unsubscribeFromWidgetType(User $user, WidgetType $widgetType)
    {
        $this->userRepository->unsubscribeFromWidgetType($user, $widgetType);
    }

    /**
     * Charges user for a widget type subscription.
     *
     * Charges a user for a widget type subscription and creates a transaction table record.
     *
     * @param Subscription $subscription Subscription instance.
     *
     * @return mixed
     */
    public function chargeForWidgetTypeSubscription(Subscription $subscription)
    {
        $amount = $subscription->price;

        try {
            $charge = $this->stripe->chargeCustomer($subscription->user->stripe_customer_id, $amount);
        } catch (InvalidRequest $e) {
            Log::error($e);

            return false;
        }

        if (!$charge) {
            return false;
        }

        $transactionData = [
            'type' => Transaction::TYPE_PLATINUM_WIDGET,
            'amount' => $amount,
            'user_id' => $subscription->user->id,
            'stripe_charge_id' => $charge->id,
        ];

        $this->subscriptionNotifier->notifyBilled($subscription);
        $this->transactionRepository->create($transactionData);
        $this->subscriptionRepository->markPaid($subscription);

        return $subscription;
    }

    /**
     * Charges user for a PRO subscription.
     *
     * Charges a user for a subscription and creates a transaction table record.
     *
     * @param Subscription $subscription Subscription instance.
     *
     * @return mixed
     */
    public function chargeForProSubscription(Subscription $subscription)
    {
        $amount = $this->config->get('subscription.prices')[$subscription->duration];

        // If it's a monthly subscription and user have free months available, don't charge.
        if ($subscription->duration === Subscription::DURATION_MONTHLY && $subscription->user->free_months_count > 0) {
            $this->userRepository->subFreeMonth($subscription->user);
            $this->subscriptionNotifier->notifyFreeMonthUsed($subscription);
        } else {
            try {
                $charge = $this->stripe->chargeCustomer($subscription->user->stripe_customer_id, $amount);
            } catch (InvalidRequest $e) {
                Log::error($e);

                return false;
            }

            if (!$charge) {
                return false;
            }

            $type = $subscription->duration === Subscription::DURATION_YEARLY ? Transaction::TYPE_PRO_SUB_YEARLY : Transaction::TYPE_PRO_SUB_MONTHLY;

            $transactionData = [
                'type' => $type,
                'amount' => $amount,
                'user_id' => $subscription->user->id,
                'stripe_charge_id' => $charge->id,
            ];

            $this->subscriptionNotifier->notifyBilled($subscription);

            $this->transactionRepository->create($transactionData);
        }

        $this->subscriptionRepository->markPaid($subscription);

        return $subscription;
    }

    /**
     * Checks expiring widget types subscriptions.
     *
     * Notifies users about expiring subscriptions, charges monthly
     * subscriptions, terminates unchargable subscriptions.
     *
     * @return Array
     */
    public function checkExpiringWidgetTypeSubscriptions()
    {
        $allUsers = $this->userRepository->getAll();
        $allUsers->load('subscriptions.widgetType', 'subscribedWidgetTypes', 'activeWidgetTypes');

        $output = [
            'prolongedSubscriptions' => 0,
            'handledSubscriptions' => 0,
            'failedCharges' => 0,
            'notifiedUsers' => 0,
        ];

        $today = Carbon::now();

        foreach ($allUsers as $user) {
            foreach ($user->activeWidgetTypes as $activeWidgetType) {
                $subscription = $user->subscriptions->filter(function (Subscription $subscription) use ($activeWidgetType) {
                    return $subscription->widget_type_id === $activeWidgetType->id && $subscription->active === true;
                })->first();

                $notificationDate = $subscription->ends_at->subDays($this->config->get('subscription.notifyBefore'));

                // If it's still not time to notify user just skip the user.
                if ($notificationDate > $today) {
                    continue;
                }

                // If time to notify user has passed and user is still not
                // notified, notify user and exit.
                if ($notificationDate < $today && !$subscription->notified) {
                    $this->subscriptionNotifier->notify($subscription);
                    $this->subscriptionRepository->markNotified($subscription);

                    $output['notifiedUsers'] = $output['notifiedUsers'] + 1;

                    continue;
                }

                // If subscription has passed...
                if ($subscription->ends_at < $today) {
                    $this->subscriptionRepository->deactivate($subscription);

                    // If transaction fail notify user.
                    if (!$this->chargeForWidgetTypeSubscription($subscription)) {
                        Log::error('Failed to change a user for a widget type subscription. User ID: '. $subscription->user_id . ', Subscription ID: '. $subscription->id);

                        // If not already notified, notified user about
                        // failed subscription.
                        if (!$subscription->billing_failed) {
                            $this->subscriptionNotifier->notifyBillingFailed($subscription);
                            $this->subscriptionRepository->markBillingFailed($subscription);
                        }

                        $subscription->user->subscribedWidgetTypes()->detach($subscription->widget_type_id);

                        $output['failedCharges'] = $output['failedCharges'] + 1;

                        continue;
                    }

                    $output['handledSubscriptions'] = $output['handledSubscriptions'] + 1;

                    // If user is subscribed create new subscription.
                    if ($user->isSubscribedToWidgetType($subscription->widget_type_id) && $subscription->widgetType->is_platinum) {
                        $newSubscription = $this->subscriptionRepository->createWidgetTypeSubscriptionAndActivate(
                            $subscription->user,
                            $subscription->widget_type_id,
                            $subscription->widgetType->price
                        );

                        $output['prolongedSubscriptions'] = $output['prolongedSubscriptions'] + 1;

                        continue;
                    }
                }
            }
        }

        return $output;
    }

    /**
     * Checks expiring PRO subscriptions.
     *
     * Notifies users about expiring subscriptions, charges monthly
     * subscriptions, terminates unchargable subscriptions.
     *
     * @return Array
     */
    public function checkExiringProSubscriptions()
    {
        $allUsers = $this->userRepository->getAll();
        $allUsers->load('subscriptions');

        $output = [
            'prolongedSubscriptions' => 0,
            'handledSubscriptions' => 0,
            'failedCharges' => 0,
            'notifiedUsers' => 0,
        ];

        $today = Carbon::now();

        foreach ($allUsers as $user) {
            if ($user->hasActiveProSubscription()) {
                $subscription = $user->activeProSubscription();
                $notificationDate = $subscription->ends_at->subDays($this->config->get('subscription.notifyBefore'));

                // If it's still not time to notify user just skip the user.
                if ($notificationDate > $today) {
                    continue;
                }

                // If time to notify user has passed and user is still not
                // notified, notify user and exit.
                if ($notificationDate < $today && !$subscription->notified) {
                    $this->subscriptionNotifier->notify($subscription);
                    $this->subscriptionRepository->markNotified($subscription);

                    $output['notifiedUsers'] = $output['notifiedUsers'] + 1;

                    continue;
                }
                // If subscription has passed...
                if ($subscription->ends_at < $today) {
                    $this->subscriptionRepository->deactivate($subscription);

                    // If it's a monthly subscription charge a user.
                    if ($subscription->duration === Subscription::DURATION_MONTHLY) {
                        // If transaction fail notify user.
                        if (!$this->chargeForProSubscription($subscription)) {
                            Log::error('Failed to change a user for a monthly PRO subscription. User ID: '. $subscription->user_id . ', Subscription ID: '. $subscription->id);

                            // If not already notified, notified user about
                            // failed subscription.
                            if (!$subscription->billing_failed) {
                                $this->subscriptionNotifier->notifyBillingFailed($subscription);
                                $this->subscriptionRepository->markBillingFailed($subscription);
                            }

                            $this->userRepository->downgradeToRegular($user);
                            $this->userRepository->unsubscribeFromPro($user);

                            $output['failedCharges'] = $output['failedCharges'] + 1;

                            continue;
                        }

                        // Deactivate current subscription and downgrade user to regular.
                        $this->userRepository->downgradeToRegular($user);
                    }

                    $output['handledSubscriptions'] = $output['handledSubscriptions'] + 1;

                    // If user is subscribed create new subscription.
                    if ($user->subscribed_to_pro) {
                        $newSubscription = $this->subscriptionRepository->createProSubscriptionAndActivate(
                            $subscription->user,
                            $subscription->user->subscription_duration
                        );

                        // If it's a yearly subscription charge right away.
                        if ($newSubscription->duration === Subscription::DURATION_YEARLY) {
                            // If transaction fail notify user.
                            if (!$this->chargeForProSubscription($newSubscription)) {
                                Log::error('Failed to change a user for a yearly PRO subscription. User ID: '. $newSubscription->user_id . ', Subscription ID: '. $newSubscription->id);

                                $this->subscriptionNotifier->notifyBillingFailed($newSubscription);

                                $output['failedCharges'] = $output['failedCharges'] + 1;

                                $this->subscriptionRepository->delete($newSubscription);
                                $this->userRepository->downgradeToRegular($user);
                                $this->userRepository->unsubscribeFromPro($user);

                                continue;
                            }
                        }

                        $this->userRepository->upgrateToPro($user);

                        $output['prolongedSubscriptions'] = $output['prolongedSubscriptions'] + 1;

                        continue;
                    }

                    $this->userRepository->downgradeToRegular($user);
                }
            }
        }

        return $output;
    }
}
