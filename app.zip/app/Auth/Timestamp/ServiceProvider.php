<?php

namespace App\Auth\Timestamp;

use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerApiRoutes($this->app['router']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1/timestamp',
            'middleware' => ['api'],
            'namespace' => 'App\Auth\Http\Controllers\Api\V1\Timestamp',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('', 'Controller@index');
        });
    }
}
