<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        \App\Console\Commands\Inspire::class,
        \App\Auth\Console\CreateUserCommand::class,
        \App\Auth\Console\ResetPasswordCommand::class,
        \App\Auth\Console\CheckExpiringProSubscriptions::class,
        \App\Auth\Console\CheckExpiringWidgetTypeSubscriptions::class,
        \App\SuggestedLinks\Console\UpdateSuggestedLinksDescription::class,
        \App\Widgets\Console\MyTopTenListItem\Commands\Notify::class,
        \App\Widgets\Console\MyTopTenListItem\Commands\ClearExpired::class,
        \App\Widgets\Console\Birthday\Commands\Notify::class,
        \App\Widgets\Console\Event\Commands\Notify::class,
    ];

    /**
     * Define the application's command schedule.
     *
     * @param Schedule $schedule A schedule.
     *
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        $schedule->command('subscription:check-expiring-pro-subscriptions')
                 ->hourly();

        $schedule->command('subscription:check-expiring-widget-type-subscriptions')
                 ->hourly();

        $schedule->command('top-ten-list:notify')
                 ->everyMinute();

        $schedule->command('birthdays:notify')
                 ->everyMinute();

        $schedule->command('events:notify')
                 ->everyMinute();

        $schedule->command('top-ten-list:clear-expired')
                 ->daily()
                 ->timezone('UTC');
    }
}
