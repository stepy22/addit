<?php

namespace App\FacebookGroups\Group;

use App\FacebookGroups\Group;
use App\InterestTags\InterestTag\Repository as InterestTagRepository;
use Carbon\Carbon;
use Cartalyst\Support\Collection;
use stdClass;

class Repository
{
    /**
     * A Group model instance.
     *
     * @var Group
     */
    protected $group;

    /**
     * An Interest tag repository instance.
     *
     * @var InterestTagRepository
     */
    protected $interestTagRepository;

    /**
     * @param Group                 $group                 A group model instance.
     * @param InterestTagRepository $interestTagRepository An interest tag repository instance.
     */
    public function __construct(Group $group, InterestTagRepository $interestTagRepository)
    {
        $this->groupModel = $group;
        $this->interestTagRepository = $interestTagRepository;
    }

    /**
     * Gets all groups.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAll()
    {
        return $this->groupModel->get();
    }

    /**
     * Finds the group by ID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $id The group ID.
     *
     * @return Group|null
     */
    public function find($id)
    {
        return $this->groupModel->find($id);
    }

    /**
     * Finds the group by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The group ID.
     *
     * @return Group
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->groupModel->findOrFail($id);
    }

    /**
     * Creates a new group and returns it.
     *
     * @param array $inputData The group input data.
     *
     * @return Group
     */
    public function create(array $inputData)
    {
        return $this->populateAndSave($this->groupModel->newInstance(), $inputData);
    }

    /**
     * Creates Facebook groups, and updates occurrences for existing ones.
     *
     * @param array $facebookGroups Facebook groups array.
     *
     * @return Collection
     */
    public function batchCreate(array $facebookGroups)
    {
        $facebookIds = array_map(function ($item) {
            return $item['id'];
        }, $facebookGroups);

        $existingGroups = $this->getByFacebookIds($facebookIds);

        $newGroups = array_filter($facebookGroups, function ($item) use ($existingGroups) {
            return $existingGroups->where('group_id', $item['id'])->count() === 0;
        });

        $newGroups = array_map(function ($item) {
            return [
                'title' => $item['name'],
                'group_id' => $item['id'],
            ];
        }, $newGroups);

        $this->groupModel
            ->insert($newGroups);

        $this->groupModel
            ->whereIn('id', $existingGroups->pluck('id')->toArray())
            ->increment('occurrences');
    }

    /**
     * Gets existing Facebook groups.
     *
     * @param array $facebookIds Array of Facebook group ids.
     *
     * @return Collection
     */
    public function getByFacebookIds(array $facebookIds)
    {
        return $this->groupModel
            ->whereIn('group_id', $facebookIds)
            ->get();
    }

    /**
     * Updates the passed group and returns it.
     *
     * @param Group $group     The group to update.
     * @param array $inputData The input data for the update.
     *
     * @return Group
     */
    public function update(Group $group, array $inputData)
    {
        return $this->populateAndSave($group, $inputData);
    }

    /**
     * Deletes the passed group from the system.
     *
     * @param Group $group The group to delete.
     *
     * @return bool|null
     */
    public function delete(Group $group)
    {
        return $group->delete();
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param Group $group     The group to populate.
     * @param array $inputData The input data for the group.
     *
     * @return Group
     */
    protected function populate(Group $group, array $inputData)
    {
        $group->title = array_get($inputData, 'title');

        return $group;
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param Group $group     The group to populate and save.
     * @param array $inputData The input data.
     *
     * @return Group
     */
    protected function populateAndSave(Group $group, array $inputData)
    {
        $group = $this->populate($group, $inputData);

        $group->save();

        if (isset($inputData['interest_tags'])) {
            $interestTagsArray = explode(',', $inputData['interest_tags']);
            $interestTags = $this->interestTagRepository->getByTitleAndCreateNonExistent($interestTagsArray);

            $group->interestTags()->sync($interestTags->pluck('id')->toArray());
        }

        return $group;
    }
}
