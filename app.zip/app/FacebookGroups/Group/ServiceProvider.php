<?php

namespace App\FacebookGroups\Group;

use App\FacebookGroups\Group;
use App\FacebookGroups\Group\Repository as GroupRepository;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use DaveJamesMiller\Breadcrumbs\Generator as BreadcrumbGenerator;
use DaveJamesMiller\Breadcrumbs\Manager as BreadcrumbManager;
use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Routing\Router;
use URL;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerRoutePatterns($this->app['router'], $this->app);
        $this->registerAdminRoutes($this->app['router']);
        $this->registerAdminBreadcrumbs($this->app['breadcrumbs']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers the route patterns.
     *
     * @param Router    $router    A router.
     * @param Container $container A dependency container.
     *
     * @return void
     */
    protected function registerRoutePatterns(Router $router, Container $container)
    {
        $idRegex = $this->routePatternRegexes['id'];
        $slugRegex = $this->routePatternRegexes['slug'];

        $router->pattern('group', $idRegex);

        $router->bind('group', function ($value) use ($container, $idRegex) {
            $groupRepository = $container->make(GroupRepository::class);

            if (preg_match("/^{$idRegex}$/D", $value)) {
                $group = $groupRepository->find($value);

                if ($group !== null) {
                    return $group;
                }
            }
        });
    }

    /**
     * Registers admin panel routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerAdminRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'admin/facebook-groups',
            'middleware' => ['web', 'auth', 'permissions'],
            'namespace' => 'App\FacebookGroups\Http\Controllers\Admin\Group',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('', 'Controller@index');

            $router->get('{group}/edit', 'Controller@edit');
            $router->put('{group}', 'Controller@update');
        });
    }

    /**
     * Registers breadcrumbs for the admin panel.
     *
     * @param BreadcrumbManager $breadcrumbs A breadcrumb manager.
     *
     * @return void
     */
    protected function registerAdminBreadcrumbs(BreadcrumbManager $breadcrumbs)
    {
        $breadcrumbs->register('admin::facebookGroups', function (BreadcrumbGenerator $breadcrumbs) {
            $breadcrumbs->parent('admin::home');

            $url = URL::action('App\FacebookGroups\Http\Controllers\Admin\Group\Controller@index');

            $breadcrumbs->push(trans('admin/navigation.facebookGroups'), $url);
        });

        $breadcrumbs->register('admin::facebookGroups.show', function (BreadcrumbGenerator $breadcrumbs, Group $group) {
            $breadcrumbs->parent('admin::facebookGroups');

            $breadcrumbs->push($group->title);
        });

        $breadcrumbs->register('admin::facebookGroups.edit', function (BreadcrumbGenerator $breadcrumbs, Group $group) {
            $breadcrumbs->parent('admin::facebookGroups.show', $group);

            $url = URL::action('App\FacebookGroups\Http\Controllers\Admin\Group\Controller@edit', ['group' => $group->id]);

            $breadcrumbs->push(trans('admin/facebookGroups.titles.edit'), $url);
        });
    }
}
