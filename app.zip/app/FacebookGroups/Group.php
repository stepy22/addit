<?php

namespace App\FacebookGroups;

use App\InterestTags\InterestTag;
use Creitive\Database\Eloquent\Model;
use Creitive\Models\Traits\CalcFoundRowableTrait;
use URL;

class Group extends Model
{
    use CalcFoundRowableTrait;

    /**
     * {@inheritDoc}
     */
    protected $table = 'facebook_groups';

    /**
     * Eloquent relationship: facebook group may have many interest tags.
     *
     * @return BelongsToMany
     */
    public function interestTags()
    {
        return $this->belongsToMany(InterestTag::class, 'facebook_group_interest_tags');
    }
}
