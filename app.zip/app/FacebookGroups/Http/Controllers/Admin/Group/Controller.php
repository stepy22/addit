<?php

namespace App\FacebookGroups\Http\Controllers\Admin\Group;

use App\FacebookGroups\Group;
use App\FacebookGroups\Group\Repository as GroupRepository;
use App\FacebookGroups\Http\Requests\Admin\Group\StoreRequest;
use App\FacebookGroups\Http\Requests\Admin\Group\UpdateRequest;
use App\Http\Controllers\Admin\Controller as BaseController;
use App\InterestTags\InterestTag\Repository as InterestTagRepository;
use Illuminate\Http\Request;
use Illuminate\Support\MessageBag;
use Redirect;

class Controller extends BaseController
{
    /**
     * A GroupRepository instance.
     *
     * @var GroupRepository
     */
    protected $groupRepository;

    /**
     * @param GroupRepository $groupRepository A group repository instance.
     */
    public function __construct(GroupRepository $groupRepository)
    {
        parent::__construct();

        $this->groupRepository = $groupRepository;

        $this->viewData->bodyDataPage = 'admin-facebook-groups';
        $this->viewData->pageTitle->setPage(trans('admin/facebookGroups.module'));
        $this->viewData->navigation->get('admin.main')->setActive('facebook-groups');
    }

    /**
     * Shows all groups.
     *
     * @param Request $request The current request.
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $data = [
            'groups' => $this->groupRepository->getAll(),
        ];

        return view('admin.facebook-groups.index', $data);
    }

    /**
     * Shows the specified group's edit page.
     *
     * @param Group                 $group                 The group.
     * @param InterestTagRepository $interestTagRepository Interest tag repository instance.
     *
     * @return \Illuminate\View\View
     */
    public function edit(
        Group $group,
        InterestTagRepository $interestTagRepository
    ) {
        $data = [
            'interestTags' => $interestTagRepository->getall(),
            'group' => $group,
        ];

        return view('admin.facebook-groups.edit', $data);
    }

    /**
     * Updates the specified group.
     *
     * @param UpdateRequest $request A group update request.
     * @param Group         $group   The group.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(UpdateRequest $request, Group $group)
    {
        $this->groupRepository->update($group, $request->all());

        $successMessage = trans('admin/facebookGroups.successMessages.edit');

        return Redirect::action(static::class.'@edit', ['group' => $group->id])
            ->with('successMessages', new MessageBag([$successMessage]));
    }
}
