<?php

namespace App\Transactions\Transaction;

use App\Transactions\Transaction;
use Carbon\Carbon;
use stdClass;

class Repository
{
    /**
     * A Transaction model instance.
     *
     * @var Transaction
     */
    protected $transaction;

    /**
     * @param Transaction $transaction A transaction model instance.
     */
    public function __construct(Transaction $transaction)
    {
        $this->transactionModel = $transaction;
    }

    /**
     * Gets all transactions.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAll()
    {
        return $this->transactionModel->sorted()->get();
    }

    /**
     * Gets n transactions for page.
     *
     * @param int $page  Page number.
     * @param int $limit Items to take.
     *
     * @return Illuminate\Database\Eloquent\Collection
     */
    public function getByPage($page = 1, $limit = 20)
    {
        return $this->transactionModel
            ->forPage($page, $limit)
            ->get();
    }

    /**
     * Finds the transaction by ID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $id The transaction ID.
     *
     * @return Transaction|null
     */
    public function find($id)
    {
        return $this->transactionModel->find($id);
    }

    /**
     * Finds the transaction by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The transaction ID.
     *
     * @return Transaction
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->transactionModel->findOrFail($id);
    }

    /**
     * Creates a new transaction and returns it.
     *
     * @param array $inputData The transaction input data.
     *
     * @return Transaction
     */
    public function create(array $inputData)
    {
        return $this->populateAndSave($this->transactionModel->newInstance(), $inputData);
    }

    /**
     * Updates the passed transaction and returns it.
     *
     * @param Transaction $transaction The transaction to update.
     * @param array       $inputData   The input data for the update.
     *
     * @return Transaction
     */
    public function update(Transaction $transaction, array $inputData)
    {
        return $this->populateAndSave($transaction, $inputData);
    }

    /**
     * Deletes the passed transaction from the system.
     *
     * @param Transaction $transaction The transaction to delete.
     *
     * @return bool|null
     */
    public function delete(Transaction $transaction)
    {
        return $transaction->delete();
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param Transaction $transaction     The transaction to populate.
     * @param array $inputData The input data for the transaction.
     *
     * @return Transaction
     */
    protected function populate(Transaction $transaction, array $inputData)
    {
        $transaction->stripe_charge_id = array_get($inputData, 'stripe_charge_id');
        $transaction->user_id = array_get($inputData, 'user_id');
        $transaction->amount = array_get($inputData, 'amount');
        $transaction->type = array_get($inputData, 'type');

        return $transaction;
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param Transaction $transaction     The transaction to populate and save.
     * @param array $inputData The input data.
     *
     * @return Transaction
     */
    protected function populateAndSave(Transaction $transaction, array $inputData)
    {
        $transaction = $this->populate($transaction, $inputData);

        $transaction->save();

        return $transaction;
    }
}
