<?php

namespace App\Transactions;

use App;
use App\Auth\User;
use Cartalyst\Sentinel\Sentinel;
use Creitive\Commerce\PriceFormatter;
use Creitive\Database\Eloquent\Model;

class Transaction extends Model
{
    /**
     * Type constants.
     */
    const TYPE_PRO_SUB_MONTHLY = 'pro_sub_monthly';
    const TYPE_PRO_SUB_YEARLY = 'pro_sub_yearly';
    const TYPE_PLATINUM_WIDGET = 'platinum_widget';

    /**
     * {@inheritDoc}
     */
    protected $appends = [
        'user_name',
        'price',
        'purpose',
        'formatted_date',
    ];

    /**
     * Eloquent relation: Transaction belongs to a user.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Gets user's name attribute.
     *
     * @return string
     */
    public function getUserNameAttribute()
    {
        return $this->user->full_name;
    }

    /**
     * Gets price formatter attribute.
     *
     * @return string
     */
    public function getPriceAttribute()
    {
        $priceFormatter = App::make(PriceFormatter::class);

        return trans('commerce.currency.symbol').$priceFormatter->toString($this->amount);
    }

    /**
     * Gets purpose attribute.
     *
     * @return string
     */
    public function getPurposeAttribute()
    {
        return trans('admin/home.transactionTypes.'.$this->type);
    }

    /**
     * Gets date formatter attribute.
     *
     * @return string
     */
    public function getFormattedDateAttribute()
    {
        $sentinel = App::make(Sentinel::class);

        return $this->created_at->setTimezone($sentinel->getUser()->timezone)->format(trans('common.dateFormat'));
    }
}
