<?php

namespace App;

use Creitive\Html\DefaultSeoPresenter;

class SeoPresenter extends DefaultSeoPresenter
{
    /**
     * @param string $siteName     The site name.
     * @param string $locale       The locale.
     * @param string $description  The description.
     * @param string $defaultImage The default image.
     */
    public function __construct($siteName, $locale, $description, $defaultImage)
    {
        $this->siteName = $siteName;
        $this->type = 'website';
        $this->locale = $locale;
        $this->description = $description;
        $this->image = $defaultImage;
    }
}
