<?php

namespace App\Exceptions;

use App;
use App\Content\Exceptions\UndefinedPageAutoRedirectUrlException;
use Cartalyst\Sentinel\Checkpoints\NotActivatedException;
use Creitive\Api\ApiDetector;
use Exception;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\Exception\TooManyRequestsHttpException;
use View;

class Handler extends ExceptionHandler
{
    /**
     * A list of the exception types that should not be reported.
     *
     * @var array
     */
    protected $dontReport = [
        AuthorizationException::class,
        HttpException::class,
        ModelNotFoundException::class,
        ValidationException::class,
    ];

    /**
     * A list of the inputs that are never flashed for validation exceptions.
     *
     * @var array
     */
    protected $dontFlash = [
        'password',
        'password_confirmation',
    ];

    /**
     * Report or log an exception.
     *
     * This is a great spot to send exceptions to Sentry, Bugsnag, etc.
     *
     * @param Exception $exception The exception to report.
     *
     * @return void
     *
     * @throws HttpException
     */
    public function report(Exception $exception)
    {
        if ($exception instanceof UndefinedPageAutoRedirectUrlException) {
            $context = [
                'pageId' => $exception->getPageId(),
            ];

            $this->log->error($exception->getMessage(), $context);

            throw new HttpException(500, null, $exception);
        }

        return parent::report($exception);
    }

    /**
     * Render an exception into an HTTP response.
     *
     * @param mixed     $request   The current request instance.
     * @param Exception $exception The exception to render.
     *
     * @return Response
     */
    public function render($request, Exception $exception)
    {
        $apiDetector = new ApiDetector($request);

        if ($apiDetector->isApi() && $exception instanceof HttpException) {
            return new Response(['message' => $exception->getMessage()], $exception->getStatusCode());
        } else {
            return $this->renderError($request, $exception);
        }
    }

    /**
     * Custom error rendering.
     *
     * @param Request   $request   The current request instance.
     * @param Exception $exception The exception to render.
     *
     * @return Response
     */
    public function renderError(Request $request, Exception $exception)
    {
        // We don't want to explicitly handle errors during development; we'll
        // just let them bubble up to Laravel's built-in exception handler,
        // which pretty prints the errors using `filp/whoops`.
        if (App::environment() === 'local' ||
            App::runningInConsole() ||
            $exception instanceof ValidationException
        ) {
            return parent::render($request, $exception);
        }

        // The "staging" and "production" environments mustn't display any
        // traces or error output for security reasons, so we'll handle those
        // manually, returning the appropriate HTTP status code and a generic
        // error page. The same goes for the "testing" environment, since we
        // want to be able to actually test whether the appropriate responses
        // are returned.
        //
        // We will explicitly check some specific exceptions we need to handle
        // individually, and display nice error pages in those cases.
        if (($exception instanceof NotFoundHttpException)
            || ($exception instanceof ModelNotFoundException)) {
            return response(view('errors.404'), 404);
        } elseif ($exception instanceof BadRequestHttpException) {
            return response(view('errors.400'), 400);
        } elseif ((
                ($exception instanceof HttpException)
                && ($exception->getStatusCode() === 403))
            || ($exception instanceof AccessDeniedHttpException)) {
            return response(view('errors.403'), 403);
        } elseif ($exception instanceof TooManyRequestsHttpException) {
            return response('Too many requests, please wait for a little while and try again.', 429);
        } elseif ($exception instanceof HttpResponseException) {
            return $exception->getResponse();
        } elseif ($exception instanceof NotActivatedException) {
            return response([ 'message' => 'Your account has not been activated yet.'], 403);
        } else {
            return response(view('errors.500'), 500);
        }
    }
}
