<?php

namespace App\Mailchimp\Subscription;

use Config;
use Mailchimp;
use Mailchimp_List_AlreadySubscribed;

class Service
{
    /**
     * A Mailchimp instance.
     *
     * @var \Mailchimp
     */
    protected $mailchimp;

    /**
     * An array of available list IDs.
     *
     * @var array
     */
    protected $listIds;

    /**
     * @param Mailchimp $mailchimp A Mailchimp instance.
     * @param array     $listIds   An array of list ids.
     */
    public function __construct(Mailchimp $mailchimp, array $listIds = [])
    {
        $this->mailchimp = $mailchimp;

        if (count($listIds)) {
            $this->listIds = $listIds;
        } else {
            $this->listIds = Config::get('mailchimp.listIds');
        }
    }

    /**
     * Attempts to subscribe a user to the specified list.
     *
     * Returns `true` on success or `false` on failure.
     *
     * @param string $list  A list for subscribing.
     * @param string $email The email.

     * @return bool
     */
    public function subscribe($list, $email)
    {
        if (!$listId = $this->getListId($list)) {
            return false;
        }

        try {
            return $this->mailchimp->lists->subscribe(
                $listId,
                [
                    'email' => $email,
                ]
            );
        } catch (Mailchimp_List_AlreadySubscribed $e) {
            return true;
        }
    }

    /**
     * Gets the list ID by its name, from the configuration file.
     *
     * Returns `null` if the list name isn't configured with an ID.
     *
     * @param string $list A list for subscribing.
     *
     * @return string|null
     */
    public function getListId($list)
    {
        return isset($this->listIds[$list]) ? $this->listIds[$list] : null;
    }
}
