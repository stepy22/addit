<?php

namespace App\Mailchimp\Subscription;

use App\Mailchimp\Subscription\Service;
use Creitive\Mailchimp\SubscriptionService;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Support\ServiceProvider as BaseServiceProvider;
use Mailchimp;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerFrontApiRoutes($this->app['router']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
        $this->app->singleton(SubscriptionService::class, function ($app) {
            return new SubscriptionService(
                $app['Mailchimp'],
                $app['config']->get('mailchimp.listIds')
            );
        });
    }

    /**
     * Registers front api routes.
     *
     * @param \Illuminate\Contracts\Routing\Registrar $router
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1/mailchimp',
            'namespace' => 'App\Mailchimp\Http\Controllers\Front\Api\Subscription',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->post('subscribe', 'Controller@subscribe');
        });
    }
}
