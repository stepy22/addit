<?php

namespace App\Mailchimp\Http\Controllers\Front\Api\Subscription;

use App\Http\Controllers\Front\Controller as BaseController;
use App\Mailchimp\Http\Requests\Front\Api\Subscription\SubscribeRequest;
use App\Mailchimp\Subscription\Service;
use Response;

class Controller extends BaseController
{
    /**
     * Sends a contact message
     *
     * @param SubscribeRequest $request             A Subscribe request instance.
     * @param Service          $subscriptionService A Subscription service instance.
     *
     * @return \Illuminate\Http\Response
     */
    public function subscribe(SubscribeRequest $request, Service $subscriptionService)
    {
        $subscriptionService->subscribe('subscribers', $request->get('email'));

        $data = [
            'successMessages' => trans('newsletter.successMessages'),
        ];

        return Response::json($data);
    }
}
