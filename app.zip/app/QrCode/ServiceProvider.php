<?php

namespace App\QrCode;

use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use SimpleSoftwareIO\QrCode\BaconQrCodeGenerator;
use SimpleSoftwareIO\QrCode\QrCodeInterface;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerFrontApiRoutes($this->app['router']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
        $this->app->bind(QrCodeInterface::class, BaconQrCodeGenerator::class);
    }

    /**
     * Registers admin API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1/qr-code',
            'middleware' => ['api'],
            'namespace' => 'App\QrCode\Http\Controllers\Api\V1\Front',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->post('generate', 'Controller@generate');
        });
    }
}
