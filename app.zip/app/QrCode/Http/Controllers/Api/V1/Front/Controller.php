<?php

namespace App\QrCode\Http\Controllers\Api\V1\Front;

use App\Http\Controllers\Admin\Controller as BaseController;
use App\QrCode\Http\Requests\Api\V1\Front\GenerateRequest;
use Response;
use SimpleSoftwareIO\QrCode\QrCodeInterface;

class Controller extends BaseController
{
    /**
     * Shorten a link.
     *
     * @param GenerateRequest $request Request instance.
     * @param QrCodeInterface $qrCode  Qr code generator instance.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function generate(GenerateRequest $request, QrCodeInterface $qrCode)
    {
        $qrCode = $qrCode
            ->format('png')
            ->size(400)
            ->generate($request->get('content'));

        return Response::make([
            'qr_code' => base64_encode($qrCode),
        ]);
    }
}
