<?php

namespace App\Content\Article;

use App\Content\Article;
use Creitive\Html\DefaultSeoPresenter;
use Opengraph\Opengraph;
use Str;
use URL;

class SeoPresenter extends DefaultSeoPresenter
{
    /**
     * @param Article $article The Article to present.
     */
    public function __construct(Article $article)
    {
        $this->type = Opengraph::TYPE_ARTICLE;

        if ($article->seo_title) {
            $this->title = $article->seo_title;
            $this->overridesTitle = true;
        } else {
            $this->title = $article->title;
        }

        if ($article->seo_description) {
            $this->description = $article->seo_description;
        } else {
            $this->description = Str::createExcerpt(strip_tags($article->lead), 160);
        }

        $this->image = URL::to($article->getImage('main', 'og'));
    }
}
