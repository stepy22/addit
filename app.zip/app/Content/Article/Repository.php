<?php

namespace App\Content\Article;

use App\Content\Article;
use App\Content\Article\TemplateRepository as ArticleTemplateRepository;
use App\Content\Page\Collection as PageCollection;
use Carbon\Carbon;
use Illuminate\Translation\Translator;

class Repository
{
    /**
     * An Article model instance.
     *
     * @var Article
     */
    protected $articleModel;

    /**
     * An ArticleTemplateRepository instance.
     *
     * @var ArticleTemplateRepository
     */
    protected $templateRepository;

    /**
     * @param Article                   $articleModel       An Article model instance.
     * @param ArticleTemplateRepository $templateRepository An ArticleTemplateRepository instance.
     */
    public function __construct(Article $articleModel, ArticleTemplateRepository $templateRepository)
    {
        $this->articleModel = $articleModel;
        $this->templateRepository = $templateRepository;
    }

    /**
     * Finds an article with the specified ID or fails.
     *
     * @param int $id The article ID.
     *
     * @return Article
     */
    public function findOrFail($id)
    {
        return $this->articleModel->findOrFail($id);
    }

    /**
     * Creates a new article and returns it.
     *
     * @param array $inputData The input data.
     *
     * @return Article
     */
    public function create(array $inputData)
    {
        $article = $this->articleModel->newInstance();

        $article->page_id = $inputData['page']->id;

        return $this->populateAndSave($article, $inputData);
    }

    /**
     * Updates the passed article and returns it.
     *
     * @param Article $article   The article to update.
     * @param array   $inputData The input data.
     *
     * @return Article
     */
    public function update(Article $article, array $inputData)
    {
        $article->page_id = (int) $inputData['page_id'];

        return $this->populateAndSave($article, $inputData);
    }

    /**
     * Populates the passed Article instance with the input data.
     *
     * @param Article $article   The article to populate.
     * @param array   $inputData The input data.
     *
     * @return Article
     */
    protected function populate(Article $article, array $inputData)
    {
        $article->title = array_get($inputData, 'title', '');
        $article->slug = array_get($inputData, 'slug', '');
        $article->template = array_get($inputData, 'template', 'default');

        $publishedAt = array_get($inputData, 'published_at', '');

        if ($publishedAt) {
            $article->published_at = Carbon::createFromFormat(trans('common.dateTimeFormat'), $publishedAt);
        } else {
            $article->published_at = null;
        }

        $article->lead = array_get($inputData, 'lead', '');
        $article->content = array_get($inputData, 'content', '');
        $article->highlighted_article = array_get($inputData, 'highlighted_article', false);

        $article->seo_title = array_get($inputData, 'seo_title', '');
        $article->seo_description = array_get($inputData, 'seo_description', '');
        $article->seo_image_main_alt_title = array_get($inputData, 'seo_image_main_alt_title', '');
        $article->seo_image_feature_alt_title = array_get($inputData, 'seo_image_feature_alt_title', '');

        if (isset($inputData['image_main_delete'])) {
            $article->deleteImage('main');
        }

        if (isset($inputData['image_feature_delete'])) {
            $article->deleteImage('feature');
        }

        if (isset($inputData['image_main'])) {
            $article->uploadImage($inputData['image_main'], 'main');
        }

        if (isset($inputData['image_feature'])) {
            $article->uploadImage($inputData['image_feature'], 'feature');
        }

        return $article;
    }

    /**
     * Populates the passed instance with the input data, saves and returns it.
     *
     * @param Article $article   The article to populate and save.
     * @param array   $inputData The input data.
     *
     * @return Article
     */
    protected function populateAndSave(Article $article, array $inputData)
    {
        $article = $this->populate($article, $inputData);

        $article->save();

        return $article;
    }

    /**
     * Attempts to delete the specified article.
     *
     * The input data must contain an `action` key, with the `confirm` value, in
     * order for the article to be deleted - otherwise, the article will not be
     * deleted, and `false` will be returned. If the article has been deleted
     * successfully, `true` will be returned.
     *
     * @param Article $article   The article to delete.
     * @param array   $inputData The input data.
     *
     * @return bool
     */
    public function delete(Article $article, array $inputData)
    {
        $action = array_get($inputData, 'action', 'cancel');

        if ($action === 'confirm') {
            $article->delete();

            return true;
        } else {
            return false;
        }
    }

    /**
     * Generates page options for a `<select>` element.
     *
     * @param PageCollection $pages All pages.
     * @param int            $level The nesting level to start from. Using this argument is not recommended.
     *
     * @return array
     */
    public function generatePageOptions(PageCollection $pages, $level = 0)
    {
        $options = [];

        foreach ($pages as $page) {
            $options[$page->id] = $this->generatePageOption($page->title, $level);

            // We're using `+` instead of `array_merge` so as to preserve the
            // numeric indexes (which are actually page IDs).
            $options += $this->generatePageOptions($page->children, $level + 1);
        }

        return $options;
    }

    /**
     * Generates a page option.
     *
     * @param string $title The page title.
     * @param int    $level The nesting level.
     *
     * @return string
     */
    protected function generatePageOption($title, $level)
    {
        // Note that we are using a non-breaking space here, instead of a
        // regular space character, to force browsers to display them as
        // intended.
        return str_repeat(' ', $level * 3).$title;
    }

    /**
     * Returns the template options.
     *
     * @return array
     */
    public function getTemplateOptions()
    {
        $templates = $this->templateRepository->getTemplates();

        $options = [];

        foreach ($templates as $id => $template) {
            $options[$id] = $template['label'];
        }

        return $options;
    }

    /**
     * Sorts articles in the passed order.
     *
     * @param array $inputData The input data.
     *
     * @return bool
     */
    public function sort(array $inputData)
    {
        $newOrder = array_map(
            function ($item) {
                return (int) $item['id'];
            },
            $inputData['items']
        );

        return $this->articleModel->updateSortOrder($newOrder);
    }

    /**
     * Gets feature article
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getFeatureArticle()
    {
        return $this->articleModel
            ->select('articles.*')
            ->join('pages', 'pages.id', '=', 'articles.page_id')
            ->where('pages.template', 'media')
            ->where('articles.highlighted_article', 1)
            ->get()
            ->first();
    }
}
