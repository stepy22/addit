<?php

namespace App\Content\Article;

use Creitive\Database\Eloquent\Collection as BaseCollection;

class Collection extends BaseCollection
{
}
