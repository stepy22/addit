<?php

namespace App\Content\Article;

use App\Content\Article;
use App\Content\Article\Repository as ArticleRepository;
use App\Content\Page;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use DaveJamesMiller\Breadcrumbs\Generator as BreadcrumbGenerator;
use DaveJamesMiller\Breadcrumbs\Manager as BreadcrumbManager;
use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Routing\Router;
use URL;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerRoutePatterns($this->app['router'], $this->app);
        $this->registerAdminRoutes($this->app['router']);
        $this->registerAdminApiRoutes($this->app['router']);
        $this->registerAdminBreadcrumbs($this->app['breadcrumbs']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers the route patterns.
     *
     * @param Router    $router    A router.
     * @param Container $container A dependency container.
     *
     * @return void
     */
    protected function registerRoutePatterns(Router $router, Container $container)
    {
        $idRegex = $this->routePatternRegexes['id'];

        $router->pattern('article', $idRegex);

        $router->bind('article', function ($value) use ($container) {
            return $container->make(ArticleRepository::class)->findOrFail($value);
        });
    }

    /**
     * Registers admin panel routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerAdminRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'admin/articles',
            'middleware' => ['web', 'auth', 'permissions'],
            'namespace' => 'App\Content\Http\Controllers\Admin\Article',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('{article}/edit', 'Controller@edit');
            $router->put('{article}', 'Controller@update');

            $router->get('{article}/delete', 'Controller@confirmDelete');
            $router->delete('{article}', 'Controller@delete');
        });
    }

    /**
     * Registers API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerAdminApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1/article-images',
            'middleware' => ['web', 'auth', 'permissions'],
            'namespace' => 'App\Content\Http\Controllers\Api\V1\Admin\ArticleImage',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->post('{article}', 'Controller@store');
        });

        $attributes = [
            'prefix' => 'api/v1/article',
            'middleware' => ['api', 'auth', 'permissions'],
            'namespace' => 'App\Content\Http\Controllers\Api\V1\Admin\Article',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->put('sort', 'Controller@sort');
        });
    }

    /**
     * Registers breadcrumbs for the admin panel.
     *
     * @param BreadcrumbManager $breadcrumbs A breadcrumb manager.
     *
     * @return void
     */
    protected function registerAdminBreadcrumbs(BreadcrumbManager $breadcrumbs)
    {
        $breadcrumbs->register('admin::articles', function (BreadcrumbGenerator $breadcrumbs, Page $page) {
            $breadcrumbs->parent('admin::pages.show', $page);

            $url = URL::action('App\Content\Http\Controllers\Admin\Article\Controller@index', ['page' => $page->id]);

            $breadcrumbs->push(trans('admin/articles.titles.index'), $url);
        });

        $breadcrumbs->register('admin::articles.show', function (BreadcrumbGenerator $breadcrumbs, Article $article) {
            $breadcrumbs->parent('admin::articles', $article->page);

            $breadcrumbs->push($article->title);
        });

        $breadcrumbs->register('admin::articles.create', function (BreadcrumbGenerator $breadcrumbs, Page $page) {
            $breadcrumbs->parent('admin::articles', $page);

            $url = URL::action('App\Content\Http\Controllers\Admin\Article\Controller@create', ['page' => $page->id]);

            $breadcrumbs->push(trans('admin/articles.titles.create'), $url);
        });

        $breadcrumbs->register('admin::articles.edit', function (BreadcrumbGenerator $breadcrumbs, Article $article) {
            $breadcrumbs->parent('admin::articles.show', $article);

            $url = URL::action('App\Content\Http\Controllers\Admin\Article\Controller@edit', ['article' => $article->id]);

            $breadcrumbs->push(trans('admin/articles.titles.edit'), $url);
        });

        $breadcrumbs->register('admin::articles.delete', function (BreadcrumbGenerator $breadcrumbs, Article $article) {
            $breadcrumbs->parent('admin::articles.show', $article);

            $url = URL::action('App\Content\Http\Controllers\Admin\Article\Controller@confirmDelete', ['article' => $article->id]);

            $breadcrumbs->push(trans('admin/articles.titles.delete'), $url);
        });
    }
}
