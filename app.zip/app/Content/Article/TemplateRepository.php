<?php

namespace App\Content\Article;

use App\Content\AbstractTemplateRepository;

class TemplateRepository extends AbstractTemplateRepository
{
    /**
     * {@inheritDoc}
     */
    protected function loadTemplates()
    {
        return $this->config->get('templates.articles');
    }
}
