<?php

namespace App\Content;

use Creitive\Database\Eloquent\Model;
use Creitive\Image\Transformers\CropThumbnail;
use Creitive\Models\Traits\ImageableTrait;
use Creitive\Models\Traits\SortableTrait;
use Illuminate\Database\Eloquent\SoftDeletes;
use URL;

class Image extends Model
{
    use ImageableTrait;
    use SoftDeletes;
    use SortableTrait;

    /**
     * {@inheritDoc}
     */
    protected $visible = [
        'id',
        'url_image_main_original',
        'url_image_main_large',
        'url_image_main_thumbnail',
        'url_image_main_dropzone',
        'url_image_main_og',
    ];

    /**
     * {@inheritDoc}
     */
    protected $appends = [
        'url_image_main_original',
        'url_image_main_large',
        'url_image_main_thumbnail',
        'url_image_main_dropzone',
        'url_image_main_og',
    ];

    /**
     * {@inheritDoc}
     */
    public function getImageConfiguration()
    {
        return [
            'versions' => [
                'main' => [
                    'original' => [],
                    'large' => [
                        [
                            'transformer' => CropThumbnail::class,
                            'width' => 800,
                            'height' => 550,
                        ],
                    ],
                    'thumbnail' => [
                        [
                            'transformer' => CropThumbnail::class,
                            'width' => 100,
                            'height' => 100,
                        ],
                    ],
                    'dropzone' => [
                        [
                            'transformer' => CropThumbnail::class,
                            'width' => 100,
                            'height' => 100,
                        ],
                    ],
                    'og' => [
                        [
                            'transformer' => CropThumbnail::class,
                            'width' => 1200,
                            'height' => 630,
                        ],
                    ],
                ],
            ],
        ];
    }

    /**
     * Eloquent relationship: a polymorphic relationship to classes that can own
     * an image.
     *
     * @return \Illuminate\Database\Eloquent\Relations\MorphTo
     */
    public function imageable()
    {
        return $this->morphTo();
    }

    /**
     * Gets the complete URL to the original main image.
     *
     * @return string
     */
    public function getUrlImageMainOriginalAttribute()
    {
        return URL::to($this->getImage('main', 'original'));
    }

    /**
     * Gets the complete URL to the large main image.
     *
     * @return string
     */
    public function getUrlImageMainLargeAttribute()
    {
        return URL::to($this->getImage('main', 'large'));
    }

    /**
     * Gets the complete URL to the thumbnail main image.
     *
     * @return string
     */
    public function getUrlImageMainThumbnailAttribute()
    {
        return URL::to($this->getImage('main', 'thumbnail'));
    }

    /**
     * Gets the complete URL to the dropzone main image.
     *
     * @return string
     */
    public function getUrlImageMainDropzoneAttribute()
    {
        return URL::to($this->getImage('main', 'dropzone'));
    }

    /**
     * Gets the complete URL to the og main image.
     *
     * @return string
     */
    public function getUrlImageMainOgAttribute()
    {
        return URL::to($this->getImage('main', 'og'));
    }
}
