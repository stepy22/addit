<?php

namespace App\Content\Http\Controllers\Front\Page;

use App\Auth\Subscription\Manager as SubscriptionManager;
use App\Content\Article;
use App\Content\Article\Repository as ArticleRepository;
use App\Content\Article\SeoPresenter as ArticleSeoPresenter;
use App\Content\Exceptions\UndefinedPageAutoRedirectUrlException;
use App\Content\Page;
use App\Content\Page\SeoPresenter as PageSeoPresenter;
use App\Http\Controllers\Front\Controller as BaseController;
use App\WidgetTypes\WidgetType\Repository as WidgetTypeRepository;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator as Paginator;
use Illuminate\Translation\Translator;
use Redirect;
use URL;

class Controller extends BaseController
{
    /**
     * The current Request instance.
     *
     * @var Request
     */
    protected $request;

    /**
     * An Article model instance.
     *
     * @var Article
     */
    protected $articleModel;

    /**
     * An Article model instance.
     *
     * @var Article
     */
    protected $articleRepository;

    /**
     * An subscription manager instance
     *
     * @var SubscriptionManager
     */
    protected $subscriptionManager;

    /**
     * An widget type repository instance
     *
     * @var WidgetTypeRepository
     */
    protected $widgetTypeRepository;

    /**
     * @param Request              $request              The current request instance.
     * @param Article              $articleModel         An article model instance.
     * @param ArticleRepository    $articleRepository    An article repository instance.
     * @param SubscriptionManager  $subscriptionManager  An subscription manager instance.
     * @param WidgetTypeRepository $widgetTypeRepository A widget type repository instance.
     */
    public function __construct(
        Request $request,
        Article $articleModel,
        ArticleRepository $articleRepository,
        SubscriptionManager $subscriptionManager,
        WidgetTypeRepository $widgetTypeRepository
    ) {
        parent::__construct();

        $this->request = $request;
        $this->articleModel = $articleModel;
        $this->articleRepository = $articleRepository;
        $this->subscriptionManager = $subscriptionManager;
        $this->widgetTypeRepository = $widgetTypeRepository;

        $this->viewData->bodyDataPage = 'home';
    }

    /**
     * Resolves a dynamic website route.
     *
     * Throws a `ModelNotFoundException` if the route cannot be resolved.
     *
     * @param string $route The route to be resolved.
     *
     * @return \Illuminate\View\View
     *
     * @throws ModelNotFoundException
     */
    public function resolveRoute($route)
    {
        // First, we'll split the passed route string on the slash character, so
        // we get all individual route segments, which we'll use to resolve the
        // final route.
        $path = explode('/', $route);

        // We need to pop the last slug, since that's what represents either an
        // article or a page - we're not sure at this moment, but we'll find out
        // soon. All the prior segments are the path to that resource. We can
        // safely do this, because the `$path` variable passed to this action
        // will always be a non-empty string, due to the route pattern used for
        // defining this route (which requires at least one character).
        //
        // Note that the `$path` array may be left empty after this operation.
        $lastSlug = array_pop($path);

        // If the path is empty, the only valid situation is that we were passed
        // a request for a root-level page. We'll immediately find and handle
        // it.
        if (empty($path)) {
            $page = $this->pages->findBySlug($lastSlug);

            if ($page === null) {
                throw new ModelNotFoundException();
            }

            if ($page->autoRedirects()) {
                return $this->handleAutoRedirect($page);
            }

            return $this->handlePage($page);
        }

        // Since the path wasn't empty, that means that a request for a nested
        // page or article was made. Since both pages and articles may only
        // belong to a parent page, we'll find that parent page first.
        $parentPage = $this->pages->findBySlugPath($path);

        if ($parentPage === null) {
            throw new ModelNotFoundException();
        }

        // Now that we know the parent page, we'll try to figure out whether the
        // last segment was a nested page, or an article. This cannot be
        // enforced at the database level, and we're not enforcing it at the
        // application level for pragmatic reasons. Therefore, it's possible to
        // have an ambiguous situation, where both a page and an article exist
        // within the same parent page, and have the same slug. In that
        // situation, we'll give a higher priority to the found page.
        $page = $parentPage->children->findBySlug($lastSlug);

        if ($page !== null) {
            if ($page->autoRedirects()) {
                return $this->handleAutoRedirect($page);
            }

            return $this->handlePage($page);
        }

        // If the last segment wasn't a page, it must be an article, so let's
        // try to resolve that.
        $article = $parentPage->articles()->whereSlug($lastSlug)->first();

        if ($article !== null) {
            // We're injecting the parent page reference to avoid additional
            // queries from within the article, in cases where `$article->page`
            // is called, e.g. when resolving the article URL.
            $article->page = $parentPage;

            return $this->handleArticle($article);
        }

        // If we didn't find a relevant article, we've exhausted our options, so
        // it must be a non-existent URL, so we'll throw an exception.
        throw new ModelNotFoundException();
    }

    /**
     * Automatically redirects somewhere, if a page has an auto redirect
     * configured.
     *
     * @param Page $page The page.
     *
     * @return \Illuminate\Http\RedirectResponse
     *
     * @throws UndefinedPageAutoRedirectUrlException
     * @throws ModelNotFoundException
     */
    protected function handleAutoRedirect(Page $page)
    {
        switch ($page->auto_redirect) {
            case Page::AUTO_REDIRECT_PAGE:
                $target = $page->children->first();
                break;

            case Page::AUTO_REDIRECT_ARTICLE:
                $target = $page->articles->first();
                break;

            case Page::AUTO_REDIRECT_URL:
                if ($page->auto_redirect_url !== null) {
                    return Redirect::to($page->auto_redirect_url);
                } else {
                    throw new UndefinedPageAutoRedirectUrlException($page->id);
                }

                break;

            default:
                throw new ModelNotFoundException();
        }

        if ($target === null) {
            throw new ModelNotFoundException();
        }

        return Redirect::action('App\Content\Http\Controllers\Front\Page\Controller@resolveRoute', ['any' => $target->full_slug]);
    }

    /**
     * Handles displaying a page in the appropriate template.
     *
     * @param Page $page The page to display.
     *
     * @return \Illuminate\View\View
     */
    protected function handlePage(Page $page)
    {
        $this->viewData->navigation->get('front.main')->setActive($page->root()->slug);
        $this->viewData->setSeo(new PageSeoPresenter($page));

        $data = $this->getPageViewData($page);

        $data['homeHeader'] = 'header--primary';
        $data['homeNavbar'] = 'navbar--primary';
        $data['homeNavbarNav'] = 'navbar-nav--primary';
        $data['homeNavbarBrand'] = 'navbar-brand--primary';
        $data['homeNavbarNavLinksItem'] = 'navbar-nav-links-item--primary';
        $data['homeNavbarNavLinksItemLink'] = 'navbar-nav-links-item-link--primary';
        $data['homeNavbarSocialIcons'] = 'navbar-socialIcons--primary';
        $data['homeNavbarToggle'] = 'navbar-toggle--primary';
        $data['homeNavbarCollapse'] = 'navbar-collapse--primary';

        if ($page->template === 'media') {
            $data['highlightedArticle'] = $this->articleRepository->getFeatureArticle();
        }

        return view('templates.pages.'.$page->template, $data);
    }

    /**
     * Handles displaying an article in the appropriate template.
     *
     * @param Article $article The article to display.
     *
     * @return \Illuminate\View\View
     */
    protected function handleArticle(Article $article)
    {
        $this->viewData->navigation->get('front.main')->setActive($article->page->root()->slug);
        $this->viewData->setSeo(new ArticleSeoPresenter($article));

        return view('templates.articles.'.$article->template, ['article' => $article]);
    }

    /**
     * Gets page view data.
     *
     * @param Page $page The page.
     *
     * @return array
     */
    protected function getPageViewData(Page $page)
    {
        if ($page->articles_per_page === 0) {
            return [
                'page' => $page,
                'articles' => $page->articles,
            ];
        }

        // Resolve pagination.
        $paginationQueryParameterName = trans('pagination.urlSegment');
        $paginationIndex = (int) $this->request->get($paginationQueryParameterName, 1);

        if ($paginationIndex < 1) {
            $paginationIndex = 1;
        }

        $articles = $page->articles()->sqlCalcFoundRows()->forPage($paginationIndex, $page->articles_per_page)->get();

        // Generate pagination.
        $total = $this->articleModel->getLastTotalRowCount();
        $options = [
            'pageName' => trans('pagination.urlSegment'),
            'path' => URL::action('App\Content\Http\Controllers\Front\Page\Controller@resolveRoute', ['any' => $page->full_slug]),
        ];

        $paginator = new Paginator($articles, $total, $page->articles_per_page, $paginationIndex, $options);

        $data = [
            'page' => $page,
            'articles' => $articles,
            'paginator' => $paginator,
        ];

        if ($page->template === 'pricing') {
            $data = $this->getPricingPageViewData($page, $data);
        }

        return $data;
    }

    /**
     * Gets data specific to a pricing page.
     *
     * @param  Page  $page Page instance.
     * @param  array $data View data array.
     *
     * @return array
     */
    protected function getPricingPageViewData(Page $page, array $data)
    {
        $data['yearlyPrice'] = $this->subscriptionManager->getProPriceYearly();
        $data['monthlyPrice'] = $this->subscriptionManager->getProPriceMonthly();
        $data['yearlyDiscount'] = $this->subscriptionManager->getYearlyPriceDiscount();
        $data['platinumWidgets'] = $this->widgetTypeRepository->getAll(['is_platinum' => true]);

        return $data;
    }
}
