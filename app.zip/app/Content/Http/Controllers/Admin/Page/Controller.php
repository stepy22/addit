<?php

namespace App\Content\Http\Controllers\Admin\Page;

use App\Content\Http\Requests\Admin\Page\StoreRequest;
use App\Content\Http\Requests\Admin\Page\UpdateRequest;
use App\Content\Page;
use App\Content\Page\Repository as PageRepository;
use App\Http\Controllers\Admin\Controller as AbstractBaseController;
use Illuminate\Http\Request;
use Illuminate\Support\MessageBag;
use Redirect;

class Controller extends AbstractBaseController
{
    /**
     */
    public function __construct()
    {
        parent::__construct();

        $this->viewData->bodyDataPage = 'admin-pages';
        $this->viewData->pageTitle->setPage(trans('admin/pages.module'));
        $this->viewData->navigation->get('admin.main')->setActive('pages');
    }

    /**
     * Shows all pages.
     *
     * @param PageRepository $pageRepository A page repository instance.
     *
     * @return \Illuminate\View\View
     */
    public function index(PageRepository $pageRepository)
    {
        $data = [
            'pages' => $pageRepository->getAll(),
        ];

        return view('admin.pages.index', $data);
    }

    /**
     * Displays the page create form.
     *
     * @param PageRepository $pageRepository A page repository instance.
     *
     * @return \Illuminate\View\View
     */
    public function create(PageRepository $pageRepository)
    {
        $data = [
            'templateOptions' => $pageRepository->getTemplateOptions(),
            'defaultTemplateOption' => 'default',
            'pageOptions' => $pageRepository->generatePageOptions($this->pages),
            'defaultPageOption' => 0,
        ];

        return view('admin.pages.create', $data);
    }

    /**
     * Saves a new page.
     *
     * @param StoreRequest   $request        A page store request.
     * @param PageRepository $pageRepository A page repository instance.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(StoreRequest $request, PageRepository $pageRepository)
    {
        if ($page = $pageRepository->create($request->all())) {
            return Redirect::action('App\Content\Http\Controllers\Admin\Page\Controller@edit', ['page' => $page->id])
                ->with('successMessages', new MessageBag([trans('admin/pages.successMessages.create')]));
        }

        return Redirect::action('App\Content\Http\Controllers\Admin\Page\Controller@create')
            ->withErrors($pageRepository->getErrors())
            ->withInput();
    }

    /**
     * Shows the specified page.
     *
     * @param Page           $page           The page to show.
     * @param PageRepository $pageRepository A page repository instance.
     *
     * @return \Illuminate\View\View
     */
    public function edit(Page $page, PageRepository $pageRepository)
    {
        $data = [
            'page' => $page,
            'templateOptions' => $pageRepository->getTemplateOptions(),
            'pageOptions' => $pageRepository->generatePageOptions($this->pages),
        ];

        return view('admin.pages.edit', $data);
    }

    /**
     * Updates the specified page.
     *
     * @param UpdateRequest  $request        A page update request.
     * @param Page           $page           The page to update.
     * @param PageRepository $pageRepository A page repository instance.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(UpdateRequest $request, Page $page, PageRepository $pageRepository)
    {
        if ($pageRepository->update($page, $request->all())) {
            return Redirect::action('App\Content\Http\Controllers\Admin\Page\Controller@edit', ['page' => $page->id])
                ->with('successMessages', new MessageBag([trans('admin/pages.successMessages.edit')]));
        }

        return Redirect::action('App\Content\Http\Controllers\Admin\Page\Controller@edit', ['page' => $page->id])
            ->withErrors($pageRepository->getErrors())
            ->withInput();
    }

    /**
     * Displays the page deletion confirmation form.
     *
     * @param Page $page The page.
     *
     * @return \Illuminate\View\View
     */
    public function confirmDelete(Page $page)
    {
        $data = [
            'page' => $page,
        ];

        return view('admin.pages.delete', $data);
    }

    /**
     * Deletes a page.
     *
     * @param Request        $request        The current request.
     * @param Page           $page           The page to delete.
     * @param PageRepository $pageRepository A page repository instance.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function delete(Request $request, Page $page, PageRepository $pageRepository)
    {
        if ($pageRepository->delete($page, $request->all())) {
            return Redirect::action('App\Content\Http\Controllers\Admin\Page\Controller@index')
                ->with('successMessages', new MessageBag([trans('admin/pages.successMessages.delete', ['title' => $page->title])]));
        }

        return Redirect::action('App\Content\Http\Controllers\Admin\Page\Controller@index');
    }
}
