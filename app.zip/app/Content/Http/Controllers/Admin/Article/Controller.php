<?php

namespace App\Content\Http\Controllers\Admin\Article;

use App\Content\Article;
use App\Content\Article\Repository as ArticleRepository;
use App\Content\Http\Requests\Admin\Article\StoreRequest;
use App\Content\Http\Requests\Admin\Article\UpdateRequest;
use App\Content\Page;
use App\Http\Controllers\Admin\Controller as AbstractBaseController;
use Illuminate\Http\Request;
use Illuminate\Support\MessageBag;
use Redirect;

class Controller extends AbstractBaseController
{
    /**
     */
    public function __construct()
    {
        parent::__construct();

        $this->viewData->bodyDataPage = 'admin-articles';
        $this->viewData->pageTitle->setPage(trans('admin/articles.module'));
        $this->viewData->navigation->get('admin.main')->setActive('pages');
    }

    /**
     * Shows all articles belonging to a page.
     *
     * @param Page $page The page whose articles to show.
     *
     * @return \Illuminate\View\View
     */
    public function index(Page $page)
    {
        $data = [
            'page' => $page,
        ];

        return view('admin.articles.index', $data);
    }

    /**
     * Displays the article create form.
     *
     * @param Page              $page              The page within which the article is being created.
     * @param ArticleRepository $articleRepository An article repository instance.
     *
     * @return \Illuminate\View\View
     */
    public function create(Page $page, ArticleRepository $articleRepository)
    {
        $data = [
            'templateOptions' => $articleRepository->getTemplateOptions(),
            'defaultTemplateOption' => 'default',
            'page' => $page,
        ];

        return view('admin.articles.create', $data);
    }

    /**
     * Saves a new article.
     *
     * @param StoreRequest      $request           An article store request.
     * @param Page              $page              The page within which the article is being created.
     * @param ArticleRepository $articleRepository An article repository instance.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(StoreRequest $request, Page $page, ArticleRepository $articleRepository)
    {
        $inputData = $request->all();
        $inputData['page'] = $page;

        if ($article = $articleRepository->create($inputData)) {
            return Redirect::action('App\Content\Http\Controllers\Admin\Article\Controller@edit', ['article' => $article->id])
                ->with('successMessages', new MessageBag([trans('admin/articles.successMessages.create')]));
        }

        return Redirect::action('App\Content\Http\Controllers\Admin\Article\Controller@create', ['page' => $page->id])
            ->withErrors($articleRepository->getErrors())
            ->withInput();
    }

    /**
     * Shows the specified article.
     *
     * @param Article           $article           The article to show.
     * @param ArticleRepository $articleRepository An article repository instance.
     *
     * @return \Illuminate\View\View
     */
    public function edit(Article $article, ArticleRepository $articleRepository)
    {
        $data = [
            'article' => $article,
            'templateOptions' => $articleRepository->getTemplateOptions(),
            'pageOptions' => $articleRepository->generatePageOptions($this->pages),
        ];

        return view('admin.articles.edit', $data);
    }

    /**
     * Updates the specified article.
     *
     * @param UpdateRequest     $request           An article update request.
     * @param Article           $article           The article to update.
     * @param ArticleRepository $articleRepository An article repository instance.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(UpdateRequest $request, Article $article, ArticleRepository $articleRepository)
    {
        if ($articleRepository->update($article, $request->all())) {
            return Redirect::action('App\Content\Http\Controllers\Admin\Article\Controller@edit', ['article' => $article->id])
                ->with('successMessages', new MessageBag([trans('admin/articles.successMessages.edit')]));
        }

        return Redirect::action('App\Content\Http\Controllers\Admin\Article\Controller@edit', ['article' => $article->id])
            ->withErrors($articleRepository->getErrors())
            ->withInput();
    }

    /**
     * Displays the article deletion confirmation form.
     *
     * @param Article $article The article to delete.
     *
     * @return \Illuminate\View\View
     */
    public function confirmDelete(Article $article)
    {
        $data = [
            'article' => $article,
        ];

        return view('admin.articles.delete', $data);
    }

    /**
     * Deletes an article.
     *
     * @param Request           $request           The current request.
     * @param Article           $article           The article to delete.
     * @param ArticleRepository $articleRepository An article repository instance.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function delete(Request $request, Article $article, ArticleRepository $articleRepository)
    {
        if ($articleRepository->delete($article, $request->all())) {
            return Redirect::action('App\Content\Http\Controllers\Admin\Article\Controller@index', ['page' => $article->page->id])
                ->with('successMessages', new MessageBag([trans('admin/articles.successMessages.delete', ['title' => $article->title])]));
        }

        return Redirect::action('App\Content\Http\Controllers\Admin\Article\Controller@index', ['page' => $article->page->id]);
    }
}
