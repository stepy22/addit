<?php

namespace App\Content\Http\Requests\Api\Admin\Image;

use App\Http\Requests\Request;
use Cartalyst\Sentinel\Sentinel;

class SortRequest extends Request
{
    /**
     * A Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * @param Sentinel $sentinel A Sentinel instance.
     */
    public function __construct(Sentinel $sentinel)
    {
        parent::__construct();

        $this->sentinel = $sentinel;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $user = $this->sentinel->getUser();

        $rules = [
            'items' => ['required', 'array'],
        ];

        return $rules;
    }
}
