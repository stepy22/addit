<?php

namespace App\Content\Http\Requests\Admin\Article;

use App\Content\Article\TemplateRepository as ArticleTemplateRepository;
use App\Content\Page\Repository as PageRepository;
use App\Http\Requests\Request;
use Cartalyst\Sentinel\Sentinel;

class UpdateRequest extends Request
{
    /**
     * A Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * A PageRepository instance.
     *
     * @var PageRepository
     */
    protected $pageRepository;

    /**
     * An ArticleTemplateRepository instance.
     *
     * @var ArticleTemplateRepository
     */
    protected $articleTemplateRepository;

    /**
     * @param Sentinel                  $sentinel                  A Sentinel instance.
     * @param PageRepository            $pageRepository            A PageRepository instance.
     * @param ArticleTemplateRepository $articleTemplateRepository An ArticleTemplateRepository instance.
     */
    public function __construct(Sentinel $sentinel, PageRepository $pageRepository, ArticleTemplateRepository $articleTemplateRepository)
    {
        parent::__construct();

        $this->sentinel = $sentinel;
        $this->pageRepository = $pageRepository;
        $this->articleTemplateRepository = $articleTemplateRepository;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'page_id' => ['required', 'digits_only', 'parent_id:pages'],
            'title' => ['required'],
            'slug' => ['slug'],
            'template' => ['required', 'template'],
            'image_main' => ['image', 'max:10240'],
            'image_feature' => ['image', 'max:10240'],
        ];

        return $rules;
    }

    /**
     * Extend the parent method so fields can be modified or added before
     * validation.
     *
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function getValidatorInstance()
    {
        $this->merge([
            'pages' => $this->pageRepository->getAll(),
            'templates' => $this->articleTemplateRepository->getTemplates(),
        ]);

        return parent::getValidatorInstance();
    }
}
