<?php

namespace App\Content\Http\Requests\Admin\Article;

use App\Content\Article\TemplateRepository as ArticleTemplateRepository;
use App\Http\Requests\Request;
use Cartalyst\Sentinel\Sentinel;

class StoreRequest extends Request
{
    /**
     * A Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * An ArticleTemplateRepository instance.
     *
     * @var ArticleTemplateRepository
     */
    protected $articleTemplateRepository;

    /**
     * @param Sentinel                  $sentinel                  A Sentinel instance.
     * @param ArticleTemplateRepository $articleTemplateRepository An ArticleTemplateRepository instance.
     */
    public function __construct(Sentinel $sentinel, ArticleTemplateRepository $articleTemplateRepository)
    {
        parent::__construct();

        $this->sentinel = $sentinel;
        $this->articleTemplateRepository = $articleTemplateRepository;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'title' => ['required'],
            'slug' => ['slug'],
            'template' => ['required', 'template'],
            'image_main' => ['image', 'max:10240'],
            'image_feature' => ['image', 'max:10240'],
        ];

        return $rules;
    }

    /**
     * Extend the parent method so fields can be modified or added before
     * validation.
     *
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function getValidatorInstance()
    {
        $this->merge([
            'templates' => $this->articleTemplateRepository->getTemplates(),
        ]);

        return parent::getValidatorInstance();
    }
}
