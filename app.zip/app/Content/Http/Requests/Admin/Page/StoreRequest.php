<?php

namespace App\Content\Http\Requests\Admin\Page;

use App\Content\Page\Repository as PageRepository;
use App\Content\Page\TemplateRepository as PageTemplateRepository;
use App\Http\Requests\Request;
use Cartalyst\Sentinel\Sentinel;

class StoreRequest extends Request
{
    /**
     * A Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * A PageRepository instance
     *
     * @var PageRepository
     */
    protected $pageRepository;

    /**
     * A PageTemplateRepository instance
     *
     * @var PageTemplateRepository
     */
    protected $pageTemplateRepository;

    /**
     * @param Sentinel               $sentinel               A Sentinel instance.
     * @param PageRepository         $pageRepository         A page repository instance.
     * @param PageTemplateRepository $pageTemplateRepository A page template repository instance.
     */
    public function __construct(
        Sentinel $sentinel,
        PageRepository $pageRepository,
        PageTemplateRepository $pageTemplateRepository
    ) {
        parent::__construct();

        $this->sentinel = $sentinel;
        $this->pageRepository = $pageRepository;
        $this->pageTemplateRepository = $pageTemplateRepository;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'parent_id' => ['required', 'digits_only', 'parent_id:pages'],
            'title' => ['required'],
            'slug' => ['slug'],
            'template' => ['required', 'template'],
            'image_main' => ['image', 'max:10240'],
            'pdf_file' => ['mimes:pdf'],
        ];

        return $rules;
    }

    /**
     * Extend the parent method so that fields can be modified or added before
     * validation.
     *
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function getValidatorInstance()
    {
        $this->merge([
            'pages' => $this->pageRepository->getAll(),
            'templates' => $this->pageTemplateRepository->getTemplates(),
        ]);

        return parent::getValidatorInstance();
    }
}
