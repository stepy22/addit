<?php

namespace App\Content;

use Illuminate\Config\Repository as ConfigRepository;
use RuntimeException;

abstract class AbstractTemplateRepository
{
    /**
     * A Config repository instance.
     *
     * @var ConfigRepository
     */
    protected $config;

    /**
     * An array of available templates.
     *
     * @var array
     */
    protected $templates = [];

    /**
     * @param ConfigRepository $config A Config repository instance.
     */
    public function __construct(ConfigRepository $config)
    {
        $this->config = $config;

        $this->templates = $this->loadTemplates();
    }

    /**
     * Returns the templates for this template repository.
     *
     * @return void
     */
    abstract protected function loadTemplates();

    /**
     * Checks whether a specified template exists.
     *
     * @param string $id The template ID.
     *
     * @return bool
     */
    public function templateExists($id)
    {
        return isset($this->templates[$id]);
    }

    /**
     * Gets a specific template's configuration.
     *
     * @param string $id The template ID.
     *
     * @return array
     *
     * @throws RuntimeException
     */
    public function getTemplate($id)
    {
        if (!$this->templateExists($id)) {
            throw new RuntimeException('The provided template does not exist.');
        }

        return $this->templates[$id];
    }

    /**
     * Returns all the templates.
     *
     * @return array
     */
    public function getTemplates()
    {
        return $this->templates;
    }

    /**
     * Returns the validation rules.
     *
     * @param string $templateName The name of the template.
     *
     * @return array
     */
    public function getPageValidationRules($templateName)
    {
        $template = $this->getPageTemplate($templateName);

        $validationRules = [];

        foreach ($template['attributes'] as $attributeName => $attributeConfiguration) {
            $validationRules[$attributeName] = $attributeConfiguration['validation'];
        }

        return $validationRules;
    }

    /**
     * Gets attributes for a template.
     *
     * @param string $templateName    The template name.
     * @param array  $attributeValues The attribute values.
     *
     * @return array
     */
    public function getAttributes($templateName, array $attributeValues)
    {
        $attributes = [];

        $template = $this->getPageTemplate($templateName);

        foreach ($template['attributes'] as $attribute => $attributeConfiguration) {
            if ($attributeConfiguration['type'] === 'checkbox') {
                $attributes[$attribute] = (isset($attributeValues[$attribute])) ? $attributeValues[$attribute] : 0;

                continue;
            }

            if (!isset($attributeValues[$attribute])) {
                continue;
            }

            $attributes[$attribute] = $attributeValues[$attribute];
        }

        return $attributes;
    }
}
