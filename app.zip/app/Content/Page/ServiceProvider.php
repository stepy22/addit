<?php

namespace App\Content\Page;

use App\Content\Page;
use App\Content\Page\Repository as PageRepository;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Creitive\Routing\LocaleResolver;
use DaveJamesMiller\Breadcrumbs\Generator as BreadcrumbGenerator;
use DaveJamesMiller\Breadcrumbs\Manager as BreadcrumbManager;
use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Routing\Router;
use URL;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerRoutePatterns($this->app['router'], $this->app);
        $this->registerAdminRoutes($this->app['router']);
        $this->registerAdminApiRoutes($this->app['router']);
        $this->registerFrontApiRoutes($this->app['router']);
        $this->registerAdminBreadcrumbs($this->app['breadcrumbs']);
        $this->registerFrontRoutes($this->app['router']);
        $this->cascadePageDeletes();
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Sets up a model event that deletes all child pages and articles of a
     * page, when the page is deleted.
     *
     * @return void
     */
    public function cascadePageDeletes()
    {
        Page::deleted(function (Page $page) {
            $page->load('children.articles', 'articles');

            foreach ($page->children as $childPage) {
                $childPage->load('articles');
                foreach ($childPage->articles as $childPageArticle) {
                    $childPageArticle->delete();
                }

                $childPage->delete();
            }

            foreach ($page->articles as $pageArticles) {
                $pageArticles->delete();
            }
        });
    }

    /**
     * Registers the route patterns.
     *
     * @param Router    $router    A router.
     * @param Container $container A dependency container.
     *
     * @return void
     */
    protected function registerRoutePatterns(Router $router, Container $container)
    {
        $idRegex = $this->routePatternRegexes['id'];

        $router->pattern('page', $idRegex);

        $router->bind('page', function ($value) use ($container) {
            return $container->make(PageRepository::class)->findOrFail($value);
        });
    }

    /**
     * Registers admin panel routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerAdminRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'admin/pages',
            'middleware' => ['web', 'auth', 'permissions'],
            'namespace' => 'App\Content\Http\Controllers\Admin',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('', 'Page\Controller@index');

            $router->get('create', 'Page\Controller@create');
            $router->post('', 'Page\Controller@store');

            $router->get('{page}/edit', 'Page\Controller@edit');
            $router->put('{page}', 'Page\Controller@update');

            $router->get('{page}/delete', 'Page\Controller@confirmDelete');
            $router->delete('{page}', 'Page\Controller@delete');

            /*
             * Articles.
             */
            $router->get('{page}/articles', 'Article\Controller@index');
            $router->get('{page}/articles/create', 'Article\Controller@create');
            $router->post('{page}/articles', 'Article\Controller@store');
        });
    }

    /**
     * Registers front panel routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontRoutes(RegistrarContract $router)
    {
        $anyRegex = $this->routePatternRegexes['any'];
        $router->pattern('any', $anyRegex);

        $attributes = [
            'middleware' => ['web'],
            'namespace' => 'App\Content\Http\Controllers\Front\Page',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('{any}', 'Controller@resolveRoute');
        });
    }

    /**
     * Registers API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerAdminApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1/pages',
            'middleware' => ['api', 'auth', 'permissions'],
            'namespace' => 'App\Content\Http\Controllers\Api\V1\Admin\Page',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->put('sort', 'Controller@sort');
        });

        $attributes = [
            'prefix' => 'api/v1/page-images',
            'middleware' => ['api', 'auth', 'permissions'],
            'namespace' => 'App\Content\Http\Controllers\Api\V1\Admin\PageImage',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->post('{page}', 'Controller@store');
        });
    }

    /**
     * Registers API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1/pages',
            'middleware' => ['api'],
            'namespace' => 'App\Content\Http\Controllers\Api\V1\Front\Page',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('templates/{template}', 'Controller@getPageByTemplate');
        });
    }

    /**
     * Registers breadcrumbs for the admin panel.
     *
     * @param BreadcrumbManager $breadcrumbs A breadcrumb manager.
     *
     * @return void
     */
    protected function registerAdminBreadcrumbs(BreadcrumbManager $breadcrumbs)
    {
        $breadcrumbs->register('admin::pages', function (BreadcrumbGenerator $breadcrumbs) {
            $breadcrumbs->parent('admin::home');

            $url = URL::action('App\Content\Http\Controllers\Admin\Page\Controller@index');

            $breadcrumbs->push(trans('admin/navigation.pages'), $url);
        });

        $breadcrumbs->register('admin::pages.show', function (BreadcrumbGenerator $breadcrumbs, Page $page) {
            $breadcrumbs->parent('admin::pages');

            $breadcrumbs->push($page->title);
        });

        $breadcrumbs->register('admin::pages.create', function (BreadcrumbGenerator $breadcrumbs) {
            $breadcrumbs->parent('admin::pages');

            $url = URL::action('App\Content\Http\Controllers\Admin\Page\Controller@create');

            $breadcrumbs->push(trans('admin/pages.titles.create'), $url);
        });

        $breadcrumbs->register('admin::pages.edit', function (BreadcrumbGenerator $breadcrumbs, Page $page) {
            $breadcrumbs->parent('admin::pages.show', $page);

            $url = URL::action('App\Content\Http\Controllers\Admin\Page\Controller@edit', ['page' => $page->id]);

            $breadcrumbs->push(trans('admin/pages.titles.edit'), $url);
        });

        $breadcrumbs->register('admin::pages.delete', function (BreadcrumbGenerator $breadcrumbs, Page $page) {
            $breadcrumbs->parent('admin::pages.show', $page);

            $url = URL::action('App\Content\Http\Controllers\Admin\Page\Controller@confirmDelete', ['page' => $page->id]);

            $breadcrumbs->push(trans('admin/pages.titles.delete'), $url);
        });
    }
}
