<?php

namespace App\Content\Page;

use App\Content\AbstractTemplateRepository;

class TemplateRepository extends AbstractTemplateRepository
{
    /**
     * {@inheritDoc}
     */
    protected function loadTemplates()
    {
        return $this->config->get('templates.pages');
    }
}
