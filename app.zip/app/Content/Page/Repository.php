<?php

namespace App\Content\Page;

use App\Content\Article;
use App\Content\Page;
use App\Content\Page\Collection as PageCollection;
use App\Content\Page\TemplateRepository as PageTemplateRepository;
use Carbon\Carbon;
use Creitive\File\Uploader as FileUploader;

class Repository
{
    /**
     * A Page model instance.
     *
     * @var Page
     */
    protected $pageModel;

    /**
     * A PageTemplateRepository instance.
     *
     * @var PageTemplateRepository
     */
    protected $pageTemplateRepository;

    /**
     * A FileUploader instance.
     *
     * @var FileUploader
     */
    protected $fileUploader;

    /**
     * @param Page                   $pageModel              A Page model instance.
     * @param PageTemplateRepository $pageTemplateRepository A PageTemplateRepository instance.
     * @param FileUploader           $fileUploader           A FileUploader instance.
     */
    public function __construct(Page $pageModel, PageTemplateRepository $pageTemplateRepository, FileUploader $fileUploader)
    {
        $this->pageModel = $pageModel;
        $this->pageTemplateRepository = $pageTemplateRepository;
        $this->fileUploader = $fileUploader;
    }

    /**
     * Finds a page by its ID or fails.
     *
     * @param int $id The page ID.
     *
     * @return Page
     */
    public function findOrFail($id)
    {
        return $this->pageModel->findOrFail($id);
    }

    /**
     * Returns the template options.
     *
     * @return array
     */
    public function getTemplateOptions()
    {
        $templates = $this->pageTemplateRepository->getTemplates();
        $options = [];

        foreach ($templates as $id => $template) {
            $options[$id] = $template['label'];
        }

        return $options;
    }

    /**
     * Generates page options for a `<select>` element.
     *
     * @param PageCollection $pages A collection of all pages.
     * @param int            $level The nesting level. Passing this argument is not recommended.
     *
     * @return array
     */
    public function generatePageOptions(PageCollection $pages, $level = 0)
    {
        $options = [];

        // We need to add the "root level" parent page option. Since the ID `0`
        // doesn't actually exist in the database, we'll use that index to
        // represent the root level.
        if ($level === 0) {
            $options[0] = '';
        }

        foreach ($pages as $page) {
            $options[$page->id] = $this->generatePageOption($page->title, $level);

            // We're using `+` instead of `array_merge` so as to preserve the
            // numeric indexes (which are actually page IDs).
            $options += $this->generatePageOptions($page->children, $level + 1);
        }

        return $options;
    }

    /**
     * Generates a page option.
     *
     * @param string $title The page title.
     * @param int    $level The nesting level.
     *
     * @return string
     */
    protected function generatePageOption($title, $level)
    {
        // Note that we are using a non-breaking space here, instead of a
        // regular space character, to force browsers to display them as
        // intended.
        return str_repeat(' ', $level * 3).$title;
    }

    /**
     * Gets all the pages, nested properly.
     *
     * @return PageCollection
     */
    public function getAll()
    {
        $pages = $this->pageModel->sorted()->get();

        return $pages->nest();
    }

    /**
     * Gets single pages by template.
     *
     * @param string $template The template ID.
     *
     * @return PageCollection
     */
    public function getByTemplate($template)
    {
        return $this->pageModel
            ->where(['template' => $template])
            ->get()
            ->first()
            ->load('articles');
    }

    /**
     * Creates a new page and returns it.
     *
     * @param array $inputData The input data.
     *
     * @return Page
     */
    public function create(array $inputData)
    {
        return $this->populateAndSave($this->pageModel->newInstance(), $inputData);
    }

    /**
     * Updates the passed page and returns it.
     *
     * @param Page  $page      The page to update.
     * @param array $inputData The input data.
     *
     * @return Page
     */
    public function update(Page $page, array $inputData)
    {
        return $this->populateAndSave($page, $inputData);
    }

    /**
     * Populates the passed Page instance with the input data.
     *
     * @param Page  $page      The page to populate.
     * @param array $inputData The input data.
     *
     * @return Page
     */
    protected function populate(Page $page, array $inputData)
    {
        $page->parent_id = ((int) array_get($inputData, 'parent_id', 0)) ?: null;
        $page->title = array_get($inputData, 'title', '');
        $page->slug = array_get($inputData, 'slug', '');
        $page->template = array_get($inputData, 'template', 'default');

        $publishedAt = array_get($inputData, 'published_at', '');

        if ($publishedAt) {
            $page->published_at = Carbon::createFromFormat(trans('common.dateTimeFormat'), $publishedAt);
        } else {
            $page->published_at = null;
        }

        $page->lead = array_get($inputData, 'lead', '');
        $page->content = array_get($inputData, 'content', '');
        $page->pdf_title = array_get($inputData, 'pdf_title', '');

        $page->seo_title = array_get($inputData, 'seo_title', '');
        $page->seo_description = array_get($inputData, 'seo_description', '');
        $page->seo_image_main_alt_title = array_get($inputData, 'seo_image_main_alt_title', '');

        $page->show_in_navigation = (bool) array_get($inputData, 'show_in_navigation', false);
        $page->selectable_in_navigation = (bool) array_get($inputData, 'selectable_in_navigation', false);
        $page->show_subpages_in_navigation = (bool) array_get($inputData, 'show_subpages_in_navigation', false);
        $page->auto_redirect = (int) array_get($inputData, 'auto_redirect', Page::AUTO_REDIRECT_NONE);
        $page->auto_redirect_url = array_get($inputData, 'auto_redirect_url') ?: null;
        $page->article_sort_order = (int) array_get($inputData, 'article_sort_order', Article::SORT_PUBLISHED_AT);
        $page->articles_per_page = (int) array_get($inputData, 'articles_per_page', 5);

        if (isset($inputData['image_main_delete'])) {
            $page->deleteImage('main');
        }

        if (isset($inputData['image_main'])) {
            $page->uploadImage($inputData['image_main'], 'main');
        }

        if (isset($inputData['pdf_file_delete'])) {
            $page->pdf_file = null;
        }

        if (isset($inputData['pdf_file'])) {
            $page->pdf_file = $this->fileUploader->upload($inputData['pdf_file']);
        }

        return $page;
    }

    /**
     * Populates the passed instance with the input data, saves and returns it.
     *
     * @param Page  $page      The page to populate and save.
     * @param array $inputData The input data.
     *
     * @return Page
     */
    protected function populateAndSave(Page $page, array $inputData)
    {
        $page = $this->populate($page, $inputData);

        $page->save();

        return $page;
    }

    /**
     * Sorts the items in the passed order.
     *
     * @param array $items The new sort order.
     *
     * @return bool
     */
    public function sort(array $items)
    {
        return $this->pageModel->updateSortOrder($items);
    }

    /**
     * Attempts to delete the specified page.
     *
     * The input data must contain an `action` key, with the `confirm` value, in
     * order for the page to be deleted - otherwise, the page will not be
     * deleted, and `false` will be returned. If the page has been deleted
     * successfully, `true` will be returned.
     *
     * @param Page  $page      The page to delete.
     * @param array $inputData The input data.
     *
     * @return bool
     */
    public function delete(Page $page, array $inputData)
    {
        $action = array_get($inputData, 'action', 'cancel');

        if ($action === 'confirm') {
            $page->delete();

            return true;
        } else {
            return false;
        }
    }
}
