<?php

namespace App\Content\Page\Repository;

use Illuminate\Support\Facades\Facade as BaseFacade;

class Facade extends BaseFacade
{
    /**
     * {@inheritDoc}
     */
    protected static function getFacadeAccessor()
    {
        return 'demo-basic.content.pageRepository';
    }
}
