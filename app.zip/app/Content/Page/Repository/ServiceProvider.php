<?php

namespace App\Content\Page\Repository;

use App\Content\Page\Repository as PageRepository;
use Illuminate\Support\ServiceProvider as BaseServiceProvider;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function register()
    {
        $this->app->singleton(PageRepository::class, function ($app) {
            return $app->make(PageRepository::class);
        });
    }
}
