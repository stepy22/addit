<?php

namespace App\Content\Page;

use App\Content\Page;
use Creitive\Html\DefaultSeoPresenter;
use Str;
use URL;

class SeoPresenter extends DefaultSeoPresenter
{
    /**
     * @param Page $page The page to present.
     */
    public function __construct(Page $page)
    {
        if ($page->seo_title) {
            $this->title = $page->seo_title;
            $this->overridesTitle = true;
        } else {
            $this->title = $page->title;
        }

        if ($page->seo_description) {
            $this->description = $page->seo_description;
        } else {
            $this->description = Str::createExcerpt(strip_tags($page->lead), 160);
        }

        $this->image = URL::to($page->getImage('main', 'og'));
    }
}
