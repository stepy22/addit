<?php

namespace App\Content\Page;

use Creitive\Collection\NestableCollectionInterface;
use Creitive\Collection\NestableSluggableCollectionInterface;
use Creitive\Collection\SluggableCollectionInterface;
use Creitive\Collection\Traits\NestableCollectionTrait;
use Creitive\Collection\Traits\NestableSluggableCollectionTrait;
use Creitive\Collection\Traits\SluggableCollectionTrait;
use Creitive\Database\Eloquent\Collection as BaseCollection;

class Collection extends BaseCollection implements NestableCollectionInterface, NestableSluggableCollectionInterface, SluggableCollectionInterface
{
    use NestableCollectionTrait;
    use NestableSluggableCollectionTrait;
    use SluggableCollectionTrait;

    /**
     * Filters out the non-published items from the collection.
     *
     * This is a destructive operation.
     *
     * @return void
     */
    public function filterPublished()
    {
        foreach ($this->items as $key => $page) {
            if ($page->isPublished()) {
                $page->children->filterPublished();
            } else {
                unset($this->items[$key]);
            }
        }
    }
}
