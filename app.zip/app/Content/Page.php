<?php

namespace App\Content;

use App\Content\Article;
use App\Content\Article\Collection as ArticleCollection;
use App\Content\Page\Collection as PageCollection;
use App\Content\Traits\ChildImageableTrait;
use Creitive\Database\Eloquent\Model;
use Creitive\Image\Transformers\CropThumbnail;
use Creitive\Image\Transformers\Thumbnail;
use Creitive\Models\ChildImageableInterface;
use Creitive\Models\NestableInterface;
use Creitive\Models\NestableSluggableInterface;
use Creitive\Models\SluggableInterface;
use Creitive\Models\Traits\ImageableTrait;
use Creitive\Models\Traits\NestableSluggableTrait;
use Creitive\Models\Traits\NestableSortableTrait;
use Creitive\Models\Traits\NestableTrait;
use Creitive\Models\Traits\PublishableTrait;
use Creitive\Models\Traits\SearchableTrait;
use Creitive\Models\Traits\SluggableTrait;
use Illuminate\Database\Eloquent\SoftDeletes;
use URL;

class Page extends Model implements ChildImageableInterface, NestableInterface, NestableSluggableInterface, SluggableInterface
{
    /**
     * Automatic redirection constants.
     *
     * See the relevant migration for more info on these.
     */
    const AUTO_REDIRECT_NONE = 0;
    const AUTO_REDIRECT_PAGE = 1;
    const AUTO_REDIRECT_ARTICLE = 2;
    const AUTO_REDIRECT_URL = 3;

    use ChildImageableTrait;
    use ImageableTrait;
    use NestableSluggableTrait;
    use NestableSortableTrait;
    use NestableTrait;
    use PublishableTrait;
    use SearchableTrait;
    use SluggableTrait;
    use SoftDeletes;

    /**
     * {@inheritDoc}
     */
    protected $visible = [
        'id',
        'parent_id',
        'title',
        'slug',
        'lead',
        'content',
        'url_image_main_original',
        'url_image_main_large',
        'url_image_main_thumbnail',
        'url_image_main_og',
        'children',
        'images',
        'articles',
    ];

    /**
     * {@inheritDoc}
     */
    protected $appends = [
        'url_image_main_original',
        'url_image_main_large',
        'url_image_main_thumbnail',
        'url_image_main_og',
    ];

    /**
     * {@inheritDoc}
     */
    public function getImageConfiguration()
    {
        return [
            'versions' => [
                'main' => [
                    'original' => [],
                    'large' => [
                        [
                            'transformer' => CropThumbnail::class,
                            'width' => 1140,
                            'height' => 380,
                        ],
                    ],
                    'thumbnail' => [
                        [
                            'transformer' => CropThumbnail::class,
                            'width' => 600,
                            'height' => 200,
                        ],
                    ],
                    'og' => [
                        [
                            'transformer' => CropThumbnail::class,
                            'width' => 1200,
                            'height' => 630,
                        ],
                    ],
                ],
            ],
        ];
    }

    /**
     * {@inheritDoc}
     */
    protected function getNestableSluggableParentAttribute()
    {
        return 'parent';
    }

    /**
     * {@inheritDoc}
     */
    protected function getSearchableColumns()
    {
        return ['title', 'content'];
    }

    /**
     * {@inheritDoc}
     */
    public function getChildImagesAttributeName()
    {
        return 'images';
    }

    /**
     * {@inheritDoc}
     */
    public function getDates()
    {
        return array_merge(parent::getDates(), ['published_at']);
    }

    /**
     * Returns a new Page collection.
     *
     * @param array $models The pages to include in the collection.
     *
     * @return PageCollection
     */
    public function newCollection(array $models = [])
    {
        return new PageCollection($models);
    }

    /**
     * Eloquent relationship: a page may have many articles.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function articles()
    {
        $articles = $this->hasMany(Article::class)->published();

        if ($this->article_sort_order === Article::SORT_CUSTOM) {
            return $articles->sorted();
        } else {
            return $articles->orderBy('published_at', 'desc');
        }
    }

    /**
     * Checks whether this page automatically redirects somewhere else.
     *
     * @return bool
     */
    public function autoRedirects()
    {
        return $this->auto_redirect !== static::AUTO_REDIRECT_NONE;
    }

    /**
     * Checks whether this page has articles at any nesting level (ie. it might
     * not have articles as direct children, but one of the child pages might
     * have some articles).
     *
     * @return bool
     */
    public function hasNestedArticles()
    {
        if (!$this->articles->isEmpty()) {
            return true;
        }

        foreach ($this->children as $page) {
            if ($page->hasNestedArticles()) {
                return true;
            }
        }

        return false;
    }

    /**
     * Returns all of this page's, and its subpages' articles.
     *
     * @return ArticleCollection
     */
    public function allArticles()
    {
        $articles = new ArticleCollection();

        $articles = $articles->merge($this->articles);

        foreach ($this->children as $page) {
            $articles = $articles->merge($page->allArticles());
        }

        return $articles;
    }

    /**
     * Gets the complete URL to the original main image.
     *
     * @return string
     */
    public function getUrlImageMainOriginalAttribute()
    {
        return URL::to($this->getImage('main', 'original'));
    }

    /**
     * Gets the complete URL to the large main image.
     *
     * @return string
     */
    public function getUrlImageMainLargeAttribute()
    {
        return URL::to($this->getImage('main', 'large'));
    }

    /**
     * Gets the complete URL to the thumbnail main image.
     *
     * @return string
     */
    public function getUrlImageMainThumbnailAttribute()
    {
        return URL::to($this->getImage('main', 'thumbnail'));
    }

    /**
     * Gets the complete URL to the og main image.
     *
     * @return string
     */
    public function getUrlImageMainOgAttribute()
    {
        return URL::to($this->getImage('main', 'og'));
    }
}
