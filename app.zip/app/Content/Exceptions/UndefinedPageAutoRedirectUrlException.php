<?php

namespace App\Content\Exceptions;

use Exception;
use RuntimeException;

class UndefinedPageAutoRedirectUrlException extends RuntimeException
{
    /**
     * The ID of the problematic page.
     *
     * @var int
     */
    protected $pageId;

    /**
     * Constructor.
     *
     * @param int       $pageId   The ID of the problematic page
     * @param Exception $previous The previous exception
     * @param int       $code     The internal exception code
     */
    public function __construct($pageId, Exception $previous = null, $code = 0)
    {
        parent::__construct('Page is set to redirect to a custom URL, but no custom URL is defined.', $code, $previous);

        $this->pageId = $pageId;
    }

    /**
     * Gets the ID of the problematic page.
     *
     * @return int
     */
    public function getPageId()
    {
        return $this->pageId;
    }
}
