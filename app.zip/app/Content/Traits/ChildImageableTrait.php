<?php

namespace App\Content\Traits;

use App\Content\Image;

trait ChildImageableTrait
{
    /**
     * Eloquent relationship: a model instance may have many images.
     *
     * Note that this is a polymorphic relationship.
     *
     * @return \Illuminate\Database\Eloquent\Relations\MorphMany
     */
    public function images()
    {
        return $this->morphMany(Image::class, 'imageable')->sorted();
    }
}
