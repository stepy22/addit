<?php

namespace App\Content\Image;

use App\Content\Image;
use App\Content\Image\Repository as ImageRepository;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Routing\Router;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerFrontApiRoutes($this->app['router']);
        $this->registerRoutePatterns($this->app['router'], $this->app);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers front-end API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1/images',
            'middleware' => ['web', 'auth'],
            'namespace' => 'App\Content\Http\Controllers\Api\V1\Admin\Image',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->put('sort', 'Controller@sort');
            $router->put('{image}', 'Controller@update');
            $router->delete('{image}', 'Controller@delete');
        });
    }

    /**
     * Registers the route patterns.
     *
     * @param Router    $router    A router.
     * @param Container $container A dependency container.
     *
     * @return void
     */
    protected function registerRoutePatterns(Router $router, Container $container)
    {
        $idRegex = $this->routePatternRegexes['id'];

        $router->pattern('image', $idRegex);

        $router->bind('image', function ($value) use ($container) {
            return $container->make(ImageRepository::class)->findOrFail($value);
        });
    }
}
