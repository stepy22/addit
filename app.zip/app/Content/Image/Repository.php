<?php

namespace App\Content\Image;

use App\Content\Image;
use Creitive\Models\ChildImageableInterface;

class Repository
{
    /**
     * An Image model instance.
     *
     * @var Image
     */
    protected $imageModel;

    /**
     * @param Image $imageModel An Image model instance.
     */
    public function __construct(Image $imageModel)
    {
        $this->imageModel = $imageModel;
    }

    /**
     * Finds an image by its ID or fails.
     *
     * @param int $id The image ID.
     *
     * @return Image
     */
    public function findOrFail($id)
    {
        return $this->imageModel->findOrFail($id);
    }

    /**
     * Uploads an image for a model that can have child images.
     *
     * @param ChildImageableInterface $model     A model implementing the `ChildImageableInterface`
     * @param array                   $inputData The input data.
     *
     * @return Image
     */
    public function upload(ChildImageableInterface $model, array $inputData)
    {
        $image = $this->imageModel->newInstance();

        $image->uploadImage($inputData['image'], 'main');

        return $model->images()->save($image);
    }

    /**
     * Sorts images.
     *
     * @param array $ids The IDs to sort by.
     *
     * @return bool
     */
    public function sort(array $ids)
    {
        return $this->imageModel->updateSortOrder($ids);
    }

    /**
     * Updates an image.
     *
     * @param Image $image     The image to update.
     * @param array $inputData The input data.
     *
     * @return bool
     */
    public function update(Image $image, array $inputData)
    {
        $image->title = array_get($inputData, 'title', $image->title);
        $image->save();

        return $image;
    }
}
