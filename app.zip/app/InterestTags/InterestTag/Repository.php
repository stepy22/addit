<?php

namespace App\InterestTags\InterestTag;

use App\InterestTags\InterestTag;
use Carbon\Carbon;
use stdClass;

class Repository
{
    /**
     * A InterestTag model instance.
     *
     * @var InterestTag
     */
    protected $interestTag;

    /**
     * @param InterestTag $interestTag A interest tag model instance.
     */
    public function __construct(InterestTag $interestTag)
    {
        $this->interestTagModel = $interestTag;
    }

    /**
     * Gets all interest tags.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAll()
    {
        return $this->interestTagModel->get();
    }

    /**
     * Returns interest tags and creates ones that does not exist.
     *
     * @param array $inputData Input data array.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getByTitleAndCreateNonExistent(array $inputData)
    {
        $inputData = array_map('trim', $inputData);

        $interestTags = $this->interestTagModel
            ->whereIn('name', $inputData)
            ->get();

        $interestTagsToCreate = array_diff($inputData, $interestTags->pluck('name')->toArray());

        // Make sure there are no empty strings in array.
        $interestTagsToCreate = array_filter($interestTagsToCreate, function ($item) {
            return $item !== '';
        });

        if (empty($interestTagsToCreate)) {
            return $interestTags;
        }

        $interestTagsToCreate = array_map(function ($item) {
            return ['name' => $item];
        }, $interestTagsToCreate);

        $this->interestTagModel->insert($interestTagsToCreate);

        return $this->interestTagModel
            ->whereIn('name', $inputData)
            ->get();
    }

    /**
     * Finds the interest tag by ID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $id The interestTag ID.
     *
     * @return InterestTag|null
     */
    public function find($id)
    {
        return $this->interestTagModel->find($id);
    }

    /**
     * Finds the interest tag by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The interestTag ID.
     *
     * @return InterestTag
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->interestTagModel->findOrFail($id);
    }

    /**
     * Creates a new interest tag and returns it.
     *
     * @param array $inputData The interestTag input data.
     *
     * @return InterestTag
     */
    public function create(array $inputData)
    {
        return $this->populateAndSave($this->interestTagModel->newInstance(), $inputData);
    }

    /**
     * Deletes the passed interest tag from the system.
     *
     * @param InterestTag $interestTag The interestTag to delete.
     *
     * @return bool|null
     */
    public function delete(InterestTag $interestTag)
    {
        return $interestTag->delete();
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param InterestTag $interestTag The interestTag to populate.
     * @param array       $inputData   The input data for the interestTag.
     *
     * @return InterestTag
     */
    protected function populate(InterestTag $interestTag, array $inputData)
    {
        $interestTag->name = array_get($inputData, 'name');

        return $interestTag;
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param InterestTag $interestTag The interestTag to populate and save.
     * @param array       $inputData   The input data.
     *
     * @return InterestTag
     */
    protected function populateAndSave(InterestTag $interestTag, array $inputData)
    {
        $interestTag = $this->populate($interestTag, $inputData);

        $interestTag->save();

        return $interestTag;
    }
}
