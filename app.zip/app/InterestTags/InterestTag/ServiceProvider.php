<?php

namespace App\InterestTags\InterestTag;

use App\InterestTags\InterestTag;
use App\InterestTags\InterestTag\Repository as InterestTagRepository;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerAdminApiRoutes($this->app['router']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers admin API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerAdminApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1/interest-tags',
            'middleware' => ['api', 'auth', 'permissions'],
            'namespace' => 'App\InterestTags\Http\Controllers\Api\V1\Admin\InterestTag',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('', 'Controller@index');
        });
    }
}
