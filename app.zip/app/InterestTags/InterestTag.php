<?php

namespace App\InterestTags;

use Creitive\Database\Eloquent\Model;

class InterestTag extends Model
{
}
