<?php

namespace App\Notifications\Http\Controllers\Admin\Announcement;

use App\Auth\User\Repository as UserRepository;
use App\Countries\Country\Repository as CountryRepository;
use App\Http\Controllers\Admin\Controller as BaseController;
use App\Notifications\Announcement;
use App\Notifications\Announcement\Repository as AnnouncementRepository;
use App\Notifications\Http\Requests\Admin\Announcement\FilterUsersRequest;
use App\Notifications\Http\Requests\Admin\Announcement\StoreRequest;
use App\Notifications\Http\Requests\Admin\Announcement\UpdateRequest;
use App\Notifications\Notification;
use App\Notifications\Notification\Notifier;
use Illuminate\Http\Request;
use Illuminate\Support\MessageBag;
use Redirect;
use URL;

class Controller extends BaseController
{
    /**
     * A AnnouncementRepository instance.
     *
     * @var AnnouncementRepository
     */
    protected $announcementRepository;

    /**
     * @param AnnouncementRepository $announcementRepository A announcement repository instance.
     */
    public function __construct(AnnouncementRepository $announcementRepository)
    {
        parent::__construct();

        $this->announcementRepository = $announcementRepository;

        $this->viewData->bodyDataPage = 'admin-announcements';
        $this->viewData->pageTitle->setPage(trans('admin/announcements.module'));
        $this->viewData->navigation->get('admin.main')->setActive('announcements');
    }

    /**
     * Shows all announcements.
     *
     * @param Request $request The current request.
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $data = [
            'announcements' => $this->announcementRepository->getAll(),
        ];

        return view('admin.announcements.index', $data);
    }

    /**
     * Displays the create form.
     *
     * @param CountryRepository $countryRepository Country repository instance.
     *
     * @return \Illuminate\View\View
     */
    public function create(CountryRepository $countryRepository)
    {
        $data = [
            'countries' => $countryRepository->getSelectOptions(),
        ];

        return view('admin.announcements.create', $data);
    }

    /**
     * Filters notification target users.
     *
     * @param FilterUsersRequest $request        Form request instance.
     * @param UserRepository     $userRepository User repository instance.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function filterUsers(FilterUsersRequest $request, UserRepository $userRepository)
    {
        $users = $userRepository->filterByInput($request->all());

        return Redirect::action(static::class.'@create', [
            'user_ids' => $users->pluck('id')->toArray(),
        ])->withInput();
    }

    /**
     * Saves a new announcement.
     *
     * @param StoreRequest   $request        A announcement store request.
     * @param Notifier       $notifier       Notifier.
     * @param UserRepository $userRepository User repository instance.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(
        StoreRequest $request,
        Notifier $notifier,
        UserRepository $userRepository
    ) {
        $announcement = $this->announcementRepository->create($request->all());

        $users = null;

        if ($request->has('user_ids') && !empty($request->get('user_ids'))) {
            $users = $userRepository->findUsersByIds($request->get('user_ids'));
        }

        $notifier->notify(
            $announcement->title,
            Notification::TYPE_ANNOUNCEMENT,
            $users,
            $announcement->uuid,
            URL::action('\App\Notifications\Http\Controllers\Front\Announcement\Controller@show', ['announcement' => $announcement->uuid], false)
        );

        $successMessage = trans('admin/announcements.successMessages.create');

        return Redirect::action(static::class.'@show', ['announcement' => $announcement->uuid])
            ->with('successMessages', new MessageBag([$successMessage]));
    }

    /**
     * Shows the specified announcement.
     *
     * @param Announcement $announcement The announcement.
     *
     * @return \Illuminate\View\View
     */
    public function show(Announcement $announcement)
    {
        $data = [
            'announcement' => $announcement,
        ];

        return view('admin.announcements.show', $data);
    }
}
