<?php

namespace App\Notifications\Http\Controllers\Api\Front\Notification;

use App\Http\Controllers\Front\Controller as BaseController;
use App\Notifications\Http\Requests\Api\Notification\MarkSeenRequest;
use App\Notifications\Notification;
use App\Notifications\Notification\Repository as NotificationRepository;
use Cartalyst\Sentinel\Sentinel;
use Illuminate\Http\Request;

class Controller extends BaseController
{
    const PER_PAGE = 5;

    /**
     * Shows last 5 notifications to a user.
     *
     * @param Sentinel               $sentinel               Sentinel instance.
     * @param Request                $request                Request instance.
     * @param NotificationRepository $notificationRepository Notification repository.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index(
        Sentinel $sentinel,
        Request $request,
        NotificationRepository $notificationRepository
    ) {
        $user = $sentinel->getUser();

        if ($request->has('page')) {
            $page = $request->get('page');
        } else {
            $page = 1;
        }

        if ($request->has('perPage')) {
            $perPage = $request->get('perPage');
        } else {
            $perPage = self::PER_PAGE;
        }

        $notifications = $user->notifications()->orderBy('created_at', 'desc')->forPage($page, $perPage)->get();

        $unseenNotifications = $notifications->where('seen', 0);

        if ($unseenNotifications->count() > 0) {
            $notificationRepository->markNotificationsSeen($notifications);
        }

        return response([
            'notifications' => array_values($notifications->toArray()),
        ]);
    }

    /**
     * Marks notification as seen.
     *
     * @param Notification           $notification           Notification instance.
     * @param MarkSeenRequest        $request                Request instance.
     * @param NotificationRepository $notificationRepository Notification repository.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function markSeen(
        Notification $notification,
        MarkSeenRequest $request,
        NotificationRepository $notificationRepository
    ) {
        $notification = $notificationRepository->markNotificationSeen($notification);

        return response([
            'notification' => $notification,
        ]);
    }
}
