<?php

namespace App\Notifications\Http\Controllers\Api\Front\Announcement;

use App\Http\Controllers\Front\Controller as BaseController;
use App\Notifications\Announcement;

class Controller extends BaseController
{

    /**
     * Shows the announcement.
     *
     * @param Announcement $announcement Announcement instance.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function show(Announcement $announcement)
    {
        return response([
            'announcement' => $announcement,
        ]);
    }
}
