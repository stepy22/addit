<?php

namespace App\Notifications\Http\Controllers\Front\Announcement;

use App\Http\Controllers\Front\Controller as BaseController;
use App\Notifications\Announcement;
use App\Notifications\Announcement\SeoPresenter;

class Controller extends BaseController
{
    /**
     * @param Announcement $announcement Announcement controller.
     *
     * @return \Illuminate\View\View
     */
    public function show(Announcement $announcement)
    {
        $this->viewData->pageTitle->setPage($announcement->title);
        $this->viewData->setSeo(new SeoPresenter($announcement));

        $data = [
            'announcement' => $announcement,
        ];

        return view('announcements.show', $data);
    }
}
