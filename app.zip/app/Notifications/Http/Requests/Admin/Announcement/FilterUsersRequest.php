<?php

namespace App\Notifications\Http\Requests\Admin\Announcement;

use App\Http\Requests\Request;
use Cartalyst\Sentinel\Sentinel;
use Illuminate\Validation\Factory as ValidationFactory;
use Illuminate\Validation\Rule;

class FilterUsersRequest extends Request
{
    /**
     * A Sentinel instance
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * @param Sentinel $sentinel A Sentinel instance.
     */
    public function __construct(Sentinel $sentinel)
    {
        parent::__construct();

        $this->sentinel = $sentinel;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $currentUser = $this->sentinel->getUser();

        $rules = [
            'gender' => ['array', 'in:'. implode(',', array_keys(config('user.genders')))],
            'age_range' => ['array', 'in:'. implode(',', array_keys(config('user.ageRanges')))],
            'country' => ['array', 'exists:countries,id'],
            'work_status' => ['array', 'in:'. implode(',', array_keys(config('user.workStatuses')))],
            'relationship_status' => ['array', 'in:'. implode(',', array_keys(config('user.relationshipStatuses')))],
            'parental_status' => ['array', 'in:'. implode(',', array_keys(config('user.parentalStatuses')))],
            'educations' => ['array', 'in:'. implode(',', array_keys(config('user.educations')))],
            'working_industries' => ['array', 'in:'. implode(',', array_keys(config('user.workingIndustries')))],
            'interests' => ['array', 'in:'. implode(',', array_keys(config('user.interests')))],
        ];

        return $rules;
    }
}
