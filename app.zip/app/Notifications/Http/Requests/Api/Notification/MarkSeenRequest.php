<?php

namespace App\Notifications\Http\Requests\Api\Notification;

use App\Http\Requests\Request;
use Cartalyst\Sentinel\Sentinel;

class MarkSeenRequest extends Request
{
    /**
     * Sentinel instance.
     *
     * @var Sentinel instance.
     */
    protected $sentinel;

    /**
     * @param Sentinel $sentinel Sentinel instance.
     */
    public function __construct(Sentinel $sentinel)
    {
        parent::__construct();

        $this->sentinel = $sentinel;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $user = $this->sentinel->getUser();
        $notification = $this->route('notification');

        return $user->notifications->where('id', $notification->id)->count() > 0;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [];
    }
}
