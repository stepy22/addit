<?php

namespace App\Notifications\Announcement;

use App\Notifications\Announcement;
use Illuminate\Support\Collection;

class Repository
{
    /**
     * A Announcement model instance.
     *
     * @var Announcement
     */
    protected $announcement;

    /**
     * @param Announcement $announcement A announcement model instance.
     */
    public function __construct(Announcement $announcement)
    {
        $this->announcementModel = $announcement;
    }

    /**
     * Gets all announcements.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAll()
    {
        return $this->announcementModel->get();
    }

    /**
     * Finds the announcement by ID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $id The announcement ID.
     *
     * @return Notification|null
     */
    public function find($id)
    {
        return $this->announcementModel->find($id);
    }

    /**
     * Finds the announcement by UUID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $uuid The announcement UUID.
     *
     * @return Notification|null
     */
    public function findByUuid($uuid)
    {
        return $this->announcementModel
            ->where(['uuid' => $uuid])
            ->firstOrFail();
    }

    /**
     * Finds the announcement by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The announcement ID.
     *
     * @return Notification
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->announcementModel->findOrFail($id);
    }

    /**
     * Creates a new announcement and returns it.
     *
     * @param array $inputData The announcement input data.
     *
     * @return Announcement
     */
    public function create(array $inputData)
    {
        return $this->populateAndSave($this->announcementModel->newInstance(), $inputData);
    }

    /**
     * Updates the passed announcement and returns it.
     *
     * @param Announcement $announcement The announcement to update.
     * @param array        $inputData    The input data for the update.
     *
     * @return Announcement
     */
    public function update(Announcement $announcement, array $inputData)
    {
        return $this->populateAndSave($announcement, $inputData);
    }

    /**
     * Deletes the passed announcement from the system.
     *
     * @param Announcement $announcement The announcement to delete.
     *
     * @return bool|null
     */
    public function delete(Announcement $announcement)
    {
        return $announcement->delete();
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param Announcement $announcement     The announcement to populate.
     * @param array        $inputData        The input data for the announcement.
     *
     * @return Announcement
     */
    protected function populate(Announcement $announcement, array $inputData)
    {
        $announcement->title = array_get($inputData, 'title');
        $announcement->content = array_get($inputData, 'content');

        return $announcement;
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param Announcement $announcement The announcement to populate and save.
     * @param array        $inputData    The input data.
     *
     * @return Announcement
     */
    protected function populateAndSave(Announcement $announcement, array $inputData)
    {
        $announcement = $this->populate($announcement, $inputData);

        $announcement->save();

        return $announcement;
    }
}
