<?php

namespace App\Notifications\Announcement;

use App\Notifications\Announcement;
use Creitive\Html\DefaultSeoPresenter;
use Str;

class SeoPresenter extends DefaultSeoPresenter
{
    /**
     * @param Announcement $announcement Announcement instance.
     */
    public function __construct(Announcement $announcement)
    {
        $this->title = $announcement->title;
        $this->description = Str::createExcerpt(strip_tags($announcement->content), 160);
    }
}
