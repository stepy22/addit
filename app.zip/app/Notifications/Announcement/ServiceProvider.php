<?php

namespace App\Notifications\Announcement;

use App\Notifications\Announcement;
use App\Notifications\Announcement\Repository as AnnouncementRepository;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Creitive\Routing\LocaleResolver;
use DaveJamesMiller\Breadcrumbs\Generator as BreadcrumbGenerator;
use DaveJamesMiller\Breadcrumbs\Manager as BreadcrumbManager;
use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Routing\Router;
use Ramsey\Uuid\Exception\UnsatisfiedDependencyException;
use Ramsey\Uuid\Uuid;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use URL;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerRoutePatterns($this->app['router'], $this->app);
        $this->registerAdminRoutes($this->app['router']);
        $this->registerAdminBreadcrumbs($this->app['breadcrumbs']);
        $this->registerFrontApiRoutes($this->app['router']);
        $this->registerFrontRoutes($this->app['router']);
        $this->attachUuidToCreatedAnnouncement();
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers the route patterns.
     *
     * @param Router    $router    A router.
     * @param Container $container A dependency container.
     *
     * @return void
     */
    protected function registerRoutePatterns(Router $router, Container $container)
    {
        $router->pattern('announcement', $this->routePatternRegexes['any']);

        $router->bind('announcement', function ($value) use ($container) {
            $announcementRepository = $container->make(AnnouncementRepository::class);

            return $announcementRepository->findByUuid($value);
        });
    }

    /**
     * Registers admin panel routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerAdminRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'admin/announcements',
            'middleware' => ['web', 'auth', 'permissions'],
            'namespace' => 'App\Notifications\Http\Controllers\Admin\Announcement',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('', 'Controller@index');

            $router->get('create', 'Controller@create');
            $router->post('filter-users', 'Controller@filterUsers');
            $router->post('', 'Controller@store');

            $router->get('{announcement}/show', 'Controller@show');
        });
    }

    /**
     * Registers front API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
           'prefix' => 'api/v1/announcements',
           'middleware' => ['api', 'auth'],
           'namespace' => 'App\Notifications\Http\Controllers\Api\Front\Announcement',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('{announcement}', 'Controller@show');
        });
    }

    /**
     * Registers front end routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontRoutes(RegistrarContract $router)
    {
        $attributes = [
           'prefix' => trans('routes.announcements'),
           'middleware' => ['web'],
           'namespace' => 'App\Notifications\Http\Controllers\Front\Announcement',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('{announcement}', 'Controller@show');
        });
    }

    /**
     * Registers breadcrumbs for the admin panel.
     *
     * @param BreadcrumbManager $breadcrumbs A breadcrumb manager.
     *
     * @return void
     */
    protected function registerAdminBreadcrumbs(BreadcrumbManager $breadcrumbs)
    {
        $breadcrumbs->register('admin::announcements', function (BreadcrumbGenerator $breadcrumbs) {
            $breadcrumbs->parent('admin::home');

            $url = URL::action('App\Notifications\Http\Controllers\Admin\Announcement\Controller@index');

            $breadcrumbs->push(trans('admin/navigation.announcements'), $url);
        });

        $breadcrumbs->register('admin::announcements.show', function (BreadcrumbGenerator $breadcrumbs, Announcement $announcement) {
            $breadcrumbs->parent('admin::announcements');

            $breadcrumbs->push($announcement->title);
        });

        $breadcrumbs->register('admin::announcements.create', function (BreadcrumbGenerator $breadcrumbs) {
            $breadcrumbs->parent('admin::announcements');

            $url = URL::action('App\Notifications\Http\Controllers\Admin\Announcement\Controller@create');

            $breadcrumbs->push(trans('admin/announcements.titles.create'), $url);
        });

        $breadcrumbs->register('admin::announcements.edit', function (BreadcrumbGenerator $breadcrumbs, Announcement $announcement) {
            $breadcrumbs->parent('admin::announcements.show', $announcement);

            $url = URL::action('App\Notifications\Http\Controllers\Admin\Announcement\Controller@show', ['announcement' => $announcement->id]);

            $breadcrumbs->push(trans('admin/announcements.titles.show'), $url);
        });
    }

    /**
     * Attaches UUID to every create announcement.
     *
     * @return void
     */
    public function attachUuidToCreatedAnnouncement()
    {
        Announcement::creating(function (Announcement $announcement) {
            try {
                $uuid = Uuid::uuid4();
                $announcement->uuid = $uuid->toString();
            } catch (UnsatisfiedDependencyException $e) {
                Log::error('Failed to generate uuid for announcement. ' . $e->getMessage() . "\n");
            }
        });
    }
}
