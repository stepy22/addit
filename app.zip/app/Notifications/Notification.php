<?php

namespace App\Notifications;

use Creitive\Database\Eloquent\Model;

class Notification extends Model
{
    const TYPE_SUBSCRIPTION_EXPIRING = 'subscription_expiring';
    const TYPE_SUBSCRIPTION_BILLING_FAILED = 'subscription_biling_failed';
    const TYPE_SUBSCRIPTION_CHARGED = 'subscription_charged';
    const TYPE_SUBSCRIPTION_FREE_MONTHS_USED = 'subscription_free_months_used';
    const TYPE_ANNOUNCEMENT = 'announcement';
    const TYPE_WIDGET_DELETION = 'widget_deleted';
    const TYPE_DASHBOARD_DELETION = 'dashboard_deleted';
    const TYPE_WIDGET_SHARING = 'widget_shared';
    const TYPE_WIDGET_PERMISSIONS_CHANGED = 'widget_permissions_changed';
    const TYPE_REMOVED_FROM_WIDGET = 'removed_from_widget';
    const TYPE_UNSUBSCRIBED_FROM_WIDGET = 'unsubscribed_from_widget';
    const TYPE_DASHBOARD_SHARING = 'dashobard_shared';
    const TYPE_REMOVED_FROM_DASHBOARD = 'removed_from_dashboard';
    const TYPE_DASHBOARD_PERMISSIONS_CHANGED = 'dashboard_permissions_changed';
    const TYPE_UNSUBSCRIBED_FROM_DASHBOARD = 'unsubscribed_from_dashboard';
    const TYPE_AFFILIATE_ACQUIRED = 'affiliate_acquired';
    const TYPE_TOP_TEN_LIST_ITEM = 'top_ten_list_task';
    const TYPE_BIRTHDAY_REMINDER = 'birthday_reminder';
    const TYPE_EVENT_REMINDER = 'event_reminder';

    /**
     * {@inheritDoc}
     */
    protected $casts = [
        'seen' => 'bool',
    ];

    /**
     * Eloquent relationship: Notification belongs to a user.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
