<?php

namespace App\Notifications;

use Creitive\Database\Eloquent\Model;

class Announcement extends Model
{
    /**
     * {@inheritDoc}
     */
    protected $table = 'notification_announcements';
}
