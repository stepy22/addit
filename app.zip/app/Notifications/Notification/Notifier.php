<?php

namespace App\Notifications\Notification;

use App\Auth\User;
use App\Notifications\Notification\Repository as NotificationRepository;
use Creitive\PushNotifications\PushNotifier;
use Illuminate\Support\Collection;

class Notifier
{
    /**
     * A NotificationRepository model instance.
     *
     * @var NotificationRepository
     */
    protected $notificationRepository;

    /**
     * Push notifier instance.
     *
     * @var \Creitive\PushNotifications\PushNotifier
     */
    protected $pushNotifier;

    /**
     * @param NotificationRepository $notificationRepository A notification repository instance.
     * @param PushNotifier           $pushNotifier           A push notifier instance.
     */
    public function __construct(
        NotificationRepository $notificationRepository,
        PushNotifier $pushNotifier
    ) {
        $this->notificationRepository = $notificationRepository;
        $this->pushNotifier = $pushNotifier;
    }

    /**
     * Notifies user about expiring subscription.
     *
     * @param  string $message    Message string.
     * @param  string $type       Type of notification.
     * @param  mixed  $target     Target user/s.
     * @param  int    $resourceId Resource ID.
     * @param  string $url        URL.
     *
     * @return void
     */
    public function notify($message, $type, $target = null, $resourceId = null, $url = null)
    {
        if ($target instanceof Collection) {
            foreach ($target as $user) {
                $this->notifyUser($message, $type, $user, $resourceId, $url);
            }
        } elseif ($target instanceof User) {
            $this->notifyUser($message, $type, $target, $resourceId, $url);
        } else {
            $pushNotificationOptions = [
                'type' => $type,
            ];

            $this->pushNotifier->notify($message, $pushNotificationOptions, $target);
        }
    }

    /**
     * Notifies single user about expiring subscription.
     *
     * @param  string $message    Message string.
     * @param  string $type       Type of notification.
     * @param  User   $user       Target user.
     * @param  int    $resourceId Resource ID.
     * @param  string $url        URL.
     *
     * @return void
     */
    public function notifyUser($message, $type, User $user, $resourceId = null, $url = null)
    {
        $notification = $this->notificationRepository->create([
            'user_id' => $user->id,
            'message' => $message,
            'resource_id' => $resourceId,
            'url' => $url,
            'type' => $type,
        ]);

        $pushNotificationOptions = [
            'type' => $type,
            'notification_id' => $notification->id,
        ];

        if ($resourceId) {
            $pushNotificationOptions['resource_id'] = $resourceId;
        }

        $this->pushNotifier->notify($message, $pushNotificationOptions, $user);

        return $notification;
    }
}
