<?php

namespace App\Notifications\Notification;

use App\Notifications\Notification;
use Illuminate\Support\Collection;

class Repository
{
    /**
     * A Notification model instance.
     *
     * @var Notification
     */
    protected $notification;

    /**
     * @param Notification $notification A notification model instance.
     */
    public function __construct(Notification $notification)
    {
        $this->notificationModel = $notification;
    }

    /**
     * Gets all notifications.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAll()
    {
        return $this->notificationModel->sorted()->get();
    }

    /**
     * Finds the notification by ID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $id The notification ID.
     *
     * @return Notification|null
     */
    public function find($id)
    {
        return $this->notificationModel->find($id);
    }

    /**
     * Finds the notification by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The notification ID.
     *
     * @return Notification
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->notificationModel->findOrFail($id);
    }

    /**
     * Marks notifications as seen.
     *
     * @param Collection $notifications Collection of notifications.
     *
     * @return void
     */
    public function markNotificationsSeen(Collection $notifications)
    {
        $this->notificationModel
            ->whereIn('id', $notifications->pluck('id')->toArray())
            ->update(['seen' => 1]);
    }

    /**
     * Marks notification as seen.
     *
     * @param Notification $notification Notification instance.
     *
     * @return Notification
     */
    public function markNotificationSeen(Notification $notification)
    {
        $notification->seen = 1;
        $notification->save();

        return $notification;
    }

    /**
     * Creates a new notification and returns it.
     *
     * @param array $inputData The notification input data.
     *
     * @return Notification
     */
    public function create(array $inputData)
    {
        return $this->populateAndSave($this->notificationModel->newInstance(), $inputData);
    }

    /**
     * Updates the passed notification and returns it.
     *
     * @param Notification $notification The notification to update.
     * @param array        $inputData    The input data for the update.
     *
     * @return Notification
     */
    public function update(Notification $notification, array $inputData)
    {
        return $this->populateAndSave($notification, $inputData);
    }

    /**
     * Deletes the passed notification from the system.
     *
     * @param Notification $notification The notification to delete.
     *
     * @return bool|null
     */
    public function delete(Notification $notification)
    {
        return $notification->delete();
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param Notification $notification     The notification to populate.
     * @param array $inputData The input data for the notification.
     *
     * @return Notification
     */
    protected function populate(Notification $notification, array $inputData)
    {
        $notification->user_id = array_get($inputData, 'user_id');
        $notification->type = array_get($inputData, 'type');
        $notification->message = array_get($inputData, 'message');
        $notification->url = array_get($inputData, 'url');
        $notification->resource_id = array_get($inputData, 'resource_id');

        return $notification;
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param Notification $notification     The notification to populate and save.
     * @param array $inputData The input data.
     *
     * @return Notification
     */
    protected function populateAndSave(Notification $notification, array $inputData)
    {
        $notification = $this->populate($notification, $inputData);

        $notification->save();

        return $notification;
    }
}
