<?php

namespace App\Notifications\Notification;

use App\Notifications\Notification;
use App\Notifications\Notification\Repository as NotificationRepository;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Creitive\Routing\LocaleResolver;
use DaveJamesMiller\Breadcrumbs\Generator as BreadcrumbGenerator;
use DaveJamesMiller\Breadcrumbs\Manager as BreadcrumbManager;
use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Routing\Router;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use URL;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerRoutePatterns($this->app['router'], $this->app);
        $this->registerFrontApiRoutes($this->app['router']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers the route patterns.
     *
     * @param Router    $router    A router.
     * @param Container $container A dependency container.
     *
     * @return void
     */
    protected function registerRoutePatterns(Router $router, Container $container)
    {
        $idRegex = $this->routePatternRegexes['id'];
        $slugRegex = $this->routePatternRegexes['slug'];

        $router->pattern('notification', $idRegex);

        $router->bind('notification', function ($value) use ($container, $idRegex) {
            $notificationRepository = $container->make(NotificationRepository::class);

            if (preg_match("/^{$idRegex}$/D", $value)) {
                $notification = $notificationRepository->find($value);

                if ($notification !== null) {
                    return $notification;
                }
            }
        });
    }

    /**
     * Registers front end routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
           'prefix' => 'api/v1/notifications',
           'middleware' => ['api', 'auth'],
           'namespace' => 'App\Notifications\Http\Controllers\Api\Front\Notification',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('', 'Controller@index');
            $router->put('{notification}/actions/mark-seen', 'Controller@markSeen');
        });
    }
}
