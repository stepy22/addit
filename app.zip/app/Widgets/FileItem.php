<?php

namespace App\Widgets;

use Creitive\Database\Eloquent\Model;
use FileUrlGenerator;
use URL;

class FileItem extends Model
{
    /**
     * {@inheritDoc}
     */
    protected $table = 'widget_file_items';

    /**
     * {@inheritDoc}
     */
    public $timestamps = false;

    /**
     * {@inheritDoc}
     */
    protected $visible = [
        'id',
        'name',
        'filepath',
        'filepath_url',
        'extension',
        'widget_file_id',
        'sort',
    ];

    /**
     * {@inheritDoc}
     */
    protected $appends = [
        'filepath_url',
    ];

    /**
     * Eloquent relationship: file item belongs to a file.
     *
     * @return BelogngsTo
     */
    public function file()
    {
        return $this->belongsTo(File::class, 'widget_file_id');
    }

    /**
     * Gets full url to uploaded file.
     *
     * @return string
     */
    public function getFilepathUrlAttribute()
    {
        return FileUrlGenerator::generate($this->filepath);
    }
}
