<?php

namespace App\Widgets\YoutubeVideo;

use App\Widgets\YoutubeVideo\Repository as WidgetYoutubeVideoRepository;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Routing\Router;
use URL;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerRoutePatterns($this->app['router'], $this->app);
        $this->registerFrontApiRoutes($this->app['router']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers the route patterns.
     *
     * @param Router    $router    A router.
     * @param Container $container A dependency container.
     *
     * @return void
     */
    protected function registerRoutePatterns(Router $router, Container $container)
    {
        $idRegex = $this->routePatternRegexes['id'];
        $slugRegex = $this->routePatternRegexes['slug'];

        $router->pattern('widgetYoutubeVideo', $idRegex);

        $router->bind('widgetYoutubeVideo', function ($value) use ($container, $idRegex) {
            $widgetYoutubeVideoRepository = $container->make(WidgetYoutubeVideoRepository::class);

            if (preg_match("/^{$idRegex}$/D", $value)) {
                $widgetYoutubeVideo = $widgetYoutubeVideoRepository->findOrFail($value);

                if ($widgetYoutubeVideo !== null) {
                    return $widgetYoutubeVideo;
                }
            }
        });
    }

    /**
     * Registers front API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1',
            'namespace' => 'App\Widgets\Http\Controllers\Api\V1\Front\YoutubeVideo',
        ];

        $attributes['middleware'] = ['api', 'auth', 'widgetYoutubeVideo.access'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->put('widget-youtube-videos/{widgetYoutubeVideo}', 'Controller@update');
        });

        $attributes['middleware'] = ['api', 'auth', 'widget.access:edit'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->post('widgets/{widget}/youtube-video', 'Controller@store');
        });
    }
}
