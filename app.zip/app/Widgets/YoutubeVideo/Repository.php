<?php

namespace App\Widgets\YoutubeVideo;

use App\Auth\User;
use App\Widgets\YoutubeVideo;

class Repository
{
    /**
     * A Youtube video model instance.
     *
     * @var YoutubeVideo
     */
    protected $youtubeVideo;

    /**
     * @param YoutubeVideo $youtubeVideo A youtube video model instance.
     */
    public function __construct(YoutubeVideo $youtubeVideo)
    {
        $this->youtubeVideoModel = $youtubeVideo;
    }

    /**
     * Finds the youtube video by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The youtube video ID.
     *
     * @return YoutubeVideo
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->youtubeVideoModel->findOrFail($id);
    }

    /**
     * Updates the passed youtube video and returns it.
     *
     * @param YoutubeVideo $youtubeVideo The youtube video to update.
     * @param array        $inputData    The input data for the update.
     *
     * @return YoutubeVideo
     */
    public function update(YoutubeVideo $youtubeVideo, array $inputData)
    {
        return $this->populateAndSave($youtubeVideo, $inputData);
    }

    /**
     * Creates a youtube video and returns it.
     *
     * @param array $inputData The input data for the update.
     *
     * @return YoutubeVideo
     */
    public function create(array $inputData)
    {
        $youtubeVideo = $this->youtubeVideoModel->newInstance();

        return $this->populateAndSave($youtubeVideo, $inputData);
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param YoutubeVideo  $youtubeVideo      The youtubeVideo to populate.
     * @param array $inputData The input data for the youtubeVideo.
     *
     * @return YoutubeVideo
     */
    protected function populate(YoutubeVideo $youtubeVideo, array $inputData)
    {
        $youtubeVideo->video_id = array_get($inputData, 'video_id', $youtubeVideo->video_id);
        $youtubeVideo->widget_id = array_get($inputData, 'widget_id', $youtubeVideo->widget_id);

        return $youtubeVideo;
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param YoutubeVideo $youtubeVideo The youtube video to populate and save.
     * @param array        $inputData    The input data.
     *
     * @return YoutubeVideo
     */
    protected function populateAndSave(YoutubeVideo $youtubeVideo, array $inputData)
    {
        $youtubeVideo = $this->populate($youtubeVideo, $inputData);

        $youtubeVideo->save();

        return $youtubeVideo;
    }
}
