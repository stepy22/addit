<?php

namespace App\Widgets\Contact;

use App\Widgets\Contact;
use Carbon\Carbon;
use Hshn\Base64EncodedFile\HttpFoundation\File\Base64EncodedFile;
use Log;

class Repository
{
    /**
     * A Contact model instance.
     *
     * @var Contact
     */
    protected $contact;

    /**
     * @param Contact $contact A contact model instance.
     */
    public function __construct(Contact $contact)
    {
        $this->contactModel = $contact;
    }

    /**
     * Gets all contact.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAll()
    {
        $query = $this->contactModel->select('*');

        return $query->get();
    }

    /**
     * Finds the contact by ID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $id The contact ID.
     *
     * @return Contact|null
     */
    public function find($id)
    {
        return $this->contactModel->find($id);
    }

    /**
     * Finds widget contacts by ids.
     *
     * @param array $ids The contact IDs.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getByIds(array $ids)
    {
        return $this->contactModel
            ->whereIn('id', $ids)
            ->get();
    }

    /**
     * Finds the contact by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The contact ID.
     *
     * @return Contact
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->contactModel->findOrFail($id);
    }

    /**
     * Updates the passed contact and returns it.
     *
     * @param Contact $contact   The contact to update.
     * @param array   $inputData The input data for the update.
     *
     * @return Contact
     * @throws \Exception
     */
    public function update(Contact $contact, array $inputData)
    {
        return $this->populateAndSave($contact, $inputData);
    }

    /**
     * Creates a contact and returns it.
     *
     * @param array $inputData The input data for the update.
     *
     * @return Contact
     * @throws \Exception
     */
    public function create(array $inputData)
    {
        $contact = $this->contactModel->newInstance();

        return $this->populateAndSave($contact, $inputData);
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param Contact $contact   The contact to populate.
     * @param array   $inputData The input data for the event.
     *
     * @return Contact
     * @throws \Exception
     */
    protected function populate(Contact $contact, array $inputData)
    {
        $contact->name = array_get($inputData, 'name', $contact->name);
        $contact->work_number = array_get($inputData, 'work_number', $contact->work_number);
        $contact->profession = array_get($inputData, 'profession', $contact->profession);
        $contact->mobile_number = array_get($inputData, 'mobile_number', $contact->mobile_number);
        $contact->company = array_get($inputData, 'company', $contact->company);
        $contact->widget_id = array_get($inputData, 'widget_id', $contact->widget_id);

        $dateOfBirth = array_get($inputData, 'date_of_birth', '');

        if ($dateOfBirth) {
            $contact->date_of_birth = Carbon::createFromFormat(trans('common.databaseDateFormat'), $dateOfBirth);
        }

        if (isset($inputData['image_main'])) {
            if ($inputData['image_main'] instanceof UploadedFile) {
                $contact->uploadImage($inputData['image_main'], 'main');
            } else {
                $file = new Base64EncodedFile($inputData['image_main']);
                $contact->uploadImage($file->getPathname(), 'main');
            }
        }

        return $contact;
    }

    /**
     * Deletes a contact.
     *
     * @param Contact $contact The contact instance.
     *
     * @return Void
     */
    public function delete(Contact $contact)
    {
        $contact->delete();
    }

    /**
     * Sorts contacts in the passed order.
     *
     * @param array $inputData The new sort order.
     *
     * @return bool
     */
    public function sort(array $inputData)
    {
        $newOrder = array_map(
            function ($item) {
                return (int) $item['id'];
            },
            $inputData['items']
        );

        return $this->contactModel->updateSortOrder($newOrder);
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param Contact $contact   The contact to populate and save.
     * @param array   $inputData The input data.
     *
     * @return Contact
     * @throws \Exception
     */
    protected function populateAndSave(Contact $contact, array $inputData)
    {
        $contact = $this->populate($contact, $inputData);

        $contact->save();

        return $contact;
    }
}
