<?php

namespace App\Widgets;

use App\Widgets\Checklist;
use Creitive\Database\Eloquent\Model;
use Creitive\Models\Traits\SortableTrait;

class ChecklistItem extends Model
{
    use SortableTrait;

    /**
     * {@inheritDoc}
     */
    protected $table = 'widget_checklist_items';

    /**
     * {@inheritDoc}
     */
    protected $visible = [
        'id',
        'title',
        'checked',
        'widget_checklist_id',
        'sort',
    ];

    /**
     * {@inheritDoc}
     */
    protected $casts = [
        'checked' => 'bool',
    ];

    /**
     * Eloquent relationship: checklist item belongs to a checklist.
     *
     * @return BelogngsTo
     */
    public function checklist()
    {
        return $this->belongsTo(Checklist::class, 'widget_checklist_id');
    }
}
