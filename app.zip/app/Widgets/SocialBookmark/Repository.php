<?php

namespace App\Widgets\SocialBookmark;

use App\Auth\User;
use App\Widgets\SocialBookmark;
use Carbon\Carbon;

class Repository
{
    /**
     * A social bookmark model instance.
     *
     * @var SocialBookmark
     */
    protected $socialBookmark;

    /**
     * @param SocialBookmark $socialBookmark A social bookmark model instance.
     */
    public function __construct(SocialBookmark $socialBookmark)
    {
        $this->socialBookmarkModel = $socialBookmark;
    }

    /**
     * Finds the social bookmark by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The social bookmark ID.
     *
     * @return SocialBookmark
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->socialBookmarkModel->findOrFail($id);
    }

    /**
     * Updates the passed social bookmark and returns it.
     *
     * @param SocialBookmark $socialBookmark The social bookmark to update.
     * @param array          $inputData      The input data for the update.
     *
     * @return SocialBookmark
     */
    public function update(SocialBookmark $socialBookmark, array $inputData)
    {
        return $this->populateAndSave($socialBookmark, $inputData);
    }

    /**
     * Creates a social bookmark and returns it.
     *
     * @param array $inputData The input data for the update.
     *
     * @return SocialBookmark
     */
    public function create(array $inputData)
    {
        $socialBookmark = $this->socialBookmarkModel->newInstance();

        return $this->populateAndSave($socialBookmark, $inputData);
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param SocialBookmark $socialBookmark The socialBookmark to populate.
     * @param array          $inputData      The input data for the socialBookmark.
     *
     * @return SocialBookmark
     */
    protected function populate(SocialBookmark $socialBookmark, array $inputData)
    {
        $socialBookmark->platform = array_get($inputData, 'platform', $socialBookmark->platform);
        $socialBookmark->user_id = array_get($inputData, 'user_id', $socialBookmark->user_id);
        $socialBookmark->widget_id = array_get($inputData, 'widget_id', $socialBookmark->widget_id);

        return $socialBookmark;
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param SocialBookmark $socialBookmark The social bookmark to populate and save.
     * @param array          $inputData      The input data.
     *
     * @return SocialBookmark
     */
    protected function populateAndSave(SocialBookmark $socialBookmark, array $inputData)
    {
        $socialBookmark = $this->populate($socialBookmark, $inputData);

        $socialBookmark->save();

        return $socialBookmark;
    }

    /**
     * Deletes a social bookmark and returns it.
     *
     * @param SocialBookmark $socialBookmark The social bookmark instance.
     *
     * @return void
     */
    public function delete(SocialBookmark $socialBookmark)
    {
        $socialBookmark->delete();
    }
}
