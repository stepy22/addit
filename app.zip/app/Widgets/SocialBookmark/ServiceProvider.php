<?php

namespace App\Widgets\SocialBookmark;

use App\Widgets\SocialBookmark\Repository as WidgetSocialBookmarkRepository;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Routing\Router;
use URL;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerRoutePatterns($this->app['router'], $this->app);
        $this->registerFrontApiRoutes($this->app['router']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers the route patterns.
     *
     * @param Router    $router    A router.
     * @param Container $container A dependency container.
     *
     * @return void
     */
    protected function registerRoutePatterns(Router $router, Container $container)
    {
        $idRegex = $this->routePatternRegexes['id'];
        $slugRegex = $this->routePatternRegexes['slug'];

        $router->pattern('widgetSocialBookmark', $idRegex);

        $router->bind('widgetSocialBookmark', function ($value) use ($container, $idRegex) {
            $widgetSocialBookmarkRepository = $container->make(WidgetSocialBookmarkRepository::class);

            if (preg_match("/^{$idRegex}$/D", $value)) {
                $widgetSocialBookmark = $widgetSocialBookmarkRepository->findOrFail($value);

                if ($widgetSocialBookmark !== null) {
                    return $widgetSocialBookmark;
                }
            }
        });
    }

    /**
     * Registers front API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1',
            'namespace' => 'App\Widgets\Http\Controllers\Api\V1\Front\SocialBookmark',
        ];

        $attributes['middleware'] = ['api'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('social-bookmarks/platforms', 'Controller@platforms');
        });

        $attributes['middleware'] = ['api', 'auth', 'widgetSocialBookmark.access'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->put('social-bookmarks/{widgetSocialBookmark}', 'Controller@update');
            $router->delete('social-bookmarks/{widgetSocialBookmark}', 'Controller@delete');
        });

        $attributes['middleware'] = ['api', 'auth', 'widget.access:edit'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->post('widgets/{widget}/social-bookmarks', 'Controller@store');
        });
    }
}
