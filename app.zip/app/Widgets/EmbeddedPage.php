<?php

namespace App\Widgets;

use App\Widgets\Widget;
use Creitive\Database\Eloquent\Model;

class EmbeddedPage extends Model
{
    /**
     * {@inheritDoc}
     */
    public $timestamps = false;

    /**
     * {@inheritDoc}
     */
    protected $table = 'widget_embedded_pages';

    /**
     * {@inheritDoc}
     */
    protected $visible = [
        'id',
        'url',
    ];

    /**
     * Eloquent relationship: youtube video belongs to a widget.
     *
     * @return BelogngsTo
     */
    public function widget()
    {
        return $this->belongsTo(Widget::class);
    }
}
