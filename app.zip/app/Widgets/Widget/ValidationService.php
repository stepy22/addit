<?php

namespace App\Widgets\Widget;

use App\Auth\User;
use App\Dashboards\Dashboard;
use App\WidgetCategories\WidgetCategory\Repository as WidgetCategoryRepository;
use App\Widgets\UserWidget;
use App\Widgets\UserWidget\Repository as UserWidgetRepository;
use App\Widgets\Widget;
use App\Widgets\Widget\Repository as WidgetRepository;
use App\WidgetTypes\WidgetType;
use App\WidgetTypes\WidgetType\Repository as WidgetTypeRepository;
use Illuminate\Database\Eloquent\Collection;
use Log;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use \RuntimeException;

class ValidationService
{
    /**
     * A widget repository instance.
     *
     * @var WidgetRepository
     */
    protected $widgetRepository;

    /**
     * A user widget repository instance.
     *
     * @var UserWidgetRepository
     */
    protected $userWidgetRepository;

    /**
     * A widget type repository instance.
     *
     * @var WidgetTypeRepository
     */
    protected $widgetТypeRepository;

    /**
     * Resources actions.
     */
    public const RESOURCE_ACTION_HAS_BLOCK = 'has_block';
    public const RESOURCE_ACTION_CAN_CREATE = 'can_create';
    public const RESOURCE_ACTION_CAN_EDIT = 'can_edit';
    public const RESOURCE_ACTION_CAN_DELETE = 'can_delete';
    public const RESOURCE_ACTION_CAN_SORT = 'can_sort';

    /**
     * @param WidgetRepository     $widgetRepository     A widget repository instance.
     * @param UserWidgetRepository $userWidgetRepository A user widget repository instance.
     * @param WidgetTypeRepository $widgetTypeRepository A widget type repository instance.
     */
    public function __construct(
        WidgetRepository $widgetRepository,
        UserWidgetRepository $userWidgetRepository,
        WidgetTypeRepository $widgetTypeRepository
    ) {
        $this->widgetRepository = $widgetRepository;
        $this->userWidgetRepository = $userWidgetRepository;
        $this->widgetTypeRepository = $widgetTypeRepository;
    }

    /**
     * Checks if user can move widget to favourites.
     *
     * @param Widget $widget Widget instance.
     * @param User   $user   User instance.
     *
     * @throws BadRequestHttpException
     *
     * @return void
     */
    public function validateAddToFavourites(Widget $widget, User $user)
    {
        // If it's already in favourites IT SHALL NOT PASS.
        if ($user->favouriteWidgets->where('id', $widget->id)->count() > 0) {
            throw new BadRequestHttpException('You have already added this widget to list of your favourite widgets.');
        }
    }

    /**
     * Checks if user can archive widget.
     *
     * @param Widget $widget Widget instance.
     * @param User   $user   User instance.
     *
     * @throws BadRequestHttpException
     *
     * @return void
     */
    public function validateArchiveWidget(Widget $widget, User $user)
    {
        // Shared widgets can't be archived.
        if ($widget->users->unique()->count() > 1) {
            if ($widget->owner()->id === $user->id) {
                throw new BadRequestHttpException('You have shared this widget, therefore it can\'t be archived.');
            } else {
                throw new BadRequestHttpException('This widget is shared with you, therefore it can\'t be archived.');
            }
        }

        if ($widget->widgetType->key === 'adsense' && !$user->isPro()) {
            throw new BadRequestHttpException('You must be a PRO user to archive this widget.');
        }
    }

    /**
     * Validates batch delete request.
     *
     * @param Collection $widgets Widgets collection.
     *
     * @throws BadRequestHttpException
     *
     * @return void
     */
    public function validateBatchDelete(Collection $widgets)
    {
        foreach ($widgets as $widget) {
            if ($widget->widgetType->origin === WidgetType::ORIGIN_DEFAULT) {
                throw new BadRequestHttpException('One of the widgets you\'re trying to delete is default widget (suggested websites. suggested apps...) and can\'t be deleted.');
            }
        }
    }

    /**
     * Checks if widget can be deleted.
     *
     * @param Widget $widget Widget instance.
     * @param User   $user   User instance.
     *
     * @throws BadRequestHttpException
     *
     * @return void
     */
    public function validateDelete(Widget $widget, User $user)
    {
        if ($widget->widgetType->key === 'adsense' && !$user->isPro()) {
            throw new BadRequestHttpException('You must be a PRO user to delete this widget.');
        }
    }

    /**
     * Validates moving of a widget.
     *
     * @param UserWidget $userWidget User widget instance.
     * @param Dashboard  $dashboard  Dashboard instance.
     *
     * @throws BadRequestHttpException
     *
     * @return void
     */
    public function validateMove(UserWidget $userWidget, Dashboard $dashboard)
    {
        $userWidget->load('widget', 'dashboard');

        // Default widgets can't be moved.
        if ($userWidget->widget->widgetType->origin === WidgetType::ORIGIN_DEFAULT) {
            throw new BadRequestHttpException('Widget you\'re trying to move is default widget (suggested websites. suggested apps...) and can\'t be moved.');
        }

        // Widget can be moved from home dashboard only if it's created there
        // (not if pinned from other dashboard).
        if ($userWidget->dashboard->is_home &&
            $userWidget->pinned_to_home
        ) {
            throw new BadRequestHttpException('Widget you\'re trying to move is pinned to home dashboard and can\'t be moved (only unpinned).');
        }

        if ($userWidget->dashboard->shared) {
            throw new BadRequestHttpException('Can\'t move widget away from a shared dashboard.');
        }

        if ($dashboard->shared) {
            throw new BadRequestHttpException('Widget can\'t be moved to a shared dashboard.');
        }

        // Check if dashboard to which widget is moved is not shared or home
        // widget.
        if ($dashboard->is_home || $dashboard->is_shared) {
            throw new BadRequestHttpException('Widgets can\'t be moved to Home or Shared widgets dashboard.');
        }

        // If dashboard is shared and user is not the owner check if they have edit mode.
        if ($dashboard->shared &&
            $dashboard->owner()->id !== $userWidget->user_id
        ) {
            if ($userWidget->widget->shared) {
                throw new BadRequestHttpException('You can\'t move shared widget to dashboard which is shared with you.');
            }

            if (!$dashboard->users->where('id', $userWidget->user_id)->first()->pivot->can_edit) {
                throw new BadRequestHttpException('You don\'t have edit mode for this dashboard so you can\'t add widget to it.');
            }
        }
    }

    /**
     * Checks if widget can pin widget to home.
     *
     * @param Widget $widget Widget instance.
     * @param User   $user   User instance.
     *
     * @throws BadRequestHttpException
     *
     * @return void
     */
    public function validatePinToHome(Widget $widget, User $user)
    {
        if ($widget->widgetType->origin === WidgetType::ORIGIN_DEFAULT) {
            throw new BadRequestHttpException('Widget you\'re trying to pin to home is default widget (suggested websites. suggested apps...) and can\'t be pinned to home.');
        }

        // If it's already pinned to home IT SHALL NOT PASS.
        if ($widget->isPinnedOnHomeForUser($user)) {
            throw new BadRequestHttpException('Widget is already pinned to home.');
        }
    }

    /**
     * Checks if widget can be removed from favourites.
     *
     * @param Widget $widget Widget instance.
     * @param User   $user   User instance.
     *
     * @throws BadRequestHttpException
     *
     * @return void
     */
    public function validateRemoveFromFavourites(Widget $widget, User $user)
    {
        // If it's not in favourites IT SHALL NOT PASS.
        if ($user->favouriteWidgets->where('id', $widget->id)->count() === 0) {
            throw new BadRequestHttpException('Widget is not in the list of your favourite widgets.');
        }
    }

    /**
     * Checks if widget can create widget.
     *
     * @param Dashboard  $dashboard  Dashboard instance.
     * @param WidgetType $widgetType Widget type instance.
     * @param User       $user       User instance.
     *
     * @throws BadRequestHttpException
     *
     * @return void
     */
    public function validateCreate(Dashboard $dashboard, WidgetType $widgetType, User $user)
    {
        if ($widgetType->origin === WidgetType::ORIGIN_DEFAULT) {
            throw new BadRequestHttpException('Default widgets (suggested websites, suggested apps...) can\'t be created.');
        }

        // Widgets can't be created on Shared widgets dashboard.
        if ($dashboard->is_shared) {
            throw new BadRequestHttpException('Widget can\'t be added to Shared widgets dashboard.');
        }

        // If dashboard is shared and user is not the owner check if they have edit mode.
        if ($dashboard->shared &&
            $dashboard->owner()->id !== $user->id &&
            !$dashboard->users->where('id', $user->id)->first()->pivot->can_edit
        ) {
            throw new BadRequestHttpException('You don\'t have edit mode for this dashboard so you can\'t add widget to it.');
        }

        // Can't create on shared dashboard as regular user.
        if ($dashboard->users->count() > 1 &&
            $user->account_plan === User::ACCOUNT_PLAN_REGULAR
        ) {
            throw new BadRequestHttpException('You cannot add widget to a shared dashboard unless you subscribe to PRO account.');
        }

        if (!$user->canUseWidgetType($widgetType)) {
            throw new BadRequestHttpException('You must buy widget ['.$widgetType->name.'] in order to use it.');
        }
    }

    /**
     * Checks if widget can be updated.
     *
     * @param  Widget $widget    Widget instance.
     * @param  array  $inputData Input data.
     *
     * @throws BadRequestHttpException
     *
     * @return void
     */
    public function validateUpdate(Widget $widget, array $inputData)
    {
        $widgetType = $widget->widgetType;
        $widgetTypeOrigin = $widgetType->origin;

        if ($widgetTypeOrigin === WidgetType::ORIGIN_DEFAULT || $widgetTypeOrigin === WidgetType::ORIGIN_CUSTOM) {
            throw new BadRequestHttpException('Custom and default widgets can\'t be updated.');
        }

        if ($widgetTypeOrigin === WidgetType::ORIGIN_BASED_ON_BASE) {
            if (isset($inputData['title']) && !$widgetType->configuration['title'] ||
                isset($inputData['description']) && !$widgetType->configuration['description']
            ) {
                throw new BadRequestHttpException('Title or a description can\'t be changed for this widget.');
            }
        }
    }

    /**
     * Checks if widget can be unpinned from home dashboard.
     *
     * @param Widget $widget Widget instance.
     * @param User   $user   User instance.
     *
     * @throws BadRequestHttpException
     *
     * @return void
     */
    public function validateUnpinFromHome(Widget $widget, User $user)
    {
        $userWidget = $widget->userWidgets
            ->where('user_id', $user->id)
            ->where('pinned_to_home', true)
            ->first();

        // It can't be unpinned if it's not pinned!!
        if (!$userWidget->pinned_to_home) {
            throw new BadRequestHttpException('Widget is not pinned to home, so it can\'t be unpinned.');
        }
    }

    /**
     * Validate if widget allow given action for a given resource.
     *
     * @param  Widget $widget   Widget instance.
     * @param  string $resource Resource which to check.
     * @param  string $action   Action to check.
     *
     * @throws RuntimeException
     * @throws AccessDeniedHttpException
     *
     * @return void
     */
    public function validateResourceAccess($widget, $resource, $action)
    {
        if ($widget->widgetType->origin === WidgetType::ORIGIN_BASED_ON_BASE) {
            $widgetTypeConfig = $widget->widgetType->configuration;

            if (!$widgetTypeConfig ||
                empty($widgetTypeConfig) ||
                !isset($widgetTypeConfig[$resource]) ||
                !isset($widgetTypeConfig[$resource][$action])
            ) {
                Log::error('Widget type ['.$widget->widgetType->name.'] is not configured properly.');

                throw new RuntimeException("There was a problem on the server. Please contact administrator.");
            }

            if (!$widgetTypeConfig[$resource][$action]) {
                throw new AccessDeniedHttpException(trans('widgets.resourcesErrorMessages')[$resource][$action]);
            }
        } else if ($widget->widgetType->origin === WidgetType::ORIGIN_USER_CUSTOM) {
            $fieldName = "users_{$resource}";

            return isset($widget->widgetType->$fieldName) && $widget->widgetType->$fieldName;
        } else {
            throw new AccessDeniedHttpException();
        }
    }
}
