<?php

namespace App\Widgets\Widget;

use App\Auth\User;
use App\Dashboards\Dashboard;
use App\InterestTags\InterestTag;
use App\InterestTags\InterestTag\Repository as InterestTagRepository;
use App\SuggestedLinks\SuggestedLink;
use App\SuggestedLinks\SuggestedLink\Repository as SuggestedLinkRepository;
use App\WidgetBackgrounds\WidgetBackground\Repository as WidgetBackgroundRepository;
use App\Widgets\MyTopTenListItem;
use App\Widgets\Widget;
use App\WidgetTypes\WidgetType;
use Carbon\Carbon;
use Favicon\Favicon;
use Illuminate\Database\Eloquent\Collection;
use Log;
use URL;

class Serializer
{
    const WIDGET_LIST_LINKS_COUNT = 5;
    const WIDGET_LIST_FILES_COUNT = 5;
    const WIDGET_LIST_EVENTS_COUNT = 5;
    const WIDGET_LIST_CHECKLIST_COUNT = 5;
    const WIDGET_LIST_GALLERIES_COUNT = 2;
    const WIDGET_LIST_NOTES_COUNT = 2;
    const WIDGET_LIST_BIRTHDAYS_COUNT = 5;
    const WIDGET_LIST_CONTACTS_COUNT = 5;

    // Widget type keys for random links order.
    const SUGGESTED_LINKS_WIDGET_TYPES_CONFIG = [
        'suggestedWebsites' => [
            'type' => 'website',
            'platform' => null,
        ],
        'suggestedAndroidApplications' => [
            'type' => 'application',
            'platform' => 'android',
        ],
        'suggestedIosApplications' => [
            'type' => 'application',
            'platform' => 'ios',
        ],
    ];

    /**
     * Serializes a widget for a dashboard.
     *
     * @param Widget $widget      Widget instance.
     * @param User   $user        User instance.
     * @param int    $dashboardId Dashboard ID.
     *
     * @return array
     */
    public function serializeForDashboard(Widget $widget, User $user, $dashboardId)
    {
        $pivot = $widget->userWidgets
            ->where('user_id', $user->id)
            ->where('dashboard_id', $dashboardId)->first();

        $data = [
            'id' => $widget->id,
            'pivot_id' => $pivot->id,
            'title' => $widget->title,
            'description' => $widget->description,
            'widgetType' => [
                'id' => $widget->widgetType->id,
                'key' => $widget->widgetType->key ?: WidgetType::DEFAULT_KEY,
                'origin' => $widget->widgetType->origin,
                'is_platinum' => $widget->widgetType->is_platinum,
                'is_pro' => $widget->widgetType->is_pro,
                'can_use' => $user->canUseWidgetType($widget->widgetType),
                'url_image_main_thumbnail' => $widget->widgetType->url_image_main_thumbnail,
                'url_image_main_large' => $widget->widgetType->url_image_main_large,
                'configuration' => $widget->widgetType->configuration,
                'uses_galleries' => $widget->widgetType->uses_galleries,
                'uses_checklists' => $widget->widgetType->uses_checklists,
                'uses_links' => $widget->widgetType->uses_links,
                'uses_files' => $widget->widgetType->uses_files,
                'uses_events' => $widget->widgetType->uses_events,
                'uses_notes' => $widget->widgetType->uses_notes,
                'uses_birthdays' => $widget->widgetType->uses_birthdays,
                'uses_contacts' => $widget->widgetType->uses_contacts,
            ],
            'can_edit' => (bool) $widget->pivot->can_edit,
            'is_owner' => (bool) $widget->pivot->is_owner,
            'sort' => $widget->pivot->sort,
            'links' => $this->getWidgetLinks($widget),
            'files' => $widget->files->take(self::WIDGET_LIST_FILES_COUNT),
            'events' => $widget->events->take(self::WIDGET_LIST_EVENTS_COUNT),
            'birthdays' => $widget->birthdays->take(self::WIDGET_LIST_BIRTHDAYS_COUNT),
            'contacts' => $widget->contacts->take(self::WIDGET_LIST_CONTACTS_COUNT),
            'checklists' => $widget->checklists->take(self::WIDGET_LIST_CHECKLIST_COUNT),
            'galleries' => $widget->galleries->take(self::WIDGET_LIST_GALLERIES_COUNT),
            'notes' => $widget->notes->take(self::WIDGET_LIST_NOTES_COUNT),
            'shared' => $widget->shared,
            'shared_owner' => $widget->shared ? $widget->owner()->full_name : null,
            'shared_disabled' => $widget->users->count() > 1 ?
                $widget->owner()->account_plan === User::ACCOUNT_PLAN_REGULAR :
                null,
            'pinned_to_home' => $widget->isPinnedOnHomeForUser($user),
            'favourite' => $widget->isFavouriteForUser($user),
            'links_count' => $widget->links_count,
            'events_count' => $widget->events_count,
            'galleries_count' => $widget->galleries_count,
            'checklists_count' => $widget->checklists_count,
            'files_count' => $widget->files_count,
            'notes_count' => $widget->notes_count,
            'birthdays_count' => $widget->birthdays_count,
            'contacts_count' => $widget->contacts_count,
            'birthdays_active_notifications_count' => $widget->birthdays_active_notifications_count,
            'events_active_notifications_count' => $widget->events_active_notifications_count,
            'cover_image' => $widget->url_image_main_large ?: $widget->widgetType->url_image_main_large,
        ];

        $customWidgetData = $this->getCustomWidgetData($widget, $user);

        $data = array_merge($data, $customWidgetData);

        return $data;
    }

    /**
     * Serializes a widget for search and favourites api endpoints.
     *
     * @param Collection $widgets Widgets collection instance.
     * @param User       $user    User instance.
     *
     * @return array
     */
    public function serializeForSearchAndFavourites(Collection $widgets, User $user)
    {
        $data = [];

        $user->load('dashboards.widgets.userWidgets');

        foreach ($widgets as $widget) {
            $dashboard = $user->dashboards->filter(function (Dashboard $dashboard) use ($widget, $user) {
                return $dashboard->widgets->where('id', $widget->id)->where('pivot.user_id', $user->id)->count() > 0;
            })->first();

            // This should never happen, but there is a check just in case.
            if (!$dashboard) {
                Log::error('Widget detected hanging without a dashboard. Widget ID: ['.$widget->id.'], User ID: ['.$user->id.']');

                continue;
            }

            $pivot = $widget->userWidgets
                ->where('user_id', $user->id)
                ->where('dashboard_id', $dashboard->id)->first();

            $data[] = [
                'id' => $widget->id,
                'title' => $widget->title,
                'description' => $widget->description,
                'widgetType' => [
                    'key' => $widget->widgetType->key ?: WidgetType::DEFAULT_KEY,
                    'origin' => $widget->widgetType->origin,
                    'is_platinum' => $widget->widgetType->is_platinum,
                    'is_pro' => $widget->widgetType->is_pro,
                    'can_use' => $user->canUseWidgetType($widget->widgetType),
                    'url_image_main_thumbnail' => $widget->widgetType->url_image_main_thumbnail,
                    'url_image_main_large' => $widget->widgetType->url_image_main_large,
                    'configuration' => $widget->widgetType->configuration,
                ],
                'is_owner' => $pivot->is_owner,
                'can_edit' => $pivot->can_edit,
                'dashboard_id' => $dashboard ? $dashboard->id : null,
                'shared' => $widget->shared,
                'shared_owner' => $widget->shared ? $widget->owner()->full_name : null,
                'shared_disabled' => $widget->users->count() > 1 ?
                    $widget->owner()->account_plan === User::ACCOUNT_PLAN_REGULAR ||
                    $user->canUseWidgetType($widget->widgetType) :
                    null,
                'pinned_to_home' => $widget->isPinnedOnHomeForUser($user),
            ];
        }

        return $data;
    }

    /**
     * Serializes a single widget.
     *
     * @param Widget                     $widget                     Widget instance.
     * @param User                       $user                       User instance.
     * @param WidgetBackgroundRepository $widgetBackgroundRepository Widget background repository instance.
     *
     * @return array
     */
    public function serializeSingleWidget(Widget $widget, User $user, WidgetBackgroundRepository $widgetBackgroundRepository)
    {
        $pivot = $widget->userWidgets
            ->where('user_id', $user->id)
            ->first();

        $data = [
            'id' => $widget->id,
            'title' => $widget->title,
            'description' => $widget->description,
            'widgetType' => [
                'id' => $widget->widgetType->id,
                'key' => $widget->widgetType->key ?: WidgetType::DEFAULT_KEY,
                'origin' => $widget->widgetType->origin,
                'is_platinum' => $widget->widgetType->is_platinum,
                'is_pro' => $widget->widgetType->is_pro,
                'can_use' => $user->canUseWidgetType($widget->widgetType),
                'configuration' => $widget->widgetType->configuration,
                'uses_galleries' => $widget->widgetType->uses_galleries,
                'url_image_main_thumbnail' => $widget->widgetType->url_image_main_thumbnail,
                'url_image_main_large' => $widget->widgetType->url_image_main_large,
                'uses_checklists' => $widget->widgetType->uses_checklists,
                'uses_links' => $widget->widgetType->uses_links,
                'uses_files' => $widget->widgetType->uses_files,
                'uses_events' => $widget->widgetType->uses_events,
                'uses_notes' => $widget->widgetType->uses_notes,
                'uses_birthdays' => $widget->widgetType->uses_birthdays,
                'uses_contacts' => $widget->widgetType->uses_contacts,
            ],
            'backgrounds' => $widget->backgrounds->merge($widgetBackgroundRepository->getDefaultWidgetBackgrounds()),
            'background' => $widget->background,
            'can_edit' => (bool) $pivot->can_edit,
            'is_owner' => (bool) $pivot->is_owner,
            'sort' => $pivot->sort,
            'shared' => $widget->shared,
            'shared_owner' => $widget->shared ? $widget->owner()->full_name : null,
            'shared_disabled' => $widget->users->count() > 1 ?
                $widget->owner()->account_plan === User::ACCOUNT_PLAN_REGULAR ||
                $user->canUseWidgetType($widget->widgetType) :
                null,
            'pinned_to_home' => $widget->isPinnedOnHomeForUser($user),
            'favourite' => $widget->isFavouriteForUser($user),

        ];

        if ($widget->widgetType->hasResource(WidgetType::RESOURCE_GALLERIES)) {
            $widget->load('galleries.images');
            $data['galleries'] = $widget->galleries;
        }

        if ($widget->widgetType->hasResource(WidgetType::RESOURCE_FILES)) {
            $widget->load('files.items');

            $data['files'] = $widget->files;
        }

        if ($widget->widgetType->hasResource(WidgetType::RESOURCE_CHECKLISTS)) {
            $widget->load('checklists.items');
            $data['checklists'] = $widget->checklists;
        }

        if ($widget->widgetType->hasResource(WidgetType::RESOURCE_LINKS)) {
            $data['links'] = $widget->links;
        }

        if ($widget->widgetType->hasResource(WidgetType::RESOURCE_EVENTS)) {
            $data['events'] = $widget->events;
        }

        if ($widget->widgetType->hasResource(WidgetType::RESOURCE_NOTES)) {
            $data['notes'] = $widget->notes;
        }

        if ($widget->widgetType->hasResource(WidgetType::RESOURCE_BIRTHDAYS)) {
            $data['birthdays'] = $widget->birthdays;
        }

        if ($widget->widgetType->hasResource(WidgetType::RESOURCE_CONTACTS)) {
            $widget->load('contacts.addresses', 'contacts.emails', 'contacts.numbers');

            $data['contacts'] = $widget->contacts;
        }

        $customWidgetData = $this->getCustomWidgetData($widget, $user);

        $data = array_merge($data, $customWidgetData);

        return $data;
    }

    /**
     * Gets custom widget data for a widget.
     *
     * @param  Widget $widget Widget instance.
     * @param  User   $user   User instance.
     *
     * @return array
     */
    public function getCustomWidgetData(Widget $widget, User $user)
    {
        $data = [];

        if ($widget->widgetType->key === 'youtube') {
            $widget->load('youtubeVideo');
            $data['youtubeVideo'] = $widget->youtubeVideo;
        }

        if ($widget->widgetType->key === 'schoolSchedule') {
            $widget->load('schoolScheduleItems');

            $data['schoolScheduleItems'] = $widget->schoolScheduleItems;
        }

        if ($widget->widgetType->key === 'socialMediaBookmarks') {
            $widget->load('socialBookmarks');

            $data['socialBookmarks'] = $widget->socialBookmarks;
        }

        if ($widget->widgetType->key === 'webpageEmbedder') {
            $widget->load('embeddedPage');

            $data['embeddedPage'] = $widget->embeddedPage;
        }

        if ($widget->widgetType->key === 'worldClock') {
            $widget->load('worldClockCities');

            $data['worldClockCities'] = $widget->worldClockCities;
        }

        if ($widget->widgetType->key === 'myTopTenList') {
            $data['myTopTenLists'] = $this->getMappedMyTopTenList($widget, $user);
        }

        if ($widget->widgetType->key === 'myInsights') {
            $data['myInsightItems'] = $widget->myInsighItems;
        }

        if ($widget->widgetType->key === 'dailyHoroscope') {
            $data['sunsigns'] = $widget->horoscopeSunsigns;
        }

        if ($widget->widgetType->key === 'liveScore') {
            $data['sports'] = [
                'Football' => env('ENET_FOOTBALL_KEY'),
                'Tennis' => env('ENET_TENNIS_KEY'),
                'Basketball' => env('ENET_BASKETBALL_KEY'),
                'Handball' => env('ENET_HANDBALL_KEY'),
                'Cricket' => env('ENET_CRICKET_KEY'),
                'Voleyball' => env('ENET_VOLEYBALL_KEY'),
                'Ice Hockey' => env('ENET_ICEHOCKEY_KEY'),
            ];
        }

        return $data;
    }

    /**
     * Gets widget links.
     *
     * @param Widget $widget The widget instance.
     *
     * @return Collection
     */
    private function getWidgetLinks(Widget $widget)
    {
        $links = [];

        if ($this->isSuggestedLinksWidget($widget->widgetType->key)) {
            $config = self::SUGGESTED_LINKS_WIDGET_TYPES_CONFIG[$widget->widgetType->key];
            $links = (new SuggestedLinkRepository(
                new SuggestedLink(),
                new InterestTagRepository(new InterestTag()),
                new Favicon([])
            ))->getRandom($config['type'], $config['platform'], self::WIDGET_LIST_LINKS_COUNT);
        } else {
            $links = $widget->links->take(self::WIDGET_LIST_LINKS_COUNT);
        }

        return $links;
    }

    /**
     * @param string $key Widget type key.
     *
     * @return bool
     */
    private function isSuggestedLinksWidget($key)
    {
        return array_key_exists($key, self::SUGGESTED_LINKS_WIDGET_TYPES_CONFIG);
    }

    /**
     * Map my top ten list items into associative array with date keys.
     *
     * @param Widget $widget The widget instance.
     * @param User   $user   The user instance.
     *
     * @return array
     */
    private function getMappedMyTopTenList(Widget $widget, User $user)
    {
        $mappedList = [];
        $now = Carbon::now('UTC')->setTime(0, 0);

        $daysOffset = MyTopTenListItem::SHOW_LAST_AND_NEXT_DAYS_FOR_REGULAR_USER;
        if ($user->isPro()) {
            $daysOffset = MyTopTenListItem::SHOW_LAST_AND_NEXT_DAYS_FOR_PRO_USER;
        }

        $myLists = $widget->myTopTenListItems()
            ->where('notify_at', '>=', $now->addDays(-$daysOffset)->format('Y-m-d'))
            ->where('notify_at', '<=', $now->addDays(2 * $daysOffset)->setTime(23, 59, 59)->format('Y-m-d'))
            ->orderBy('sort', 'asc')
            ->get()
            ->reduce(function ($carry, $item) use ($user) {
                // On frontend we need array with datekeys.
                // Hereof we map items into associative array.
                // Items in array looks like [date => [items]}. example '2018-11-14' => [['name' => 'some name', 'notified_at' => '2018-11-14 20:49:00', ...]]
                // For mapping we use reduce eloquent model method, initial value is empty array.
                $userDate = Carbon::createFromFormat('Y-m-d H:i:s', $item->notify_at, 'UTC')->setTimezone($user->timezone);
                $dateStr = $userDate->toDateString();

                if (!isset($carry[$dateStr])) {
                    $carry[$dateStr] = [];
                }

                $carry[$dateStr][] = $item;

                return $carry;
            }, []);

        // If there are no items for date range we should add empty array.
        for ($i = -$daysOffset, $startDate = Carbon::now($user->timezone)->addDays(-$daysOffset); $i <= $daysOffset; $i++) {
            $key = $startDate->format('Y-m-d');
            $mappedList[$key] = isset($myLists[$key]) ? $myLists[$key] : [];
            $startDate = $startDate->addDay();
        }

        return $mappedList;
    }
}
