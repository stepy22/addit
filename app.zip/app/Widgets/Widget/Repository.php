<?php

namespace App\Widgets\Widget;

use App\Auth\User;
use App\Dashboards\Dashboard;
use App\WidgetBackgrounds\WidgetBackground;
use App\Widgets\Link as WidgetsLink;
use App\Widgets\UserWidget\Repository as UserWidgetRepository;
use App\Widgets\Widget;
use App\WidgetTypes\WidgetType;
use Hshn\Base64EncodedFile\HttpFoundation\File\Base64EncodedFile;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\QueryException;
use Illuminate\Http\UploadedFile;
use Log;
use RuntimeException;

class Repository
{
    /**
     * A Widget model instance.
     *
     * @var Widget
     */
    protected $widget;

    /**
     * A use widget repository instance.
     *
     * @var UserWidgetRepository
     */
    protected $userWidgetRepository;

    /**
     * @param Widget               $widget               A widget model instance.
     * @param UserWidgetRepository $userWidgetRepository A user widget repository instance.
     */
    public function __construct(Widget $widget, UserWidgetRepository $userWidgetRepository)
    {
        $this->widgetModel = $widget;
        $this->userWidgetRepository = $userWidgetRepository;
    }

    /**
     * Gets all widgets.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAll()
    {
        $query = $this->widgetModel->select('*');

        return $query->get();
    }

    /**
     * Get widgets by ids.
     *
     * @param array $widgetIds Widget ids.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getByIds(array $widgetIds)
    {
        return $this->widgetModel
            ->whereIn('id', $widgetIds)
            ->get();
    }

    /**
     * Gets user's widgets.
     *
     * @param User   $user User instance.
     * @param string $term Query string.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getUsersWidgets(User $user, $term = null)
    {
        if (!$term) {
            return $user->widgets;
        }

        return $user->widgets()
            ->where(function (Builder $query) use ($term) {
                $query->where('title', 'LIKE', "%{$term}%")
                    ->orWhere('description', 'LIKE', "%{$term}%")
                    ->orWhereHas('links', function (Builder $query) use ($term) {
                        $query->where('widget_links.title', 'LIKE', "%{$term}%")
                            ->orWhere('widget_links.description', 'LIKE', "%{$term}%");
                    });
            })
            ->get()
            ->where('pivot.archived_at', null);
    }

    /**
     * Finds the widget by ID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $id The widget ID.
     *
     * @return Widget|null
     */
    public function find($id)
    {
        return $this->widgetModel->find($id);
    }

    /**
     * Finds the widget by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The widget ID.
     *
     * @return Widget
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->widgetModel->findOrFail($id);
    }

    /**
     * Updates the passed widget and returns it.
     *
     * @param Widget $widget    The widget to update.
     * @param array  $inputData The input data for the update.
     *
     * @return Widget
     */
    public function update(Widget $widget, array $inputData)
    {
        return $this->populateAndSave($widget, $inputData);
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param Widget $widget    The widget to populate.
     * @param array  $inputData The input data for the widget.
     *
     * @return Widget
     */
    protected function populate(Widget $widget, array $inputData)
    {
        $widget->title = array_get($inputData, 'title');
        $widget->description = array_get($inputData, 'description');
        if ($widget->widgetType->origin === WidgetType::ORIGIN_BASED_ON_BASE
            || $widget->widgetType->origin === WidgetType::ORIGIN_USER_CUSTOM) {
            $widget->background = array_get($inputData, 'background');
        }

        return $widget;
    }

    /**
     * Sorts widgets in the passed order.
     *
     * @param array $inputData The new sort order.
     *
     * @return bool
     */
    public function sort(array $inputData)
    {
        $newOrder = array_map(
            function ($item) {
                return (int) $item['id'];
            },
            $inputData['items']
        );

        return $this->widgetModel->updateSortOrder($newOrder);
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param Widget $widget    The widget to populate and save.
     * @param array  $inputData The input data.
     *
     * @return Widget
     */
    protected function populateAndSave(Widget $widget, array $inputData)
    {
        $widget = $this->populate($widget, $inputData);

        $widget->save();

        return $widget;
    }

    /**
     * Creates a widget for a user on a specified dashboard.
     *
     * @param  WidgetType $widgetType  Widget type instance.
     * @param  User       $user        User instance.
     * @param  int        $dashboardId Dashboard ID.
     *
     * @return Widget
     */
    public function create(WidgetType $widgetType, User $user, $dashboardId)
    {
        $userWidgets = $user->widgets->where('pivot.dashboard_id', $dashboardId)->sortByDesc('pivot.sort');

        if (!$userWidgets->isEmpty()) {
            $nextSortValue = $userWidgets->first()->pivot->sort + 1;
        } else {
            $nextSortValue = 1;
        }

        $widget = $this->widgetModel->newInstance();

        $widget->title = $widgetType->name;
        $widget->widget_type_id = $widgetType->id;
        $background = WidgetBackground::where('default', true)->first();
        if ($background) {
            $widget->background = $background->background_str;
        }

        $widget->save();

        $user->widgets()->attach([
            $widget->id => [
                'is_owner' => true,
                'can_edit' => true,
                'dashboard_id' => $dashboardId,
                'sort' => $nextSortValue,
            ],
        ]);

        return $widget;
    }

    /**
     * Creates widgets for a passed user.
     *
     * @param array $configuration Configuration array.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function createWidgetsForUser(array $configuration)
    {
        $widgets = collect();
        $dashboardUuids = [];

        foreach ($configuration as $item) {
            foreach ($item['widgetTypes'] as $widgetType) {
                $widget = $this->widgetModel->newInstance();

                $widget->title = $widgetType->name;
                $widget->widget_type_id = $widgetType->id;
                $widget->init_dashboard_uuid = $item['dashboardUuid'];

                $dashboardUuids[] = $item['dashboardUuid'];

                $widgets->push($widget);
            }
        }

        try {
            $this->widgetModel->insert($widgets->toArray());
        } catch (QueryException $e) {
            Log::error($e);

            return false;
        }

        return $this->widgetModel
            ->whereIn('init_dashboard_uuid', $dashboardUuids)
            ->get();
    }

    /**
     * Deletes a widget.
     *
     * @param Widget $widget Widget instance.
     *
     * @return void
     */
    public function delete(Widget $widget)
    {
        $widget->delete();
    }

    /**
     * Deletes a widget with passed ids.
     *
     * @param array $widgetIds Widget ids.
     *
     * @return void
     */
    public function deleteByIds(array $widgetIds)
    {
        $this->widgetModel
            ->whereIn('id', $widgetIds)
            ->delete();
    }

    /**
     * Shares a widget with a user.
     *
     * @param  Widget $widget Widget instance.
     * @param  User   $user   User instance.
     *
     * @return Widget
     *
     * @throws RuntimeException
     */
    public function share(Widget $widget, User $user)
    {
        // First we must find user's Shared dashboard.
        $user->load('dashboards');

        $sharedDashboard = $user->dashboards->where('is_shared', true)->first();

        if (!$sharedDashboard) {
            Log::error("Failed to share a widget, user {$user->email} don't have a Shared dashboard.");

            throw new RuntimeException;
        }

        if ($sharedDashboard->widgets->isEmpty()) {
            $newSort = 1;
        } else {
            $newSort = $sharedDashboard->widgets->sortByDesc('pivot.sort')->first()->pivot->sort + 1;
        }

        $widget->users()->attach([
            $user->id => [
                'dashboard_id' => $sharedDashboard->id,
                'is_owner' => false,
                'can_edit' => false,
                'sort' => $newSort,
            ],
        ]);

        return $widget;
    }

    /**
     * Attaches dashboard users to a widget.
     *
     * @param User      $owner     User instance.
     * @param Widget    $widget    Widget instance.
     * @param Dashboard $dashboard Dashboard instance.
     *
     * @return void
     */
    public function attachDashboardUsers(User $owner, Widget $widget, Dashboard $dashboard)
    {
        $dashboard->load('users', 'widgets');

        $users = $dashboard->users->where('id', '!==', $owner->id);

        $usersForAttaching = [];

        foreach ($users as $user) {
            $usersForAttaching[$user->id] = [
                'is_owner' => false,
                'can_edit' => $user->pivot->can_edit,
                'dashboard_id' => $dashboard->id,
                'sort' => $dashboard->widgets->where('pivot.user_id', $user->id)->count() + 1,
            ];
        }

        $widget->users()->attach($usersForAttaching);
    }

    /**
     * Change widget cover picture.
     *
     * @param Widget $widget    Widget instance.
     * @param array  $inputData The input data.
     *
     * @return Widget
     *
     * @throws \Exception
     */
    public function changeCoverPicture(Widget $widget, array $inputData)
    {
        if ($inputData['image'] instanceof UploadedFile) {
            $widget->uploadImage($inputData['image'], 'main');
        } else {
            $file = new Base64EncodedFile($inputData['image']);
            $widget->uploadImage($file->getPathname(), 'main');
        }

        $widget->save();

        return $widget;
    }
}
