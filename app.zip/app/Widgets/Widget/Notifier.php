<?php

namespace App\Widgets\Widget;

use App\Auth\User;
use App\Jobs\NotifyUser;
use App\Notifications\Notification;
use App\Notifications\Notification\Notifier as BaseNotifier;
use App\Widgets\Mail\MyTopTenTaskNotification;
use App\Widgets\Mail\RemovedFromWidget;
use App\Widgets\Mail\SharedWidget;
use App\Widgets\Mail\SharedWidgetDeleted;
use App\Widgets\Mail\SharedWidgetInvitation;
use App\Widgets\Mail\SharedWidgetPermissionsChanged;
use App\Widgets\Mail\UnsubscribedFromWidget;
use App\Widgets\UserWidget;
use App\Widgets\Widget;
use Illuminate\Contracts\Mail\Mailer;
use Illuminate\Support\Collection;
use URL;

class Notifier
{
    /**
     * A Mailer instance.
     *
     * @var Mailer
     */
    protected $mailer;

    /**
     * A base notifier service..
     *
     * @var BaseNotifier
     */
    protected $baseNotifier;

    /**
     * @param Mailer       $mailer       Mailer class instance.
     * @param BaseNotifier $baseNotifier Base notifier instance.
     */
    public function __construct(Mailer $mailer, BaseNotifier $baseNotifier)
    {
        $this->mailer = $mailer;
        $this->baseNotifier = $baseNotifier;
    }

    /**
     * Notifies a user about deleted shared widget.
     *
     * @param Widget     $widget Widget instance.
     * @param Collection $users  Users collection.
     *
     * @return void
     */
    public function notifySharedDeleted(Widget $widget, Collection $users)
    {
        $this->mailer->queue(new SharedWidgetDeleted($widget, $users));

        NotifyUser::dispatch(
            $this->baseNotifier,
            trans('widgets.notifications.'.Notification::TYPE_WIDGET_DELETION, [
                'user' => $widget->owner()->full_name,
                'widget' => $widget->title,
            ]),
            Notification::TYPE_WIDGET_DELETION,
            $users,
            null,
            URL::action('App\Dashboards\Http\Controllers\Front\Dashboard\Controller@index', [], false)
        );
    }

    /**
     * Notifies a user that widget is shared with them.
     *
     * @param Widget $widget Widget instance.
     * @param User   $user   User instance.
     *
     * @return void
     */
    public function notifyShared(Widget $widget, User $user)
    {
        $this->mailer->queue(new SharedWidget($widget, $user));

        NotifyUser::dispatch(
            $this->baseNotifier,
            trans('widgets.notifications.'.Notification::TYPE_WIDGET_SHARING, [
                'user' => $widget->owner()->full_name,
                'widget' => $widget->title,
            ]),
            Notification::TYPE_WIDGET_SHARING,
            $user,
            null,
            URL::action('App\Dashboards\Http\Controllers\Front\Dashboard\Controller@index', [], false)
        );
    }

    /**
     * Notifies a user that permission of shared widget is changed.
     *
     * @param UserWidget $userWidget User widget instance.
     * @param bool       $canEdit    Flag that indicates permission settings.
     *
     * @return void
     */
    public function notifySharedPermissionsChange(UserWidget $userWidget, $canEdit)
    {
        $userWidget->load('user', 'widget');

        $this->mailer->queue(new SharedWidgetPermissionsChanged($userWidget, $canEdit));

        if ($userWidget->user) {
            NotifyUser::dispatch(
                $this->baseNotifier,
                trans('widgets.notifications.'.Notification::TYPE_WIDGET_PERMISSIONS_CHANGED, [
                    'user' => $userWidget->widget->owner()->full_name,
                    'widget' => $userWidget->widget->title,
                ]),
                Notification::TYPE_WIDGET_PERMISSIONS_CHANGED,
                $userWidget->user,
                null,
                URL::action('App\Dashboards\Http\Controllers\Front\Dashboard\Controller@index', [], false)
            );
        }
    }

    /**
     * Notifies a user that they have been unsubscribed from a widget.
     *
     * @param UserWidget $userWidget User widget instance.
     *
     * @return void
     */
    public function notifyRemovedFromWidget(UserWidget $userWidget)
    {
        $userWidget->load('user', 'widget');

        $this->mailer->queue(new RemovedFromWidget($userWidget));

        if ($userWidget->user) {
            NotifyUser::dispatch(
                $this->baseNotifier,
                trans('widgets.notifications.'.Notification::TYPE_REMOVED_FROM_WIDGET, [
                    'user' => $userWidget->widget->owner()->full_name,
                    'widget' => $userWidget->widget->title,
                ]),
                Notification::TYPE_REMOVED_FROM_WIDGET,
                $userWidget->user,
                null,
                URL::action('App\Dashboards\Http\Controllers\Front\Dashboard\Controller@index', [], false)
            );
        }
    }

    /**
     * Notifies owner of a widget that user has unsubscribed from their widget.
     *
     * @param UserWidget $userWidget User widget instance.
     *
     * @return void
     */
    public function notifyUnsubscribedFromWidget(UserWidget $userWidget)
    {
        $userWidget->load('user', 'widget');

        $this->mailer->queue(new UnsubscribedFromWidget($userWidget));

        NotifyUser::dispatch(
            $this->baseNotifier,
            trans('widgets.notifications.'.Notification::TYPE_UNSUBSCRIBED_FROM_WIDGET, [
                'user' => $userWidget->user->full_name,
                'widget' => $userWidget->widget->title,
            ]),
            Notification::TYPE_UNSUBSCRIBED_FROM_WIDGET,
            $userWidget->widget->owner(),
            null,
            URL::action('App\Dashboards\Http\Controllers\Front\Dashboard\Controller@index', [], false)
        );
    }

    /**
     * Sends invitation to a user, to join Add-it and use the widget that is
     * shared with them.
     *
     * @param Widget $widget Widget instance.
     * @param string $email  Email to which to send invitation.
     *
     * @return void
     */
    public function sharedWidgetInvitation(Widget $widget, $email)
    {
        $widget->load('users');
        $this->mailer->queue(new SharedWidgetInvitation($widget, $email));
    }

    /**
     * Sends notification to a user, to notify about created task.
     *
     * @param string $userName      Name of user.
     * @param string $userEmail     User email address.
     * @param string $taskName      Name of task.
     * @param int    $numberOfTasks Number of tasks.
     */
    public function sendMyTopTenTaskNotification($userName, $userEmail, $taskName, $numberOfTasks)
    {
        $this->mailer->queue(new MyTopTenTaskNotification($userName, $userEmail, $taskName, $numberOfTasks));
    }
}
