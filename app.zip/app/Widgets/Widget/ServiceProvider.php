<?php

namespace App\Widgets\Widget;

use App\Widgets\Widget;
use App\Widgets\Widget\Repository as WidgetRepository;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Creitive\Routing\LocaleResolver;
use DaveJamesMiller\Breadcrumbs\Generator as BreadcrumbGenerator;
use DaveJamesMiller\Breadcrumbs\Manager as BreadcrumbManager;
use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Routing\Router;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use URL;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerRoutePatterns($this->app['router'], $this->app);
        $this->registerFrontApiRoutes($this->app['router']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers the route patterns.
     *
     * @param Router    $router    A router.
     * @param Container $container A dependency container.
     *
     * @return void
     */
    protected function registerRoutePatterns(Router $router, Container $container)
    {
        $idRegex = $this->routePatternRegexes['id'];
        $slugRegex = $this->routePatternRegexes['slug'];

        $router->pattern('widget', $idRegex);

        $router->bind('widget', function ($value) use ($container, $idRegex) {
            $widgetRepository = $container->make(WidgetRepository::class);

            if (preg_match("/^{$idRegex}$/D", $value)) {
                $widget = $widgetRepository->find($value);

                if ($widget !== null) {
                    return $widget;
                }
            }
        });
    }

    /**
     * Registers front API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1/widgets',
            'middleware' => ['api', 'auth'],
            'namespace' => 'App\Widgets\Http\Controllers\Api\V1\Front\Widget',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('', 'Controller@index');
            $router->put('sort', 'Controller@sort');
            $router->post('actions/batch-delete', 'Controller@batchDelete');
            $router->post('actions/batch-unarchive', 'Controller@batchUnarchive');
            $router->get('favourites', 'Controller@favouriteWidgets');
            $router->put('{userWidget}/actions/archive', 'Controller@archive');
            $router->put('{userWidget}/actions/unarchive', 'Controller@unarchive');
            $router->put('{userWidget}/actions/move', 'Controller@move');
            $router->post('{userWidget}/actions/change-cover-picture', 'Controller@changeCoverPicture');
            $router->put('{widget}/actions/pin-to-home', 'Controller@pinToHome');
            $router->put('{widget}/actions/unpin-from-home', 'Controller@unpinFromHome');
            $router->put('{widget}/actions/add-to-favourites', 'Controller@addToFavourites');
            $router->put('{widget}/actions/remove-from-favourites', 'Controller@removeFromFavourites');
            $router->put('{widget}/actions/update-background', 'Controller@updateBackground');
        });

        $attributes['middleware'] = ['api', 'auth', 'widget.access'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('{widget}', 'Controller@show');
        });

        $attributes['middleware'] = ['api', 'auth', 'widget.access:edit'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->put('{widget}', 'Controller@update');
        });

        $attributes['middleware'] = ['api', 'auth', 'widget.ownership'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->delete('{widget}', 'Controller@delete');
        });
    }
}
