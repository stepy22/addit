<?php

namespace App\Widgets\Widget;

use App\Auth\User;
use App\Dashboards\Dashboard;
use App\WidgetCategories\WidgetCategory\Repository as WidgetCategoryRepository;
use App\Widgets\EmbeddedPage\Repository as WidgetEmbeddedPageRepository;
use App\Widgets\MyInsightItem\Repository as WidgetMyInsightItemRepository;
use App\Widgets\UserWidget;
use App\Widgets\UserWidget\Repository as UserWidgetRepository;
use App\Widgets\Widget;
use App\Widgets\Widget\Notifier as WidgetNotifier;
use App\Widgets\Widget\Repository as WidgetRepository;
use App\Widgets\YoutubeVideo\Repository as WidgetYoutubeVideoRepository;
use App\WidgetTypes\WidgetType\Repository as WidgetTypeRepository;
use Illuminate\Database\Eloquent\Collection;
use Log;

class Manager
{
    /**
     * A widget repository instance.
     *
     * @var WidgetRepository
     */
    protected $widgetRepository;

    /**
     * A user widget repository instance.
     *
     * @var UserWidgetRepository
     */
    protected $userWidgetRepository;

    /**
     * A widget type repository instance.
     *
     * @var WidgetTypeRepository
     */
    protected $widgetТypeRepository;

    /**
     * A widget notifier instance.
     *
     * @var WidgetNotifier
     */
    protected $widgetNotifier;

    /**
     * A widget youtube video repository instance.
     *
     * @var WidgetYoutubeVideoRepository
     */
    protected $widgetYoutubeVideoRepository;

    /**
     * A widget embedded page repository instance.
     *
     * @var WidgetEmbeddedPageRepository
     */
    protected $widgetEmbeddedPageRepository;

    /**
     * A widget my insight item repository instance.
     *
     * @var WidgetMyInsightItemRepository
     */
    protected $widgetMyInsightItemRepository;

    /**
     * @param WidgetRepository              $widgetRepository              A widget repository instance.
     * @param UserWidgetRepository          $userWidgetRepository          A user widget repository instance.
     * @param WidgetTypeRepository          $widgetTypeRepository          A widget type repository instance.
     * @param WidgetNotifier                $widgetNotifier                A widget notifier instance.
     * @param WidgetYoutubeVideoRepository  $widgetYoutubeVideoRepository  A widget youtube video repository instance.
     * @param WidgetEmbeddedPageRepository  $widgetEmbeddedPageRepository  A widget embedded page repository instance.
     * @param WidgetMyInsightItemRepository $widgetMyInsightItemRepository A widget my insight item repository instance.
     */
    public function __construct(
        WidgetRepository $widgetRepository,
        UserWidgetRepository $userWidgetRepository,
        WidgetTypeRepository $widgetTypeRepository,
        WidgetNotifier $widgetNotifier,
        WidgetYoutubeVideoRepository $widgetYoutubeVideoRepository,
        WidgetEmbeddedPageRepository $widgetEmbeddedPageRepository,
        WidgetMyInsightItemRepository $widgetMyInsightItemRepository
    ) {
        $this->widgetRepository = $widgetRepository;
        $this->userWidgetRepository = $userWidgetRepository;
        $this->widgetTypeRepository = $widgetTypeRepository;
        $this->widgetNotifier = $widgetNotifier;
        $this->widgetYoutubeVideoRepository = $widgetYoutubeVideoRepository;
        $this->widgetEmbeddedPageRepository = $widgetEmbeddedPageRepository;
        $this->widgetMyInsightItemRepository = $widgetMyInsightItemRepository;
    }

    /**
     * Suggests initial widgets for newly created user.
     *
     * @param User $user User instance.
     *
     * @return Collection
     */
    public function suggestWidgets(User $user)
    {
        $configuration = [];

        $user->load('dashboards.dashboardCategory.defaultWidgetTypes');

        // Load default widget type ids (those which are created for each
        // dashboard, like adsense and suggested link widgets).
        $defaultWidgetTypes = $this->widgetTypeRepository->getDefaultWidgetTypes();

        // Load default widgets for each dashboard.
        foreach ($user->dashboards as $dashboard) {
            // We don't want to suggest anything for shared widgets dashboard,
            // only shared widgets there.
            if ($dashboard->is_shared) {
                continue;
            }

            $widgetTypes = collect();

            if ($dashboard->dashboardCategory) {
                $widgetTypes = $dashboard->dashboardCategory->defaultWidgetTypes;
            }

            $configuration[] = [
                'dashboardUuid' => $dashboard->uuid,
                'widgetTypes' => $defaultWidgetTypes->merge($widgetTypes),
            ];
        }

        $widgets = $this->widgetRepository->createWidgetsForUser($configuration, $user);

        if (!$widgets) {
            Log::error('Failed to create initial widgets for user with ID: '. $user->id);

            return false;
        }

        $userWidgetsData = [];

        foreach ($widgets as $widget) {
            $dashboardId = $user->dashboards
                ->where('uuid', $widget->init_dashboard_uuid)
                ->first()->id;

            $userWidgetsData[$widget->id] = [
                'is_owner' => true,
                'can_edit' => true,
                'dashboard_id' => $dashboardId,
            ];
        }

        $user->widgets()->attach($userWidgetsData);

        return $widgets;
    }

    /**
     * Suggests initial widgets for newly created user.
     *
     * @param Dashboard $dashboard Dashboard instance.
     * @param User      $user      User instance.
     *
     * @return Collection
     */
    public function suggestWidgetsForDashboard(Dashboard $dashboard, User $user)
    {
        $configuration = [];

        $defaultWidgetTypes = $this->widgetTypeRepository->getDefaultWidgetTypes();
        $dashboardWidgetTypes = $dashboard->dashboardCategory->defaultWidgetTypes;

        $configuration[] = [
            'dashboardUuid' => $dashboard->uuid,
            'widgetTypes' => $defaultWidgetTypes->merge($dashboardWidgetTypes),
        ];

        $widgets = $this->widgetRepository->createWidgetsForUser($configuration, $user);

        if (!$widgets) {
            Log::error('Failed to create initial widgets for user with ID: '. $user->id);

            return false;
        }

        $userWidgetsData = [];

        foreach ($widgets as $widget) {
            $userWidgetsData[$widget->id] = [
                'is_owner' => true,
                'can_edit' => true,
                'dashboard_id' => $dashboard->id,
            ];
        }

        $user->widgets()->attach($userWidgetsData);

        return $widgets;
    }

    /**
     * Shares a widget with a user.
     *
     * @param Widget $widget Widget instance.
     * @param User   $user   User instance.
     *
     * @return Widget
     */
    public function share(Widget $widget, User $user)
    {
        $this->widgetNotifier->notifyShared($widget, $user);
        $this->widgetRepository->share($widget, $user);

        return $widget;
    }

    /**
     * Creates invitation for shared widget.
     *
     * @param Widget $widget Widget instance.
     * @param string $email  Email of a user.
     *
     * @return Widget
     */
    public function createInvitation(Widget $widget, $email)
    {
        $this->widgetNotifier->sharedWidgetInvitation($widget, $email);
        $this->userWidgetRepository->createWidgetInvitation($widget, $email);

        return $widget;
    }

    /**
     * Connects widget invitations to newly created user.
     *
     * @param User $user User instance.
     *
     * @return void
     */
    public function connectInvitations(User $user)
    {
        $invitations = $this->userWidgetRepository->getInvitations($user->email);
        $sharedDashboard = $user->dashboards->where('is_shared', true)->first();

        if (!$sharedDashboard) {
            Log::error('Failed to connect widget invitations for user: ' . $user->email . ', no shared dashboard found for a user.');

            return;
        }

        $sort = 1;

        foreach ($invitations as $invitation) {
            $invitation->email = null;
            $invitation->user_id = $user->id;
            $invitation->dashboard_id = $sharedDashboard->id;
            $invitation->sort = $sort++;

            $invitation->save();
        }
    }

    /**
     * Handle creation of a widget on shared dashboard.
     *
     * @param User      $user      User instance.
     * @param Widget    $widget    Widget instance.
     * @param Dashboard $dashboard Target dashboard.
     *
     * @return void
     */
    public function handleCreateOnSharedDashboard(User $user, Widget $widget, Dashboard $dashboard)
    {
        // If target dashboard is shared - share widget with all dashboard users.
        if ($dashboard->shared) {
            $this->widgetRepository->attachDashboardUsers($user, $widget, $dashboard);
        }
    }

    /**
     * Seeds initial data based on a widget type where that is needed.
     *
     * @param Widget $widget Widget instance.
     *
     * @return void
     */
    public function seedInitialDataByWidgetType($widget)
    {
        if ($widget->widgetType->key == 'webpageEmbedder') {
            $this->widgetEmbeddedPageRepository->create([
                'widget_id' => $widget->id,
                'url' => '',
            ]);
        }

        if ($widget->widgetType->key == 'youtube') {
            $this->widgetYoutubeVideoRepository->create([
                'widget_id' => $widget->id,
                'video_id' => '',
            ]);
        }

        if ($widget->widgetType->key == 'myInsights') {
            $this->widgetMyInsightItemRepository->createDefaultSubjects($widget->id);
        }
    }
}
