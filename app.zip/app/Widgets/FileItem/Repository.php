<?php

namespace App\Widgets\FileItem;

use App\Widgets\FileItem;
use Creitive\File\Uploader as FileUploader;
use Hshn\Base64EncodedFile\HttpFoundation\File\Base64EncodedFile;
use Symfony\Component\HttpFoundation\File\File as SymfonyFile;
use wapmorgan\FileTypeDetector\Detector;

class Repository
{
    /**
     * A FileItem model instance.
     *
     * @var FileItem
     */
    protected $fileItemModel;

    /**
     * A FileUploader instance.
     *
     * @var FileUploader
     */
    protected $fileUploader;

    /**
     * @param FileItem     $fileItem     A file item model instance.
     * @param FileUploader $fileUploader A file uploader instance.
     */
    public function __construct(FileItem $fileItem, FileUploader $fileUploader)
    {
        $this->fileItemModel = $fileItem;
        $this->fileUploader = $fileUploader;
    }

    /**
     * Gets all file items.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAll()
    {
        $query = $this->fileItemModel->select('*');

        return $query->get();
    }

    /**
     * Finds the file item by ID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $id The fileItem ID.
     *
     * @return FileItem|null
     */
    public function find($id)
    {
        return $this->fileItemModel->find($id);
    }

    /**
     * Finds widget file items by ids.
     *
     * @param array $ids The file item IDs.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getByIds(array $ids)
    {
        return $this->fileItemModel
            ->whereIn('id', $ids)
            ->get();
    }

    /**
     * Finds the file item by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The file item ID.
     *
     * @return FileItem
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->fileItemModel->findOrFail($id);
    }

    /**
     * Updates the passed fileItem and returns it.
     *
     * @param FileItem $fileItem  The file item to update.
     * @param array    $inputData The input data for the update.
     *
     * @return FileItem
     */
    public function update(FileItem $fileItem, array $inputData)
    {
        return $this->populateAndSave($fileItem, $inputData);
    }

    /**
     * Creates a file item and returns it.
     *
     * @param array $inputData The input data for the update.
     *
     * @return FileItem
     */
    public function create(array $inputData)
    {
        $fileItem = $this->fileItemModel->newInstance();

        return $this->populateAndSave($fileItem, $inputData);
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param FileItem $fileItem  The file item to populate.
     * @param array    $inputData The input data for the file item.
     *
     * @return FileItem
     */
    protected function populate(FileItem $fileItem, array $inputData)
    {
        $fileItem->name = array_get($inputData, 'name', $fileItem->name);
        $fileItem->widget_file_id = array_get($inputData, 'widget_file_id', $fileItem->widget_file_id);

        if (isset($inputData['file'])) {
            $uploadedFile = new Base64EncodedFile($inputData['file']);
            $uploadedFile = new SymfonyFile($uploadedFile);

            $fileItem->filepath = $this->fileUploader->upload($uploadedFile);
            $type = Detector::detectByContent(public_path('upload/files/' . $fileItem->filepath));

            if ($type && is_array($type) && isset($type[1])) {
                $fileItem->extension = $type[1];
            } else {
                $fileItem->extension = $uploadedFile->guessExtension();
            }
        }

        return $fileItem;
    }

    /**
     * Deletes a fileItem.
     *
     * @param FileItem $fileItem The file item instance.
     *
     * @return Void
     */
    public function delete(FileItem $fileItem)
    {
        $fileItem->delete();
    }

    /**
     * Sorts file items in the passed order.
     *
     * @param array $inputData The new sort order.
     *
     * @return bool
     */
    public function sort(array $inputData)
    {
        $newOrder = array_map(
            function ($item) {
                return (int) $item['id'];
            },
            $inputData['items']
        );

        return $this->fileItemModel->updateSortOrder($newOrder);
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param FileItem $fileItem  The file item to populate and save.
     * @param array    $inputData The input data.
     *
     * @return FileItem
     */
    protected function populateAndSave(FileItem $fileItem, array $inputData)
    {
        $fileItem = $this->populate($fileItem, $inputData);

        $fileItem->save();

        return $fileItem;
    }
}
