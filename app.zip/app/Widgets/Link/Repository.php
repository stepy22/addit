<?php

namespace App\Widgets\Link;

use App\Auth\User;
use App\SuggestedLinks\SuggestedLink;
use App\SuggestedLinks\SuggestedLink\Repository as SuggestedLinkRepository;
use App\Widgets\Link;
use Favicon\Favicon;
use Favicon\FaviconDLType;
use Hshn\Base64EncodedFile\HttpFoundation\File\Base64EncodedFile;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\QueryException;
use Illuminate\Support\Collection;
use Log;

class Repository
{
    /**
     * A Link model instance.
     *
     * @var Link
     */
    protected $link;

    /**
     * A suggest links repository.
     *
     * @var SuggestLinkRepository
     */
    protected $suggestLinkRepository;

    /**
     * A favicon instance.
     *
     * @var Favicon
     */
    protected $favicon;

    /**
     * @param Link                    $link                    A link model instance.
     * @param SuggestedLinkRepository $suggestedLinkRepository A suggested link repository instance.
     * @param Favicon                 $favicon                 A favicon instance.
     */
    public function __construct(Link $link, SuggestedLinkRepository $suggestedLinkRepository, Favicon $favicon)
    {
        $this->linkModel = $link;
        $this->suggestedLinkRepository = $suggestedLinkRepository;
        $this->favicon = $favicon;
    }

    /**
     * Gets all links.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAll()
    {
        $query = $this->linkModel->select('*');

        return $query->get();
    }

    /**
     * Finds the link by ID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $id The link ID.
     *
     * @return Link|null
     */
    public function find($id)
    {
        return $this->linkModel->find($id);
    }

    /**
     * Finds widget links by ids.
     *
     * @param array $ids The link IDs.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getByIds(array $ids)
    {
        return $this->linkModel
            ->whereIn('id', $ids)
            ->get();
    }

    /**
     * Finds the link by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The link ID.
     *
     * @return Link
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->linkModel->findOrFail($id);
    }

    /**
     * Updates the passed link and returns it.
     *
     * @param Link  $link      The link to update.
     * @param array $inputData The input data for the update.
     *
     * @return Link
     */
    public function update(Link $link, array $inputData)
    {
        return $this->populateAndSave($link, $inputData);
    }

    /**
     * Creates a link and returns it.
     *
     * @param array $inputData The input data for the update.
     *
     * @return Link
     */
    public function create(array $inputData)
    {
        $link = $this->linkModel->newInstance();

        return $this->populateAndSave($link, $inputData);
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param Link  $link      The link to populate.
     * @param array $inputData The input data for the link.
     *
     * @return Link
     */
    protected function populate(Link $link, array $inputData)
    {
        if (isset($inputData['url']) && $inputData['url'] !== $link->url) {
            $icon = $this->favicon->get($inputData['url'], FaviconDLType::RAW_IMAGE);
            $file = new Base64EncodedFile(base64_encode($icon));

            try {
                $link->uploadImage($file->getPathname(), 'main');
            } catch (\ImagickException $e) {
                Log::error($e);
            }
        }

        $link->title = array_get($inputData, 'title', $link->title);
        $link->description = array_get($inputData, 'description', $link->description);
        $link->url = array_get($inputData, 'url', $link->url);
        $link->widget_id = array_get($inputData, 'widget_id', $link->widget_id);

        if (isset($inputData['image_main'])) {
            if ($inputData['image_main'] instanceof UploadedFile) {
                $link->uploadImage($inputData['image_main'], 'main');
            } else {
                $file = new Base64EncodedFile($inputData['image_main']);
                $link->uploadImage($file->getPathname(), 'main');
            }
        }

        return $link;
    }

    /**
     * Deletes a link.
     *
     * @param Link $link The link instance.
     *
     * @return Void
     */
    public function delete(Link $link)
    {
        $link->delete();
    }

    /**
     * Sorts links in the passed order.
     *
     * @param array $inputData The new sort order.
     *
     * @return bool
     */
    public function sort(array $inputData)
    {
        $newOrder = array_map(
            function ($item) {
                return (int) $item['id'];
            },
            $inputData['items']
        );

        return $this->linkModel->updateSortOrder($newOrder);
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param Link  $link      The link to populate and save.
     * @param array $inputData The input data.
     *
     * @return Link
     */
    protected function populateAndSave(Link $link, array $inputData)
    {
        $link = $this->populate($link, $inputData);

        $link->save();

        return $link;
    }

    /**
     * Suggests links for user's widgets.
     *
     * @param array $configuration  Configuration array.
     * @param User  $user           User instance.
     * @param int   $linksPerWidget User instance.
     *
     * @return void
     */
    public function suggestLinks(array $configuration, User $user, $linksPerWidget)
    {
        $user->load('interestTags');

        $linksToCreate = [];
        $allWebisteLinks = $this->suggestedLinkRepository->getAllByType(SuggestedLink::TYPE_WEBSITE);
        $allAppLinks = $this->suggestedLinkRepository->getAllByType(SuggestedLink::TYPE_APP);

        foreach ($configuration as $item) {
            // Save ids of widgets for which links are created.
            $iosAppsWidgetId = $item['suggestedIosAppsWiget'] ? $item['suggestedIosAppsWiget']->id : null;
            $androidAppsWidgetId = $item['suggestedAndroidAppsWiget'] ? $item['suggestedAndroidAppsWiget']->id : null;
            $websitesWidgetId = $item['suggestedWebsitesWiget'] ? $item['suggestedWebsitesWiget']->id : null;

            // If there is no dashboard links for a dashboard it may be a Home
            // or Shared dashboard, in case of Home dashboard suggest random
            // links from all categories, in any other case just skip current
            // iteration.
            if ($item['dashboardLinks'] === null) {
                if ($item['homeDashboard']) {
                    $homeLinks = $this->getHomeDashboardLinks(
                        $user,
                        $allWebisteLinks,
                        $allAppLinks,
                        $androidAppsWidgetId,
                        $iosAppsWidgetId,
                        $websitesWidgetId,
                        $linksPerWidget
                    );

                    $linksToCreate = array_merge($homeLinks, $linksToCreate);
                }

                continue;
            }

            // Filter all dashboard links by widget type (Android apps widget, Ios apps
            // widget, Websites widget).
            $androidLinks = $item['dashboardLinks']->where('platform', SuggestedLink::PLATFORM_ANDROID);
            $iosLinks = $item['dashboardLinks']->where('platform', SuggestedLink::PLATFORM_IOS);
            $websiteLinks = $item['dashboardLinks']->where('type', SuggestedLink::TYPE_WEBSITE);

            // Sorts links by interest tags matched so relevant tags came to the
            // top of the list and get only as much as needed.
            if ($user->interestTags->count()) {
                $androidLinks = $androidLinks->sortByInterestTagsMatched($user)->take($linksPerWidget);
                $iosLinks = $iosLinks->sortByInterestTagsMatched($user)->take($linksPerWidget);
                $websiteLinks = $websiteLinks->sortByInterestTagsMatched($user)->take($linksPerWidget);
            }

            // Creates formatted array of links for bulk insert.
            if ($androidAppsWidgetId) {
                $androidLinksToCreate = $this->getLinksArrayForWidget($androidLinks, $androidAppsWidgetId);
            } else {
                $androidLinksToCreate = [];
            }

            if ($iosAppsWidgetId) {
                $iosLinksToCreate = $this->getLinksArrayForWidget($iosLinks, $iosAppsWidgetId);
            } else {
                $iosLinksToCreate = [];
            }

            if ($websitesWidgetId) {
                $websiteLinksToCreate = $this->getLinksArrayForWidget($websiteLinks, $websitesWidgetId);
            } else {
                $websiteLinksToCreate = [];
            }

            $links = array_merge($androidLinksToCreate, $iosLinksToCreate, $websiteLinksToCreate);
            $linksToCreate = array_merge($links, $linksToCreate);
        }

        try {
            $this->linkModel->insert($linksToCreate);
        } catch (QueryException $e) {
            Log::error($e);

            return false;
        }
    }

    /**
     * Create links array for a widget.
     *
     * @param Collection $links    Links collection.
     * @param int        $widgetId ID of a widget.
     *
     * @return array
     */
    protected function getLinksArrayForWidget(Collection $links, $widgetId)
    {
        $linksToCreate = [];
        $sort = 1;

        foreach ($links as $link) {
            $linksToCreate[] = [
                'widget_id' => $widgetId,
                'title' => $link->title,
                'url' => $link->url,
                'description' => $link->description,
                'image_main_original' => $link->image_main_original,
                'image_main_favicon' => $link->image_main_favicon,
                'image_main_app_logo' => $link->image_main_app_logo,
                'sort' => $sort++,
            ];
        }

        return $linksToCreate;
    }

    /**
     * Creates home dashboard widget links
     *
     * @param  User       $user                User instance.
     * @param  Collection $allWebisteLinks     List of all website links.
     * @param  Collection $allAppLinks         List of all apps links.
     * @param  int        $androidAppsWidgetId Android apps widget ID.
     * @param  int        $iosAppsWidgetId     iOS apps widget ID.
     * @param  int        $websitesWidgetId    Website widgets ID.
     * @param  int        $linksPerWidget      Links per widget.
     *
     * @return array
     */
    protected function getHomeDashboardLinks(
        User $user,
        Collection $allWebisteLinks,
        Collection $allAppLinks,
        $androidAppsWidgetId,
        $iosAppsWidgetId,
        $websitesWidgetId,
        $linksPerWidget
    ) {
        $androidLinks = $allAppLinks
            ->where('platform', SuggestedLink::PLATFORM_ANDROID)
            ->sortByInterestTagsMatched($user)
            ->take($linksPerWidget);

        $iosLinks = $allAppLinks
            ->where('platform', SuggestedLink::PLATFORM_IOS)
            ->sortByInterestTagsMatched($user)
            ->take($linksPerWidget);

        $websiteLinks = $allWebisteLinks
            ->sortByInterestTagsMatched($user)
            ->take($linksPerWidget);

        // Creates formatted array of links for bulk insert.
        if ($androidAppsWidgetId) {
            $androidLinksToCreate = $this->getLinksArrayForWidget($androidLinks, $androidAppsWidgetId);
        } else {
            $androidLinksToCreate = [];
        }

        if ($iosAppsWidgetId) {
            $iosLinksToCreate = $this->getLinksArrayForWidget($iosLinks, $iosAppsWidgetId);
        } else {
            $iosLinksToCreate = [];
        }

        if ($websitesWidgetId) {
            $websiteLinksToCreate = $this->getLinksArrayForWidget($websiteLinks, $websitesWidgetId);
        } else {
            $websiteLinksToCreate = [];
        }

        return array_merge($androidLinksToCreate, $iosLinksToCreate, $websiteLinksToCreate);
    }

    /**
     * Widget links ids.
     *
     * @param array $widgetLinkIds Widget link IDs.
     *
     * @return void
     */
    public function deleteByIds(array $widgetLinkIds)
    {
        $this->linkModel
            ->whereIn('id', $widgetLinkIds)
            ->delete();
    }
}
