<?php

namespace App\Widgets\Link;

use App\Auth\User;
use App\Dashboards\Dashboard;
use App\WidgetCategories\WidgetCategory\Repository as WidgetCategoryRepository;
use App\Widgets\Link;
use App\Widgets\Link\Repository as LinkRepository;
use App\Widgets\Widget;
use App\WidgetTypes\WidgetType\Repository as WidgetTypeRepository;
use Illuminate\Config\Repository as Config;
use Illuminate\Database\Eloquent\Collection;
use Log;

class Manager
{
    /**
     * A Link repository instance.
     *
     * @var LinkRepository
     */
    protected $linkRepository;

    /**
     * Config repository.
     *
     * @var Config
     */
    protected $config;

    /**
     * @param LinkRepository $linkRepository A link repository instance.
     * @param Config         $config         A config repository instance.
     */
    public function __construct(
        LinkRepository $linkRepository,
        Config $config
    ) {
        $this->linkRepository = $linkRepository;
        $this->config = $config;
    }

    /**
     * Suggest links for suggested apps and websites widgets for a passed user.
     *
     * @param User $user User instance.
     *
     * @return User
     */
    public function suggestLinks(User $user)
    {
        $user->load('dashboards.widgets.widgetType', 'dashboards.dashboardCategory.suggestedLinks');

        $configuration = [];

        foreach ($user->dashboards as $dashboard) {
            // We don't want to suggest anything for shared widgets dashboard,
            // only shared widgets there.
            if ($dashboard->is_shared) {
                continue;
            }

            $suggestedAppsWigets = [];
            $suggestedWebsitesWidgets = [];

            // We're pulling widgets with links from each dashboard, there
            // should be 3 widgets per each dashboard (suggested websites,
            // suggested iOs app and suggested android apps).
            $suggestedAndroidAppsWiget = $dashboard->widgets->filter(function (Widget $widget) {
                return $widget->widgetType->key === 'suggestedAndroidApplications';
            })->first();

            $suggestedIosAppsWiget = $dashboard->widgets->filter(function (Widget $widget) {
                return $widget->widgetType->key === 'suggestedIosApplications';
            })->first();

            $suggestedWebsitesWiget = $dashboard->widgets->filter(function (Widget $widget) {
                return $widget->widgetType->key === 'suggestedWebsites';
            })->first();

            $configuration[] = [
                'suggestedIosAppsWiget' => $suggestedIosAppsWiget,
                'suggestedAndroidAppsWiget' => $suggestedAndroidAppsWiget,
                'suggestedWebsitesWiget' => $suggestedWebsitesWiget,
                'dashboardLinks' => $dashboard->dashboardCategory ? $dashboard->dashboardCategory->suggestedLinks : null,
                'homeDashboard' => $dashboard->is_home,
            ];
        }

        $this->linkRepository->suggestLinks($configuration, $user, $this->config->get('suggestedLinks.linksPerWidget'));

        return $user;
    }

    /**
     * Suggest links for a passed dashboard.
     *
     * @param Dashboard $dashboard Dashboard instance.
     * @param User      $user      User instance.
     *
     * @return User
     */
    public function suggestLinksForDashboard(Dashboard $dashboard, User $user)
    {
        $configuration = [];

        $suggestedAppsWigets = [];
        $suggestedWebsitesWidgets = [];

        // We're pulling widgets with links from each dashboard, there
        // should be 3 widgets per each dashboard (suggested websites,
        // suggested iOs app and suggested android apps).
        $suggestedAndroidAppsWiget = $dashboard->widgets->filter(function (Widget $widget) {
            return $widget->widgetType->key === 'suggestedAndroidApplications';
        })->first();

        $suggestedIosAppsWiget = $dashboard->widgets->filter(function (Widget $widget) {
            return $widget->widgetType->key === 'suggestedIosApplications';
        })->first();

        $suggestedWebsitesWiget = $dashboard->widgets->filter(function (Widget $widget) {
            return $widget->widgetType->key === 'suggestedWebsites';
        })->first();

        $configuration[] = [
            'suggestedIosAppsWiget' => $suggestedIosAppsWiget,
            'suggestedAndroidAppsWiget' => $suggestedAndroidAppsWiget,
            'suggestedWebsitesWiget' => $suggestedWebsitesWiget,
            'dashboardLinks' => $dashboard->dashboardCategory ? $dashboard->dashboardCategory->suggestedLinks : null,
            'homeDashboard' => $dashboard->is_home,
        ];

        $this->linkRepository->suggestLinks($configuration, $user, $this->config->get('suggestedLinks.linksPerWidget'));

        return $user;
    }

    /**
     * Removes all suggested links from all user's widgets.
     *
     * @param User $user User instance.
     *
     * @return void
     */
    public function removeSuggestedLinks(User $user)
    {
        $linksIds = [];

        foreach ($user->widgets as $widget) {
            if ($widget->owner()->id === $user->id) {
                if ($widget->widgetType->key === 'suggestedWebsites' ||
                    $widget->widgetType->key === 'suggestedAndroidApplications' ||
                    $widget->widgetType->key === 'suggestedIosApplications'
                ) {
                    $linksIds = array_merge($linksIds, $widget->links->pluck('id')->toArray());
                }
            }
        }

        $this->linkRepository->deleteByIds($linksIds);
    }
}
