<?php

namespace App\Widgets;

use App\Widgets\MyInsightItem\File;
use App\Widgets\MyInsightItem\Link;
use App\Widgets\MyInsightItem\Photo;
use Creitive\Database\Eloquent\Model;
use Creitive\Models\Traits\SortableTrait;

class MyInsightItem extends Model
{
    use SortableTrait;

    /**
     * {@inheritDoc}
     */
    protected $table = 'widget_my_insight_items';

    /**
     * {@inheritDoc}
     */
    protected $visible = [
        'id',
        'subject',
        'description',
        'sort',
        'widget_id',
    ];

    /**
     * {@inheritDoc}
     */
    public $timestamps = false;

    /**
     * Eloquent relationship: my insight item belongs to a widget.
     *
     * @return BelogngsTo
     */
    public function widget()
    {
        return $this->belongsTo(Widget::class);
    }

    /**
     * Eloquent relationship: my insight item may have many links.
     *
     * @return HasMany
     */
    public function files()
    {
        return $this->hasMany(File::class, 'widget_my_insight_item_id');
    }

    /**
     * Eloquent relationship: my insight item may have many photos.
     *
     * @return HasMany
     */
    public function photos()
    {
        return $this->hasMany(Photo::class, 'widget_my_insight_item_id');
    }

    /**
     * Eloquent relationship: my insight item may have many links.
     *
     * @return HasMany
     */
    public function links()
    {
        return $this->hasMany(Link::class, 'widget_my_insight_item_id');
    }
}
