<?php

namespace App\Widgets\Horoscope;

use App\Widgets\Horoscope\Repository as HoroscopeSunsignRepository;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Routing\Router;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerFrontApiRoutes($this->app['router']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers front API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1/horoscope',
            'namespace' => 'App\Widgets\Http\Controllers\Api\V1\Front\Horoscope',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('', 'Controller@getDaily');
        });

        $attributes['prefix'] = 'api/v1';
        $attributes['middleware'] = ['api', 'auth', 'widget.access:edit'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('widgets/{widget}/horoscope-sunsigns', 'Controller@getWidgetSunsigns');
            $router->post('widgets/{widget}/horoscope-sunsigns', 'Controller@syncSunsigns');
        });
    }
}
