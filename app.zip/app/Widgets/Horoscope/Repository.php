<?php

namespace App\Widgets\Horoscope;

use App\Widgets\HoroscopeSunsign;
use App\Widgets\Widget;
use Cartalyst\Sentinel\Sentinel;
use Creitive\Horoscope\Client as HoroscopeApiClient;
use DB;

class Repository
{
    /**
     * A horoscope sunsign model instance.
     *
     * @var HoroscopeSunsign
     */
    protected $horoscopeSunsign;

    /**
     * A horoscope api client instance.
     *
     * @var HoroscopeApiClient
     */
    protected $horoscopeApiClient;

    /**
     * A sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * @param HoroscopeSunsign   $horoscopeSunsign   A horoscope sunsign instance model.
     * @param HoroscopeApiClient $horoscopeApiClient A horoscope api client instance.
     * @param Sentinel           $sentinel           Sentinel instance.
     */
    public function __construct(HoroscopeSunsign $horoscopeSunsign, HoroscopeApiClient $horoscopeApiClient, Sentinel $sentinel)
    {
        $this->horoscopeSunsign = $horoscopeSunsign;
        $this->horoscopeApiClient = $horoscopeApiClient;
        $this->sentinel = $sentinel;
    }

    /**
     * Finds the horoscope sunsign by ID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $id The file ID.
     *
     * @return HoroscopeSunsign|null
     */
    public function find($id)
    {
        return $this->horoscopeSunsign->find($id);
    }

    /**
     * Gets widget sunsigns with belongs property.
     *
     * @param int $widgetId Widget id.
     *
     * @return mixed
     */
    public function getWidgetHoroscopeSunsigns($widgetId)
    {
        return HoroscopeSunsign::select(
            'horoscope_sunsigns.*',
            DB::raw('CASE WHEN COALESCE(widgets_horoscope_sunsigns.id, -1) > -1 THEN true ELSE false END as belongs')
        )
        ->leftJoin('widgets_horoscope_sunsigns', function ($join) use ($widgetId) {
            return $join->on('horoscope_sunsigns.id', '=', 'widgets_horoscope_sunsigns.horoscope_sunsign_id')
                ->where('widgets_horoscope_sunsigns.widget_id', '=', $widgetId);
        })
        ->get()
        ->each(function ($sunsign) {
            $sunsign->makeVisible(['belongs', 'title']);
            $sunsign->title = __('horoscope.titles.' . $sunsign->sunsign);
        });
    }

    /**
     * Sync  widget sunsigns.
     *
     * @param Widget $widget The widget instance.
     * @param array  $signs  Sunsigs array.
     *
     * @return array
     */
    public function syncWidgetSunsights(Widget $widget, array $signs)
    {
        $sunsigns = [];
        $horoscopeSunsignIds = [];

        foreach ($signs as $sign) {
            $sunsigns[] = $sign['sunsign'];
            $horoscopeSunsignIds[] = $sign['id'];
        }

        $widget->horoscopeSunsigns()->sync($horoscopeSunsignIds);

        return $this->fetchHoroscope($sunsigns);
    }

    /**
     * Fetch horoscope from API.
     *
     * @param array $sunsigns The sunsigns array.
     *
     * @return array
     */
    public function fetchHoroscope(array $sunsigns = [])
    {
        $dailyHoroscope = $this->horoscopeApiClient->dailyHoroscope();
        $horoscope = [];

        foreach ($sunsigns as $sunsign) {
            $sunsignHoroscope = [];
            $sunsignHoroscope['sunsign'] = $sunsign;
            $sunsignHoroscope['horoscope'] = $dailyHoroscope->$sunsign;
            $horoscope[] = $sunsignHoroscope;
        }

        return $horoscope;
    }
}
