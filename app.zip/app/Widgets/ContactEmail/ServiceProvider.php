<?php

namespace App\Widgets\ContactEmail;

use App\Widgets\ContactEmail\Repository as WidgetContactEmailRepository;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Routing\Router;
use URL;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerRoutePatterns($this->app['router'], $this->app);
        $this->registerFrontApiRoutes($this->app['router']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers the route patterns.
     *
     * @param Router    $router    A router.
     * @param Container $container A dependency container.
     *
     * @return void
     */
    protected function registerRoutePatterns(Router $router, Container $container)
    {
        $idRegex = $this->routePatternRegexes['id'];
        $slugRegex = $this->routePatternRegexes['slug'];

        $router->pattern('widgetContactEmail', $idRegex);

        $router->bind('widgetContactEmail', function ($value) use ($container, $idRegex) {
            $widgetContactEmailRepository = $container->make(WidgetContactEmailRepository::class);

            if (preg_match("/^{$idRegex}$/D", $value)) {
                $widgetContactEmail = $widgetContactEmailRepository->find($value);

                if ($widgetContactEmail !== null) {
                    return $widgetContactEmail;
                }
            }
        });
    }

    /**
     * Registers front API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1',
            'middleware' => ['api', 'auth'],
            'namespace' => 'App\Widgets\Http\Controllers\Api\V1\Front\ContactEmail',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->put('widget-contact-emails/sort', 'Controller@sort');
        });

        $attributes['middleware'] = ['api', 'auth', 'widgetContactEmail.access'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->delete('widget-contact-emails/{widgetContactEmail}', 'Controller@delete');
            $router->put('widget-contact-emails/{widgetContactEmail}', 'Controller@update');
        });

        $attributes['middleware'] = ['api', 'auth', 'widgetContact.access'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('widget-contacts/{widgetContact}/emails', 'Controller@index');
            $router->post('widget-contacts/{widgetContact}/emails', 'Controller@store');
        });
    }
}
