<?php

namespace App\Widgets\ContactEmail;

use App\Widgets\ContactEmail;

class Repository
{
    /**
     * A ContactEmail model instance.
     *
     * @var ContactEmail
     */
    protected $contactEmail;

    /**
     * @param ContactEmail $contactEmail A contact email model instance.
     */
    public function __construct(ContactEmail $contactEmail)
    {
        $this->contactEmailModel = $contactEmail;
    }

    /**
     * Gets all contact emails.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAll()
    {
        $query = $this->contactEmailModel->select('*');

        return $query->get();
    }

    /**
     * Finds the contact email by ID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $id The checklistItem ID.
     *
     * @return ContactEmail|null
     */
    public function find($id)
    {
        return $this->contactEmailModel->find($id);
    }

    /**
     * Finds widget contact emails by ids.
     *
     * @param array $ids The contact email IDs.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getByIds(array $ids)
    {
        return $this->contactEmailModel
            ->whereIn('id', $ids)
            ->get();
    }

    /**
     * Finds the contact email by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The contact email ID.
     *
     * @return ContactEmail
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->contactEmailModel->findOrFail($id);
    }

    /**
     * Updates the passed checklistItem and returns it.
     *
     * @param ContactEmail $contactEmail The contact email to update.
     * @param array        $inputData    The input data for the update.
     *
     * @return ContactEmail
     */
    public function update(ContactEmail $contactEmail, array $inputData)
    {
        return $this->populateAndSave($contactEmail, $inputData);
    }

    /**
     * Creates a contact email and returns it.
     *
     * @param array $inputData The input data for the update.
     *
     * @return ContactEmail
     */
    public function create(array $inputData)
    {
        $contactEmail = $this->contactEmailModel->newInstance();

        return $this->populateAndSave($contactEmail, $inputData);
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param ContactEmail $contactEmail The contact email to populate.
     * @param array        $inputData    The input data for the contact email.
     *
     * @return ContactEmail
     */
    protected function populate(ContactEmail $contactEmail, array $inputData)
    {
        $contactEmail->email = array_get($inputData, 'email', $contactEmail->email);
        $contactEmail->widget_contact_id = array_get($inputData, 'widget_contact_id', $contactEmail->widget_contact_id);

        return $contactEmail;
    }

    /**
     * Deletes a contactEmail.
     *
     * @param ContactEmail $contactEmail The contact email instance.
     *
     * @return Void
     */
    public function delete(ContactEmail $contactEmail)
    {
        $contactEmail->delete();
    }

    /**
     * Sorts contact emails in the passed order.
     *
     * @param array $inputData The new sort order.
     *
     * @return bool
     */
    public function sort(array $inputData)
    {
        $newOrder = array_map(
            function ($item) {
                return (int) $item['id'];
            },
            $inputData['items']
        );

        return $this->contactEmailModel->updateSortOrder($newOrder);
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param ContactEmail $contactEmail The contact email to populate and save.
     * @param array        $inputData    The input data.
     *
     * @return ContactEmail
     */
    protected function populateAndSave(ContactEmail $contactEmail, array $inputData)
    {
        $contactEmail = $this->populate($contactEmail, $inputData);

        $contactEmail->save();

        return $contactEmail;
    }
}
