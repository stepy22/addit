<?php

namespace App\Widgets;

use App\Widgets\Widget;
use Creitive\Database\Eloquent\Model;

class SocialBookmark extends Model
{
    /**
     * {@inheritDoc}
     */
    public $timestamps = false;

    /**
     * {@inheritDoc}
     */
    protected $table = 'widget_social_bookmarks';

    /*
     * Social media platforms.
     */
    public const PLATFORM_FACEBOOK = 'facebook';
    public const PLATFORM_LINKEDIN = 'linkedin';
    public const PLATFORM_INSTAGRAM = 'instagram';
    public const PLATFORM_TWITTER = 'twitter';

    /**
     * {@inheritDoc}
     */
    protected $visible = [
        'id',
        'platform',
        'user_id',
    ];

    /**
     * Eloquent relationship: social bookmark belongs to a widget.
     *
     * @return BelogngsTo
     */
    public function widget()
    {
        return $this->belongsTo(Widget::class);
    }
}
