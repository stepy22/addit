<?php

namespace App\Widgets\ContactAddress;

use App\Widgets\ContactAddress\Repository as WidgetContactAddressRepository;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Routing\Router;
use URL;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerRoutePatterns($this->app['router'], $this->app);
        $this->registerFrontApiRoutes($this->app['router']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers the route patterns.
     *
     * @param Router    $router    A router.
     * @param Container $container A dependency container.
     *
     * @return void
     */
    protected function registerRoutePatterns(Router $router, Container $container)
    {
        $idRegex = $this->routePatternRegexes['id'];
        $slugRegex = $this->routePatternRegexes['slug'];

        $router->pattern('widgetContactAddress', $idRegex);

        $router->bind('widgetContactAddress', function ($value) use ($container, $idRegex) {
            $widgetContactAddressRepository = $container->make(WidgetContactAddressRepository::class);

            if (preg_match("/^{$idRegex}$/D", $value)) {
                $widgetContactAddress = $widgetContactAddressRepository->find($value);

                if ($widgetContactAddress !== null) {
                    return $widgetContactAddress;
                }
            }
        });
    }

    /**
     * Registers front API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1',
            'middleware' => ['api', 'auth'],
            'namespace' => 'App\Widgets\Http\Controllers\Api\V1\Front\ContactAddress',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->put('widget-contact-addresses/sort', 'Controller@sort');
        });

        $attributes['middleware'] = ['api', 'auth', 'widgetContactAddress.access'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->delete('widget-contact-addresses/{widgetContactAddress}', 'Controller@delete');
            $router->put('widget-contact-addresses/{widgetContactAddress}', 'Controller@update');
        });

        $attributes['middleware'] = ['api', 'auth', 'widgetContact.access'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('widget-contacts/{widgetContact}/addresses', 'Controller@index');
            $router->post('widget-contacts/{widgetContact}/addresses', 'Controller@store');
        });
    }
}
