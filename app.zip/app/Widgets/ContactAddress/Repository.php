<?php

namespace App\Widgets\ContactAddress;

use App\Widgets\ContactAddress;

class Repository
{
    /**
     * A ContactAddress model instance.
     *
     * @var ContactAddress
     */
    protected $contactAddress;

    /**
     * @param ContactAddress $contactAddress A contact address model instance.
     */
    public function __construct(ContactAddress $contactAddress)
    {
        $this->contactAddressModel = $contactAddress;
    }

    /**
     * Gets all contact addresses.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAll()
    {
        $query = $this->contactAddressModel->select('*');

        return $query->get();
    }

    /**
     * Finds the contact address by ID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $id The contactAddress ID.
     *
     * @return ContactAddress|null
     */
    public function find($id)
    {
        return $this->contactAddressModel->find($id);
    }

    /**
     * Finds widget contact addresses by ids.
     *
     * @param array $ids The contact address IDs.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getByIds(array $ids)
    {
        return $this->contactAddressModel
            ->whereIn('id', $ids)
            ->get();
    }

    /**
     * Finds the contact address by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The contact address ID.
     *
     * @return ContactAddress
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->contactAddressModel->findOrFail($id);
    }

    /**
     * Updates the passed contactAddress and returns it.
     *
     * @param ContactAddress $contactAddress The contact address to update.
     * @param array          $inputData      The input data for the update.
     *
     * @return ContactAddress
     */
    public function update(ContactAddress $contactAddress, array $inputData)
    {
        return $this->populateAndSave($contactAddress, $inputData);
    }

    /**
     * Creates a conatct address and returns it.
     *
     * @param array $inputData The input data for the update.
     *
     * @return ContactAddress
     */
    public function create(array $inputData)
    {
        $contactAddress = $this->contactAddressModel->newInstance();

        return $this->populateAndSave($contactAddress, $inputData);
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param ContactAddress $contactAddress The aontact address to populate.
     * @param array          $inputData      The input data for the checklist item.
     *
     * @return ContactAddress
     */
    protected function populate(ContactAddress $contactAddress, array $inputData)
    {
        $contactAddress->address = array_get($inputData, 'address', $contactAddress->title);
        $contactAddress->widget_contact_id = array_get($inputData, 'widget_contact_id', $contactAddress->widget_contact_id);

        return $contactAddress;
    }

    /**
     * Deletes a contactAddress.
     *
     * @param ContactAddress $contactAddress The contact address instance.
     *
     * @return Void
     */
    public function delete(ContactAddress $contactAddress)
    {
        $contactAddress->delete();
    }

    /**
     * Sorts contact address in the passed order.
     *
     * @param array $inputData The new sort order.
     *
     * @return bool
     */
    public function sort(array $inputData)
    {
        $newOrder = array_map(
            function ($item) {
                return (int) $item['id'];
            },
            $inputData['items']
        );

        return $this->contactAddressModel->updateSortOrder($newOrder);
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param ContactAddress $contactAddress The contact address to populate and save.
     * @param array          $inputData      The input data.
     *
     * @return ContactAddress
     */
    protected function populateAndSave(ContactAddress $contactAddress, array $inputData)
    {
        $contactAddress = $this->populate($contactAddress, $inputData);

        $contactAddress->save();

        return $contactAddress;
    }
}
