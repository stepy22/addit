<?php

namespace App\Widgets\SchoolScheduleItem;

use App\Auth\User;
use App\Widgets\SchoolScheduleItem;
use Carbon\Carbon;

class Repository
{
    /**
     * A school schedule item model instance.
     *
     * @var SchoolScheduleItem
     */
    protected $schoolScheduleItem;

    /**
     * @param SchoolScheduleItem $schoolScheduleItem A school schedule item model instance.
     */
    public function __construct(SchoolScheduleItem $schoolScheduleItem)
    {
        $this->schoolScheduleItemModel = $schoolScheduleItem;
    }

    /**
     * Finds the school schedule item by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The school schedule item ID.
     *
     * @return SchoolScheduleItem
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->schoolScheduleItemModel->findOrFail($id);
    }

    /**
     * Updates the passed school schedule item and returns it.
     *
     * @param SchoolScheduleItem $schoolScheduleItem The school schedule item to update.
     * @param array              $inputData          The input data for the update.
     *
     * @return SchoolScheduleItem
     */
    public function update(SchoolScheduleItem $schoolScheduleItem, array $inputData)
    {
        return $this->populateAndSave($schoolScheduleItem, $inputData);
    }

    /**
     * Creates a school schedule item and returns it.
     *
     * @param array $inputData The input data for the update.
     *
     * @return SchoolScheduleItem
     */
    public function create(array $inputData)
    {
        $schoolScheduleItem = $this->schoolScheduleItemModel->newInstance();

        return $this->populateAndSave($schoolScheduleItem, $inputData);
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param SchoolScheduleItem $schoolScheduleItem The schoolScheduleItem to populate.
     * @param array              $inputData          The input data for the schoolScheduleItem.
     *
     * @return SchoolScheduleItem
     */
    protected function populate(SchoolScheduleItem $schoolScheduleItem, array $inputData)
    {
        $schoolScheduleItem->day = array_get($inputData, 'day', $schoolScheduleItem->day);
        $schoolScheduleItem->class_name = array_get($inputData, 'class_name', $schoolScheduleItem->class_name);
        $schoolScheduleItem->widget_id = array_get($inputData, 'widget_id', $schoolScheduleItem->widget_id);

        if ($inputData['starts_at']) {
            $schoolScheduleItem->starts_at = Carbon::createFromFormat(trans('common.timeFormat'), $inputData['starts_at']);
        }

        if ($inputData['ends_at']) {
            $schoolScheduleItem->ends_at = Carbon::createFromFormat(trans('common.timeFormat'), $inputData['ends_at']);
        }

        return $schoolScheduleItem;
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param SchoolScheduleItem $schoolScheduleItem The school schedule item to populate and save.
     * @param array              $inputData          The input data.
     *
     * @return SchoolScheduleItem
     */
    protected function populateAndSave(SchoolScheduleItem $schoolScheduleItem, array $inputData)
    {
        $schoolScheduleItem = $this->populate($schoolScheduleItem, $inputData);

        $schoolScheduleItem->save();

        return $schoolScheduleItem;
    }

    /**
     * Deletes a school schedule item and returns it.
     *
     * @param SchoolScheduleItem $schoolScheduleItem The school schedule item instance.
     *
     * @return void
     */
    public function delete(SchoolScheduleItem $schoolScheduleItem)
    {
        $schoolScheduleItem->delete();
    }
}
