<?php

namespace App\Widgets\SchoolScheduleItem;

use App\Widgets\SchoolScheduleItem\Repository as WidgetSchoolScheduleItemRepository;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Routing\Router;
use URL;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerRoutePatterns($this->app['router'], $this->app);
        $this->registerFrontApiRoutes($this->app['router']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers the route patterns.
     *
     * @param Router    $router    A router.
     * @param Container $container A dependency container.
     *
     * @return void
     */
    protected function registerRoutePatterns(Router $router, Container $container)
    {
        $idRegex = $this->routePatternRegexes['id'];
        $slugRegex = $this->routePatternRegexes['slug'];

        $router->pattern('widgetSchoolScheduleItem', $idRegex);

        $router->bind('widgetSchoolScheduleItem', function ($value) use ($container, $idRegex) {
            $widgetSchoolScheduleItemRepository = $container->make(WidgetSchoolScheduleItemRepository::class);

            if (preg_match("/^{$idRegex}$/D", $value)) {
                $widgetSchoolScheduleItem = $widgetSchoolScheduleItemRepository->findOrFail($value);

                if ($widgetSchoolScheduleItem !== null) {
                    return $widgetSchoolScheduleItem;
                }
            }
        });
    }

    /**
     * Registers front API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1',
            'namespace' => 'App\Widgets\Http\Controllers\Api\V1\Front\SchoolScheduleItem',
        ];

        $attributes['middleware'] = ['api'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('school-schedule-items/days', 'Controller@days');
        });

        $attributes['middleware'] = ['api', 'auth', 'widgetSchoolScheduleItem.access'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->put('school-schedule-items/{widgetSchoolScheduleItem}', 'Controller@update');
            $router->delete('school-schedule-items/{widgetSchoolScheduleItem}', 'Controller@delete');
        });

        $attributes['middleware'] = ['api', 'auth', 'widget.access:edit'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->post('widgets/{widget}/school-schedule-items', 'Controller@store');
        });
    }
}
