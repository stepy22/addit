<?php

namespace App\Widgets;

use App\Auth\User;
use App\Dashboards\Dashboard;
use App\Widgets\Widget;
use Creitive\Database\Eloquent\Model;
use Creitive\Models\Traits\SortableTrait;

class UserWidget extends Model
{
    use SortableTrait;

    /**
     * {@inheritDoc}
     */
    protected $casts = [
        'pinned_to_home' => 'bool',
        'is_owner' => 'bool',
        'can_edit' => 'bool',
    ];

    /**
     * {@inheritDoc}
     */
    public $timestamps = false;

    /**
     * Eloquent relationship: user widget belong to a users.
     *
     * @return BelongsTo
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Eloquent relationship: user widget belong to a widget.
     *
     * @return BelongsTo
     */
    public function widget()
    {
        return $this->belongsTo(Widget::class);
    }

    /**
     * Eloquent relationship: user widget belong to a dashboard.
     *
     * @return BelongsTo
     */
    public function dashboard()
    {
        return $this->belongsTo(Dashboard::class);
    }
}
