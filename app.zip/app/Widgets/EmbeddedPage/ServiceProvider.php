<?php

namespace App\Widgets\EmbeddedPage;

use App\Widgets\EmbeddedPage\Repository as WidgetEmbeddedPageRepository;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Routing\Router;
use URL;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerRoutePatterns($this->app['router'], $this->app);
        $this->registerFrontApiRoutes($this->app['router']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers the route patterns.
     *
     * @param Router    $router    A router.
     * @param Container $container A dependency container.
     *
     * @return void
     */
    protected function registerRoutePatterns(Router $router, Container $container)
    {
        $idRegex = $this->routePatternRegexes['id'];
        $slugRegex = $this->routePatternRegexes['slug'];

        $router->pattern('widgetEmbeddedPage', $idRegex);

        $router->bind('widgetEmbeddedPage', function ($value) use ($container, $idRegex) {
            $widgetEmbeddedPageRepository = $container->make(WidgetEmbeddedPageRepository::class);

            if (preg_match("/^{$idRegex}$/D", $value)) {
                $widgetEmbeddedPage = $widgetEmbeddedPageRepository->findOrFail($value);

                if ($widgetEmbeddedPage !== null) {
                    return $widgetEmbeddedPage;
                }
            }
        });
    }

    /**
     * Registers front API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1',
            'namespace' => 'App\Widgets\Http\Controllers\Api\V1\Front\EmbeddedPage',
        ];

        $attributes['middleware'] = ['api', 'auth', 'widgetEmbeddedPage.access'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->put('widget-embedded-pages/{widgetEmbeddedPage}', 'Controller@update');
        });

        $attributes['middleware'] = ['api', 'auth', 'widget.access:edit'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->post('widgets/{widget}/embedded-page', 'Controller@store');
        });
    }
}
