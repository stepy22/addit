<?php

namespace App\Widgets\EmbeddedPage;

use App\Auth\User;
use App\Widgets\EmbeddedPage;

class Repository
{
    /**
     * A embedded page model instance.
     *
     * @var EmbeddedPage
     */
    protected $embeddedPage;

    /**
     * @param EmbeddedPage $embeddedPage A youtube video model instance.
     */
    public function __construct(EmbeddedPage $embeddedPage)
    {
        $this->embeddedPageModel = $embeddedPage;
    }

    /**
     * Finds the youtube video by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The youtube video ID.
     *
     * @return EmbeddedPage
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->embeddedPageModel->findOrFail($id);
    }

    /**
     * Updates the passed youtube video and returns it.
     *
     * @param EmbeddedPage $embeddedPage The youtube video to update.
     * @param array        $inputData    The input data for the update.
     *
     * @return EmbeddedPage
     */
    public function update(EmbeddedPage $embeddedPage, array $inputData)
    {
        return $this->populateAndSave($embeddedPage, $inputData);
    }

    /**
     * Creates a youtube video and returns it.
     *
     * @param array $inputData The input data for the update.
     *
     * @return EmbeddedPage
     */
    public function create(array $inputData)
    {
        $embeddedPage = $this->embeddedPageModel->newInstance();

        return $this->populateAndSave($embeddedPage, $inputData);
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param EmbeddedPage $embeddedPage The embeddedPage to populate.
     * @param array        $inputData    The input data for the embeddedPage.
     *
     * @return EmbeddedPage
     */
    protected function populate(EmbeddedPage $embeddedPage, array $inputData)
    {
        $embeddedPage->url = array_get($inputData, 'url', $embeddedPage->url);
        $embeddedPage->widget_id = array_get($inputData, 'widget_id', $embeddedPage->widget_id);

        return $embeddedPage;
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param EmbeddedPage $embeddedPage The youtube video to populate and save.
     * @param array        $inputData    The input data.
     *
     * @return EmbeddedPage
     */
    protected function populateAndSave(EmbeddedPage $embeddedPage, array $inputData)
    {
        $embeddedPage = $this->populate($embeddedPage, $inputData);

        $embeddedPage->save();

        return $embeddedPage;
    }
}
