<?php

namespace App\Widgets;

use App\Widgets\Widget;
use Creitive\Database\Eloquent\Model;
use Creitive\Image\Transformers\Thumbnail;
use Creitive\Models\Traits\ImageableTrait;
use Creitive\Models\Traits\SortableTrait;
use URL;

class Event extends Model
{
    use ImageableTrait;
    use SortableTrait;

    /**
     * {@inheritDoc}
     */
    protected $table = 'widget_events';

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = ['starts_at', 'ends_at', 'notify_at'];

    /**
     * {@inheritDoc}
     */
    protected $visible = [
        'id',
        'title',
        'description',
        'starts_at',
        'ends_at',
        'notify_me',
        'notify_at',
        'url_image_main_original',
        'url_image_main_small',
        'url_image_main_thumbnail',
        'url_image_main_large',
        'widget_id',
        'sort',
    ];

    /**
     * {@inheritDoc}
     */
    protected $appends = [
        'url_image_main_original',
        'url_image_main_small',
        'url_image_main_thumbnail',
        'url_image_main_large',
    ];

    /**
     * {@inheritDoc}
     */
    public function getImageConfiguration()
    {
        return [
            'versions' => [
                'main' => [
                    'original' => [],
                    'small' => [
                        [
                            'transformer' => Thumbnail::class,
                            'width' => 100,
                            'height' => 75,
                        ],
                    ],
                    'thumbnail' => [
                        [
                            'transformer' => Thumbnail::class,
                            'width' => 600,
                            'height' => 450,
                        ],
                    ],
                    'large' => [
                        [
                            'transformer' => Thumbnail::class,
                            'width' => 1200,
                            'height' => 875,
                        ],
                    ],
                ],
            ],
        ];
    }

    /**
     * Eloquent relationship: event belongs to a widget.
     *
     * @return BelogngsTo
     */
    public function widget()
    {
        return $this->belongsTo(Widget::class);
    }

    /**
     * Gets the complete URL to the original main image.
     *
     * @return string
     */
    public function getUrlImageMainOriginalAttribute()
    {
        return URL::to($this->getImage('main', 'original'));
    }

    /**
     * Gets the complete URL to the small main image.
     *
     * @return string
     */
    public function getUrlImageMainSmallAttribute()
    {
        return URL::to($this->getImage('main', 'small'));
    }

    /**
     * Gets the complete URL to the thumbnail main image.
     *
     * @return string
     */
    public function getUrlImageMainThumbnailAttribute()
    {
        return URL::to($this->getImage('main', 'thumbnail'));
    }

    /**
     * Gets the complete URL to the large main image.
     *
     * @return string
     */
    public function getUrlImageMainLargeAttribute()
    {
        return URL::to($this->getImage('main', 'large'));
    }
}
