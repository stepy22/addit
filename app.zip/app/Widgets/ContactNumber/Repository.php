<?php

namespace App\Widgets\ContactNumber;

use App\Widgets\ContactNumber;

class Repository
{
    /**
     * A ContactNumber model instance.
     *
     * @var ContactNumber
     */
    protected $contactNumber;

    /**
     * @param ContactNumber $contactNumber A contact number model instance.
     */
    public function __construct(ContactNumber $contactNumber)
    {
        $this->contactNumberModel = $contactNumber;
    }

    /**
     * Gets all contact numbers.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAll()
    {
        $query = $this->contactNumberModel->select('*');

        return $query->get();
    }

    /**
     * Finds the contact number by ID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $id The contactNumber ID.
     *
     * @return ContactNumber|null
     */
    public function find($id)
    {
        return $this->contactNumberModel->find($id);
    }

    /**
     * Finds widget contact numbers by ids.
     *
     * @param array $ids The contact number IDs.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getByIds(array $ids)
    {
        return $this->contactNumberModel
            ->whereIn('id', $ids)
            ->get();
    }

    /**
     * Finds the contact number by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The contact number ID.
     *
     * @return ContactNumber
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->contactNumberModel->findOrFail($id);
    }

    /**
     * Updates the passed contactNumber and returns it.
     *
     * @param ContactNumber $contactNumber The contact number to update.
     * @param array         $inputData     The input data for the update.
     *
     * @return ContactNumber
     */
    public function update(ContactNumber $contactNumber, array $inputData)
    {
        return $this->populateAndSave($contactNumber, $inputData);
    }

    /**
     * Creates a contact number and returns it.
     *
     * @param array $inputData The input data for the update.
     *
     * @return ContactNumber
     */
    public function create(array $inputData)
    {
        $contactNumber = $this->contactNumberModel->newInstance();

        return $this->populateAndSave($contactNumber, $inputData);
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param ContactNumber $contactNumber The contact number to populate.
     * @param array        $inputData    The input data for the contact number.
     *
     * @return ContactNumber
     */
    protected function populate(ContactNumber $contactNumber, array $inputData)
    {
        $contactNumber->number = array_get($inputData, 'number', $contactNumber->number);
        $contactNumber->widget_contact_id = array_get($inputData, 'widget_contact_id', $contactNumber->widget_contact_id);

        return $contactNumber;
    }

    /**
     * Deletes a contactNumber.
     *
     * @param ContactNumber $contactNumber The contact number instance.
     *
     * @return Void
     */
    public function delete(ContactNumber $contactNumber)
    {
        $contactNumber->delete();
    }

    /**
     * Sorts contact numbers in the passed order.
     *
     * @param array $inputData The new sort order.
     *
     * @return bool
     */
    public function sort(array $inputData)
    {
        $newOrder = array_map(
            function ($item) {
                return (int) $item['id'];
            },
            $inputData['items']
        );

        return $this->contactNumberModel->updateSortOrder($newOrder);
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param ContactNumber $contactNumber The contact number to populate and save.
     * @param array         $inputData     The input data.
     *
     * @return ContactNumber
     */
    protected function populateAndSave(ContactNumber $contactNumber, array $inputData)
    {
        $contactNumber = $this->populate($contactNumber, $inputData);

        $contactNumber->save();

        return $contactNumber;
    }
}
