<?php

namespace App\Widgets\UserWidget;

use App\Auth\User;
use App\Widgets\Widget;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;

class ValidationService
{
    /**
     * Checks if widget can be shared with a user.
     *
     * @param Widget $widget Widget instance.
     * @param string $email  Email instance.
     * @param mixed  $user   User instance.
     *
     * @throws BadRequestHttpException
     *
     * @return void
     */
    public function validateStore(Widget $widget, $email, $user = null)
    {
        if (!$user) {
            // Check if email is already invited.
            if ($widget->userWidgets->where('email', $email)->count() > 0) {
                throw new BadRequestHttpException('You have already shared this widget with a given email.');
            }
        } else {
            // Check if widget is already shared with a user.
            if ($widget->users->where('id', $user->id)->count() > 0) {
                throw new BadRequestHttpException('You have already shared this widget with a given user.');
            }

            if (!$user->profile_completed) {
                throw new BadRequestHttpException('User you\'re trying to share with still hasn\'t completed their profile.');
            }
        }
    }
}
