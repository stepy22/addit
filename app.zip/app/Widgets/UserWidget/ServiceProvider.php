<?php

namespace App\Widgets\UserWidget;

use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use URL;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerFrontApiRoutes($this->app['router']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers front API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1/widgets',
            'middleware' => ['api', 'auth'],
            'namespace' => 'App\Widgets\Http\Controllers\Api\V1\Front\UserWidget',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->delete('users/{userWidget}', 'Controller@delete');
        });

        $attributes['middleware'][] = 'widget.ownership';

        $router->group($attributes, function (RegistrarContract $router) {
            $router->put('users/{userWidget}', 'Controller@update');
            $router->get('{widget}/users', 'Controller@index');
            $router->post('{widget}/users', 'Controller@store');
        });
    }
}
