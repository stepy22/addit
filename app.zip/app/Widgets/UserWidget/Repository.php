<?php

namespace App\Widgets\UserWidget;

use App\Dashboards\UserDashboard;
use App\Widgets\UserWidget;
use App\Widgets\Widget;
use Carbon\Carbon;

class Repository
{
    /**
     * A UserWidget model instance.
     *
     * @var UserWidget
     */
    protected $userWidget;

    /**
     * @param UserWidget $userWidget A widget model instance.
     */
    public function __construct(UserWidget $userWidget)
    {
        $this->userWidgetModel = $userWidget;
    }

    /**
     * Gets all widgets.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAll()
    {
        return $this->userWidgetModel->sorted()->get();
    }

    /**
     * Finds the user widget by ID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $id The user widget ID.
     *
     * @return UserWidget|null
     */
    public function find($id)
    {
        return $this->userWidgetModel->find($id);
    }

    /**
     * Finds the user widget by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The user widget ID.
     *
     * @return UserWidget
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->userWidgetModel->findOrFail($id);
    }

    /**
     * Creates widget invitation.
     *
     * @param  Widget $widget Widget instance.
     * @param  string $email  Email to which to assign invitation.
     *
     * @return UserWidget
     */
    public function createWidgetInvitation(Widget $widget, $email)
    {
        $userWidget = $this->userWidgetModel->newInstance();

        $userWidget->widget_id = $widget->id;
        $userWidget->can_edit = false;
        $userWidget->is_owner = false;
        $userWidget->email = $email;

        $userWidget->save();

        return $userWidget;
    }

    /**
     * Gets invitations for passed email.
     *
     * @param string $email Email.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getInvitations($email)
    {
        return $this->userWidgetModel
            ->where('email', $email)
            ->whereNull('user_id')
            ->get();
    }

    /**
     * Deletes the passed widget from the system.
     *
     * @param UserWidget $userWidget The user widget to delete.
     *
     * @return bool|null
     */
    public function delete(UserWidget $userWidget)
    {
        $userWidget->load('widget', 'user.userWidgets');
        $widget = $userWidget->widget;

        if (!$userWidget->user) {
            return $userWidget->delete();
        }

        // If pinned version is unsubscribed find original and unsubscribe too.
        if ($userWidget->pinned_to_home) {
            $originalUserWidget = $userWidget->user->userWidgets->filter(function (UserWidget $userWidget) use ($widget) {
                return $widget->id === $userWidget->widget_id && !$userWidget->pinned_to_home;
            })->first();

            if ($originalUserWidget) {
                $originalUserWidget->delete();
            }
        } else {
            $pinnedVersion = $userWidget->user->userWidgets->filter(function (UserWidget $userWidget) use ($widget) {
                return $userWidget->pinned_to_home === true && $userWidget->widget_id === $widget->id;
            })->first();

            if ($pinnedVersion) {
                $pinnedVersion->delete();
            }
        }

        // If shared widget is added to favourites, remove it when unsubscribed.
        if ($userWidget->user->favouriteWidgets->where('id', $userWidget->widget_id)->count() > 0) {
            $userWidget->user->favouriteWidgets()->detach($userWidget->widget_id);
        }

        return $userWidget->delete();
    }

    /**
     * Deletes the passed pinned widget from the system.
     *
     * Different function then delete is used since when widget is deleted
     * system checks if there is a pinned version and it deletes an original
     * widget too, we don't want that here.
     *
     * @param UserWidget $userWidget The user widget to delete.
     *
     * @return bool|null
     */
    public function deletePinned(UserWidget $userWidget)
    {
        return $userWidget->delete();
    }

    /**
     * Archives a user widget.
     *
     * @param UserWidget $userWidget The user widget to archive.
     *
     * @return UserWidget
     */
    public function archive(UserWidget $userWidget)
    {
        $userWidget->archived_at = Carbon::now();
        $userWidget->save();

        return $userWidget;
    }

    /**
     * Unarchives a user widget.
     *
     * @param UserWidget $userWidget The user widget to unarchive.
     *
     * @return UserWidget
     */
    public function unarchive(UserWidget $userWidget)
    {
        $userWidget->archived_at = null;
        $userWidget->save();

        return $userWidget;
    }

    /**
     * Bach unarchives a user widget.
     *
     * @param array $userWidgetIds The user widget ids to unarchive.
     *
     * @return void
     */
    public function batchUnarchive(array $userWidgetIds)
    {
        $this->userWidgetModel
            ->whereIn('id', $userWidgetIds)
            ->update(['archived_at' => null]);
    }

    /**
     * Moves a widget to another dashboard.
     *
     * @param UserWidget $userWidget  The user widget to archive.
     * @param int        $dashboardId Dashboard ID.
     *
     * @return UserWidget
     */
    public function move(UserWidget $userWidget, $dashboardId)
    {
        $userWidget->dashboard_id = $dashboardId;
        $userWidget->save();

        return $userWidget;
    }

    /**
     * Change permissions.
     *
     * @param UserWidget $userWidget The user widget to change permissions for..
     * @param bool       $canEdit    Flag that indicates user's permission level on widget.
     *
     * @return UserWidget
     */
    public function changePermissions(UserWidget $userWidget, $canEdit)
    {
        $userWidget->can_edit = $canEdit;
        $userWidget->save();

        return $userWidget;
    }

    /**
     * Bulk change permissions for passed user widgets.
     *
     * @param array $userWidgetIds The user widget ids to change permissions for.
     * @param bool  $canEdit       Flag that indicates user's permission level on widget.
     *
     * @return bool
     */
    public function bulkChangePermissions(array $userWidgetIds, $canEdit)
    {
        return $this->userWidgetModel
            ->whereIn('id', $userWidgetIds)
            ->update(['can_edit' => $canEdit]);
    }

    /**
     * Unsubscribe user from all widgets from the passed shared dashboard.
     *
     * Removes only user's widgets that are still on that dashboard, if user
     * moves a widget to another dashboard it will not be removed.
     *
     * @param UserDashboard $userDashboard User dashboard.
     *
     * @return Void
     */
    public function unsubscribeFromSharedDashboardWidgets(UserDashboard $userDashboard)
    {
        $userDashboard->load('user', 'dashboard.widgets');

        $user = $userDashboard->user;

        $usersWidgetsIds = $user->widgets->filter(function (Widget $widget) use ($userDashboard) {
            return $widget->pivot->dashboard_id === $userDashboard->dashboard_id;
        })->pluck('pivot.id')->toArray();

        $this->userWidgetModel
            ->whereIn('id', $usersWidgetsIds)
            ->delete();
    }

    /**
     * Sorts user widgets in the passed order.
     *
     * @param array $inputData The new sort order.
     *
     * @return bool
     */
    public function sort(array $inputData)
    {
        $newOrder = array_map(
            function ($item) {
                return (int) $item['id'];
            },
            $inputData['items']
        );

        return $this->userWidgetModel->updateSortOrder($newOrder);
    }

    /**
     * Return next sort value for a model.
     *
     * @return int
     */
    public function getNextSortValue()
    {
        return $this->userWidgetModel->getNextSortValue();
    }
}
