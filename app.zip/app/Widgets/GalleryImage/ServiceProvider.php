<?php

namespace App\Widgets\GalleryImage;

use App\Widgets\GalleryImage\Repository as WidgetGalleryImageRepository;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Routing\Router;
use URL;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerRoutePatterns($this->app['router'], $this->app);
        $this->registerFrontApiRoutes($this->app['router']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers the route patterns.
     *
     * @param Router    $router    A router.
     * @param Container $container A dependency container.
     *
     * @return void
     */
    protected function registerRoutePatterns(Router $router, Container $container)
    {
        $idRegex = $this->routePatternRegexes['id'];
        $slugRegex = $this->routePatternRegexes['slug'];

        $router->pattern('widgetGalleryImage', $idRegex);

        $router->bind('widgetGalleryImage', function ($value) use ($container, $idRegex) {
            $widgetGalleryImageRepository = $container->make(WidgetGalleryImageRepository::class);

            if (preg_match("/^{$idRegex}$/D", $value)) {
                $widgetGalleryImage = $widgetGalleryImageRepository->find($value);

                if ($widgetGalleryImage !== null) {
                    return $widgetGalleryImage;
                }
            }
        });
    }

    /**
     * Registers front API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1',
            'middleware' => ['api', 'auth'],
            'namespace' => 'App\Widgets\Http\Controllers\Api\V1\Front\GalleryImage',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->put('widget-gallery-images/sort', 'Controller@sort');
        });

        $attributes['middleware'] = ['api', 'auth', 'widgetGalleryImage.access'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->delete('widget-gallery-images/{widgetGalleryImage}', 'Controller@delete');
            $router->put('widget-gallery-images/{widgetGalleryImage}', 'Controller@update');
        });

        $attributes['middleware'] = ['api', 'auth', 'widgetGallery.access'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('widget-galleries/{widgetGallery}/images', 'Controller@index');
            $router->post('widget-galleries/{widgetGallery}/images', 'Controller@store');
        });
    }
}
