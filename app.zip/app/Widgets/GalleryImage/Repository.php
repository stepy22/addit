<?php

namespace App\Widgets\GalleryImage;

use App\Widgets\Gallery;
use App\Widgets\GalleryImage;
use Hshn\Base64EncodedFile\HttpFoundation\File\Base64EncodedFile;
use Illuminate\Http\UploadedFile;

class Repository
{
    /**
     * An GalleryImage model instance.
     *
     * @var GalleryImage
     */
    protected $imageModel;

    /**
     * @param GalleryImage $imageModel An gallery image model instance.
     */
    public function __construct(GalleryImage $imageModel)
    {
        $this->imageModel = $imageModel;
    }

    /**
     * Finds an image by its ID or fails.
     *
     * @param int $id The image ID.
     *
     * @return GalleryImage
     */
    public function find($id)
    {
        return $this->imageModel->findOrFail($id);
    }

    /**
     * Finds widget galleries by ids.
     *
     * @param array $ids The gallery image IDs.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getByIds(array $ids)
    {
        return $this->imageModel
            ->whereIn('id', $ids)
            ->get();
    }

    /**
     * Uploads an image for a model that can have child images.
     *
     * @param Gallery $gallery   A gallery instance.
     * @param array   $inputData Input data.
     *
     * @return GalleryImage
     */
    public function upload(Gallery $gallery, array $inputData)
    {
        $image = $this->imageModel->newInstance();

        if (isset($inputData['remote_image_url'])) {
            $contentString = file_get_contents($inputData['remote_image_url']);
            $inputData['image'] = base64_encode($contentString);
        }

        if ($inputData['image'] instanceof UploadedFile) {
            $image->uploadImage($inputData['image'], 'main');
        } else {
            $file = new Base64EncodedFile($inputData['image']);
            $image->uploadImage($file->getPathname(), 'main');
        }

        $image->title = array_get($inputData, 'title', $image->title);

        return $gallery->images()->save($image);
    }

    /**
     * Sorts images.
     *
     * @param array $ids The IDs to sort by.
     *
     * @return bool
     */
    public function sort(array $ids)
    {
        return $this->imageModel->updateSortOrder($ids);
    }

    /**
     * Updates an image.
     *
     * @param GalleryImage $image     The image to update.
     * @param array        $inputData The input data.
     *
     * @return GalleryImage
     */
    public function update(GalleryImage $image, array $inputData)
    {
        $image->title = array_get($inputData, 'title', $image->title);
        $image->save();

        return $image;
    }

    /**
     * Deletes an image.
     *
     * @param GalleryImage $image The image to update.
     *
     * @return bool
     */
    public function delete(GalleryImage $image)
    {
        return $image->delete();
    }
}
