<?php

namespace App\Widgets;

use Creitive\Database\Eloquent\Model;
use Creitive\Models\Traits\SortableTrait;

class ContactEmail extends Model
{
    use SortableTrait;

    /**
     * {@inheritDoc}
     */
    protected $table = 'widget_contact_emails';

    /**
     * {@inheritDoc}
     */
    public $timestamps = false;

    /**
     * {@inheritDoc}
     */
    protected $visible = [
        'id',
        'email',
        'widget_contact_id',
        'sort',
    ];

    /**
     * Eloquent relationship: contact email belongs to a contact.
     *
     * @return BelogngsTo
     */
    public function contact()
    {
        return $this->belongsTo(Contact::class, 'widget_contact_id');
    }
}
