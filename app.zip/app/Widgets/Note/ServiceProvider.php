<?php

namespace App\Widgets\Note;

use App\Widgets\Note;
use App\Widgets\Note\Repository as WidgetNoteRepository;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Routing\Router;
use URL;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerRoutePatterns($this->app['router'], $this->app);
        $this->registerFrontApiRoutes($this->app['router']);
        $this->attachCreatedEventHandler();
        $this->attachDeletedEventHandler();
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers the route patterns.
     *
     * @param Router    $router    A router.
     * @param Container $container A dependency container.
     *
     * @return void
     */
    protected function registerRoutePatterns(Router $router, Container $container)
    {
        $idRegex = $this->routePatternRegexes['id'];

        $router->pattern('widgetNote', $idRegex);

        $router->bind('widgetNote', function ($value) use ($container, $idRegex) {
            $widgetNoteRepository = $container->make(WidgetNoteRepository::class);

            if (preg_match("/^{$idRegex}$/D", $value)) {
                $widgetNote = $widgetNoteRepository->find($value);

                if ($widgetNote !== null) {
                    return $widgetNote;
                }
            }
        });
    }

    /**
     * Registers front API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1',
            'middleware' => ['api', 'auth'],
            'namespace' => 'App\Widgets\Http\Controllers\Api\V1\Front\Note',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->put('widget-notes/sort', 'Controller@sort');
        });

        $attributes['middleware'] = ['api', 'auth', 'widgetNote.access'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->put('widget-notes/{widgetNote}', 'Controller@update');
            $router->delete('widget-notes/{widgetNote}', 'Controller@delete');
        });

        $attributes['middleware'] = ['api', 'auth', 'widget.access'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('widgets/{widget}/notes', 'Controller@index');
        });

        $attributes['middleware'] = ['api', 'auth', 'widget.access:edit'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->post('widgets/{widget}/notes', 'Controller@store');
        });
    }

    /**
     * Attaches a handler to created note.
     *
     * @return void
     */
    public function attachCreatedEventHandler()
    {
        Note::created(function (Note $note) {
            $widget = $note->widget;
            $widget->notes_count = $widget->notes_count + 1;

            $widget->save();
        });
    }

    /**
     * Attaches a handler to deleted note.
     *
     * @return void
     */
    public function attachDeletedEventHandler()
    {
        Note::deleted(function (Note $note) {
            $widget = $note->widget;
            $widget->notes_count = $widget->notes_count - 1;

            $widget->save();
        });
    }
}
