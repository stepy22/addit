<?php

namespace App\Widgets\Note;

use App\Widgets\Note;
use Log;

class Repository
{
    /**
     * A Note model instance.
     *
     * @var Note
     */
    protected $note;

    /**
     * @param Note $note A note model instance.
     */
    public function __construct(Note $note)
    {
        $this->noteModel = $note;
    }

    /**
     * Gets all notes.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAll()
    {
        $query = $this->noteModel->select('*');

        return $query->get();
    }

    /**
     * Finds the note by ID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $id The note ID.
     *
     * @return Note|null
     */
    public function find($id)
    {
        return $this->noteModel->find($id);
    }

    /**
     * Finds widget notes by ids.
     *
     * @param array $ids The note IDs.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getByIds(array $ids)
    {
        return $this->noteModel
            ->whereIn('id', $ids)
            ->get();
    }

    /**
     * Finds the note by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The note ID.
     *
     * @return Note
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->noteModel->findOrFail($id);
    }

    /**
     * Updates the passed note and returns it.
     *
     * @param Note  $note      The note to update.
     * @param array $inputData The input data for the update.
     *
     * @return Note
     */
    public function update(Note $note, array $inputData)
    {
        return $this->populateAndSave($note, $inputData);
    }

    /**
     * Creates a note and returns it.
     *
     * @param array $inputData The input data for the update.
     *
     * @return Note
     */
    public function create(array $inputData)
    {
        $note = $this->noteModel->newInstance();

        return $this->populateAndSave($note, $inputData);
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param Note  $note      The note to populate.
     * @param array $inputData The input data for the note.
     *
     * @return Note
     */
    protected function populate(Note $note, array $inputData)
    {
        $note->title = array_get($inputData, 'title', $note->title);
        $note->description = array_get($inputData, 'description', $note->description);
        $note->widget_id = array_get($inputData, 'widget_id', $note->widget_id);

        return $note;
    }

    /**
     * Deletes a note.
     *
     * @param Note $note The note instance.
     *
     * @return Void
     */
    public function delete(Note $note)
    {
        $note->delete();
    }

    /**
     * Sorts notes in the passed order.
     *
     * @param array $inputData The new sort order.
     *
     * @return bool
     */
    public function sort(array $inputData)
    {
        $newOrder = array_map(
            function ($item) {
                return (int) $item['id'];
            },
            $inputData['items']
        );

        return $this->noteModel->updateSortOrder($newOrder);
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param Note  $note      The note to populate and save.
     * @param array $inputData The input data.
     *
     * @return Note
     */
    protected function populateAndSave(Note $note, array $inputData)
    {
        $note = $this->populate($note, $inputData);

        $note->save();

        return $note;
    }
}
