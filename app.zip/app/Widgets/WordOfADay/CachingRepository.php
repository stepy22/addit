<?php

namespace App\Widgets\WordOfADay;

use Creitive\WordsApi\Client as WordsApiClient;
use Illuminate\Cache\Repository as CacheRepository;

class CachingRepository
{
    /**
     * Words API client.
     *
     * @var WordsApiClient $wordsApiClient Words API client.
     */
    protected $wordsApiClient;

    /**
     * Cache repository instance.
     *
     * @var CacheRepository $cache Cache repository instance.
     */
    protected $cache;

    /**
     * @param WordsApiClient  $wordsApiClient Words API client.
     * @param CacheRepository $cache          Cache repository instance.
     */
    public function __construct(WordsApiClient $wordsApiClient, CacheRepository $cache)
    {
        $this->wordsApiClient = $wordsApiClient;
        $this->cache = $cache;
    }

    /**
     * Gets random word.
     *
     * @return array
     */
    public function getWordOfADay()
    {
        if ($this->cache->has('word-of-a-day') && isset(get_object_vars($this->cache->get('word-of-a-day'))['word'])) {
            $data = $this->cache->get('word-of-a-day');
        } else {
            $data = $this->wordsApiClient->getRandomWord();

            $this->cache->add('word-of-a-day', $data, 24 * 60);
        }

        return $data;
    }
}
