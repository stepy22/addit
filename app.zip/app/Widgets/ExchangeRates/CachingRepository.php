<?php

namespace App\Widgets\ExchangeRates;

use Creitive\OpenExchangeRates\Client as OpenExchangeRateClient;
use Illuminate\Cache\Repository as CacheRepository;

class CachingRepository
{
    /**
     * Open exchange rate API client.
     *
     * @var OpenExchangeRateClient $openExchangeRateClient Open exchange rate API client.
     */
    protected $openExchangeRateClient;

    /**
     * Cache repository instance.
     *
     * @var CacheRepository $cache Cache repository instance.
     */
    protected $cache;

    /**
     * @param OpenExchangeRateClient $openExchangeRateClient Open exchange rate API client.
     * @param CacheRepository        $cache                  Cache repository instance.
     */
    public function __construct(OpenExchangeRateClient $openExchangeRateClient, CacheRepository $cache)
    {
        $this->openExchangeRateClient = $openExchangeRateClient;
        $this->cache = $cache;
    }

    /**
     * Gets exchange rates.
     *
     * @return array
     */
    public function getExchangeRates()
    {
        if ($this->cache->has('exchange-rates')) {
            $data = $this->cache->get('exchange-rates');
        } else {
            $data = $this->openExchangeRateClient->getExchangeRates();

            $this->cache->add('exchange-rates', $data, 60);
        }

        return $data;
    }
}
