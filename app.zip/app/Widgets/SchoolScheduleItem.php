<?php

namespace App\Widgets;

use App\Widgets\Widget;
use Creitive\Database\Eloquent\Model;

class SchoolScheduleItem extends Model
{
    /**
     * {@inheritDoc}
     */
    public $timestamps = false;

    /**
     * {@inheritDoc}
     */
    protected $table = 'widget_school_schedule_items';

    /*
     * Day constants.
     */
    public const DAY_MONDAY = 'monday';
    public const DAY_TUESDAY = 'tuesday';
    public const DAY_WEDNESDAY = 'wednesday';
    public const DAY_THURSDAY = 'thursday';
    public const DAY_FRIDAY = 'friday';
    public const DAY_SATURDAY = 'saturday';
    public const DAY_SUNDAY = 'sunday';

    /**
     * {@inheritDoc}
     */
    protected $visible = [
        'id',
        'day',
        'class_name',
        'starts_at',
        'ends_at',
    ];

    /**
     * {@inheritDoc}
     */
    protected $casts = [
        'starts_at' => 'datetime:H:i:s',
        'ends_at' => 'datetime:H:i:s',
    ];

    /**
     * Eloquent relationship: school schedule item belongs to a widget.
     *
     * @return BelogngsTo
     */
    public function widget()
    {
        return $this->belongsTo(Widget::class);
    }
}
