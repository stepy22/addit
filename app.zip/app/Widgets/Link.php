<?php

namespace App\Widgets;

use App\Widgets\Widget;
use Creitive\Database\Eloquent\Model;
use Creitive\Image\Transformers\Thumbnail;
use Creitive\Models\Traits\ImageableTrait;
use Creitive\Models\Traits\SortableTrait;
use URL;

class Link extends Model
{
    use ImageableTrait;
    use SortableTrait;

    /**
     * {@inheritDoc}
     */
    protected $table = 'widget_links';

    /**
     * {@inheritDoc}
     */
    public $timestamps = false;

    /**
     * {@inheritDoc}
     */
    protected $visible = [
        'id',
        'title',
        'description',
        'url',
        'url_image_main_original',
        'url_image_main_favicon',
        'url_image_main_app_logo',
        'widget_id',
        'sort',
    ];

    /**
     * {@inheritDoc}
     */
    protected $appends = [
        'url_image_main_original',
        'url_image_main_favicon',
        'url_image_main_app_logo',
    ];

    /**
     * {@inheritDoc}
     */
    public function getImageConfiguration()
    {
        return [
            'versions' => [
                'main' => [
                    'original' => [],
                    'favicon' => [
                        [
                            'transformer' => Thumbnail::class,
                            'width' => 16,
                            'height' => 16,
                        ],
                    ],
                    'app_logo' => [
                        [
                            'transformer' => Thumbnail::class,
                            'width' => 175,
                            'height' => 175,
                        ],
                    ],
                ],
            ],
        ];
    }

    /**
     * Eloquent relationship: link belongs to a widget.
     *
     * @return BelogngsTo
     */
    public function widget()
    {
        return $this->belongsTo(Widget::class);
    }

    /**
     * Gets the complete URL to the original main image.
     *
     * @return string
     */
    public function getUrlImageMainOriginalAttribute()
    {
        return URL::to($this->getImage('main', 'original'));
    }

    /**
     * Gets the complete URL to the favicon main image.
     *
     * @return string
     */
    public function getUrlImageMainFaviconAttribute()
    {
        return URL::to($this->getImage('main', 'favicon'));
    }

    /**
     * Gets the complete URL to the top main image.
     *
     * @return string
     */
    public function getUrlImageMainAppLogoAttribute()
    {
        return URL::to($this->getImage('main', 'app_logo'));
    }
}
