<?php

namespace App\Widgets\Mail;

use App\Widgets\UserWidget;
use App\Widgets\Widget;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use URL;

class MyTopTenTaskNotification extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * The user name.
     *
     * @var string
     */
    public $userName;

    /**
     * The user email.
     *
     * @var string
     */
    public $userEmail;

    /**
     * The Task name.
     *
     * @var string
     */
    public $topTenItemName;

    /**
     * Number of tasks.
     *
     * @var int
     */
    public $numberOfTasks;

    /**
     * @param string $userName       User name.
     * @param string $userEmail      User email.
     * @param string $topTenItemName Task name.
     * @param int    $numberOfTasks  Number of tasks.
     */
    public function __construct($userName, $userEmail, $topTenItemName, $numberOfTasks)
    {
        $this->userName = $userName;
        $this->userEmail = $userEmail;
        $this->topTenItemName = $topTenItemName;
        $this->numberOfTasks = $numberOfTasks;
    }

    /**
     * {@inheritDoc}
     */
    public function build()
    {
        return $this->view('emails.widgets.my-top-ten-reminder')
            ->subject(trans('emails/widgets/myTopTenList.subject', ['number' => $this->numberOfTasks]))
            ->to($this->userEmail)
            ->with([
                'dashboardLink' => URL::action(
                    'App\Dashboards\Http\Controllers\Front\Dashboard\Controller@index'
                ),
            ]);
    }
}
