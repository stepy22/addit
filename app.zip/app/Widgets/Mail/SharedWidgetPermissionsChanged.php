<?php

namespace App\Widgets\Mail;

use App\Widgets\UserWidget;
use App\Widgets\Widget;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class SharedWidgetPermissionsChanged extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * The UserWidget instance.
     *
     * @var UserWidget
     */
    public $userWidget;

    /**
     * Whether user can or cannot edit shared widget.
     *
     * @var bool
     */
    public $canEdit;

    /**
     * Widget instance.
     *
     * @var Widget
     */
    public $widget;

    /**
     * @param UserWidget $userWidget UserWidget instance.
     * @param bool       $canEdit    Whether can edit widget or not.
     */
    public function __construct(UserWidget $userWidget, $canEdit)
    {
        $this->userWidget = $userWidget;
        $this->widget = $userWidget->widget;
        $this->canEdit = $canEdit;
    }

    /**
     * {@inheritDoc}
     */
    public function build()
    {
        $email = $this->userWidget->user ? $this->userWidget->user->email : $this->userWidget->email;
        $name = $this->userWidget->user ? $this->userWidget->user->name : '';

        return $this->view('emails.widgets.permissions-change')
            ->subject(trans('emails/widgets/permissionsChanged.subject'))
            ->to($email, $name);
    }
}
