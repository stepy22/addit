<?php

namespace App\Widgets\Mail;

use App\Widgets\Widget;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Collection;

class SharedWidgetDeleted extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * The Widget instance.
     *
     * @var Widget
     */
    public $widget;

    /**
     * Users collection.
     *
     * @var Collection
     */
    public $users;

    /**
     * @param Widget     $widget Widget instance.
     * @param Collection $users  Users collection instance.
     */
    public function __construct(Widget $widget, Collection $users)
    {
        $this->widget = $widget;
        $this->users = $users;
    }

    /**
     * {@inheritDoc}
     */
    public function build()
    {
        $message = $this->view('emails.widgets.deleted')
            ->subject(trans('emails/widgets/deletion.subject'));

        foreach ($this->users as $user) {
            $message->bcc($user->email, $user->full_name);
        }

        return $message;
    }
}
