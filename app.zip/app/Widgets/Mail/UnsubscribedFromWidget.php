<?php

namespace App\Widgets\Mail;

use App\Widgets\UserWidget;
use App\Widgets\Widget;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class UnsubscribedFromWidget extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * The UserWidget instance.
     *
     * @var UserWidget
     */
    public $userWidget;

    /**
     * User instance.
     *
     * @var User
     */
    public $user;

    /**
     * Widget instance.
     *
     * @var Widget
     */
    public $widget;

    /**
     * @param UserWidget $userWidget UserWidget instance.
     */
    public function __construct(UserWidget $userWidget)
    {
        $this->userWidget = $userWidget;
        $this->widget = $userWidget->widget;
        $this->user = $userWidget->user;
    }

    /**
     * {@inheritDoc}
     */
    public function build()
    {
        return $this->view('emails.widgets.unsubscribed-from-widget')
            ->subject(trans('emails/widgets/unsubscribedFromWidget.subject'))
            ->to($this->widget->owner()->email, $this->widget->owner()->full_name);
    }
}
