<?php

namespace App\Widgets\Mail;

use App\Widgets\Widget;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use URL;

class SharedWidgetInvitation extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Widget instance.
     *
     * @var Widget
     */
    public $widget;

    /**
     * Email to which to send invitation.
     *
     * @var string
     */
    public $email;

    /**
     * @param Widget $widget Widget instance.
     * @param string $email  Email to which to send invitation.
     */
    public function __construct(Widget $widget, $email)
    {
        $this->widget = $widget;
        $this->email = $email;
    }

    /**
     * {@inheritDoc}
     */
    public function build()
    {
        return $this->view('emails.widgets.shared-invitation')
            ->subject(trans('emails/widgets/sharedInvitation.subject'))
            ->to($this->email)
            ->with([
                'registrationLink' => URL::action(
                    'App\Auth\Http\Controllers\Front\Registration\Controller@index',
                    ['referrer' => $this->widget->owner()->id]
                ),
            ]);
    }
}
