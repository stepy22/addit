<?php

namespace App\Widgets\Mail;

use App\Widgets\UserWidget;
use App\Widgets\Widget;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class RemovedFromWidget extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * The UserWidget instance.
     *
     * @var UserWidget
     */
    public $userWidget;

    /**
     * The Widget instance.
     *
     * @var Widget
     */
    public $widget;

    /**
     * @param UserWidget $userWidget UserWidget instance.
     */
    public function __construct(UserWidget $userWidget)
    {
        $this->userWidget = $userWidget;
        $this->widget = $userWidget->widget;
    }

    /**
     * {@inheritDoc}
     */
    public function build()
    {
        $email = $this->userWidget->user ? $this->userWidget->user->email : $this->userWidget->email;
        $name = $this->userWidget->user ? $this->userWidget->user->name : '';

        return $this->view('emails.widgets.removed-from-widget')
            ->subject(trans('emails/widgets/removedFromWidget.subject'))
            ->to($email, $name);
    }
}
