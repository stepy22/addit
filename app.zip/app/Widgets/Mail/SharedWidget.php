<?php

namespace App\Widgets\Mail;

use App\Auth\User;
use App\Widgets\Widget;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class SharedWidget extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * The Widget instance.
     *
     * @var Widget
     */
    public $widget;

    /**
     * Users instance.
     *
     * @var User
     */
    public $user;

    /**
     * @param Widget $widget Widget instance.
     * @param User   $user   User instance.
     */
    public function __construct(Widget $widget, User $user)
    {
        $this->widget = $widget;
        $this->user = $user;
    }

    /**
     * {@inheritDoc}
     */
    public function build()
    {
        return $this->view('emails.widgets.shared')
            ->subject(trans('emails/widgets/sharing.subject'))
            ->to($this->user->email, $this->user->full_name);
    }
}
