<?php

namespace App\Widgets\File;

use App\Widgets\File;
use App\Widgets\File\Repository as WidgetFileRepository;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Routing\Router;
use URL;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerRoutePatterns($this->app['router'], $this->app);
        $this->registerFrontApiRoutes($this->app['router']);
        $this->attachCreatedEventHandler();
        $this->attachDeletedEventHandler();
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers the route patterns.
     *
     * @param Router    $router    A router.
     * @param Container $container A dependency container.
     *
     * @return void
     */
    protected function registerRoutePatterns(Router $router, Container $container)
    {
        $idRegex = $this->routePatternRegexes['id'];
        $slugRegex = $this->routePatternRegexes['slug'];

        $router->pattern('widgetFile', $idRegex);

        $router->bind('widgetFile', function ($value) use ($container, $idRegex) {
            $widgetFileRepository = $container->make(WidgetFileRepository::class);

            if (preg_match("/^{$idRegex}$/D", $value)) {
                $widgetFile = $widgetFileRepository->find($value);

                if ($widgetFile !== null) {
                    return $widgetFile;
                }
            }
        });
    }

    /**
     * Registers front API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1',
            'middleware' => ['api', 'auth'],
            'namespace' => 'App\Widgets\Http\Controllers\Api\V1\Front\File',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->put('widget-files/sort', 'Controller@sort');
        });

        $attributes['middleware'] = ['api', 'auth', 'widgetFile.access'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->put('widget-files/{widgetFile}', 'Controller@update');
            $router->delete('widget-files/{widgetFile}', 'Controller@delete');
        });

        $attributes['middleware'] = ['api', 'auth', 'widget.access'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('widgets/{widget}/files', 'Controller@index');
        });

        $attributes['middleware'] = ['api', 'auth', 'widget.access:edit'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->post('widgets/{widget}/files', 'Controller@store');
        });
    }

    /**
     * Attaches a handler to created event.
     *
     * @return void
     */
    public function attachCreatedEventHandler()
    {
        File::created(function (File $file) {
            $widget = $file->widget;
            $widget->files_count = $widget->files_count + 1;

            $widget->save();
        });
    }

    /**
     * Attaches a handler to deleted event.
     *
     * @return void
     */
    public function attachDeletedEventHandler()
    {
        File::deleted(function (File $file) {
            $widget = $file->widget;
            $widget->files_count = $widget->files_count - 1;

            $widget->save();
        });
    }
}
