<?php

namespace App\Widgets\File;

use App\Auth\User;
use App\Widgets\File;
use Creitive\File\Uploader as FileUploader;
use Hshn\Base64EncodedFile\HttpFoundation\File\Base64EncodedFile;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\QueryException;
use Illuminate\Support\Collection;
use Log;
use Symfony\Component\HttpFoundation\File\File as SymfonyFile;
use wapmorgan\FileTypeDetector\Detector;

class Repository
{
    /**
     * A File model instance.
     *
     * @var File
     */
    protected $file;

    /**
     * @param File $file A file model instance.
     */
    public function __construct(File $file)
    {
        $this->fileModel = $file;
    }

    /**
     * Gets all files.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAll()
    {
        $query = $this->fileModel->select('*');

        return $query->get();
    }

    /**
     * Finds the file by ID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $id The file ID.
     *
     * @return File|null
     */
    public function find($id)
    {
        return $this->fileModel->find($id);
    }

    /**
     * Finds widget files by ids.
     *
     * @param array $ids The file IDs.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getByIds(array $ids)
    {
        return $this->fileModel
            ->whereIn('id', $ids)
            ->get();
    }

    /**
     * Finds the file by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The file ID.
     *
     * @return File
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->fileModel->findOrFail($id);
    }

    /**
     * Updates the passed file and returns it.
     *
     * @param File  $file      The file to update.
     * @param array $inputData The input data for the update.
     *
     * @return File
     */
    public function update(File $file, array $inputData)
    {
        return $this->populateAndSave($file, $inputData);
    }

    /**
     * Creates a file and returns it.
     *
     * @param array $inputData The input data for the update.
     *
     * @return File
     */
    public function create(array $inputData)
    {
        $file = $this->fileModel->newInstance();

        return $this->populateAndSave($file, $inputData);
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param File  $file      The file to populate.
     * @param array $inputData The input data for the file.
     *
     * @return File
     *
     * @throws BadRequestHttpException
     */
    protected function populate(File $file, array $inputData)
    {
        $file->title = array_get($inputData, 'title', $file->title);
        $file->widget_id = array_get($inputData, 'widget_id', $file->widget_id);

        return $file;
    }

    /**
     * Deletes a file.
     *
     * @param File $file The file instance.
     *
     * @return Void
     */
    public function delete(File $file)
    {
        $file->delete();
    }

    /**
     * Sorts files in the passed order.
     *
     * @param array $inputData The new sort order.
     *
     * @return bool
     */
    public function sort(array $inputData)
    {
        $newOrder = array_map(
            function ($item) {
                return (int) $item['id'];
            },
            $inputData['items']
        );

        return $this->fileModel->updateSortOrder($newOrder);
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param File  $file      The file to populate and save.
     * @param array $inputData The input data.
     *
     * @return File
     */
    protected function populateAndSave(File $file, array $inputData)
    {
        $file = $this->populate($file, $inputData);

        $file->save();

        return $file;
    }
}
