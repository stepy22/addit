<?php

namespace App\Widgets\MyInsightItem\Link;

use App\Auth\User;
use App\Widgets\MyInsightItem\Link;
use Creitive\PageDescriptionCrawler\Crawler;
use Hshn\Base64EncodedFile\HttpFoundation\File\Base64EncodedFile;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\QueryException;
use Illuminate\Support\Collection;
use Log;

class Repository
{
    /**
     * A Link model instance.
     *
     * @var Link
     */
    protected $linkModel;

    /**
     * @param Link $link A link model instance.
     */
    public function __construct(Link $link)
    {
        $this->linkModel = $link;
    }

    /**
     * Gets all links.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAll()
    {
        $query = $this->linkModel->select('*');

        return $query->get();
    }

    /**
     * Finds the link by ID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $id The link ID.
     *
     * @return Link|null
     */
    public function find($id)
    {
        return $this->linkModel->find($id);
    }

    /**
     * Finds widget my insight links by ids.
     *
     * @param array $ids The link IDs.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getByIds(array $ids)
    {
        return $this->linkModel
            ->whereIn('id', $ids)
            ->get();
    }

    /**
     * Finds the link by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The link ID.
     *
     * @return Link
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->linkModel->findOrFail($id);
    }

    /**
     * Updates the passed link and returns it.
     *
     * @param Link    $link      The link to update.
     * @param array   $inputData The input data for the update.
     * @param Crawler $crawler   Page description crawler instance.
     *
     * @return Link
     */
    public function update(Link $link, array $inputData, Crawler $crawler)
    {
        return $this->populateAndSave($link, $inputData, $crawler);
    }

    /**
     * Creates a link and returns it.
     *
     * @param array   $inputData The input data for the update.
     * @param Crawler $crawler   Page description crawler instance.
     *
     * @return Link
     */
    public function create(array $inputData, Crawler $crawler)
    {
        $link = $this->linkModel->newInstance();

        return $this->populateAndSave($link, $inputData, $crawler);
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param Link    $link      The link to populate.
     * @param array   $inputData The input data for the link.
     * @param Crawler $crawler   Page description crawler instance.
     *
     * @return Link
     */
    protected function populate(Link $link, array $inputData, Crawler $crawler)
    {
        $link->title = array_get($inputData, 'title', $link->title);
        $link->description = array_get($inputData, 'description', $link->description);
        if ($link->url !== $inputData['url']) {
            $link->description = $crawler->getPageDescription($inputData['url']);
        }
        $link->url = array_get($inputData, 'url', $link->url);
        $link->widget_my_insight_item_id = array_get($inputData, 'widget_my_insight_item_id', $link->widget_my_insight_item_id);

        if (isset($inputData['image_main'])) {
            if ($inputData['image_main'] instanceof UploadedFile) {
                $link->uploadImage($inputData['image_main'], 'main');
            } else {
                $file = new Base64EncodedFile($inputData['image_main']);
                $link->uploadImage($file->getPathname(), 'main');
            }
        }

        return $link;
    }

    /**
     * Deletes a link.
     *
     * @param Link $link The link instance.
     *
     * @return Void
     */
    public function delete(Link $link)
    {
        $link->delete();
    }

    /**
     * Sorts links in the passed order.
     *
     * @param array $inputData The new sort order.
     *
     * @return bool
     */
    public function sort(array $inputData)
    {
        $newOrder = array_map(
            function ($item) {
                return (int) $item['id'];
            },
            $inputData['items']
        );

        return $this->linkModel->updateSortOrder($newOrder);
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param Link    $link      The link to populate and save.
     * @param array   $inputData The input data.
     * @param Crawler $crawler   Page description crawler instance.
     *
     * @return Link
     */
    protected function populateAndSave(Link $link, array $inputData, Crawler $crawler)
    {
        $link = $this->populate($link, $inputData, $crawler);

        $link->save();

        return $link;
    }
}
