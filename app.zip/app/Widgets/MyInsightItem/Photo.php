<?php

namespace App\Widgets\MyInsightItem;

use App\Widgets\MyInsightItem;
use Creitive\Database\Eloquent\Model;
use Creitive\Image\Transformers\CropThumbnail;
use Creitive\Models\Traits\ImageableTrait;
use Creitive\Models\Traits\SortableTrait;
use URL;

class Photo extends Model
{
    use ImageableTrait;
    use SortableTrait;

    /**
     * {@inheritDoc}
     */
    protected $table = 'widget_my_insight_photos';

    /**
     * {@inheritDoc}
     */
    public $timestamps = false;

    /**
     * {@inheritDoc}
     */
    protected $visible = [
        'id',
        'title',
        'url_image_main_original',
        'url_image_main_large',
        'url_image_main_thumbnail',
        'url_image_main_small',
        'widget_my_insight_item_id',
    ];

    /**
     * {@inheritDoc}
     */
    protected $appends = [
        'url_image_main_original',
        'url_image_main_large',
        'url_image_main_thumbnail',
        'url_image_main_small',
    ];

    /**
     * {@inheritDoc}
     */
    public function getImageConfiguration()
    {
        return [
            'versions' => [
                'main' => [
                    'original' => [],
                    'large' => [
                        [
                            'transformer' => CropThumbnail::class,
                            'width' => 800,
                            'height' => 550,
                        ],
                    ],
                    'thumbnail' => [
                        [
                            'transformer' => CropThumbnail::class,
                            'width' => 400,
                            'height' => 275,
                        ],
                    ],
                    'small' => [
                        [
                            'transformer' => CropThumbnail::class,
                            'width' => 270,
                            'height' => 270,
                        ],
                    ],
                ],
            ],
        ];
    }

    /**
     * Gets the complete URL to the original main image.
     *
     * @return string
     */
    public function getUrlImageMainOriginalAttribute()
    {
        return URL::to($this->getImage('main', 'original'));
    }

    /**
     * Gets the complete URL to the large main image.
     *
     * @return string
     */
    public function getUrlImageMainLargeAttribute()
    {
        return URL::to($this->getImage('main', 'large'));
    }

    /**
     * Gets the complete URL to the thumbnail main image.
     *
     * @return string
     */
    public function getUrlImageMainThumbnailAttribute()
    {
        return URL::to($this->getImage('main', 'thumbnail'));
    }

    /**
     * Gets the complete URL to the small main image.
     *
     * @return string
     */
    public function getUrlImageMainSmallAttribute()
    {
        return URL::to($this->getImage('main', 'small'));
    }

    /**
     * Eloquent relationship: file belongs to a myInsightItem.
     *
     * @return BelogngsTo
     */
    public function myInsightItem()
    {
        return $this->belongsTo(MyInsightItem::class, 'widget_my_insight_item_id');
    }
}
