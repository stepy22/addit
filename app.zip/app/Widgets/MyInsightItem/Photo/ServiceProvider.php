<?php

namespace App\Widgets\MyInsightItem\Photo;

use App\Widgets\MyInsightItem\Photo\Repository as MyInsightItemPhotoRepository;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Routing\Router;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerRoutePatterns($this->app['router'], $this->app);
        $this->registerFrontApiRoutes($this->app['router']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers the route patterns.
     *
     * @param Router    $router    A router.
     * @param Container $container A dependency container.
     *
     * @return void
     */
    protected function registerRoutePatterns(Router $router, Container $container)
    {
        $idRegex = $this->routePatternRegexes['id'];
        $slugRegex = $this->routePatternRegexes['slug'];

        $router->pattern('myInsightItemPhoto', $idRegex);

        $router->bind('myInsightItemPhoto', function ($value) use ($container, $idRegex) {
            $myInsightItemPhotoRepository = $container->make(MyInsightItemPhotoRepository::class);

            if (preg_match("/^{$idRegex}$/D", $value)) {
                $myInsightItemPhoto = $myInsightItemPhotoRepository->find($value);

                if ($myInsightItemPhoto !== null) {
                    return $myInsightItemPhoto;
                }
            }
        });
    }

    /**
     * Registers front API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1',
            'middleware' => ['api', 'auth'],
            'namespace' => 'App\Widgets\Http\Controllers\Api\V1\Front\MyInsightItem\Photo',
        ];

        $attributes['middleware'] = ['api', 'auth', 'widgetMyInsightItemPhoto.access'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->delete('my-insight-item-photos/{myInsightItemPhoto}', 'Controller@delete');
        });

        $attributes['middleware'] = ['api', 'auth', 'widgetMyInsightItem.access'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('my-insight-items/{myInsightItem}/photos', 'Controller@index');
            $router->post('my-insight-items/{myInsightItem}/photos', 'Controller@store');
        });
    }
}
