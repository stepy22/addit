<?php

namespace App\Widgets\MyInsightItem\Photo;

use App\Auth\User;
use App\Widgets\MyInsightItem;
use App\Widgets\MyInsightItem\Photo;
use Hshn\Base64EncodedFile\HttpFoundation\File\Base64EncodedFile;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\QueryException;
use Illuminate\Support\Collection;
use Log;
use Symfony\Component\HttpFoundation\File\File as SymfonyFile;
use wapmorgan\FileTypeDetector\Detector;

class Repository
{
    /**
     * An Photo model instance.
     *
     * @var MyInsightPhoto
     */
    protected $photoModel;

    /**
     * @param Photo $photoModel An my insight photo model instance.
     */
    public function __construct(Photo $photoModel)
    {
        $this->photoModel = $photoModel;
    }

    /**
     * Finds an photo by its ID or fails.
     *
     * @param int $id The photo ID.
     *
     * @return Photo
     */
    public function find($id)
    {
        return $this->photoModel->findOrFail($id);
    }

    /**
     * Finds widget my insight photos by ids.
     *
     * @param array $ids The my insight photo IDs.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getByIds(array $ids)
    {
        return $this->photoModel
            ->whereIn('id', $ids)
            ->get();
    }

    /**
     * Sorts photos.
     *
     * @param array $ids The IDs to sort by.
     *
     * @return bool
     */
    public function sort(array $ids)
    {
        return $this->photoModel->updateSortOrder($ids);
    }

    /**
     * Updates an photo.
     *
     * @param Photo $photo     The photo to update.
     * @param array $inputData The input data.
     *
     * @return Photo
     */
    public function update(Photo $photo, array $inputData)
    {
        $photo->title = array_get($inputData, 'title', $photo->title);
        $photo->save();

        return $photo;
    }

    /**
     * Uploads an photo for a model that can have child photos.
     *
     * @param MyInsightItem $myInsightItem A my insight item instance.
     * @param array         $inputData     Input data.
     *
     * @return Photo
     */
    public function upload(MyInsightItem $myInsightItem, array $inputData)
    {
        $photo = $this->photoModel->newInstance();

        if ($inputData['image'] instanceof UploadedFile) {
            $photo->uploadImage($inputData['image'], 'main');
        } else {
            $file = new Base64EncodedFile($inputData['image']);
            $photo->uploadImage($file->getPathname(), 'main');
        }

        $photo->title = array_get($inputData, 'title', $photo->title);

        return $myInsightItem->photos()->save($photo);
    }

    /**
     * Deletes an photo.
     *
     * @param Photo $photo The photo to delete.
     *
     * @return bool
     */
    public function delete(Photo $photo)
    {
        return $photo->delete();
    }
}
