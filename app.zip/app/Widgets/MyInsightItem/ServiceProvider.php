<?php

namespace App\Widgets\MyInsightItem;

use App\Widgets\MyInsightItem\Repository as WidgetMyInsightItemRepository;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Routing\Router;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerRoutePatterns($this->app['router'], $this->app);
        $this->registerFrontApiRoutes($this->app['router']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers the route patterns.
     *
     * @param Router    $router    A router.
     * @param Container $container A dependency container.
     *
     * @return void
     */
    protected function registerRoutePatterns(Router $router, Container $container)
    {
        $idRegex = $this->routePatternRegexes['id'];
        $slugRegex = $this->routePatternRegexes['slug'];

        $router->pattern('myInsightItem', $idRegex);

        $router->bind('myInsightItem', function ($value) use ($container, $idRegex) {
            $widgetMyInsightItemRepository = $container->make(WidgetMyInsightItemRepository::class);

            if (preg_match("/^{$idRegex}$/D", $value)) {
                $widgetMyInsightItem = $widgetMyInsightItemRepository->find($value);

                if ($widgetMyInsightItem !== null) {
                    return $widgetMyInsightItem;
                }
            }
        });
    }

    /**
     * Registers front API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1',
            'middleware' => ['api', 'auth'],
            'namespace' => 'App\Widgets\Http\Controllers\Api\V1\Front\MyInsightItem',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->put('my-insight-items/sort', 'Controller@sort');
        });

        $attributes['middleware'] = ['api', 'auth', 'widgetMyInsightItem.access'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('my-insight-items/{myInsightItem}', 'Controller@show');
            $router->delete('my-insight-items/{myInsightItem}', 'Controller@delete');
            $router->put('my-insight-items/{myInsightItem}', 'Controller@update');
        });

        $attributes['middleware'] = ['api', 'auth', 'widget.access'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->post('widgets/{widget}/my-insight-items', 'Controller@store');
        });
    }
}
