<?php

namespace App\Widgets\MyInsightItem;

use App\Widgets\MyInsightItem;
use Creitive\Database\Eloquent\Model;
use Creitive\Models\Traits\SortableTrait;
use FileUrlGenerator;
use URL;

class File extends Model
{
    use SortableTrait;

    /**
     * {@inheritDoc}
     */
    protected $table = 'widget_my_insight_files';

    /**
     * {@inheritDoc}
     */
    public $timestamps = false;

    /**
     * {@inheritDoc}
     */
    protected $visible = [
        'id',
        'name',
        'filepath',
        'filepath_url',
        'extension',
        'widget_my_insight_item_id',
    ];

    /**
     * {@inheritDoc}
     */
    protected $appends = [
        'filepath_url',
    ];

    /**
     * Eloquent relationship: file belongs to a myInsightItem.
     *
     * @return BelogngsTo
     */
    public function myInsightItem()
    {
        return $this->belongsTo(MyInsightItem::class, 'widget_my_insight_item_id');
    }

    /**
     * Gets full url to uploaded file.
     *
     * @return string
     */
    public function getFilepathUrlAttribute()
    {
        return FileUrlGenerator::generate($this->filepath);
    }
}
