<?php

namespace App\Widgets\MyInsightItem;

use App\MyInsightSubjects\MyInsightSubject;
use App\Widgets\MyInsightItem;

class Repository
{
    /**
     * A MyInsightItem model instance.
     *
     * @var MyInsightItem
     */
    protected $myInsightItemModel;

    /**
     * @param MyInsightItem $myInsightItem A MyInsightItem model instance.
     */
    public function __construct(MyInsightItem $myInsightItem)
    {
        $this->myInsightItemModel = $myInsightItem;
    }

    /**
     * Gets all my insight items.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAll()
    {
        $query = $this->myInsightItemModel->select('*');

        return $query->get();
    }

    /**
     * Finds the my insight item by ID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $id The my insight item ID.
     *
     * @return MyInsightItem|null
     */
    public function find($id)
    {
        return $this->myInsightItemModel->find($id);
    }

    /**
     * Finds widget my insight items by ids.
     *
     * @param array $ids The my insight item IDs.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getByIds(array $ids)
    {
        return $this->myInsightItemModel
            ->whereIn('id', $ids)
            ->get();
    }

    /**
     * Finds the my insight item by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The my insight item ID.
     *
     * @return MyInsightItem
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->myInsightItemModel->findOrFail($id);
    }

    /**
     * Updates the passed my insight item and returns it.
     *
     * @param MyInsightItem $myInsightItem The my insight item to update.
     * @param array         $inputData     The input data for the update.
     *
     * @return MyInsightItem
     */
    public function update(MyInsightItem $myInsightItem, array $inputData)
    {
        return $this->populateAndSave($myInsightItem, $inputData);
    }

    /**
     * Creates a my insight item and returns it.
     *
     * @param array $inputData The input data for the update.
     *
     * @return MyInsightItem
     */
    public function create(array $inputData)
    {
        $myInsightItem = $this->myInsightItemModel->newInstance();

        return $this->populateAndSave($myInsightItem, $inputData);
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param MyInsightItem $myInsightItem The my insight item to populate.
     * @param array         $inputData     The input data for the my insight subject.
     *
     * @return MyInsightItem
     */
    protected function populate(MyInsightItem $myInsightItem, array $inputData)
    {
        $myInsightItem->subject = array_get($inputData, 'subject', $myInsightItem->subject);
        $myInsightItem->description = array_get($inputData, 'description', $myInsightItem->description);
        $myInsightItem->widget_id = array_get($inputData, 'widget_id', $myInsightItem->widget_id);

        return $myInsightItem;
    }

    /**
     * Deletes a my insight item.
     *
     * @param MyInsightItem $myInsightItem The my insight item instance.
     *
     * @return Void
     */
    public function delete(MyInsightItem $myInsightItem)
    {
        $myInsightItem->delete();
    }

    /**
     * Sorts my insight items in the passed order.
     *
     * @param array $inputData The new sort order.
     *
     * @return bool
     */
    public function sort(array $inputData)
    {
        $newOrder = array_map(
            function ($item) {
                return (int) $item['id'];
            },
            $inputData['items']
        );

        return $this->myInsightItemModel->updateSortOrder($newOrder);
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param MyInsightItem $myInsightItem The my insight item to populate and save.
     * @param array         $inputData     The input data.
     *
     * @return MyInsightItem
     */
    protected function populateAndSave(MyInsightItem $myInsightItem, array $inputData)
    {
        $myInsightItem = $this->populate($myInsightItem, $inputData);

        $myInsightItem->save();

        return $myInsightItem;
    }

    /**
     * Create default my insight items for widget.
     *
     * @param int $widgetId Id of the widget.
     */
    public function createDefaultSubjects($widgetId)
    {
        $myInsightItems = [];
        $defaultSubjects = MyInsightSubject::select('subject', 'description')->get()->toArray();

        foreach ($defaultSubjects as $defaultSubject) {
            $defaultSubject['widget_id'] = $widgetId;
            $myInsightItems[] = $defaultSubject;
        }

        MyInsightItem::insert($myInsightItems);
    }
}
