<?php

namespace App\Widgets\MyInsightItem\File;

use App\Auth\User;
use App\Widgets\MyInsightItem\File;
use Creitive\File\Uploader as FileUploader;
use Hshn\Base64EncodedFile\HttpFoundation\File\Base64EncodedFile;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\QueryException;
use Illuminate\Support\Collection;
use Log;
use Symfony\Component\HttpFoundation\File\File as SymfonyFile;
use wapmorgan\FileTypeDetector\Detector;

class Repository
{
    /**
     * A File model instance.
     *
     * @var File
     */
    protected $fileModel;

    /**
     * A FileUploader instance.
     *
     * @var FileUploader
     */
    protected $fileUploader;

    /**
     * @param File         $file         A file item model instance.
     * @param FileUploader $fileUploader A file uploader instance.
     */
    public function __construct(File $file, FileUploader $fileUploader)
    {
        $this->fileModel = $file;
        $this->fileUploader = $fileUploader;
    }

    /**
     * Gets all files.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAll()
    {
        $query = $this->fileModel->select('*');

        return $query->get();
    }

    /**
     * Finds the file by ID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $id The file ID.
     *
     * @return File|null
     */
    public function find($id)
    {
        return $this->fileModel->find($id);
    }

    /**
     * Finds my insight item files by ids.
     *
     * @param array $ids The file IDs.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getByIds(array $ids)
    {
        return $this->fileModel
            ->whereIn('id', $ids)
            ->get();
    }

    /**
     * Finds the file by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The file item ID.
     *
     * @return File
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->fileModel->findOrFail($id);
    }

    /**
     * Updates the passed file and returns it.
     *
     * @param File  $file      The file item to update.
     * @param array $inputData The input data for the update.
     *
     * @return File
     */
    public function update(File $file, array $inputData)
    {
        return $this->populateAndSave($file, $inputData);
    }

    /**
     * Creates a file and returns it.
     *
     * @param array $inputData The input data for the update.
     *
     * @return File
     */
    public function create(array $inputData)
    {
        $file = $this->fileModel->newInstance();

        return $this->populateAndSave($file, $inputData);
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param File  $file      The file to populate.
     * @param array $inputData The input data for the file item.
     *
     * @return File
     */
    protected function populate(File $file, array $inputData)
    {
        $file->name = array_get($inputData, 'name', $file->name);
        $file->widget_my_insight_item_id = array_get($inputData, 'widget_my_insight_item_id', $file->widget_my_insight_item_id);

        if (isset($inputData['file'])) {
            $uploadedFile = new Base64EncodedFile($inputData['file']);
            $uploadedFile = new SymfonyFile($uploadedFile);

            $file->filepath = $this->fileUploader->upload($uploadedFile);
            $type = Detector::detectByContent(public_path('upload/files/' . $file->filepath));

            if ($type && is_array($type) && isset($type[1])) {
                $file->extension = $type[1];
            } else {
                $file->extension = $uploadedFile->guessExtension();
            }
        }

        return $file;
    }

    /**
     * Deletes a file.
     *
     * @param File $file The file item instance.
     *
     * @return Void
     */
    public function delete(File $file)
    {
        $file->delete();
    }

    /**
     * Sorts files in the passed order.
     *
     * @param array $inputData The new sort order.
     *
     * @return bool
     */
    public function sort(array $inputData)
    {
        $newOrder = array_map(
            function ($item) {
                return (int) $item['id'];
            },
            $inputData['items']
        );

        return $this->fileModel->updateSortOrder($newOrder);
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param File  $file      The file item to populate and save.
     * @param array $inputData The input data.
     *
     * @return File
     */
    protected function populateAndSave(File $file, array $inputData)
    {
        $file = $this->populate($file, $inputData);

        $file->save();

        return $file;
    }
}
