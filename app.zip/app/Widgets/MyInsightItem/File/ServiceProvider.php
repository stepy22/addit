<?php

namespace App\Widgets\MyInsightItem\File;

use App\Widgets\MyInsightItem\File\Repository as MyInsightItemFileRepository;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Routing\Router;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerRoutePatterns($this->app['router'], $this->app);
        $this->registerFrontApiRoutes($this->app['router']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers the route patterns.
     *
     * @param Router    $router    A router.
     * @param Container $container A dependency container.
     *
     * @return void
     */
    protected function registerRoutePatterns(Router $router, Container $container)
    {
        $idRegex = $this->routePatternRegexes['id'];
        $slugRegex = $this->routePatternRegexes['slug'];

        $router->pattern('myInsightItemFile', $idRegex);

        $router->bind('myInsightItemFile', function ($value) use ($container, $idRegex) {
            $myInsightItemFileRepository = $container->make(MyInsightItemFileRepository::class);

            if (preg_match("/^{$idRegex}$/D", $value)) {
                $myInsightItemFile = $myInsightItemFileRepository->find($value);

                if ($myInsightItemFile !== null) {
                    return $myInsightItemFile;
                }
            }
        });
    }

    /**
     * Registers front API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1',
            'middleware' => ['api', 'auth'],
            'namespace' => 'App\Widgets\Http\Controllers\Api\V1\Front\MyInsightItem\File',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->put('my-insight-item-files/sort', 'Controller@sort');
        });

        $attributes['middleware'] = ['api', 'auth', 'widgetMyInsightItemFile.access'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->delete('my-insight-item-files/{myInsightItemFile}', 'Controller@delete');
            $router->put('my-insight-item-files/{myInsightItemFile}', 'Controller@update');
        });

        $attributes['middleware'] = ['api', 'auth', 'widgetMyInsightItem.access'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('my-insight-items/{myInsightItem}/files', 'Controller@index');
            $router->post('my-insight-items/{myInsightItem}/files', 'Controller@store');
        });
    }
}
