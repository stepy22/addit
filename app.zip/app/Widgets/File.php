<?php

namespace App\Widgets;

use App\Widgets\Widget;
use Creitive\Database\Eloquent\Model;
use Creitive\Models\Traits\SortableTrait;
use URL;

class File extends Model
{
    use SortableTrait;

    /**
     * {@inheritDoc}
     */
    protected $table = 'widget_files';

    /**
     * {@inheritDoc}
     */
    protected $visible = [
        'id',
        'title',
        'widget_id',
        'sort',
        'items',
    ];

    /**
     * Eloquent relationship: file belongs to a widget.
     *
     * @return BelogngsTo
     */
    public function widget()
    {
        return $this->belongsTo(Widget::class);
    }

    /**
     * Eloquent relationship: file may have many items.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function items()
    {
        return $this->hasMany(FileItem::class, 'widget_file_id');
    }
}
