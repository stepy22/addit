<?php

namespace App\Widgets\MyTopTenListItem;

use App\Widgets\MyTopTenListItem\Repository as WidgetMyTopTenListItemRepository;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Routing\Router;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerRoutePatterns($this->app['router'], $this->app);
        $this->registerFrontApiRoutes($this->app['router']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers the route patterns.
     *
     * @param Router    $router    A router.
     * @param Container $container A dependency container.
     *
     * @return void
     */
    protected function registerRoutePatterns(Router $router, Container $container)
    {
        $idRegex = $this->routePatternRegexes['id'];
        $slugRegex = $this->routePatternRegexes['slug'];

        $router->pattern('myTopTenListItem', $idRegex);

        $router->bind('myTopTenListItem', function ($value) use ($container, $idRegex) {
            $widgetMyTopTenListItemRepository = $container->make(WidgetMyTopTenListItemRepository::class);

            if (preg_match("/^{$idRegex}$/D", $value)) {
                $widgetMyTopTenListItem = $widgetMyTopTenListItemRepository->find($value);

                if ($widgetMyTopTenListItem !== null) {
                    return $widgetMyTopTenListItem;
                }
            }
        });
    }

    /**
     * Registers front API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1',
            'middleware' => ['api', 'auth'],
            'namespace' => 'App\Widgets\Http\Controllers\Api\V1\Front\MyTopTenListItem',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->put('my-top-ten-list-items/sort', 'Controller@sort');
            $router->post('my-top-ten-list-items/clear', 'Controller@clear');
        });

        $attributes['middleware'] = ['api', 'auth', 'widgetMyTopTenList.access'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->delete('my-top-ten-list-items/{myTopTenListItem}', 'Controller@delete');
            $router->put('my-top-ten-list-items/{myTopTenListItem}', 'Controller@update');
            $router->put('my-top-ten-list-items/{myTopTenListItem}/forward-to-next-day', 'Controller@forwardToNextDay');
        });

        $attributes['middleware'] = ['api', 'auth', 'widget.access'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->post('widgets/{widget}/my-top-ten-list-items', 'Controller@store');
        });
    }
}
