<?php

namespace App\Widgets\MyTopTenListItem;

use App\Auth\User;
use App\Widgets\MyTopTenListItem;
use Carbon\Carbon;

class Repository
{
    /**
     * A my top ten list item model instance.
     *
     * @var MyTopTenList
     */
    protected $myTopTenListItemModel;

    /**
     * @param MyTopTenListItem $myTopTenListItem A my top ten list item model instance.
     */
    public function __construct(MyTopTenListItem $myTopTenListItem)
    {
        $this->myTopTenListItemModel = $myTopTenListItem;
    }

    /**
     * Finds the my top ten list item by ID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $id The my top ten list item ID.
     *
     * @return MyTopTenListItem|null
     */
    public function find($id)
    {
        return $this->myTopTenListItemModel->find($id);
    }

    /**
     * Finds widget top ten list items by ids.
     *
     * @param array $ids The top ten list items IDs.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getByIds(array $ids)
    {
        return $this->myTopTenListItemModel
            ->whereIn('id', $ids)
            ->get();
    }

    /**
     * Creates a my top ten list item and returns it.
     *
     * @param array $inputData The input data for the update.
     * @param User  $user      User instance.
     *
     * @return MyTopTenListItem
     */
    public function create(array $inputData, User $user)
    {
        $myTopTenListItemModel = $this->myTopTenListItemModel->newInstance();

        return $this->populateAndSave($myTopTenListItemModel, $inputData, $user);
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param MyTopTenListItem $myTopTenListItem The myTopTenListItem to populate.
     * @param array            $inputData        The input data for the myTopTenListItem.
     * @param User             $user             User instance.
     *
     * @return MyTopTenListItem
     */
    protected function populate(MyTopTenListItem $myTopTenListItem, array $inputData, User $user)
    {
        $myTopTenListItem->name = array_get($inputData, 'name', $myTopTenListItem->name);
        $myTopTenListItem->widget_id = array_get($inputData, 'widget_id', $myTopTenListItem->widget_id);
        $myTopTenListItem->notified = array_get($inputData, 'notified', $myTopTenListItem->notified ?: false);
        $myTopTenListItem->notify_me = array_get($inputData, 'notify_me', $myTopTenListItem->notify_me ?: false);
        $myTopTenListItem->completed = array_get($inputData, 'completed', $myTopTenListItem->completed ?: false);

        // Save notify_at always in UTC timezone.
        if (isset($inputData['notify_at'])) {
            $notifyAt = array_get($inputData, 'notify_at', $myTopTenListItem->notify_at);
            $myTopTenListItem->notify_at = Carbon::createFromFormat('Y-m-d H:i:s', $notifyAt, $user->timezone)
                                                    ->setTimezone('UTC')->toDateTimeString();
        }

        return $myTopTenListItem;
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param MyTopTenListItem $myTopTenListItem The my top ten list item to populate and save.
     * @param array            $inputData        The input data.
     * @param User             $user             User instance.
     *
     * @return MyTopTenListItem
     */
    protected function populateAndSave(MyTopTenListItem $myTopTenListItem, array $inputData, User $user)
    {
        $myTopTenListItem = $this->populate($myTopTenListItem, $inputData, $user);

        $myTopTenListItem->save();

        return $myTopTenListItem;
    }

    /**
     * Updates the passed top ten list item and returns it.
     *
     * @param MyTopTenListItem $myTopTenListItem The top ten list item to update.
     * @param array            $inputData        The input data for the update.
     * @param User             $user             User instance.
     *
     * @return MyTopTenListItem
     * @throws \Exception
     */
    public function update(MyTopTenListItem $myTopTenListItem, array $inputData, User $user)
    {
        return $this->populateAndSave($myTopTenListItem, $inputData, $user);
    }

    /**
     * Create new item from existing one and return it.
     *
     * @param MyTopTenListItem $myTopTenListItem The top ten list item to update.
     * @param User             $user             User instance.
     *
     * @return array
     */
    public function forwardToNextDay(MyTopTenListItem $myTopTenListItem, User $user)
    {
        $myTopTenListItem->notify_at = Carbon::createFromFormat('Y-m-d H:i:s', $myTopTenListItem->notify_at, 'UTC')->addDay()->toDateTimeString();
        $myTopTenListItem->completed = false;

        $myTopTenListItem->save();
        $forDate = Carbon::createFromFormat('Y-m-d H:i:s', $myTopTenListItem->notify_at, 'UTC')->setTimezone($user->timezone)->toDateString();

        return [
            'task' => $myTopTenListItem,
            'forDate' => $forDate,
        ];
    }

    /**
     * Deletes a my top ten list item.
     *
     * @param MyTopTenListItem $myTopTenListItem The my top ten list item instance.
     *
     * @return Void
     */
    public function delete(MyTopTenListItem $myTopTenListItem)
    {
        $myTopTenListItem->delete();
    }

    /**
     * Sorts top ten list items in the passed order.
     *
     * @param array $inputData The new sort order.
     *
     * @return bool
     */
    public function sort(array $inputData)
    {
        $newOrder = array_map(
            function ($item) {
                return (int) $item['id'];
            },
            $inputData['items']
        );

        return $this->myTopTenListItemModel->updateSortOrder($newOrder);
    }

    /**
     * Clears top ten list items.
     *
     * @param array $inputData Ids of items to delete.
     *
     * @return bool
     */
    public function clear(array $inputData)
    {
        $itemIds = array_map(
            function ($item) {
                return (int) $item['id'];
            },
            $inputData['items']
        );

        return $this->myTopTenListItemModel->destroy($itemIds);
    }
}
