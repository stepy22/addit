<?php

namespace App\Widgets;

use App\Widgets\Widget;
use Creitive\Database\Eloquent\Model;
use Creitive\Image\Transformers\Thumbnail;
use Creitive\Models\Traits\ImageableTrait;
use Creitive\Models\Traits\SortableTrait;
use URL;

class HoroscopeSunsign extends Model
{
    const AQUARIUS = 'aquarius';
    const ARIES = 'aries';
    const CANCER = 'cancer';
    const CAPRICORN = 'capricorn';
    const GEMINI = 'gemini';
    const LEO = 'leo';
    const LIBRA = 'libra';
    const PISCES = 'pisces';
    const SAGITTARIUS = 'sagittarius';
    const SCORPIO = 'scorpio';
    const TAURUS = 'taurus';
    const VIRGO = 'virgo';

    public static $sunsigns = [
        self::ARIES,
        self::TAURUS,
        self::GEMINI,
        self::CANCER,
        self::LEO,
        self::VIRGO,
        self::LIBRA,
        self::SCORPIO,
        self::SAGITTARIUS,
        self::CAPRICORN,
        self::AQUARIUS,
        self::PISCES,
    ];

    /**
     * {@inheritDoc}
     */
    protected $table = 'horoscope_sunsigns';

    /**
     * {@inheritDoc}
     */
    public $timestamps = false;

    /**
     * {@inheritDoc}
     */
    protected $visible = [
        'id',
        'sunsign',
    ];
}
