<?php

namespace App\Widgets;

use Creitive\Database\Eloquent\Model;
use Creitive\Models\Traits\SortableTrait;

class ContactAddress extends Model
{
    use SortableTrait;

    /**
     * {@inheritDoc}
     */
    protected $table = 'widget_contact_addresses';

    /**
     * {@inheritDoc}
     */
    public $timestamps = false;

    /**
     * {@inheritDoc}
     */
    protected $visible = [
        'id',
        'address',
        'widget_contact_id',
        'sort',
    ];

    /**
     * Eloquent relationship: contact address belongs to a contact.
     *
     * @return BelogngsTo
     */
    public function contact()
    {
        return $this->belongsTo(Contact::class, 'widget_contact_id');
    }
}
