<?php

namespace App\Widgets\ChecklistItem;

use App\Widgets\ChecklistItem\Repository as WidgetChecklistItemRepository;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Routing\Router;
use URL;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerRoutePatterns($this->app['router'], $this->app);
        $this->registerFrontApiRoutes($this->app['router']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers the route patterns.
     *
     * @param Router    $router    A router.
     * @param Container $container A dependency container.
     *
     * @return void
     */
    protected function registerRoutePatterns(Router $router, Container $container)
    {
        $idRegex = $this->routePatternRegexes['id'];
        $slugRegex = $this->routePatternRegexes['slug'];

        $router->pattern('widgetChecklistItem', $idRegex);

        $router->bind('widgetChecklistItem', function ($value) use ($container, $idRegex) {
            $widgetChecklistItemRepository = $container->make(WidgetChecklistItemRepository::class);

            if (preg_match("/^{$idRegex}$/D", $value)) {
                $widgetChecklistItem = $widgetChecklistItemRepository->find($value);

                if ($widgetChecklistItem !== null) {
                    return $widgetChecklistItem;
                }
            }
        });
    }

    /**
     * Registers front API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1',
            'middleware' => ['api', 'auth'],
            'namespace' => 'App\Widgets\Http\Controllers\Api\V1\Front\ChecklistItem',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->put('widget-checklist-items/sort', 'Controller@sort');
        });

        $attributes['middleware'] = ['api', 'auth', 'widgetChecklistItem.access'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->delete('widget-checklist-items/{widgetChecklistItem}', 'Controller@delete');
            $router->put('widget-checklist-items/{widgetChecklistItem}', 'Controller@update');
        });

        $attributes['middleware'] = ['api', 'auth', 'widgetChecklist.access'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('widget-checklists/{widgetChecklist}/items', 'Controller@index');
            $router->post('widget-checklists/{widgetChecklist}/items', 'Controller@store');
        });
    }
}
