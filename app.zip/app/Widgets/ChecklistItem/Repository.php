<?php

namespace App\Widgets\ChecklistItem;

use App\Widgets\ChecklistItem;

class Repository
{
    /**
     * A ChecklistItem model instance.
     *
     * @var ChecklistItem
     */
    protected $checklistItem;

    /**
     * @param ChecklistItem $checklistItem A checklist item model instance.
     */
    public function __construct(ChecklistItem $checklistItem)
    {
        $this->checklistItemModel = $checklistItem;
    }

    /**
     * Gets all checklist items.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAll()
    {
        $query = $this->checklistItemModel->select('*');

        return $query->get();
    }

    /**
     * Finds the checklist item by ID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $id The checklistItem ID.
     *
     * @return ChecklistItem|null
     */
    public function find($id)
    {
        return $this->checklistItemModel->find($id);
    }

    /**
     * Finds widget checklist items by ids.
     *
     * @param array $ids The checklist item IDs.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getByIds(array $ids)
    {
        return $this->checklistItemModel
            ->whereIn('id', $ids)
            ->get();
    }

    /**
     * Finds the checklist item by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The checklist item ID.
     *
     * @return ChecklistItem
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->checklistItemModel->findOrFail($id);
    }

    /**
     * Updates the passed checklistItem and returns it.
     *
     * @param ChecklistItem $checklistItem The checklist item to update.
     * @param array         $inputData     The input data for the update.
     *
     * @return ChecklistItem
     */
    public function update(ChecklistItem $checklistItem, array $inputData)
    {
        return $this->populateAndSave($checklistItem, $inputData);
    }

    /**
     * Creates a checklist item and returns it.
     *
     * @param array $inputData The input data for the update.
     *
     * @return ChecklistItem
     */
    public function create(array $inputData)
    {
        $checklistItem = $this->checklistItemModel->newInstance();

        return $this->populateAndSave($checklistItem, $inputData);
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param ChecklistItem $checklistItem The checklist item to populate.
     * @param array         $inputData     The input data for the checklist item.
     *
     * @return ChecklistItem
     */
    protected function populate(ChecklistItem $checklistItem, array $inputData)
    {
        $checklistItem->title = array_get($inputData, 'title', $checklistItem->title);
        $checklistItem->widget_checklist_id = array_get($inputData, 'widget_checklist_id', $checklistItem->widget_checklist_id);
        $checklistItem->checked = array_get($inputData, 'checked', $checklistItem->checked);

        return $checklistItem;
    }

    /**
     * Deletes a checklistItem.
     *
     * @param ChecklistItem $checklistItem The checklist item instance.
     *
     * @return Void
     */
    public function delete(ChecklistItem $checklistItem)
    {
        $checklistItem->delete();
    }

    /**
     * Sorts checklist items in the passed order.
     *
     * @param array $inputData The new sort order.
     *
     * @return bool
     */
    public function sort(array $inputData)
    {
        $newOrder = array_map(
            function ($item) {
                return (int) $item['id'];
            },
            $inputData['items']
        );

        return $this->checklistItemModel->updateSortOrder($newOrder);
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param ChecklistItem $checklistItem The checklist item to populate and save.
     * @param array         $inputData     The input data.
     *
     * @return ChecklistItem
     */
    protected function populateAndSave(ChecklistItem $checklistItem, array $inputData)
    {
        $checklistItem = $this->populate($checklistItem, $inputData);

        $checklistItem->save();

        return $checklistItem;
    }
}
