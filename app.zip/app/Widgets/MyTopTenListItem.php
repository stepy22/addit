<?php

namespace App\Widgets;

use Creitive\Database\Eloquent\Model;
use Creitive\Models\Traits\SortableTrait;

class MyTopTenListItem extends Model
{
    use SortableTrait;

    const SHOW_LAST_AND_NEXT_DAYS_FOR_PRO_USER = 7;
    const SHOW_LAST_AND_NEXT_DAYS_FOR_REGULAR_USER = 1;

    /**
     * {@inheritDoc}
     */
    protected $table = 'my_top_ten_list_items';

    /**
     * {@inheritDoc}
     */
    protected $visible = [
        'id',
        'name',
        'notify_at',
        'notify_me',
        'notified',
        'completed',
        'sort',
        'widget_id',
    ];

    /**
     * {@inheritDoc}
     */
    public $timestamps = false;

    /**
     * {@inheritDoc}
     */
    protected $casts = [
        'notify_me' => 'bool',
        'completed' => 'bool',
        'notified' => 'bool',
    ];

    /**
     * Eloquent relationship: item belongs to a widget.
     *
     * @return BelogngsTo
     */
    public function widget()
    {
        return $this->belongsTo(Widget::class);
    }
}
