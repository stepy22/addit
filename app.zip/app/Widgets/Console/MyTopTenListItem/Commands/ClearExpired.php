<?php

namespace App\Widgets\Console\MyTopTenListItem\Commands;

use App\Widgets\MyTopTenListItem;
use Carbon\Carbon;
use Illuminate\Console\Command;

class ClearExpired extends Command
{
    /**
     * The console command name.
     *
     * @var string
     */
    protected $name = 'top-ten-list:clear-expired';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Clear expired tasks';

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        $daysOffset = MyTopTenListItem::SHOW_LAST_AND_NEXT_DAYS_FOR_PRO_USER;

        $timeStr = Carbon::now('UTC')
            ->setTimeFromTimeString('00:00:00')
            ->addDays(-$daysOffset)
            ->toDateTimeString();

        $expiredTaskIds = MyTopTenListItem::where('notify_at', '<=', $timeStr)->get()->pluck('id');

        MyTopTenListItem::destroy($expiredTaskIds);
    }
}
