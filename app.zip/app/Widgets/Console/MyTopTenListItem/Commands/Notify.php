<?php

namespace App\Widgets\Console\MyTopTenListItem\Commands;

use App\Notifications\Notification;
use App\Notifications\Notification\Repository as NotificationRepository;
use App\Widgets\MyTopTenListItem;
use App\Widgets\Widget\Notifier;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class Notify extends Command
{
    /**
     * The widget notifier.
     *
     * @var Notifier
     */
    protected $notifier;

    /**
     * The console command name.
     *
     * @var string
     */
    protected $name = 'top-ten-list:notify';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send notification to user for specific task';

    /**
     * @param Notifier $notifier The widget notifier instance.
     */
    public function __construct(Notifier $notifier)
    {
        parent::__construct();

        $this->notifier = $notifier;
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        $timeStr = Carbon::now('UTC')->toDateTimeString();

        $items = MyTopTenListItem::join('user_widgets', 'user_widgets.widget_id', '=', 'my_top_ten_list_items.widget_id')
            ->join('users', 'users.id', '=', 'user_widgets.user_id')
            ->where('my_top_ten_list_items.notify_at', '<=', $timeStr)
            ->where('my_top_ten_list_items.notified', false)
            ->where('my_top_ten_list_items.notify_me', true)
            ->select(
                'my_top_ten_list_items.id',
                'my_top_ten_list_items.name as task_name',
                'my_top_ten_list_items.notify_at',
                'users.id as user_id',
                'users.first_name as user_name',
                'users.email as user_email',
                'users.timezone as user_timezone'
            )
            ->get()
            ->each(function ($item) {
                $item->setVisible(['id', 'task_name', 'notify_at', 'user_name', 'user_email', 'user_timezone']);
            })
            ->reduce(function ($carry, $item) {
                if (!in_array($item->id, $carry['ids'])) {
                    $carry['ids'][] = $item->id;
                }

                if (!isset($carry['emails'][$item->user_email])) {
                    $carry['emails'][$item->user_email] = [
                        'user_name' => $item->user_name,
                        'tasks' => [],
                    ];
                }

                $carry['emails'][$item->user_email]['tasks'][] = $item->task_name;

                $time = Carbon::createFromFormat('Y-m-d H:i:s', $item->notify_at, 'UTC')->setTimezone($item->user_timezone)->toTimeString();

                $carry['notifications'][] = [
                    'user_id' => $item->user_id,
                    'message' => 'Reminder - ' . $item->task_name . ' due today by ' . $time,
                    'resource_id' => null,
                    'url' => null,
                    'type' => Notification::TYPE_TOP_TEN_LIST_ITEM,
                ];

                return $carry;
            }, ['ids' => [], 'emails' => [], 'notifications' => []]);

        DB::beginTransaction();

        try {
            $this->insertNotifications($items['notifications']);
            $this->updateNotified($items['ids']);

            DB::commit();

            $this->sendEmailNotification($items['emails']);
        } catch (\Exception $ex) {
            DB::rollBack();
        }
    }

    /**
     * Insert notifications in database.
     *
     * @param array $notifications Notifications array for insertion.
     */
    private function insertNotifications(array $notifications)
    {
        Notification::insert($notifications);
    }

    /**
     * Sends email to users.
     *
     * @param array $emails User emails config.
     */
    private function sendEmailNotification($emails)
    {
        foreach ($emails as $email => $value) {
            $this->notifier->sendMyTopTenTaskNotification($value['user_name'], $email, implode(', ', $value['tasks']), count($value['tasks']));
        }
    }

    /**
     * Update top ten list items.
     *
     * @param array $taskIds Ids of tasks for update.
     */
    private function updateNotified(array $taskIds)
    {
        DB::table('my_top_ten_list_items')->whereIn('id', $taskIds)->update(['notified' => true]);
    }
}
