<?php

namespace App\Widgets\Console\Birthday\Commands;

use App\Jobs\NotifyUser;
use App\Notifications\Notification;
use App\Notifications\Notification\Notifier as BaseNotifier;
use App\Widgets\Birthday;
use App\Widgets\Widget\Notifier;
use Carbon\Carbon;
use Doctrine\DBAL\Query\QueryBuilder;
use Illuminate\Console\Command;
use URL;

class Notify extends Command
{
    /**
     * The base notifier.
     *
     * @var BaseNotifier
     */
    protected $baseNotifier;

    /**
     * The console command name.
     *
     * @var string
     */
    protected $name = 'birthdays:notify';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send notification to user for birthdays';

    /**
     * @param BaseNotifier $baseNotifier The base notifier instance.
     */
    public function __construct(BaseNotifier $baseNotifier)
    {
        parent::__construct();

        $this->baseNotifier = $baseNotifier;
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        $usersBirthdayToNotify = $this->getBirthdaysWithUserToNotify();

        $this->notify($usersBirthdayToNotify);

        $this->updateNotified();
    }

    /**
     * Gets birthdays wich remind time
     *
     * @return QueryBuilder
     */
    private function birthdaysToNotify()
    {
        $now = Carbon::now('UTC')->toDateTimeString();

        return Birthday::whereNotNull('notify_at')
            ->where('notify_me', '=', true)
            ->where('notify_at', '<', $now);
    }

    /**
     * Gets birthdays with widget users to notify.
     *
     * @return mixed
     */
    private function getBirthdaysWithUserToNotify()
    {
        return $this->birthdaysToNotify()
            ->with('widget.users')
            ->get()
            ->each(function ($item) {
                $item->setVisible(['id', 'widget_id', 'name', 'date_of_birth', 'notify_at', 'widget']);
            });
    }

    /**
     * Update birthday notify_at, set next year.
     */
    private function updateNotified()
    {
        $this->birthdaysToNotify()->chunk(50, function ($birthdays) {
            foreach ($birthdays as $birthday) {
                $birthday->notify_at = Carbon::createFromFormat(
                    'Y-m-d H:i:s',
                    $birthday->notify_at
                )->addYear(1)->toDateTimeString();
                $birthday->update();
            }
        });
    }

    /**
     * Notify users.
     *
     * @param $usersBirthdayToNotify
     */
    private function notify($usersBirthdayToNotify)
    {
        foreach ($usersBirthdayToNotify as $birthUser) {
            NotifyUser::dispatch(
                $this->baseNotifier,
                trans('widgets.notifications.' . Notification::TYPE_BIRTHDAY_REMINDER, [
                    'user' => $birthUser->name,
                    'date_of_birth' => Carbon::createFromFormat('Y-m-d H:i:s', $birthUser->date_of_birth)->toDateString(),
                ]),
                Notification::TYPE_BIRTHDAY_REMINDER,
                $birthUser->widget->users,
                null,
                URL::action('App\Dashboards\Http\Controllers\Front\Dashboard\Controller@index', [], false)
            );
        }
    }
}
