<?php

namespace App\Widgets\Console\Event\Commands;

use App\Jobs\NotifyUser;
use App\Notifications\Notification;
use App\Notifications\Notification\Notifier as BaseNotifier;
use App\Widgets\Event;
use App\Widgets\Widget\Notifier;
use Carbon\Carbon;
use Doctrine\DBAL\Query\QueryBuilder;
use Illuminate\Console\Command;
use URL;

class Notify extends Command
{
    /**
     * The base notifier.
     *
     * @var BaseNotifier
     */
    protected $baseNotifier;

    /**
     * The console command name.
     *
     * @var string
     */
    protected $name = 'events:notify';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send notification to user for events';

    /**
     * @param BaseNotifier $baseNotifier The base notifier instance.
     */
    public function __construct(BaseNotifier $baseNotifier)
    {
        parent::__construct();

        $this->baseNotifier = $baseNotifier;
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        $usersEventToNotify = $this->getEventsWithUserToNotify();

        $this->notify($usersEventToNotify);

        $this->updateNotified();
    }

    private function eventsToNotify()
    {
        $now = Carbon::now('UTC')->toDateTimeString();

        return Event::whereNotNull('notify_at')
            ->where('notify_me', '=', true)
            ->where('notify_at', '<', $now);
    }

    /**
     * Gets events with widget users to notify.
     *
     * @return mixed
     */
    private function getEventsWithUserToNotify()
    {
        return $this->eventsToNotify()
            ->with('widget.users')
            ->get()
            ->each(function ($item) {
                $item->setVisible(['id', 'title', 'starts_at', 'notify_at', 'widget']);
            });
    }

    /**
     * Update birthday notify_at, set notified to true.
     */
    private function updateNotified()
    {
        $this->eventsToNotify()->chunk(50, function ($events) {
            foreach ($events as $event) {
                $event->notify_me = false;
                $event->notify_at = null;
                $event->update();
            }
        });
    }

    /**
     * Notify users.
     *
     * @param $usersEventToNotify
     */
    private function notify($usersEventToNotify)
    {
        foreach ($usersEventToNotify as $eventUser) {
            NotifyUser::dispatch(
                $this->baseNotifier,
                trans('widgets.notifications.' . Notification::TYPE_EVENT_REMINDER, [
                    'name' => $eventUser->title,
                    'starts_at' => $eventUser->starts_at,
                ]),
                Notification::TYPE_EVENT_REMINDER,
                $eventUser->widget->users,
                null,
                URL::action('App\Dashboards\Http\Controllers\Front\Dashboard\Controller@index', [], false)
            );
        }
    }
}
