<?php

namespace App\Widgets\RecipeFoodNutrition;

use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerFrontApiRoutes($this->app['router']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers front API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1/recipe-food-nutrition',
            'namespace' => 'App\Widgets\Http\Controllers\Api\V1\Front\RecipeFoodNutrition',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('recipes', 'Controller@findRecipeByQuery');
            $router->get('recipes/ingredients', 'Controller@findRecipeByIngredients');
            $router->get('recipes/{id}', 'Controller@getInstructions');
            $router->get('recipes-autocomplete', 'Controller@findRecipeAutocomplete');
            $router->get('ingredients-autocomplete', 'Controller@findIngredientsAutocomplete');
        });
    }
}
