<?php

namespace App\Widgets;

use Creitive\Database\Eloquent\Model;
use Creitive\Image\Transformers\Thumbnail;
use Creitive\Models\Traits\ImageableTrait;
use Creitive\Models\Traits\SortableTrait;
use URL;

class Birthday extends Model
{
    use ImageableTrait;
    use SortableTrait;

    /**
     * {@inheritDoc}
     */
    protected $table = 'widget_birthdays';

    /**
     * {@inheritDoc}
     */
    public $timestamps = false;

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = ['date_of_birth', 'notify_at'];

    /**
     * {@inheritDoc}
     */
    protected $visible = [
        'id',
        'name',
        'date_of_birth',
        'widget_id',
        'notify_me',
        'notify_at',
        'sort',
        'url_image_main_original',
        'url_image_main_small',
    ];

    /**
     * {@inheritDoc}
     */
    protected $appends = [
        'url_image_main_original',
        'url_image_main_small',
    ];

    /**
     * {@inheritDoc}
     */
    public function getImageConfiguration()
    {
        return [
            'versions' => [
                'main' => [
                    'original' => [],
                    'small' => [
                        [
                            'transformer' => Thumbnail::class,
                            'width' => 100,
                            'height' => 75,
                        ],
                    ],
                ],
            ],
        ];
    }

    /**
     * Gets the complete URL to the original main image.
     *
     * @return string
     */
    public function getUrlImageMainOriginalAttribute()
    {
        return URL::to($this->getImage('main', 'original'));
    }

    /**
     * Gets the complete URL to the small main image.
     *
     * @return string
     */
    public function getUrlImageMainSmallAttribute()
    {
        return URL::to($this->getImage('main', 'small'));
    }

    /**
     * Eloquent relationship: checklist belongs to a widget.
     *
     * @return BelogngsTo
     */
    public function widget()
    {
        return $this->belongsTo(Widget::class);
    }
}
