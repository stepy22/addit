<?php

namespace App\Widgets;

use App\Widgets\Widget;
use Creitive\Database\Eloquent\Model;

class YoutubeVideo extends Model
{
    /**
     * {@inheritDoc}
     */
    public $timestamps = false;

    /**
     * {@inheritDoc}
     */
    protected $table = 'widget_youtube_videos';

    /**
     * {@inheritDoc}
     */
    protected $visible = [
        'id',
        'video_id',
    ];

    /**
     * Eloquent relationship: youtube video belongs to a widget.
     *
     * @return BelogngsTo
     */
    public function widget()
    {
        return $this->belongsTo(Widget::class);
    }
}
