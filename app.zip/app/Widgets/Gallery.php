<?php

namespace App\Widgets;

use App\Widgets\GalleryImage;
use App\Widgets\Widget;
use Creitive\Database\Eloquent\Model;
use Creitive\Models\ChildImageableInterface;
use Creitive\Models\Traits\ChildImageableTrait;
use Creitive\Models\Traits\SortableTrait;

class Gallery extends Model implements ChildImageableInterface
{
    use ChildImageableTrait;
    use SortableTrait;

    /**
     * {@inheritDoc}
     */
    protected $table = 'widget_galleries';

    /**
     * {@inheritDoc}
     */
    protected $visible = [
        'id',
        'title',
        'widget_id',
        'sort',
        'images',
    ];

    /**
     * {@inheritDoc}
     */
    public function getChildImagesAttributeName()
    {
        return 'images';
    }

    /**
     * Eloquent relationship: checklist belongs to a widget.
     *
     * @return BelogngsTo
     */
    public function widget()
    {
        return $this->belongsTo(Widget::class);
    }

    /**
     * Eloquent relationship: gallery may have many images.
     *
     * @return BelogngsTo
     */
    public function images()
    {
        return $this->hasMany(GalleryImage::class, 'widget_gallery_id')->sorted();
    }
}
