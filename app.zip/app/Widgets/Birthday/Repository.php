<?php

namespace App\Widgets\Birthday;

use App\Widgets\Birthday;
use Carbon\Carbon;
use Hshn\Base64EncodedFile\HttpFoundation\File\Base64EncodedFile;
use Log;

class Repository
{
    /**
     * A Birthday model instance.
     *
     * @var Birthday
     */
    protected $birthday;

    /**
     * @param Birthday $birthday A event model instance.
     */
    public function __construct(Birthday $birthday)
    {
        $this->birthdayModel = $birthday;
    }

    /**
     * Gets all birthday.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAll()
    {
        $query = $this->birthdayModel->select('*');

        return $query->get();
    }

    /**
     * Finds the birthday by ID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $id The birthday ID.
     *
     * @return Birthday|null
     */
    public function find($id)
    {
        return $this->birthdayModel->find($id);
    }

    /**
     * Finds widget birthdays by ids.
     *
     * @param array $ids The birthday IDs.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getByIds(array $ids)
    {
        return $this->birthdayModel
            ->whereIn('id', $ids)
            ->get();
    }

    /**
     * Finds the birthday by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The birthday ID.
     *
     * @return Birthday
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->birthdayModel->findOrFail($id);
    }

    /**
     * Updates the passed birthday and returns it.
     *
     * @param Birthday $birthday  The birthday to update.
     * @param array    $inputData The input data for the update.
     *
     * @return Birthday
     * @throws \Exception
     */
    public function update(Birthday $birthday, array $inputData)
    {
        return $this->populateAndSave($birthday, $inputData);
    }

    /**
     * Creates a birthday and returns it.
     *
     * @param array $inputData The input data for the update.
     *
     * @return Birthday
     * @throws \Exception
     */
    public function create(array $inputData)
    {
        $event = $this->birthdayModel->newInstance();

        return $this->populateAndSave($event, $inputData);
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param Birthday $birthday  The birthday to populate.
     * @param array    $inputData The input data for the event.
     *
     * @return Birthday
     * @throws \Exception
     */
    protected function populate(Birthday $birthday, array $inputData)
    {
        $birthday->name = array_get($inputData, 'name', $birthday->name);
        $birthday->widget_id = array_get($inputData, 'widget_id', $birthday->widget_id);
        $birthday->notify_me = array_get($inputData, 'notify_me', $birthday->notify_me);

        $dateOfBirth = array_get($inputData, 'date_of_birth', '');
        $notifyAt = array_get($inputData, 'notify_at', '');

        if ($dateOfBirth) {
            $birthday->date_of_birth = Carbon::createFromFormat(trans('common.databaseDateFormat'), $dateOfBirth);
        }

        if ($notifyAt) {
            $birthday->notify_at = Carbon::createFromFormat(trans('common.databaseDateTimeFormat'), $notifyAt);
        } else {
            $birthday->notify_at = null;
        }

        if (isset($inputData['image_main'])) {
            if ($inputData['image_main'] instanceof UploadedFile) {
                $birthday->uploadImage($inputData['image_main'], 'main');
            } else {
                $file = new Base64EncodedFile($inputData['image_main']);
                $birthday->uploadImage($file->getPathname(), 'main');
            }
        }

        return $birthday;
    }

    /**
     * Deletes a birthday.
     *
     * @param Birthday $birthday The birthday instance.
     *
     * @return Void
     */
    public function delete(Birthday $birthday)
    {
        $birthday->delete();
    }

    /**
     * Sorts birthdays in the passed order.
     *
     * @param array $inputData The new sort order.
     *
     * @return bool
     */
    public function sort(array $inputData)
    {
        $newOrder = array_map(
            function ($item) {
                return (int) $item['id'];
            },
            $inputData['items']
        );

        return $this->birthdayModel->updateSortOrder($newOrder);
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param Birthday $birthday  The birthday to populate and save.
     * @param array    $inputData The input data.
     *
     * @return Birthday
     * @throws \Exception
     */
    protected function populateAndSave(Birthday $birthday, array $inputData)
    {
        $birthday = $this->populate($birthday, $inputData);

        $birthday->save();

        return $birthday;
    }
}
