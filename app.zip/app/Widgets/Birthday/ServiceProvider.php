<?php

namespace App\Widgets\Birthday;

use App\Widgets\Birthday;
use App\Widgets\Birthday\Repository as WidgetBirthdayRepository;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Routing\Router;
use URL;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerRoutePatterns($this->app['router'], $this->app);
        $this->registerFrontApiRoutes($this->app['router']);
        $this->attachCreatedEventHandler();
        $this->attachUpdatedEventHandler();
        $this->attachDeletedEventHandler();
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers the route patterns.
     *
     * @param Router    $router    A router.
     * @param Container $container A dependency container.
     *
     * @return void
     */
    protected function registerRoutePatterns(Router $router, Container $container)
    {
        $idRegex = $this->routePatternRegexes['id'];

        $router->pattern('widgetBirthday', $idRegex);

        $router->bind('widgetBirthday', function ($value) use ($container, $idRegex) {
            $widgetBirthdayRepository = $container->make(WidgetBirthdayRepository::class);

            if (preg_match("/^{$idRegex}$/D", $value)) {
                $widgetBirthday = $widgetBirthdayRepository->find($value);

                if ($widgetBirthday !== null) {
                    return $widgetBirthday;
                }
            }
        });
    }

    /**
     * Registers front API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1',
            'middleware' => ['api', 'auth'],
            'namespace' => 'App\Widgets\Http\Controllers\Api\V1\Front\Birthday',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->put('widget-birthdays/sort', 'Controller@sort');
        });

        $attributes['middleware'] = ['api', 'auth', 'widgetBirthday.access'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->put('widget-birthdays/{widgetBirthday}', 'Controller@update');
            $router->delete('widget-birthdays/{widgetBirthday}', 'Controller@delete');
        });

        $attributes['middleware'] = ['api', 'auth', 'widget.access'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('widgets/{widget}/birthdays', 'Controller@index');
        });

        $attributes['middleware'] = ['api', 'auth', 'widget.access:edit'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->post('widgets/{widget}/birthdays', 'Controller@store');
        });
    }

    /**
     * Attaches a handler to created birthday.
     *
     * @return void
     */
    public function attachCreatedEventHandler()
    {
        Birthday::created(function (Birthday $birthday) {
            $widget = $birthday->widget;
            $widget->birthdays_count = $widget->birthdays_count + 1;
            if ($birthday->notify_me && $birthday->notify_at) {
                $widget->birthdays_active_notifications_count = $widget->birthdays_active_notifications_count + 1;
            }

            $widget->save();
        });
    }

    /**
     * Attaches a handler to updated birthday.
     *
     * @return void
     */
    public function attachUpdatedEventHandler()
    {
        Birthday::updated(function (Birthday $birthday) {
            $widget = $birthday->widget;
            if ($birthday->notify_me && !$birthday->getOriginal('notify_me')) {
                $widget->birthdays_active_notifications_count = $widget->birthdays_active_notifications_count + 1;
            } else if (!$birthday->notify_me && $birthday->getOriginal('notify_me')) {
                $widget->birthdays_active_notifications_count = $widget->birthdays_active_notifications_count - 1;
            }
            $widget->save();
        });
    }

    /**
     * Attaches a handler to deleted birthday.
     *
     * @return void
     */
    public function attachDeletedEventHandler()
    {
        Birthday::deleted(function (Birthday $birthday) {
            $widget = $birthday->widget;
            $widget->birthdays_count = $widget->birthdays_count - 1;
            if ($birthday->notify_me && $birthday->notify_at) {
                $widget->birthdays_active_notifications_count = $widget->birthdays_active_notifications_count - 1;
            }

            $widget->save();
        });
    }
}
