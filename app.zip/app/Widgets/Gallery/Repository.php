<?php

namespace App\Widgets\Gallery;

use App\Widgets\Gallery;

class Repository
{
    /**
     * A Gallery model instance.
     *
     * @var Gallery
     */
    protected $gallery;

    /**
     * @param Gallery $gallery A gallery model instance.
     */
    public function __construct(Gallery $gallery)
    {
        $this->galleryModel = $gallery;
    }

    /**
     * Gets all galleries.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAll()
    {
        $query = $this->galleryModel->select('*');

        return $query->get();
    }

    /**
     * Finds the gallery by ID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $id The gallery ID.
     *
     * @return Gallery|null
     */
    public function find($id)
    {
        return $this->galleryModel->find($id);
    }

    /**
     * Finds widget galleries by ids.
     *
     * @param array $ids The gallery IDs.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getByIds(array $ids)
    {
        return $this->galleryModel
            ->whereIn('id', $ids)
            ->get();
    }

    /**
     * Finds the gallery by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The gallery ID.
     *
     * @return Gallery
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->galleryModel->findOrFail($id);
    }

    /**
     * Updates the passed gallery and returns it.
     *
     * @param Gallery $gallery   The gallery to update.
     * @param array   $inputData The input data for the update.
     *
     * @return Gallery
     */
    public function update(Gallery $gallery, array $inputData)
    {
        return $this->populateAndSave($gallery, $inputData);
    }

    /**
     * Creates a gallery and returns it.
     *
     * @param array $inputData The input data for the update.
     *
     * @return Gallery
     */
    public function create(array $inputData)
    {
        $gallery = $this->galleryModel->newInstance();

        return $this->populateAndSave($gallery, $inputData);
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param Gallery $gallery The gallery to populate.
     * @param array     $inputData The input data for the gallery.
     *
     * @return Gallery
     */
    protected function populate(Gallery $gallery, array $inputData)
    {
        $gallery->title = array_get($inputData, 'title', $gallery->title);
        $gallery->widget_id = array_get($inputData, 'widget_id', $gallery->widget_id);

        return $gallery;
    }

    /**
     * Deletes a gallery.
     *
     * @param Gallery $gallery The gallery instance.
     *
     * @return Void
     */
    public function delete(Gallery $gallery)
    {
        $gallery->delete();
    }

    /**
     * Sorts galleries in the passed order.
     *
     * @param array $inputData The new sort order.
     *
     * @return bool
     */
    public function sort(array $inputData)
    {
        $newOrder = array_map(
            function ($item) {
                return (int) $item['id'];
            },
            $inputData['items']
        );

        return $this->galleryModel->updateSortOrder($newOrder);
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param Gallery $gallery The gallery to populate and save.
     * @param array     $inputData The input data.
     *
     * @return Gallery
     */
    protected function populateAndSave(Gallery $gallery, array $inputData)
    {
        $gallery = $this->populate($gallery, $inputData);

        $gallery->save();

        return $gallery;
    }
}
