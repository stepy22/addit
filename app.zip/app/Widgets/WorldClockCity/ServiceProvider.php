<?php

namespace App\Widgets\WorldClockCity;

use App\Widgets\WorldClockCity\Repository as WidgetWorldClockCityRepository;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Routing\Router;
use URL;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerRoutePatterns($this->app['router'], $this->app);
        $this->registerFrontApiRoutes($this->app['router']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers the route patterns.
     *
     * @param Router    $router    A router.
     * @param Container $container A dependency container.
     *
     * @return void
     */
    protected function registerRoutePatterns(Router $router, Container $container)
    {
        $idRegex = $this->routePatternRegexes['id'];
        $slugRegex = $this->routePatternRegexes['slug'];

        $router->pattern('widgetWorldClockCity', $idRegex);

        $router->bind('widgetWorldClockCity', function ($value) use ($container, $idRegex) {
            $widgetWorldClockCityRepository = $container->make(WidgetWorldClockCityRepository::class);

            if (preg_match("/^{$idRegex}$/D", $value)) {
                $widgetWorldClockCity = $widgetWorldClockCityRepository->findOrFail($value);

                if ($widgetWorldClockCity !== null) {
                    return $widgetWorldClockCity;
                }
            }
        });
    }

    /**
     * Registers front API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1',
            'namespace' => 'App\Widgets\Http\Controllers\Api\V1\Front\WorldClockCity',
        ];

        $attributes['middleware'] = ['api', 'auth', 'widgetWorldClockCity.access'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->delete('world-clock-cities/{widgetWorldClockCity}', 'Controller@delete');
        });

        $attributes['middleware'] = ['api', 'auth', 'widget.access:edit'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->post('widgets/{widget}/world-clock-cities', 'Controller@store');
        });
    }
}
