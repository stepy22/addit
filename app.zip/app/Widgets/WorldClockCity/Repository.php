<?php

namespace App\Widgets\WorldClockCity;

use App\Auth\User;
use App\Widgets\WorldClockCity;

class Repository
{
    /**
     * A Youtube video model instance.
     *
     * @var WorldClockCity
     */
    protected $worldClockCity;

    /**
     * @param WorldClockCity $worldClockCity A world clock city model instance.
     */
    public function __construct(WorldClockCity $worldClockCity)
    {
        $this->worldClockCityModel = $worldClockCity;
    }

    /**
     * Finds the world clock city by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The world clock city ID.
     *
     * @return WorldClockCity
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->worldClockCityModel->findOrFail($id);
    }

    /**
     * Creates a world clock city and returns it.
     *
     * @param array $inputData The input data for the update.
     *
     * @return WorldClockCity
     */
    public function create(array $inputData)
    {
        $worldClockCity = $this->worldClockCityModel->newInstance();

        return $this->populateAndSave($worldClockCity, $inputData);
    }

    /**
     * Deletes a world clock city.
     *
     * @param WorldClockCity $worldClockCity The world clock city.
     *
     * @return WorldClockCity
     */
    public function delete(WorldClockCity $worldClockCity)
    {
        return $worldClockCity->delete();
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param WorldClockCity  $worldClockCity      The worldClockCity to populate.
     * @param array $inputData The input data for the worldClockCity.
     *
     * @return WorldClockCity
     */
    protected function populate(WorldClockCity $worldClockCity, array $inputData)
    {
        $worldClockCity->city = array_get($inputData, 'city', $worldClockCity->city);
        $worldClockCity->timezone = array_get($inputData, 'timezone', $worldClockCity->timezone);
        $worldClockCity->widget_id = array_get($inputData, 'widget_id', $worldClockCity->widget_id);

        return $worldClockCity;
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param WorldClockCity $worldClockCity The world clock city to populate and save.
     * @param array        $inputData    The input data.
     *
     * @return WorldClockCity
     */
    protected function populateAndSave(WorldClockCity $worldClockCity, array $inputData)
    {
        $worldClockCity = $this->populate($worldClockCity, $inputData);

        $worldClockCity->save();

        return $worldClockCity;
    }
}
