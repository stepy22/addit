<?php

namespace App\Widgets\Checklist;

use App\Widgets\Checklist;

class Repository
{
    /**
     * A Checklist model instance.
     *
     * @var Checklist
     */
    protected $checklist;

    /**
     * @param Checklist $checklist A checklist model instance.
     */
    public function __construct(Checklist $checklist)
    {
        $this->checklistModel = $checklist;
    }

    /**
     * Gets all checklists.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAll()
    {
        $query = $this->checklistModel->select('*');

        return $query->get();
    }

    /**
     * Finds the checklist by ID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $id The checklist ID.
     *
     * @return Checklist|null
     */
    public function find($id)
    {
        return $this->checklistModel->find($id);
    }

    /**
     * Finds widget checklists by ids.
     *
     * @param array $ids The checklist IDs.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getByIds(array $ids)
    {
        return $this->checklistModel
            ->whereIn('id', $ids)
            ->get();
    }

    /**
     * Finds the checklist by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The checklist ID.
     *
     * @return Checklist
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->checklistModel->findOrFail($id);
    }

    /**
     * Updates the passed checklist and returns it.
     *
     * @param Checklist $checklist The checklist to update.
     * @param array     $inputData The input data for the update.
     *
     * @return Checklist
     */
    public function update(Checklist $checklist, array $inputData)
    {
        return $this->populateAndSave($checklist, $inputData);
    }

    /**
     * Creates a checklist and returns it.
     *
     * @param array $inputData The input data for the update.
     *
     * @return Checklist
     */
    public function create(array $inputData)
    {
        $checklist = $this->checklistModel->newInstance();

        return $this->populateAndSave($checklist, $inputData);
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param Checklist $checklist The checklist to populate.
     * @param array     $inputData The input data for the checklist.
     *
     * @return Checklist
     */
    protected function populate(Checklist $checklist, array $inputData)
    {
        $checklist->title = array_get($inputData, 'title', $checklist->title);
        $checklist->widget_id = array_get($inputData, 'widget_id', $checklist->widget_id);

        return $checklist;
    }

    /**
     * Deletes a checklist.
     *
     * @param Checklist $checklist The checklist instance.
     *
     * @return Void
     */
    public function delete(Checklist $checklist)
    {
        $checklist->delete();
    }

    /**
     * Sorts checklists in the passed order.
     *
     * @param array $inputData The new sort order.
     *
     * @return bool
     */
    public function sort(array $inputData)
    {
        $newOrder = array_map(
            function ($item) {
                return (int) $item['id'];
            },
            $inputData['items']
        );

        return $this->checklistModel->updateSortOrder($newOrder);
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param Checklist $checklist The checklist to populate and save.
     * @param array     $inputData The input data.
     *
     * @return Checklist
     */
    protected function populateAndSave(Checklist $checklist, array $inputData)
    {
        $checklist = $this->populate($checklist, $inputData);

        $checklist->save();

        return $checklist;
    }
}
