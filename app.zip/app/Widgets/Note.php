<?php

namespace App\Widgets;

use Creitive\Database\Eloquent\Model;
use Creitive\Models\Traits\SortableTrait;

class Note extends Model
{
    use SortableTrait;

    /**
     * {@inheritDoc}
     */
    protected $table = 'widget_notes';

    /**
     * {@inheritDoc}
     */
    public $timestamps = false;

    /**
     * {@inheritDoc}
     */
    protected $visible = [
        'id',
        'title',
        'description',
        'widget_id',
        'sort',
    ];

    /**
     * Eloquent relationship: link belongs to a widget.
     *
     * @return BelogngsTo
     */
    public function widget()
    {
        return $this->belongsTo(Widget::class);
    }
}
