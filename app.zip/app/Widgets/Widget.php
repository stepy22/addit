<?php

namespace App\Widgets;

use App\Auth\User;
use App\Dashboards\Dashboard;
use App\WidgetBackgrounds\WidgetBackground;
use App\Widgets\Checklist;
use App\Widgets\EmbeddedPage;
use App\Widgets\Event;
use App\Widgets\File;
use App\Widgets\Gallery;
use App\Widgets\HoroscopeSunsign;
use App\Widgets\Link;
use App\Widgets\SchoolScheduleItem;
use App\Widgets\SocialBookmark;
use App\Widgets\UserWidget;
use App\Widgets\WorldClockCity;
use App\WidgetTypes\WidgetType;
use Creitive\Database\Eloquent\Model;
use Creitive\Image\Transformers\CropThumbnail;
use Creitive\Models\Traits\ImageableTrait;
use URL;

class Widget extends Model
{
    use ImageableTrait;

    /**
     * {@inheritDoc}
     */
    public function getImageConfiguration()
    {
        return [
            'versions' => [
                'main' => [
                    'large' => [
                        [
                            'transformer' => CropThumbnail::class,
                            'width' => 620,
                            'height' => 260,
                        ],
                    ],
                ],
            ],
        ];
    }

    /**
     * Gets the complete URL to the large main image.
     *
     * @return string|null
     */
    public function getUrlImageMainLargeAttribute()
    {
        return $this->image_main_large ? URL::to($this->getImage('main', 'large')) : null;
    }

    /**
     * Eloquent relationship: widget can belong to multiple users.
     *
     * @return BelongsToMany
     */
    public function users()
    {
        return $this->belongsToMany(User::class, 'user_widgets')
            ->withPivot([
                'id',
                'is_owner',
                'can_edit',
                'dashboard_id',
            ]);
    }

    /**
     * Eloquent relationship: widget can belong to multiple horoscope sunsigns.
     *
     * @return BelongsToMany
     */
    public function horoscopeSunsigns()
    {
        return $this->belongsToMany(HoroscopeSunsign::class, 'widgets_horoscope_sunsigns');
    }

    /**
     * Eloquent relationship: widget can be favourite for many users.
     *
     * @return BelongsToMany
     */
    public function favouriteForUsers()
    {
        return $this->belongsToMany(User::class, 'favourite_widgets');
    }

    /**
     * Eloquent relationship: widget belongs to a widget type.
     *
     * @return BelogngsTo
     */
    public function widgetType()
    {
        return $this->belongsTo(WidgetType::class);
    }

    /**
     * Eloquent relationship: widget may have many links.
     *
     * @return HasMany
     */
    public function links()
    {
        return $this->hasMany(Link::class)->sorted();
    }

    /**
     * Eloquent relationship: widget may have many files.
     *
     * @return HasMany
     */
    public function files()
    {
        return $this->hasMany(File::class)->sorted();
    }

    /**
     * Eloquent relationship: widget may have many events.
     *
     * @return HasMany
     */
    public function events()
    {
        return $this->hasMany(Event::class)->sorted();
    }

    /**
     * Eloquent relationship: widget may have many checklists.
     *
     * @return HasMany
     */
    public function checklists()
    {
        return $this->hasMany(Checklist::class)->sorted();
    }

    /**
     * Eloquent relationship: widget may have many galleries.
     *
     * @return HasMany
     */
    public function galleries()
    {
        return $this->hasMany(Gallery::class)->sorted();
    }

    /**
     * Eloquent relationship: widget may have many notes.
     *
     * @return HasMany
     */
    public function notes()
    {
        return $this->hasMany(Note::class)->sorted();
    }

    /**
     * Eloquent relationship: widget may have many birthdays.
     *
     * @return HasMany
     */
    public function birthdays()
    {
        return $this->hasMany(Birthday::class)->sorted();
    }

    /**
     * Eloquent relationship: widget may have many contacts.
     *
     * @return HasMany
     */
    public function contacts()
    {
        return $this->hasMany(Contact::class)->sorted();
    }

    /**
     * Eloquent relationship: widget may have many my insigh items.
     *
     * @return HasMany
     */
    public function myInsighItems()
    {
        return $this->hasMany(MyInsightItem::class)->sorted();
    }

    /**
     * Eloquent relationship: widget may have one Youtube video.
     *
     * @return HasOne
     */
    public function youtubeVideo()
    {
        return $this->hasOne(YoutubeVideo::class);
    }

    /**
     * Eloquent relationship: widget may have one embedded page.
     *
     * @return HasOne
     */
    public function embeddedPage()
    {
        return $this->hasOne(EmbeddedPage::class);
    }

    /**
     * Eloquent relationship: widget may have many school schedule items.
     *
     * @return HasMany
     */
    public function schoolScheduleItems()
    {
        return $this->hasMany(SchoolScheduleItem::class);
    }

    /**
     * Eloquent relationship: widget may have many social bookmarks.
     *
     * @return HasMany
     */
    public function socialBookmarks()
    {
        return $this->hasMany(SocialBookmark::class);
    }

    /**
     * Eloquent relationship: widget may have many world clock cities.
     *
     * @return HasMany
     */
    public function worldClockCities()
    {
        return $this->hasMany(WorldClockCity::class);
    }

    /**
     * Eloquent relationship: widget may have many my top ten list items.
     *
     * @return HasMany
     */
    public function myTopTenListItems()
    {
        return $this->hasMany(MyTopTenListItem::class);
    }

    /**
     * Eloquent relationship: widget may have many backgrounds.
     *
     * @return HasMany
     */
    public function backgrounds()
    {
        return $this->hasMany(WidgetBackground::class);
    }

    /**
     * Eloquent relationship: widget may have many user widgets.
     *
     * This is unconventional relation to pivot table, we need this to take
     * advantage of our image upload system and other stuff that is specific to
     * our CMS and it's not supported on laravel pivots by default (image
     * uploading, sorting...).
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function userWidgets()
    {
        return $this->hasMany(UserWidget::class);
    }

    /**
     * Returns an owner of the widget.
     *
     * @return \App\Auth\User
     */
    public function owner()
    {
        return $this->users->where('pivot.is_owner', 1)->first();
    }

    /**
     * Checks if widget is pinned to home dashboard for user.
     *
     * @param User $user User instance.
     *
     * @return boolean
     */
    public function isPinnedOnHomeForUser(User $user)
    {
        return $this->userWidgets->filter(function (UserWidget $userWidget) use ($user) {
            return $userWidget->pinned_to_home === true && $userWidget->user_id === $user->id;
        })->count() > 0;
    }

    /**
     * Checks if widget is favourites list for user.
     *
     * @param User $user User instance.
     *
     * @return boolean
     */
    public function isFavouriteForUser(User $user)
    {
        return $this->favouriteForUsers->where('id', $user->id)->count() === 1;
    }

    /**
     * Gets shared attribute, showing if widget is shared with someone.
     *
     * @return bool
     */
    public function getSharedAttribute()
    {
        return $this->users->unique()->count() > 1;
    }
}
