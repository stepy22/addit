<?php

namespace App\Widgets;

use App\Widgets\ChecklistItem;
use App\Widgets\Widget;
use Creitive\Database\Eloquent\Model;
use Creitive\Models\Traits\SortableTrait;

class Checklist extends Model
{
    use SortableTrait;

    /**
     * {@inheritDoc}
     */
    protected $table = 'widget_checklists';

    /**
     * {@inheritDoc}
     */
    protected $visible = [
        'id',
        'title',
        'widget_id',
        'sort',
        'items',
    ];

    /**
     * Eloquent relationship: checklist belongs to a widget.
     *
     * @return BelogngsTo
     */
    public function widget()
    {
        return $this->belongsTo(Widget::class);
    }

    /**
     * Eloquent relationship: checklist may have many items.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function items()
    {
        return $this->hasMany(ChecklistItem::class, 'widget_checklist_id')->sorted();
    }
}
