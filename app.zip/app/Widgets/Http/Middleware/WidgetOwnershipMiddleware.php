<?php

namespace App\Widgets\Http\Middleware;

use Cartalyst\Sentinel\Sentinel;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

class WidgetOwnershipMiddleware
{
    /**
     * The Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * @param Sentinel $sentinel Sentinel instance.
     */
    public function __construct(Sentinel $sentinel)
    {
        $this->sentinel = $sentinel;
    }

    /**
     * Handle an incoming request.
     *
     * @param Request  $request Request instance.
     * @param \Closure $next    Closure function.
     *
     * @return mixed
     *
     * @throws AccessDeniedHttpException
     */
    public function handle(Request $request, Closure $next)
    {
        $user = $this->sentinel->getUser();
        $widget = $request->route('widget');

        if (!$widget) {
            $userWidget = $request->route('userWidget');
            $widget = $userWidget->widget;
        }

        if (!$widget) {
            throw new AccessDeniedHttpException('You don\'t have access to this widget.');
        }

        $widget->load('users');

        if (!$widget->owner() || $widget->owner()->id !== $user->id) {
            throw new AccessDeniedHttpException('You don\'t have access to this widget.');
        }

        return $next($request);
    }
}
