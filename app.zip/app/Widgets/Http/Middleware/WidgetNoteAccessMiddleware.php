<?php

namespace App\Widgets\Http\Middleware;

use Cartalyst\Sentinel\Sentinel;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

class WidgetNoteAccessMiddleware
{
    /**
     * The Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * @param Sentinel $sentinel Sentinel instance.
     */
    public function __construct(Sentinel $sentinel)
    {
        $this->sentinel = $sentinel;
    }

    /**
     * Handle an incoming request.
     *
     * @param Request  $request Request instance.
     * @param \Closure $next    Closure function.
     *
     * @return mixed
     *
     * @throws AccessDeniedHttpException
     */
    public function handle(Request $request, Closure $next)
    {
        $user = $this->sentinel->getUser();
        $widgetNote = $request->route('widgetNote');
        $widget = $widgetNote->widget;

        $widget->load('users');

        $userWidget = $widget->users->where('id', $user->id)->first();

        if (!$userWidget || !$userWidget->pivot->can_edit) {
            throw new AccessDeniedHttpException('You don\'t have access to this widget.');
        }

        if ($widget->owner()->id !== $user->id && !$widget->owner()->isPro()) {
            throw new AccessDeniedHttpException('You don\'t have access to this widget.');
        }

        return $next($request);
    }
}
