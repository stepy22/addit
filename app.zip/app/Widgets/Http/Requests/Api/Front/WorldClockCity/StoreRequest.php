<?php

namespace App\Widgets\Http\Requests\Api\Front\WorldClockCity;

use App\Http\Requests\Request;
use Camroncade\Timezone\Timezone;

class StoreRequest extends Request
{
    /**
     * Timezones instance.
     *
     * @var Timezone
     */
    protected $timezones;

    /**
     * @param Timezone $timezones Timezones instance.
     */
    public function __construct(Timezone $timezones)
    {
        $this->timezones = $timezones;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $timezones = array_keys($this->timezones->timezoneList);

        $rules = [
            'timezone' => ['required', 'in:'.implode(',', $timezones)],
        ];

        return $rules;
    }
}
