<?php

namespace App\Widgets\Http\Requests\Api\Front\FileItem;

use App\Http\Requests\Request;

class StoreRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'name' => ['required', 'max:255'],
            // Base 64 encoding needs ~ 8 bits for each 6 bits of the original
            // data (or 4 bytes to store 3).
            // Since laravel detects base64 encoded file as a string and expects
            // number of characters to be given as file size limit we first
            // multiply our limit (5120 - 5mb) by 1024 to get value in
            // bytes and then calculate size of a encoded file for that limit.
            'file' => ['required', 'base_64_encoded_file:pdf,doc,docx,odt,rtf,txt,ods,xls,xlsx,pptx,ppt', 'max:'.(5120 * 1024) / 3 * 4],
        ];

        return $rules;
    }

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array
     */
    public function messages()
    {
        return array_dot(trans('widgetFileItems.errorMessages'));
    }
}
