<?php

namespace App\Widgets\Http\Requests\Api\Front\Checklist;

use App\Http\Requests\Request;
use App\Widgets\Checklist\Repository as WidgetChecklistRepository;
use Cartalyst\Sentinel\Sentinel;

class SortRequest extends Request
{
    /**
     * Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * WidgetChecklistRepository instance.
     *
     * @var WidgetChecklistRepository
     */
    protected $widgetChecklistRepository;

    /**
     * @param Sentinel                  $sentinel                  Sentinel instance.
     * @param WidgetChecklistRepository $widgetChecklistRepository Widget checklist repository instance.
     */
    public function __construct(Sentinel $sentinel, WidgetChecklistRepository $widgetChecklistRepository)
    {
        $this->sentinel = $sentinel;
        $this->widgetChecklistRepository = $widgetChecklistRepository;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $items = $this->get('items');
        $widgetChecklists = $this->widgetChecklistRepository->getByIds(array_column($items, 'id'));

        $widgetIds = $widgetChecklists->unique('widget_id')->pluck('widget_id')->toArray();

        // If links from more than one widget submitted deny.
        if (count($widgetIds) > 1) {
            return false;
        }

        if ($widgetChecklists->count() !== count($items)) {
            return false;
        }

        $widget = $widgetChecklists->first()->widget;
        $user = $this->sentinel->getUser();

        $userWidget = $user->widgets->where('id', $widget->id)->first();

        if (!$userWidget || !$userWidget->pivot->can_edit) {
            return false;
        }

        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'items' => ['required', 'array'],
        ];

        return $rules;
    }
}
