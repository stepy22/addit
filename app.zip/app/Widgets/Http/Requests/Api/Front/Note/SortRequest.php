<?php

namespace App\Widgets\Http\Requests\Api\Front\Note;

use App\Http\Requests\Request;
use App\Widgets\Note\Repository as WidgetNoteRepository;
use Cartalyst\Sentinel\Sentinel;

class SortRequest extends Request
{
    /**
     * Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * WidgetNoteRepository instance.
     *
     * @var WidgetNoteRepository
     */
    protected $widgetNoteRepository;

    /**
     * @param Sentinel             $sentinel             Sentinel instance.
     * @param WidgetNoteRepository $widgetNoteRepository Widget note repository instance.
     */
    public function __construct(Sentinel $sentinel, WidgetNoteRepository $widgetNoteRepository)
    {
        $this->sentinel = $sentinel;
        $this->widgetNoteRepository = $widgetNoteRepository;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $items = $this->get('items');
        $widgetNotes = $this->widgetNoteRepository->getByIds(array_column($items, 'id'));

        $widgetIds = $widgetNotes->unique('widget_id')->pluck('widget_id')->toArray();

        // If links from more than one widget submitted deny.
        if (count($widgetIds) > 1) {
            return false;
        }

        if ($widgetNotes->count() !== count($items)) {
            return false;
        }

        $widget = $widgetNotes->first()->widget;
        $user = $this->sentinel->getUser();

        $userWidget = $user->widgets->where('id', $widget->id)->first();

        if (!$userWidget || !$userWidget->pivot->can_edit) {
            return false;
        }

        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'items' => ['required', 'array'],
        ];

        return $rules;
    }
}
