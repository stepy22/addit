<?php

namespace App\Widgets\Http\Requests\Api\Front\ContactEmail;

use App\Http\Requests\Request;
use App\Widgets\ContactEmail\Repository as WidgetContactEmailRepository;
use Cartalyst\Sentinel\Sentinel;

class SortRequest extends Request
{
    /**
     * Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * WidgetContactEmailRepository instance.
     *
     * @var WidgetContactEmailRepository
     */
    protected $widgetContactEmailRepository;

    /**
     * @param Sentinel                     $sentinel                     Sentinel instance.
     * @param WidgetContactEmailRepository $widgetContactEmailRepository Widget checklist item repository instance.
     */
    public function __construct(Sentinel $sentinel, WidgetContactEmailRepository $widgetContactEmailRepository)
    {
        $this->sentinel = $sentinel;
        $this->widgetContactEmailRepository = $widgetContactEmailRepository;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $items = $this->get('items');
        $widgetContactEmails = $this->widgetContactEmailRepository->getByIds(array_column($items, 'id'));

        $widgetContactIds = $widgetContactEmails->unique('widget_contact_id')->pluck('widget_contact_id')->toArray();

        if (count($widgetContactIds) > 1) {
            return false;
        }

        if ($widgetContactEmails->count() !== count($items)) {
            return false;
        }

        $widget = $widgetContactEmails->first()->contact->widget;
        $user = $this->sentinel->getUser();

        $userWidget = $user->widgets->where('id', $widget->id)->first();

        if (!$userWidget || !$userWidget->pivot->can_edit) {
            return false;
        }

        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'items' => ['required', 'array'],
        ];

        return $rules;
    }
}
