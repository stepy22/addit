<?php

namespace App\Widgets\Http\Requests\Api\Front\ContactNumber;

use App\Http\Requests\Request;
use App\Widgets\ContactNumber\Repository as WidgetContactNumberRepository;
use Cartalyst\Sentinel\Sentinel;

class SortRequest extends Request
{
    /**
     * Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * WidgetContactNumberRepository instance.
     *
     * @var WidgetContactNumberRepository
     */
    protected $widgetContactNumberRepository;

    /**
     * @param Sentinel                      $sentinel                      Sentinel instance.
     * @param WidgetContactNumberRepository $widgetContactNumberRepository Widget contact number repository instance.
     */
    public function __construct(Sentinel $sentinel, WidgetContactNumberRepository $widgetContactNumberRepository)
    {
        $this->sentinel = $sentinel;
        $this->widgetContactNumberRepository = $widgetContactNumberRepository;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $items = $this->get('items');
        $widgetContactNumbers = $this->widgetContactNumberRepository->getByIds(array_column($items, 'id'));

        $widgetContactIds = $widgetContactNumbers->unique('widget_contact_id')->pluck('widget_contact_id')->toArray();

        if (count($widgetContactIds) > 1) {
            return false;
        }

        if ($widgetContactNumbers->count() !== count($items)) {
            return false;
        }

        $widget = $widgetContactNumbers->first()->contact->widget;
        $user = $this->sentinel->getUser();

        $userWidget = $user->widgets->where('id', $widget->id)->first();

        if (!$userWidget || !$userWidget->pivot->can_edit) {
            return false;
        }

        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'items' => ['required', 'array'],
        ];

        return $rules;
    }
}
