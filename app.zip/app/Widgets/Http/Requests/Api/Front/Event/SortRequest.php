<?php

namespace App\Widgets\Http\Requests\Api\Front\Event;

use App\Http\Requests\Request;
use App\Widgets\Event\Repository as WidgetEventRepository;
use Cartalyst\Sentinel\Sentinel;

class SortRequest extends Request
{
    /**
     * Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * WidgetEventRepository instance.
     *
     * @var WidgetEventRepository
     */
    protected $widgetEventRepository;

    /**
     * @param Sentinel              $sentinel              Sentinel instance.
     * @param WidgetEventRepository $widgetEventRepository Widget event repository instance.
     */
    public function __construct(Sentinel $sentinel, WidgetEventRepository $widgetEventRepository)
    {
        $this->sentinel = $sentinel;
        $this->widgetEventRepository = $widgetEventRepository;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $items = $this->get('items');
        $widgetEvents = $this->widgetEventRepository->getByIds(array_column($items, 'id'));

        $widgetIds = $widgetEvents->unique('widget_id')->pluck('widget_id')->toArray();

        // If links from more than one widget submitted deny.
        if (count($widgetIds) > 1) {
            return false;
        }

        if ($widgetEvents->count() !== count($items)) {
            return false;
        }

        $widget = $widgetEvents->first()->widget;
        $user = $this->sentinel->getUser();

        $userWidget = $user->widgets->where('id', $widget->id)->first();

        if (!$userWidget || !$userWidget->pivot->can_edit) {
            return false;
        }

        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'items' => ['required', 'array'],
        ];

        return $rules;
    }
}
