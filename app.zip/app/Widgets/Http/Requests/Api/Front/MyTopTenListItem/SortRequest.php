<?php

namespace App\Widgets\Http\Requests\Api\Front\MyTopTenListItem;

use App\Http\Requests\Request;
use App\Widgets\MyTopTenListItem\Repository as WidgetTopTenListItemRepository;
use Cartalyst\Sentinel\Sentinel;

class SortRequest extends Request
{
    /**
     * Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * WidgetTopTenListItemRepository instance.
     *
     * @var WidgetTopTenListItemRepository
     */
    protected $widgetTopTenListItemRepository;

    /**
     * @param Sentinel                       $sentinel                       Sentinel instance.
     * @param WidgetTopTenListItemRepository $widgetTopTenListItemRepository Widget top ten list item repository instance.
     */
    public function __construct(Sentinel $sentinel, WidgetTopTenListItemRepository $widgetTopTenListItemRepository)
    {
        $this->sentinel = $sentinel;
        $this->widgetTopTenListItemRepository = $widgetTopTenListItemRepository;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $items = $this->get('items');
        $widgetTopTenListItems = $this->widgetTopTenListItemRepository->getByIds(array_column($items, 'id'));

        $widgetIds = $widgetTopTenListItems->unique('widget_id')->pluck('widget_id')->toArray();

        // If links from more than one widget submitted deny.
        if (count($widgetIds) > 1) {
            return false;
        }

        if ($widgetTopTenListItems->count() !== count($items)) {
            return false;
        }

        $widget = $widgetTopTenListItems->first()->widget;
        $user = $this->sentinel->getUser();

        $userWidget = $user->widgets->where('id', $widget->id)->first();

        if (!$userWidget || !$userWidget->pivot->can_edit) {
            return false;
        }

        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'items' => ['required', 'array'],
        ];

        return $rules;
    }
}
