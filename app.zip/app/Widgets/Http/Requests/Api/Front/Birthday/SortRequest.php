<?php

namespace App\Widgets\Http\Requests\Api\Front\Birthday;

use App\Http\Requests\Request;
use App\Widgets\Birthday\Repository as WidgetBirthdayRepository;
use Cartalyst\Sentinel\Sentinel;

class SortRequest extends Request
{
    /**
     * Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * WidgetBirthdayRepository instance.
     *
     * @var WidgetBirthdayRepository
     */
    protected $widgetBirthdayRepository;

    /**
     * @param Sentinel                 $sentinel                 Sentinel instance.
     * @param WidgetBirthdayRepository $widgetBirthdayRepository Widget birthday repository instance.
     */
    public function __construct(Sentinel $sentinel, WidgetBirthdayRepository $widgetBirthdayRepository)
    {
        $this->sentinel = $sentinel;
        $this->widgetBirthdayRepository = $widgetBirthdayRepository;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $items = $this->get('items');
        $widgetBirthdays = $this->widgetBirthdayRepository->getByIds(array_column($items, 'id'));

        $widgetIds = $widgetBirthdays->unique('widget_id')->pluck('widget_id')->toArray();

        // If links from more than one widget submitted deny.
        if (count($widgetIds) > 1) {
            return false;
        }

        if ($widgetBirthdays->count() !== count($items)) {
            return false;
        }

        $widget = $widgetBirthdays->first()->widget;
        $user = $this->sentinel->getUser();

        $userWidget = $user->widgets->where('id', $widget->id)->first();

        if (!$userWidget || !$userWidget->pivot->can_edit) {
            return false;
        }

        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'items' => ['required', 'array'],
        ];

        return $rules;
    }
}
