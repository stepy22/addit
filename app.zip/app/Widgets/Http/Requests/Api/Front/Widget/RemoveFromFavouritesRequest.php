<?php

namespace App\Widgets\Http\Requests\Api\Front\Widget;

use App\Http\Requests\Request;
use App\WidgetTypes\WidgetType;
use Cartalyst\Sentinel\Sentinel;

class RemoveFromFavouritesRequest extends Request
{
    /**
     * Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * @param Sentinel $sentinel Sentinel instance.
     */
    public function __construct(Sentinel $sentinel)
    {
        $this->sentinel = $sentinel;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $user = $this->sentinel->getUser();
        $widget = $this->route('widget');

        // Check if user has access to passed widget.
        if ($widget->users->where('id', $user->id)->count() === 0) {
            return false;
        }

        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [];
    }
}
