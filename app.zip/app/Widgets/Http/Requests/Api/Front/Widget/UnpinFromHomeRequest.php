<?php

namespace App\Widgets\Http\Requests\Api\Front\Widget;

use App\Http\Requests\Request;
use App\WidgetTypes\WidgetType;
use Cartalyst\Sentinel\Sentinel;

class UnpinFromHomeRequest extends Request
{
    /**
     * Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * @param Sentinel $sentinel Sentinel instance.
     */
    public function __construct(Sentinel $sentinel)
    {
        $this->sentinel = $sentinel;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $user = $this->sentinel->getUser();
        $widget = $this->route('widget');

        $userWidget = $widget->userWidgets
            ->where('user_id', $user->id)
            ->where('pinned_to_home', true)
            ->first();

        // Check if user has access to passed user widget.
        if ($userWidget->user_id !== $user->id) {
            return false;
        }

        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [];
    }
}
