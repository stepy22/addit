<?php

namespace App\Widgets\Http\Requests\Api\Front\Widget;

use App\Auth\User;
use App\Http\Requests\Request;
use App\WidgetTypes\WidgetType;
use App\WidgetTypes\WidgetType\Repository as WidgetTypeRepository;
use Cartalyst\Sentinel\Sentinel;

class StoreRequest extends Request
{
    /**
     * Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * Widget type repository.
     *
     * @var WidgetTypeRepository
     */
    protected $widgetTypeRepository;

    /**
     * @param Sentinel             $sentinel             Sentinel instance.
     * @param WidgetTypeRepository $widgetTypeRepository WidgetTypeRepository.
     */
    public function __construct(Sentinel $sentinel, WidgetTypeRepository $widgetTypeRepository)
    {
        $this->sentinel = $sentinel;
        $this->widgetTypeRepository = $widgetTypeRepository;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $user = $this->sentinel->getUser();
        $dashboard = $this->route('dashboard');
        $userDashboard = $dashboard->userDashboards->where('user_id', $user->id)->first();

        // Check if user have access and edit permissions on dashboard.
        if (!$userDashboard || !$userDashboard->can_edit) {
            return false;
        }

        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'widget_type_id' => ['required', 'exists:widget_types,id'],
        ];

        return $rules;
    }
}
