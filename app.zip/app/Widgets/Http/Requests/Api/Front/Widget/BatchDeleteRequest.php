<?php

namespace App\Widgets\Http\Requests\Api\Front\Widget;

use App\Http\Requests\Request;
use App\Widgets\Widget\Repository as WidgetRepository;
use App\WidgetTypes\WidgetType;
use Cartalyst\Sentinel\Sentinel;

class BatchDeleteRequest extends Request
{
    /**
     * Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * Widget repository.
     *
     * @var WidgetRepository
     */
    protected $widgetRepository;

    /**
     * @param Sentinel         $sentinel         Sentinel instance.
     * @param WidgetRepository $widgetRepository Widget repository instance.
     */
    public function __construct(
        Sentinel $sentinel,
        WidgetRepository $widgetRepository
    ) {
        $this->sentinel = $sentinel;
        $this->widgetRepository = $widgetRepository;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $user = $this->sentinel->getUser();
        $widgetIds = $this->get('widget_ids');

        $widgets = $this->widgetRepository->getByIds($widgetIds);
        $widgets->load('users');

        foreach ($widgets as $widget) {
            if ($user->id !== $widget->owner()->id) {
                return false;
            }
        }

        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'widget_ids' => ['required', 'array', 'exists:widgets,id'],
        ];
    }
}
