<?php

namespace App\Widgets\Http\Requests\Api\Front\Widget;

use App\Http\Requests\Request;
use Cartalyst\Sentinel\Sentinel;

class BatchUnarchiveRequest extends Request
{
    /**
     * Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * @param Sentinel $sentinel Sentinel instance.
     */
    public function __construct(Sentinel $sentinel)
    {
        $this->sentinel = $sentinel;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $user = $this->sentinel->getUser();
        $user->load('widgets.users');
        $userWidgetIds = $this->get('user_widget_ids');

        foreach ($userWidgetIds as $pivotId) {
            $widget = $user->widgets
                ->where('pivot.id', $pivotId)
                ->where('pivot.archived_at', '!==', null)
                ->first();

            if (!$widget) {
                return false;
            }
        }

        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'user_widget_ids' => ['required', 'array', 'exists:user_widgets,id'],
        ];
    }
}
