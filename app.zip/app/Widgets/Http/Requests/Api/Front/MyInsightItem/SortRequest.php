<?php

namespace App\Widgets\Http\Requests\Api\Front\MyInsightItem;

use App\Http\Requests\Request;
use App\Widgets\MyInsightItem\Repository as WidgetMyInsightItemRepository;
use Cartalyst\Sentinel\Sentinel;

class SortRequest extends Request
{
    /**
     * Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * WidgetMyInsightItemRepository instance.
     *
     * @var WidgetMyInsightItemRepository
     */
    protected $widgetMyInsightItemRepository;

    /**
     * @param Sentinel                      $sentinel                      Sentinel instance.
     * @param WidgetMyInsightItemRepository $widgetMyInsightItemRepository Widget my insight item repository instance.
     */
    public function __construct(Sentinel $sentinel, WidgetMyInsightItemRepository $widgetMyInsightItemRepository)
    {
        $this->sentinel = $sentinel;
        $this->widgetMyInsightItemRepository = $widgetMyInsightItemRepository;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $items = $this->get('items');
        $widgetMyInsightItems = $this->widgetMyInsightItemRepository->getByIds(array_column($items, 'id'));

        $widgetIds = $widgetMyInsightItems->unique('widget_id')->pluck('widget_id')->toArray();

        // If links from more than one widget submitted deny.
        if (count($widgetIds) > 1) {
            return false;
        }

        if ($widgetMyInsightItems->count() !== count($items)) {
            return false;
        }

        $widget = $widgetMyInsightItems->first()->widget;
        $user = $this->sentinel->getUser();

        $userWidget = $user->widgets->where('id', $widget->id)->first();

        if (!$userWidget || !$userWidget->pivot->can_edit) {
            return false;
        }

        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'items' => ['required', 'array'],
        ];

        return $rules;
    }
}
