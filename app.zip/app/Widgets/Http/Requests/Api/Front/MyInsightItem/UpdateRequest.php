<?php

namespace App\Widgets\Http\Requests\Api\Front\MyInsightItem;

use App\Http\Requests\Request;

class UpdateRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'subject' => ['required', 'string', 'max:191'],
            'description' => ['nullable', 'string', 'max:500'],
        ];

        return $rules;
    }
}
