<?php

namespace App\Widgets\Http\Requests\Api\Front\UserWidget;

use App\Http\Requests\Request;
use Cartalyst\Sentinel\Sentinel;

class DeleteRequest extends Request
{
    /**
     * Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * @param Sentinel $sentinel Sentinel instance.
     */
    public function __construct(Sentinel $sentinel)
    {
        $this->sentinel = $sentinel;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $user = $this->sentinel->getUser();
        $userWidget = $this->route('userWidget');
        $userWidget->load('widget.users');

        $widget = $userWidget->widget;

        // Even though this should never happed, we should check anyway.
        // Dashboard owner can't be deleted.
        if ($userWidget->is_owner) {
            return false;
        }

        if ($widget->owner()->id !== $user->id) {
            if ($userWidget->user_id === $user->id) {
                return true;
            }

            return false;
        }

        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [];
    }
}
