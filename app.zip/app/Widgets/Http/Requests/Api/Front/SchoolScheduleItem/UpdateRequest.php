<?php

namespace App\Widgets\Http\Requests\Api\Front\SchoolScheduleItem;

use App\Http\Requests\Request;
use App\Widgets\SchoolScheduleItem;

class UpdateRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $dayOptions = [
            SchoolScheduleItem::DAY_MONDAY,
            SchoolScheduleItem::DAY_TUESDAY,
            SchoolScheduleItem::DAY_WEDNESDAY,
            SchoolScheduleItem::DAY_THURSDAY,
            SchoolScheduleItem::DAY_FRIDAY,
            SchoolScheduleItem::DAY_SATURDAY,
            SchoolScheduleItem::DAY_SUNDAY,
        ];

        $rules = [
            'day' => ['required', 'in:'.implode(',', $dayOptions)],
            'class_name' => ['required'],
            'starts_at' => ['required', 'date_format:'.trans('common.timeFormat')],
            'ends_at' => ['required', 'date_format:'.trans('common.timeFormat')],
        ];

        return $rules;
    }
}
