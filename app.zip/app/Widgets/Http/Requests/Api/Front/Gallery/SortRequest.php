<?php

namespace App\Widgets\Http\Requests\Api\Front\Gallery;

use App\Http\Requests\Request;
use App\Widgets\Gallery\Repository as WidgetGalleryRepository;
use Cartalyst\Sentinel\Sentinel;

class SortRequest extends Request
{
    /**
     * Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * WidgetGalleryRepository instance.
     *
     * @var WidgetGalleryRepository
     */
    protected $widgetGalleryRepository;

    /**
     * @param Sentinel                $sentinel                Sentinel instance.
     * @param WidgetGalleryRepository $widgetGalleryRepository Widget gallery repository instance.
     */
    public function __construct(Sentinel $sentinel, WidgetGalleryRepository $widgetGalleryRepository)
    {
        $this->sentinel = $sentinel;
        $this->widgetGalleryRepository = $widgetGalleryRepository;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $items = $this->get('items');
        $widgetGalleries = $this->widgetGalleryRepository->getByIds(array_column($items, 'id'));

        $widgetIds = $widgetGalleries->unique('widget_id')->pluck('widget_id')->toArray();

        // If links from more than one widget submitted deny.
        if (count($widgetIds) > 1) {
            return false;
        }

        if ($widgetGalleries->count() !== count($items)) {
            return false;
        }

        $widget = $widgetGalleries->first()->widget;
        $user = $this->sentinel->getUser();

        $userWidget = $user->widgets->where('id', $widget->id)->first();

        if (!$userWidget || !$userWidget->pivot->can_edit) {
            return false;
        }

        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'items' => ['required', 'array'],
        ];

        return $rules;
    }
}
