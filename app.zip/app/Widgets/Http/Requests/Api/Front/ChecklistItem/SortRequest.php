<?php

namespace App\Widgets\Http\Requests\Api\Front\ChecklistItem;

use App\Http\Requests\Request;
use App\Widgets\ChecklistItem\Repository as WidgetChecklistItemRepository;
use Cartalyst\Sentinel\Sentinel;

class SortRequest extends Request
{
    /**
     * Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * WidgetChecklistItemRepository instance.
     *
     * @var WidgetChecklistItemRepository
     */
    protected $widgetChecklistItemRepository;

    /**
     * @param Sentinel                      $sentinel                      Sentinel instance.
     * @param WidgetChecklistItemRepository $widgetChecklistItemRepository Widget checklist item repository instance.
     */
    public function __construct(Sentinel $sentinel, WidgetChecklistItemRepository $widgetChecklistItemRepository)
    {
        $this->sentinel = $sentinel;
        $this->widgetChecklistItemRepository = $widgetChecklistItemRepository;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $items = $this->get('items');
        $widgetChecklistItems = $this->widgetChecklistItemRepository->getByIds(array_column($items, 'id'));

        $widgetChecklistIds = $widgetChecklistItems->unique('widget_checklist_id')->pluck('widget_checklist_id')->toArray();

        // If images from more than one checklist are submitted deny.
        if (count($widgetChecklistIds) > 1) {
            return false;
        }

        if ($widgetChecklistItems->count() !== count($items)) {
            return false;
        }

        $widget = $widgetChecklistItems->first()->checklist->widget;
        $user = $this->sentinel->getUser();

        $userWidget = $user->widgets->where('id', $widget->id)->first();

        if (!$userWidget || !$userWidget->pivot->can_edit) {
            return false;
        }

        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'items' => ['required', 'array'],
        ];

        return $rules;
    }
}
