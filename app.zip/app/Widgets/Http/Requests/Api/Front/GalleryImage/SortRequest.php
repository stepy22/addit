<?php

namespace App\Widgets\Http\Requests\Api\Front\GalleryImage;

use App\Http\Requests\Request;
use App\Widgets\GalleryImage\Repository as WidgetGalleryImageRepository;
use Cartalyst\Sentinel\Sentinel;

class SortRequest extends Request
{
    /**
     * Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * WidgetGalleryImageRepository instance.
     *
     * @var WidgetGalleryImageRepository
     */
    protected $widgetGalleryImageRepository;

    /**
     * @param Sentinel                     $sentinel                     Sentinel instance.
     * @param WidgetGalleryImageRepository $widgetGalleryImageRepository Widget gallery repository instance.
     */
    public function __construct(Sentinel $sentinel, WidgetGalleryImageRepository $widgetGalleryImageRepository)
    {
        $this->sentinel = $sentinel;
        $this->widgetGalleryImageRepository = $widgetGalleryImageRepository;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $items = $this->get('items');
        $widgetGalleryImages = $this->widgetGalleryImageRepository->getByIds(array_column($items, 'id'));

        $widgetGalleryIds = $widgetGalleryImages->unique('widget_gallery_id')->pluck('widget_gallery_id')->toArray();

        // If images from more than one gallery are submitted deny.
        if (count($widgetGalleryIds) > 1) {
            return false;
        }

        if ($widgetGalleryImages->count() !== count($items)) {
            return false;
        }

        $widget = $widgetGalleryImages->first()->gallery->widget;
        $user = $this->sentinel->getUser();

        $userWidget = $user->widgets->where('id', $widget->id)->first();

        if (!$userWidget || !$userWidget->pivot->can_edit) {
            return false;
        }

        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'items' => ['required', 'array'],
        ];

        return $rules;
    }
}
