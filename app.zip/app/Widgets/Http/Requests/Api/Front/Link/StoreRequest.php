<?php

namespace App\Widgets\Http\Requests\Api\Front\Link;

use App\Http\Requests\Request;

class StoreRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'url' => ['required', 'url'],
            // Base 64 encoding needs ~ 8 bits for each 6 bits of the original
            // data (or 4 bytes to store 3).
            // Since laravel detects base64 encoded file as a string and expects
            // number of characters to be given as file size limit we first
            // multiply our limit (10240 - 10mb) by 1024 to get value in
            // bytes and then calculate size of a encoded file for that limit.
            'image_main' => ['base_64_encoded_image', 'max:'.(10240 * 1024) / 3 * 4],
            'title' => ['required', 'max:255'],
        ];

        return $rules;
    }

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array
     */
    public function messages()
    {
        return array_dot(trans('widgetLinks.errorMessages'));
    }
}
