<?php

namespace App\Widgets\Http\Requests\Api\Front\Link;

use App\Http\Requests\Request;
use App\Widgets\Link\Repository as WidgetLinkRepository;
use Cartalyst\Sentinel\Sentinel;

class SortRequest extends Request
{
    /**
     * Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * WidgetLinkRepository instance.
     *
     * @var WidgetLinkRepository
     */
    protected $widgetLinkRepository;

    /**
     * @param Sentinel             $sentinel             Sentinel instance.
     * @param WidgetLinkRepository $widgetLinkRepository Widget link repository instance.
     */
    public function __construct(Sentinel $sentinel, WidgetLinkRepository $widgetLinkRepository)
    {
        $this->sentinel = $sentinel;
        $this->widgetLinkRepository = $widgetLinkRepository;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $items = $this->get('items');
        $widgetLinks = $this->widgetLinkRepository->getByIds(array_column($items, 'id'));

        $widgetIds = $widgetLinks->unique('widget_id')->pluck('widget_id')->toArray();

        // If links from more than one widget submitted deny.
        if (count($widgetIds) > 1) {
            return false;
        }

        if ($widgetLinks->count() !== count($items)) {
            return false;
        }

        $widget = $widgetLinks->first()->widget;
        $user = $this->sentinel->getUser();

        $userWidget = $user->widgets->where('id', $widget->id)->first();

        if (!$userWidget || !$userWidget->pivot->can_edit) {
            return false;
        }

        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'items' => ['required', 'array'],
        ];

        return $rules;
    }
}
