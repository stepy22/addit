<?php

namespace App\Widgets\Http\Requests\Api\Front\SocialBookmark;

use App\Http\Requests\Request;
use App\Widgets\SocialBookmark;

class StoreRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $platformOptions = [
            SocialBookmark::PLATFORM_FACEBOOK,
            SocialBookmark::PLATFORM_INSTAGRAM,
            SocialBookmark::PLATFORM_LINKEDIN,
            SocialBookmark::PLATFORM_TWITTER,
        ];

        $rules = [
            'platform' => ['required', 'in:'.implode(',', $platformOptions)],
            'user_id' => ['required'],
        ];

        return $rules;
    }
}
