<?php

namespace App\Widgets\Http\Requests\Api\Front\ContactAddress;

use App\Http\Requests\Request;
use App\Widgets\ContactAddress\Repository as WidgetContactAddressRepository;
use Cartalyst\Sentinel\Sentinel;

class SortRequest extends Request
{
    /**
     * Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * WidgetContactAddressRepository instance.
     *
     * @var WidgetContactAddressRepository
     */
    protected $widgetContactAddressRepository;

    /**
     * @param Sentinel                       $sentinel                       Sentinel instance.
     * @param WidgetContactAddressRepository $widgetContactAddressRepository Widget contact address repository instance.
     */
    public function __construct(Sentinel $sentinel, WidgetContactAddressRepository $widgetContactAddressRepository)
    {
        $this->sentinel = $sentinel;
        $this->widgetContactAddressRepository = $widgetContactAddressRepository;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $items = $this->get('items');
        $widgetContactAddresss = $this->widgetContactAddressRepository->getByIds(array_column($items, 'id'));

        $widgetContactsIds = $widgetContactAddresss->unique('widget_contact_id')->pluck('widget_contact_id')->toArray();

        if (count($widgetContactsIds) > 1) {
            return false;
        }

        if ($widgetContactAddresss->count() !== count($items)) {
            return false;
        }

        $widget = $widgetContactAddresss->first()->contact->widget;
        $user = $this->sentinel->getUser();

        $userWidget = $user->widgets->where('id', $widget->id)->first();

        if (!$userWidget || !$userWidget->pivot->can_edit) {
            return false;
        }

        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'items' => ['required', 'array'],
        ];

        return $rules;
    }
}
