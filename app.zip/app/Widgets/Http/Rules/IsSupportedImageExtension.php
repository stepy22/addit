<?php

namespace App\Widgets\Http\Rules;

use Illuminate\Contracts\Validation\Rule;

class IsSupportedImageExtension implements Rule
{
    private $supportedImageExtensions = [
        'jpg', 'jpeg', 'png', 'bmp', 'gif', 'svg',
    ];

    /**
     * Create a new rule instance.
     *
     * @return void
     */
    public function __construct()
    {
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string $attribute Attribute name.
     * @param  mixed  $value     Attribute value.
     * @return bool
     */
    public function passes($attribute, $value)
    {
        if (empty($value)) {
            return false;
        }

        $pathinfo = pathinfo(explode("?", $value)[0]);
        if (!array_key_exists('extension', $pathinfo)) {
            return false;
        }

        return in_array($pathinfo['extension'], $this->supportedImageExtensions);
    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return trans('validation.unsupported_image_extension');
    }
}
