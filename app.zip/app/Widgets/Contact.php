<?php

namespace App\Widgets;

use Creitive\Database\Eloquent\Model;
use Creitive\Image\Transformers\Thumbnail;
use Creitive\Models\Traits\ImageableTrait;
use Creitive\Models\Traits\SortableTrait;
use URL;

class Contact extends Model
{
    use ImageableTrait;
    use SortableTrait;

    /**
     * {@inheritDoc}
     */
    protected $table = 'widget_contacts';

    /**
     * {@inheritDoc}
     */
    public $timestamps = false;

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = ['date_of_birth'];

    /**
     * {@inheritDoc}
     */
    protected $visible = [
        'id',
        'name',
        'date_of_birth',
        'work_number',
        'profession',
        'mobile_number',
        'company',
        'widget_id',
        'addresses',
        'emails',
        'numbers',
        'url_image_main_original',
        'url_image_main_small',
        'sort',
    ];

    /**
     * {@inheritDoc}
     */
    protected $appends = [
        'url_image_main_original',
        'url_image_main_small',
    ];

    /**
     * {@inheritDoc}
     */
    public function getImageConfiguration()
    {
        return [
            'versions' => [
                'main' => [
                    'original' => [],
                    'small' => [
                        [
                            'transformer' => Thumbnail::class,
                            'width' => 100,
                            'height' => 75,
                        ],
                    ],
                ],
            ],
        ];
    }

    /**
     * Gets the complete URL to the original main image.
     *
     * @return string
     */
    public function getUrlImageMainOriginalAttribute()
    {
        return URL::to($this->getImage('main', 'original'));
    }

    /**
     * Gets the complete URL to the small main image.
     *
     * @return string
     */
    public function getUrlImageMainSmallAttribute()
    {
        return URL::to($this->getImage('main', 'small'));
    }

    /**
     * Eloquent relationship: checklist belongs to a widget.
     *
     * @return BelogngsTo
     */
    public function widget()
    {
        return $this->belongsTo(Widget::class);
    }

    /**
     * Eloquent relationship: contact may have many addresses.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function addresses()
    {
        return $this->hasMany(ContactAddress::class, 'widget_contact_id')->sorted();
    }

    /**
     * Eloquent relationship: contact may have many emails.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function emails()
    {
        return $this->hasMany(ContactEmail::class, 'widget_contact_id')->sorted();
    }

    /**
     * Eloquent relationship: contact may have many numbers.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function numbers()
    {
        return $this->hasMany(ContactNumber::class, 'widget_contact_id')->sorted();
    }
}
