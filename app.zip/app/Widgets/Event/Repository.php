<?php

namespace App\Widgets\Event;

use App\Auth\User;
use App\Events\Event\Repository as EventRepository;
use App\Widgets\Event;
use Carbon\Carbon;
use Hshn\Base64EncodedFile\HttpFoundation\File\Base64EncodedFile;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\QueryException;
use Illuminate\Support\Collection;
use Log;

class Repository
{
    /**
     * A Event model instance.
     *
     * @var Event
     */
    protected $event;

    /**
     * @param Event $event A event model instance.
     */
    public function __construct(Event $event)
    {
        $this->eventModel = $event;
    }

    /**
     * Gets all events.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAll()
    {
        $query = $this->eventModel->select('*');

        return $query->get();
    }

    /**
     * Finds the event by ID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $id The event ID.
     *
     * @return Event|null
     */
    public function find($id)
    {
        return $this->eventModel->find($id);
    }

    /**
     * Finds widget events by ids.
     *
     * @param array $ids The event IDs.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getByIds(array $ids)
    {
        return $this->eventModel
            ->whereIn('id', $ids)
            ->get();
    }

    /**
     * Finds the event by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The event ID.
     *
     * @return Event
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->eventModel->findOrFail($id);
    }

    /**
     * Updates the passed event and returns it.
     *
     * @param Event $event     The event to update.
     * @param array $inputData The input data for the update.
     *
     * @return Event
     */
    public function update(Event $event, array $inputData)
    {
        return $this->populateAndSave($event, $inputData);
    }

    /**
     * Creates a event and returns it.
     *
     * @param array $inputData The input data for the update.
     *
     * @return Event
     */
    public function create(array $inputData)
    {
        $event = $this->eventModel->newInstance();

        return $this->populateAndSave($event, $inputData);
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param Event  $event      The event to populate.
     * @param array $inputData The input data for the event.
     *
     * @return Event
     */
    protected function populate(Event $event, array $inputData)
    {
        $event->title = array_get($inputData, 'title', $event->title);
        $event->description = array_get($inputData, 'description', $event->description);
        $event->widget_id = array_get($inputData, 'widget_id', $event->widget_id);
        $event->notify_me = array_get($inputData, 'notify_me', $event->notify_me);

        $startsAt = array_get($inputData, 'starts_at', '');
        $endsAt = array_get($inputData, 'ends_at', '');
        $notifyAt = array_get($inputData, 'notify_at', '');

        if ($startsAt) {
            $event->starts_at = Carbon::createFromFormat(trans('common.databaseDateTimeFormat'), $startsAt);
        } else {
            $event->starts_at = null;
        }

        if ($endsAt) {
            $event->ends_at = Carbon::createFromFormat(trans('common.databaseDateTimeFormat'), $endsAt);
        } else {
            $event->ends_at = null;
        }

        if ($notifyAt) {
            $event->notify_at = Carbon::createFromFormat(trans('common.databaseDateTimeFormat'), $notifyAt);
        } else {
            $event->notify_at = null;
        }

        if (isset($inputData['image_main'])) {
            if ($inputData['image_main'] instanceof UploadedFile) {
                $event->uploadImage($inputData['image_main'], 'main');
            } else {
                $file = new Base64EncodedFile($inputData['image_main']);
                $event->uploadImage($file->getPathname(), 'main');
            }
        }

        return $event;
    }

    /**
     * Deletes a event.
     *
     * @param Event $event The event instance.
     *
     * @return Void
     */
    public function delete(Event $event)
    {
        $event->delete();
    }

    /**
     * Sorts events in the passed order.
     *
     * @param array $inputData The new sort order.
     *
     * @return bool
     */
    public function sort(array $inputData)
    {
        $newOrder = array_map(
            function ($item) {
                return (int) $item['id'];
            },
            $inputData['items']
        );

        return $this->eventModel->updateSortOrder($newOrder);
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param Event  $event      The event to populate and save.
     * @param array $inputData The input data.
     *
     * @return Event
     */
    protected function populateAndSave(Event $event, array $inputData)
    {
        $event = $this->populate($event, $inputData);

        $event->save();

        return $event;
    }
}
