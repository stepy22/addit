<?php

namespace App\Widgets\Event;

use App\Widgets\Event;
use App\Widgets\Event\Repository as WidgetEventRepository;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Routing\Router;
use URL;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerRoutePatterns($this->app['router'], $this->app);
        $this->registerFrontApiRoutes($this->app['router']);
        $this->attachCreatedEventHandler();
        $this->attachUpdatedEventHandler();
        $this->attachDeletedEventHandler();
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers the route patterns.
     *
     * @param Router    $router    A router.
     * @param Container $container A dependency container.
     *
     * @return void
     */
    protected function registerRoutePatterns(Router $router, Container $container)
    {
        $idRegex = $this->routePatternRegexes['id'];
        $slugRegex = $this->routePatternRegexes['slug'];

        $router->pattern('widgetEvent', $idRegex);

        $router->bind('widgetEvent', function ($value) use ($container, $idRegex) {
            $widgetEventRepository = $container->make(WidgetEventRepository::class);

            if (preg_match("/^{$idRegex}$/D", $value)) {
                $widgetEvent = $widgetEventRepository->find($value);

                if ($widgetEvent !== null) {
                    return $widgetEvent;
                }
            }
        });
    }

    /**
     * Registers front API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1',
            'middleware' => ['api', 'auth'],
            'namespace' => 'App\Widgets\Http\Controllers\Api\V1\Front\Event',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->put('widget-events/sort', 'Controller@sort');
        });

        $attributes['middleware'] = ['api', 'auth', 'widgetEvent.access'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->put('widget-events/{widgetEvent}', 'Controller@update');
            $router->delete('widget-events/{widgetEvent}', 'Controller@delete');
        });

        $attributes['middleware'] = ['api', 'auth', 'widget.access'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('widgets/{widget}/events', 'Controller@index');
        });

        $attributes['middleware'] = ['api', 'auth', 'widget.access:edit'];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->post('widgets/{widget}/events', 'Controller@store');
        });
    }

    /**
     * Attaches a handler to created event.
     *
     * @return void
     */
    public function attachCreatedEventHandler()
    {
        Event::created(function (Event $event) {
            $widget = $event->widget;
            $widget->events_count = $widget->events_count + 1;
            if ($event->notify_me && $event->notify_at) {
                $widget->events_active_notifications_count = $widget->events_active_notifications_count + 1;
            }

            $widget->save();
        });
    }

    /**
     * Attaches a handler to updated event.
     *
     * @return void
     */
    public function attachUpdatedEventHandler()
    {
        Event::updated(function (Event $event) {
            $widget = $event->widget;
            if ($event->notify_me && !$event->getOriginal('notify_me')) {
                $widget->events_active_notifications_count = $widget->events_active_notifications_count + 1;
            } else if (!$event->notify_me && $event->getOriginal('notify_me')) {
                $widget->events_active_notifications_count = $widget->events_active_notifications_count - 1;
            }
            $widget->save();
        });
    }

    /**
     * Attaches a handler to deleted event.
     *
     * @return void
     */
    public function attachDeletedEventHandler()
    {
        Event::deleted(function (Event $event) {
            $widget = $event->widget;
            $widget->events_count = $widget->events_count - 1;
            if ($event->notify_me && $event->notify_at) {
                $widget->events_active_notifications_count = $widget->events_active_notifications_count - 1;
            }

            $widget->save();
        });
    }
}
