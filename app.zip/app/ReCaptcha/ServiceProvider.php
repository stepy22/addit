<?php

namespace App\ReCaptcha;

use Illuminate\Support\ServiceProvider as BaseServiceProvider;
use ReCaptcha\ReCaptcha;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function register()
    {
        $this->app->singleton(ReCaptcha::class, function ($app) {
            $secret = $app['config']->get('google.recaptcha.secret');

            return new ReCaptcha($secret);
        });
    }
}
