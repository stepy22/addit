<?php

namespace App\OxfordDictionary\Http\Controllers\Api\V1\Front;

use App\Http\Controllers\Admin\Controller as BaseController;
use Illuminate\Http\Request;
use Inani\OxfordApiWrapper\Exceptions\DictionaryException;
use Inani\OxfordApiWrapper\Exceptions\TranslateException;
use Inani\OxfordApiWrapper\OxfordWrapper;
use Response;

class Controller extends BaseController
{
    /**
     * Returns a definition of a word.
     *
     * @param string        $word             Word to search for..
     * @param OxfordWrapper $oxfordApiWrapper Oxford API wrapper instance.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index($word, OxfordWrapper $oxfordApiWrapper)
    {
        try {
            $definitions = $oxfordApiWrapper
                ->lookFor($word)
                ->define();
        } catch (TranslateException $e) {
            $definitions = null;
        }

        try {
            $synonyms = $oxfordApiWrapper
                ->lookFor($word)
                ->synonym()
                ->fetch();
            $synonyms = $synonyms->get();
        } catch (DictionaryException $e) {
            $synonyms = [];
        }

        try {
            $examples = $oxfordApiWrapper
                ->lookFor($word)
                ->examples();
            $examples = $examples->get();
        } catch (\Exception $e) {
            $examples = null;
        }

        $data = [
            'definitions' => $definitions ? $definitions->get() : null,
            'examples' => $examples,
            'synonyms' => array_get($synonyms, 'synonyms'),
        ];

        return Response::make($data);
    }

    /**
     * Returns synonyms and antonyms of a word.
     *
     * @param string        $word             Word to search for..
     * @param OxfordWrapper $oxfordApiWrapper Oxford API wrapper instance.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function thesaurus($word, OxfordWrapper $oxfordApiWrapper)
    {
        try {
            $synonyms = $oxfordApiWrapper
                ->lookFor($word)
                ->synonym()
                ->fetch();
            $synonyms = $synonyms->get();
        } catch (DictionaryException $e) {
            $synonyms = [];
        }

        try {
            $antonyms = $oxfordApiWrapper
                ->lookFor($word)
                ->antonym()
                ->fetch();
            $antonyms = $antonyms->get();
        } catch (DictionaryException $e) {
            $antonyms = [];
        }

        $data = [
            'synonyms' => array_get($synonyms, 'synonyms', null),
            'antonyms' => array_get($antonyms, 'antonyms', null),
        ];

        return Response::make($data);
    }
}
