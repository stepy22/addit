<?php

namespace App\ViewData\Middleware;

use Cartalyst\Sentinel\Sentinel;
use Closure;
use Creitive\ViewData\ViewData;
use Illuminate\Http\Request;
use Illuminate\Support\MessageBag;

class AttachSessionDependentDataToViewData
{
    /**
     * A ViewData instance.
     *
     * @var ViewData
     */
    protected $viewData;

    /**
     * A Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * @param ViewData $viewData A ViewData instance.
     * @param Sentinel $sentinel A Sentinel instance.
     *
     * @return void
     */
    public function __construct(ViewData $viewData, Sentinel $sentinel)
    {
        $this->viewData = $viewData;
        $this->sentinel = $sentinel;
    }

    /**
     * Handle an incoming request.
     *
     * @param Request $request A Request.
     * @param Closure $next    The next middleware.
     *
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        $this->viewData->currentUser = $this->sentinel->getUser();
        $this->viewData->successMessages = $request->session()->get('successMessages', new MessageBag());
        $this->viewData->errorMessages = $request->session()->get('errorMessages', new MessageBag());
        $this->viewData->profileNotCompletedRedirectMessages = $request->session()->get('profileNotCompletedRedirectMessages', new MessageBag());

        return $next($request);
    }
}
