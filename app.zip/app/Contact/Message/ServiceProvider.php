<?php

namespace App\Contact\Message;

use App\Contact\Message;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Routing\Router;
use URL;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerFrontRoutes($this->app['router']);
        $this->registerFrontApiRoutes($this->app['router']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers admin panel routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => trans('routes.contact'),
            'middleware' => ['web'],
            'namespace' => 'App\Contact\Http\Controllers\Front\Message',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('', 'Controller@index');
            $router->post('', 'Controller@send');
        });
    }

    /**
     * Registers front api routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1/contact-messages',
            'middleware' => ['api'],
            'namespace' => 'App\Contact\Http\Controllers\Api\V1\Message',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->post('', 'Controller@send');
        });
    }
}
