<?php

namespace App\Contact\Message;

use App\Contact\Message;

class Repository
{
    /**
     * Creates a new message and returns it.
     *
     * @param array $inputData The input data for the message.
     *
     * @return Message
     */
    public function create(array $inputData)
    {
        $message = new Message();

        $message->first_name = array_get($inputData, 'first_name');
        $message->last_name = array_get($inputData, 'last_name');
        $message->email = array_get($inputData, 'email');
        $message->message = array_get($inputData, 'message');

        return $message;
    }
}
