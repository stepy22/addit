<?php

namespace App\Contact;

class Message
{
    /**
     * The first name of the message author.
     *
     * @var string
     */
    public $first_name;

    /**
     * The last name of the message author.
     *
     * @var string
     */
    public $last_name;

    /**
     * The email address of the message author.
     *
     * @var string
     */
    public $email;

    /**
     * The message itself.
     *
     * @var string
     */
    public $message;
}
