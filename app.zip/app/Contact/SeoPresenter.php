<?php

namespace App\Contact;

use Creitive\Html\DefaultSeoPresenter;

class SeoPresenter extends DefaultSeoPresenter
{
    /**
     * @param string      $title       The title to use.
     * @param string|null $description The description to use.
     * @param string|null $image       The image to use.
     */
    public function __construct($title, $description = null, $image = null)
    {
        $this->title = $title;
        $this->description = $description;
        $this->image = $image;
    }
}
