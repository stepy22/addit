<?php

namespace App\Contact\Http\Requests\Front\Message;

use App\Http\Requests\Request;

class SendRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'first_name' => ['required'],
            'last_name' => ['required'],
            'email' => ['email', 'required'],
            'message' => ['required'],
            'agree' => ['accepted'],
            'g-recaptcha-response' => ['required', 'recaptcha'],
        ];

        return $rules;
    }

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array
     */
    public function messages()
    {
        return array_dot(trans('contact.errorMessages'));
    }
}
