<?php

namespace App\Contact\Http\Controllers\Api\V1\Message;

use App\Contact\Http\Requests\Api\V1\Message\SendRequest;
use App\Contact\Message\Repository as MessageRepository;
use Illuminate\Config\Repository as Config;
use Illuminate\Contracts\Mail\Mailer;
use Illuminate\Routing\Controller as BaseController;
use Response;
use Str;

class Controller extends BaseController
{
    /**
     * Sends a contact message.
     *
     * @param SendRequest       $request           A contact message send request.
     * @param MessageRepository $messageRepository A contact message repository.
     * @param Mailer            $mailer            A mailer implementation.
     * @param Config            $config            A config repository.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function send(SendRequest $request, MessageRepository $messageRepository, Mailer $mailer, Config $config)
    {
        $submittedMessage = $messageRepository->create($request->all());

        $mailer->send(
            'emails.contact.form',
            [
                'submittedMessage' => $submittedMessage,
            ],
            function ($message) use ($submittedMessage, $config) {
                $message
                    ->to($config->get('mail.recipients.contact.address'), $config->get('mail.recipients.contact.name'))
                    ->replyTo($submittedMessage->email, $submittedMessage->first_name.' '.$submittedMessage->last_name)
                    ->subject(trans('contact.email.subject', ['random' => Str::random(8)]));
            }
        );

        return Response::json(null, 200);
    }
}
