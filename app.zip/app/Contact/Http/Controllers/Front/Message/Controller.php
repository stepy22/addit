<?php

namespace App\Contact\Http\Controllers\Front\Message;

use App\Contact\Http\Requests\Front\Message\SendRequest;
use App\Contact\Message\Repository as MessageRepository;
use App\Contact\SeoPresenter;
use App\Http\Controllers\Front\Controller as BaseController;
use Illuminate\Config\Repository as Config;
use Illuminate\Contracts\Mail\Mailer;
use Illuminate\Http\Request;
use Illuminate\Support\MessageBag;
use Redirect;
use Str;

class Controller extends BaseController
{
    /**
     */
    public function __construct()
    {
        parent::__construct();

        $this->viewData->pageTitle->setPage(trans('navigation.contact'));
        $this->viewData->setSeo(new SeoPresenter(trans('navigation.contact')));
        $this->viewData->navigation->get('front.main')->setActive('contact');
    }

    /**
     * Shows the contact form.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        $data['homeHeader'] = 'header--primary';
        $data['homeNavbar'] = 'navbar--primary';
        $data['homeNavbarNav'] = 'navbar-nav--primary';
        $data['homeNavbarBrand'] = 'navbar-brand--primary';
        $data['homeNavbarNavLinksItem'] = 'navbar-nav-links-item--primary';
        $data['homeNavbarNavLinksItemLink'] = 'navbar-nav-links-item-link--primary';
        $data['homeNavbarSocialIcons'] = 'navbar-socialIcons--primary';
        $data['homeNavbarToggle'] = 'navbar-toggle--primary';
        $data['homeNavbarCollapse'] = 'navbar-collapse--primary';

        return view('contact', $data);
    }

    /**
     * Sends a contact message.
     *
     * @param SendRequest       $request           A contact message send request.
     * @param MessageRepository $messageRepository A contact message repository.
     * @param Mailer            $mailer            A mailer implementation.
     * @param Config            $config            A config repository.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function send(SendRequest $request, MessageRepository $messageRepository, Mailer $mailer, Config $config)
    {
        $submittedMessage = $messageRepository->create($request->all());

        $mailer->send(
            'emails.contact.form',
            [
                'submittedMessage' => $submittedMessage,
            ],
            function ($message) use ($submittedMessage, $config) {
                $message
                    ->to($config->get('mail.recipients.contact.address'), $config->get('mail.recipients.contact.name'))
                    ->replyTo($submittedMessage->email, $submittedMessage->first_name.' '.$submittedMessage->last_name)
                    ->subject(trans('contact.email.subject', ['random' => Str::random(8)]));
            }
        );

        return Redirect::action('App\Contact\Http\Controllers\Front\Message\Controller@index')
                ->with('successMessages', new MessageBag([trans('contact.successMessages.sent')]));
    }
}
