<?php

namespace App\SuggestedLinks\Http\Requests\Admin\SuggestedLink;

use App\Http\Requests\Request;
use App\SuggestedLinks\SuggestedLink;

class StoreRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'title' => ['required'],
            'url' => ['required', 'url'],
            'type' => ['required', 'in:'.SuggestedLink::TYPE_WEBSITE.','.SuggestedLink::TYPE_APP],
            'platform' => ['required_if:type,'.SuggestedLink::TYPE_APP, 'in:'.SuggestedLink::PLATFORM_ANDROID.','.SuggestedLink::PLATFORM_IOS],
            'image_main' => ['image'],
        ];

        return $rules;
    }
}
