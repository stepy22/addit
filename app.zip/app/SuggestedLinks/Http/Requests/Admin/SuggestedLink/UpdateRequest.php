<?php

namespace App\SuggestedLinks\Http\Requests\Admin\SuggestedLink;

use App\Http\Requests\Request;
use App\SuggestedLinks\SuggestedLink;

class UpdateRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'title' => ['required'],
            'url' => ['required', 'url'],
            'platform' => ['in:'.SuggestedLink::PLATFORM_ANDROID.','.SuggestedLink::PLATFORM_IOS],
            'image_main' => ['image'],
            'dashboard_category_ids' => ['array', 'exists:dashboard_categories,id'],
        ];

        return $rules;
    }
}
