<?php

namespace App\SuggestedLinks\Http\Controllers\Api\V1\Admin\SuggestedLink;

use App\Http\Controllers\Admin\Controller as BaseController;
use App\SuggestedLinks\Http\Requests\Admin\SuggestedLink\SortRequest;
use App\SuggestedLinks\SuggestedLink\Repository as SuggestedLinkRepository;
use Response;

class Controller extends BaseController
{
    /**
     * A SuggestedLink repository instance.
     *
     * @var SuggestedLinkRepository
     */
    protected $suggestedLinkRepository;

    /**
     * @param SuggestedLinkRepository $suggestedLinkRepository A suggestedLink repository instance.
     */
    public function __construct(SuggestedLinkRepository $suggestedLinkRepository)
    {
        parent::__construct();

        $this->suggestedLinkRepository = $suggestedLinkRepository;
    }

    /**
     * Sorts the suggested links in the passed order.
     *
     * @param SortRequest $request A suggestedLink sort request.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function sort(SortRequest $request)
    {
        $image = $this->suggestedLinkRepository->sort($request->all());

        return Response::make('', 204);
    }
}
