<?php

namespace App\SuggestedLinks\Http\Controllers\Admin\SuggestedLink;

use App\DashboardCategories\DashboardCategory\Repository as DashboardCategoryRepository;
use App\Http\Controllers\Admin\Controller as BaseController;
use App\InterestTags\InterestTag\Repository as InterestTagRepository;
use App\SuggestedLinks\Http\Requests\Admin\SuggestedLink\StoreRequest;
use App\SuggestedLinks\Http\Requests\Admin\SuggestedLink\UpdateRequest;
use App\SuggestedLinks\SuggestedLink;
use App\SuggestedLinks\SuggestedLink\Repository as SuggestedLinkRepository;
use Creitive\PageDescriptionCrawler\Crawler as PageDescriptionCrawler;
use Illuminate\Http\Request;
use Illuminate\Support\MessageBag;
use Redirect;

class Controller extends BaseController
{
    /**
     * A SuggestedLinkRepository instance.
     *
     * @var SuggestedLinkRepository
     */
    protected $suggestedLinkRepository;

    /**
     * @param SuggestedLinkRepository $suggestedLinkRepository A suggestedLink repository instance.
     */
    public function __construct(SuggestedLinkRepository $suggestedLinkRepository)
    {
        parent::__construct();

        $this->suggestedLinkRepository = $suggestedLinkRepository;

        $this->viewData->bodyDataPage = 'admin-suggested-links';
        $this->viewData->pageTitle->setPage(trans('admin/suggestedLinks.module'));
        $this->viewData->navigation->get('admin.main')->setActive('suggested-links');
    }

    /**
     * Shows all suggestedLinks.
     *
     * @param Request $request The current request.
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $data = [
            'suggestedLinks' => $this->suggestedLinkRepository->getAll($request->all()),
        ];

        return view('admin.suggested-links.index', $data);
    }

    /**
     * Displays the create form.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        return view('admin.suggested-links.create');
    }

    /**
     * Saves a new suggestedLink.
     *
     * @param StoreRequest           $request A suggestedLink store request.
     * @param PageDescriptionCrawler $crawler Page description crawler instance.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(StoreRequest $request, PageDescriptionCrawler $crawler)
    {
        $suggestedLink = $this->suggestedLinkRepository->create($request->all(), $crawler);

        $successMessage = trans('admin/suggestedLinks.successMessages.create');

        return Redirect::action(static::class.'@edit', ['suggestedLink' => $suggestedLink->id])
            ->with('successMessages', new MessageBag([$successMessage]));
    }

    /**
     * Shows the specified suggestedLink's edit page.
     *
     * @param SuggestedLink               $suggestedLink               The suggestedLink.
     * @param DashboardCategoryRepository $dashboardCategoryRepository The dashboard category repository.
     * @param InterestTagRepository       $interestTagRepository       The interest tag repository.
     *
     * @return \Illuminate\View\View
     */
    public function edit(
        SuggestedLink $suggestedLink,
        DashboardCategoryRepository $dashboardCategoryRepository,
        InterestTagRepository $interestTagRepository
    ) {
        $data = [
            'suggestedLink' => $suggestedLink,
            'dashboardCategoryOptions' => $dashboardCategoryRepository->getSelectOptions(),
            'interestTags' => $interestTagRepository->getAll(),
        ];

        return view('admin.suggested-links.edit', $data);
    }

    /**
     * Updates the specified suggestedLink.
     *
     * @param UpdateRequest          $request       A suggestedLink update request.
     * @param SuggestedLink          $suggestedLink The suggestedLink.
     * @param PageDescriptionCrawler $crawler       Page description crawler instance.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(UpdateRequest $request, SuggestedLink $suggestedLink, PageDescriptionCrawler $crawler)
    {
        $this->suggestedLinkRepository->update($suggestedLink, $request->all(), $crawler);

        $successMessage = trans('admin/suggestedLinks.successMessages.edit');

        return Redirect::action(static::class.'@edit', ['suggestedLink' => $suggestedLink->id])
            ->with('successMessages', new MessageBag([$successMessage]));
    }

    /**
     * Displays the suggestedLink deletion confirmation form.
     *
     * @param SuggestedLink $suggestedLink The suggestedLink.
     *
     * @return \Illuminate\View\View
     */
    public function confirmDelete(SuggestedLink $suggestedLink)
    {
        $data = [
            'suggestedLink' => $suggestedLink,
        ];

        return view('admin.suggested-links.delete', $data);
    }

    /**
     * Deletes a suggestedLink.
     *
     * @param Request       $request       The current request.
     * @param SuggestedLink $suggestedLink The suggestedLink to delete.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function delete(Request $request, SuggestedLink $suggestedLink)
    {
        if ($request->get('action') !== 'confirm') {
            return Redirect::action(static::class.'@index');
        }

        $this->suggestedLinkRepository->delete($suggestedLink);

        $successMessage = trans('admin/suggestedLinks.successMessages.delete', ['title' => $suggestedLink->title]);

        return Redirect::action(static::class.'@index')
            ->with('successMessages', new MessageBag([$successMessage]));
    }
}
