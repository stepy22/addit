<?php

namespace App\SuggestedLinks\SuggestedLink;

use App\Auth\User;
use App\SuggestedLinks\SuggestedLink;
use Creitive\Database\Eloquent\Collection as BaseCollection;

class Collection extends BaseCollection
{
    /**
     * Sorts suggested links by tags matched.
     *
     * @param User $user User instance.
     *
     * @return Collection
     */
    public function sortByInterestTagsMatched(User $user)
    {
        return $this->sortByDesc(function (SuggestedLink $link) use ($user) {
            $userInterestTagIds = $user->interestTags->pluck('id')->toArray();
            $linkInterestTagIds = $link->interestTags->pluck('id')->toArray();

            $matchedTags = array_intersect($linkInterestTagIds, $userInterestTagIds);

            return count($matchedTags);
        });
    }
}
