<?php

namespace App\SuggestedLinks\SuggestedLink;

use App\SuggestedLinks\SuggestedLink;
use App\SuggestedLinks\SuggestedLink\Repository as SuggestedLinkRepository;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Creitive\Routing\LocaleResolver;
use DaveJamesMiller\Breadcrumbs\Generator as BreadcrumbGenerator;
use DaveJamesMiller\Breadcrumbs\Manager as BreadcrumbManager;
use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Routing\Router;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use URL;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerRoutePatterns($this->app['router'], $this->app);
        $this->registerAdminRoutes($this->app['router']);
        $this->registerAdminApiRoutes($this->app['router']);
        $this->registerAdminBreadcrumbs($this->app['breadcrumbs']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers the route patterns.
     *
     * @param Router    $router    A router.
     * @param Container $container A dependency container.
     *
     * @return void
     */
    protected function registerRoutePatterns(Router $router, Container $container)
    {
        $idRegex = $this->routePatternRegexes['id'];
        $slugRegex = $this->routePatternRegexes['slug'];

        $router->pattern('suggestedLink', $idRegex);

        $router->bind('suggestedLink', function ($value) use ($container, $idRegex) {
            $suggestedLinkRepository = $container->make(SuggestedLinkRepository::class);

            if (preg_match("/^{$idRegex}$/D", $value)) {
                $suggestedLink = $suggestedLinkRepository->find($value);

                if ($suggestedLink !== null) {
                    return $suggestedLink;
                }
            }
        });
    }

    /**
     * Registers admin panel routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerAdminRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'admin/suggested-links',
            'middleware' => ['web', 'auth', 'permissions'],
            'namespace' => 'App\SuggestedLinks\Http\Controllers\Admin\SuggestedLink',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('', 'Controller@index');

            $router->get('create', 'Controller@create');
            $router->post('', 'Controller@store');

            $router->get('{suggestedLink}/edit', 'Controller@edit');
            $router->put('{suggestedLink}', 'Controller@update');

            $router->get('{suggestedLink}/delete', 'Controller@confirmDelete');
            $router->delete('{suggestedLink}', 'Controller@delete');
        });
    }

    /**
     * Registers admin API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerAdminApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1/suggested-links',
            'middleware' => ['api', 'auth', 'permissions'],
            'namespace' => 'App\SuggestedLinks\Http\Controllers\Api\V1\Admin\SuggestedLink',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->put('sort', 'Controller@sort');
        });
    }

    /**
     * Registers breadcrumbs for the admin panel.
     *
     * @param BreadcrumbManager $breadcrumbs A breadcrumb manager.
     *
     * @return void
     */
    protected function registerAdminBreadcrumbs(BreadcrumbManager $breadcrumbs)
    {
        $breadcrumbs->register('admin::suggestedLinks', function (BreadcrumbGenerator $breadcrumbs) {
            $breadcrumbs->parent('admin::home');

            $url = URL::action('App\SuggestedLinks\Http\Controllers\Admin\SuggestedLink\Controller@index');

            $breadcrumbs->push(trans('admin/navigation.suggestedLinks'), $url);
        });

        $breadcrumbs->register('admin::suggestedLinks.show', function (BreadcrumbGenerator $breadcrumbs, SuggestedLink $suggestedLink) {
            $breadcrumbs->parent('admin::suggestedLinks');

            $breadcrumbs->push($suggestedLink->title);
        });

        $breadcrumbs->register('admin::suggestedLinks.create', function (BreadcrumbGenerator $breadcrumbs) {
            $breadcrumbs->parent('admin::suggestedLinks');

            $url = URL::action('App\SuggestedLinks\Http\Controllers\Admin\SuggestedLink\Controller@create');

            $breadcrumbs->push(trans('admin/suggestedLinks.titles.create'), $url);
        });

        $breadcrumbs->register('admin::suggestedLinks.edit', function (BreadcrumbGenerator $breadcrumbs, SuggestedLink $suggestedLink) {
            $breadcrumbs->parent('admin::suggestedLinks.show', $suggestedLink);

            $url = URL::action('App\SuggestedLinks\Http\Controllers\Admin\SuggestedLink\Controller@edit', ['suggestedLink' => $suggestedLink->id]);

            $breadcrumbs->push(trans('admin/suggestedLinks.titles.edit'), $url);
        });

        $breadcrumbs->register('admin::suggestedLinks.delete', function (BreadcrumbGenerator $breadcrumbs, SuggestedLink $suggestedLink) {
            $breadcrumbs->parent('admin::suggestedLinks.show', $suggestedLink);

            $url = URL::action('App\SuggestedLinks\Http\Controllers\Admin\SuggestedLink\Controller@confirmDelete', ['suggestedLink' => $suggestedLink->id]);

            $breadcrumbs->push(trans('admin/suggestedLinks.titles.delete'), $url);
        });
    }
}
