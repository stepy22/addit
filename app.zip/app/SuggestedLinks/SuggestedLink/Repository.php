<?php

namespace App\SuggestedLinks\SuggestedLink;

use App\InterestTags\InterestTag\Repository as InterestTagRepository;
use App\SuggestedLinks\SuggestedLink;
use Carbon\Carbon;
use Creitive\PageDescriptionCrawler\Crawler;
use Favicon\Favicon;
use Favicon\FaviconDLType;
use Hshn\Base64EncodedFile\HttpFoundation\File\Base64EncodedFile;
use Illuminate\Support\Collection;
use Log;
use stdClass;

class Repository
{
    /**
     * A SuggestedLink model instance.
     *
     * @var SuggestedLink
     */
    protected $suggestedLink;

    /**
     * An Interest tag repository instance.
     *
     * @var InterestTagRepository
     */
    protected $interestTagRepository;

    /**
     * A favicon package.
     *
     * @var Favicon
     */
    protected $favicon;

    /**
     * @param SuggestedLink         $suggestedLink         A suggestedLink model instance.
     * @param InterestTagRepository $interestTagRepository A interest tag repository instance.
     * @param Favicon               $favicon               A favicon instance.
     */
    public function __construct(
        SuggestedLink $suggestedLink,
        InterestTagRepository $interestTagRepository,
        Favicon $favicon
    ) {
        $this->suggestedLinkModel = $suggestedLink;
        $this->interestTagRepository = $interestTagRepository;
        $this->favicon = $favicon;
    }

    /**
     * Gets all suggestedLinks.
     *
     * @param array $inputData Input data array.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAll(array $inputData)
    {
        $type = array_get($inputData, 'type', null);
        $platform = array_get($inputData, 'platform', null);

        $query = $this->suggestedLinkModel->sorted();

        if ($type) {
            $query->whereType($type);
        }

        if ($platform) {
            $query->wherePlatform($platform);
        }

        return $query->get();
    }

    /**
     * Gets all suggested links by type.
     *
     * @param string $type Type of the link.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAllByType($type)
    {
        return $this->suggestedLinkModel
            ->whereType($type)
            ->get();
    }

    /**
     * Finds the suggestedLink by ID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $id The suggestedLink ID.
     *
     * @return SuggestedLink|null
     */
    public function find($id)
    {
        return $this->suggestedLinkModel->find($id);
    }

    /**
     * Finds the suggestedLink by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The suggestedLink ID.
     *
     * @return SuggestedLink
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->suggestedLinkModel->findOrFail($id);
    }

    /**
     * Creates a new suggestedLink and returns it.
     *
     * @param array   $inputData The suggestedLink input data.
     * @param Crawler $crawler   Page description crawler instance.
     *
     * @return SuggestedLink
     */
    public function create(array $inputData, Crawler $crawler)
    {
        return $this->populateAndSave($this->suggestedLinkModel->newInstance(), $inputData, $crawler);
    }

    /**
     * Updates the passed suggestedLink and returns it.
     *
     * @param SuggestedLink $suggestedLink The suggestedLink to update.
     * @param array         $inputData     The input data for the update.
     * @param Crawler       $crawler       Page description crawler instance
     *
     * @return SuggestedLink
     */
    public function update(SuggestedLink $suggestedLink, array $inputData, Crawler $crawler)
    {
        return $this->populateAndSave($suggestedLink, $inputData, $crawler);
    }

    /**
     * Deletes the passed suggestedLink from the system.
     *
     * @param SuggestedLink $suggestedLink The suggestedLink to delete.
     *
     * @return bool|null
     */
    public function delete(SuggestedLink $suggestedLink)
    {
        return $suggestedLink->delete();
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param SuggestedLink $suggestedLink The suggestedLink to populate.
     * @param array         $inputData     The input data for the suggestedLink.
     * @param Crawler       $crawler       Page description crawler instance.
     *
     * @return SuggestedLink
     */
    protected function populate(SuggestedLink $suggestedLink, array $inputData, Crawler $crawler)
    {
        if (isset($inputData['url']) && $inputData['url'] !== $suggestedLink->url) {
            $icon = $this->favicon->get($inputData['url'], FaviconDLType::RAW_IMAGE);
            $file = new Base64EncodedFile(base64_encode($icon));

            try {
                $suggestedLink->uploadImage($file->getPathname(), 'main');
            } catch (\ImagickException $e) {
                Log::error($e);
            }
        }

        if (isset($inputData['url']) && $inputData['url'] !== $suggestedLink->url) {
            $suggestedLink->description = $crawler->getPageDescription(array_get($inputData, 'url'));
        }

        $suggestedLink->title = array_get($inputData, 'title');
        $suggestedLink->url = array_get($inputData, 'url');
        $suggestedLink->type = array_get($inputData, 'type', $suggestedLink->type);
        $suggestedLink->platform = array_get($inputData, 'platform', $suggestedLink->platform);

        if (isset($inputData['image_main'])) {
            $suggestedLink->uploadImage($inputData['image_main'], 'main');
        }

        if (isset($inputData['interest_tags'])) {
            $interestTagsArray = explode(',', $inputData['interest_tags']);
            $interestTags = $this->interestTagRepository->getByTitleAndCreateNonExistent($interestTagsArray);

            $suggestedLink->interestTags()->sync($interestTags->pluck('id')->toArray());
        }

        if (isset($inputData['dashboard_category_ids'])) {
            $suggestedLink->dashboardCategories()->sync($inputData['dashboard_category_ids']);
        }

        return $suggestedLink;
    }

    /**
     * Sorts suggestedLinks in the passed order.
     *
     * @param array $inputData The new sort order.
     *
     * @return bool
     */
    public function sort(array $inputData)
    {
        $newOrder = array_map(
            function ($item) {
                return (int) $item['id'];
            },
            $inputData['items']
        );

        return $this->suggestedLinkModel->updateSortOrder($newOrder);
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param SuggestedLink $suggestedLink The suggestedLink to populate and save.
     * @param array         $inputData     The input data.
     * @param Crawler       $crawler       Page description crawler instance.
     *
     * @return SuggestedLink
     */
    protected function populateAndSave(SuggestedLink $suggestedLink, array $inputData, Crawler $crawler)
    {
        $suggestedLink = $this->populate($suggestedLink, $inputData, $crawler);

        $suggestedLink->save();

        return $suggestedLink;
    }

    /**
     * Get suggested links in random order.
     *
     * @param string $type     Suggested link type (website|application).
     * @param string $platform Suggested link platform (ios|android).
     * @param int    $take     Number of links.
     *
     * @return Collection
     */
    public function getRandom($type, $platform, $take = 5)
    {
        return $this->suggestedLinkModel
            ->when($type, function ($query) use ($type) {
                return $query->where('type', $type);
            })
            ->when($platform, function ($query) use ($platform) {
                return $query->where('platform', $platform);
            })
            ->inRandomOrder()
            ->get()
            ->take($take);
    }
}
