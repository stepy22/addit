<?php

namespace App\SuggestedLinks\Console;

use App\SuggestedLinks\SuggestedLink;
use App\Widgets\Link;
use Creitive\PageDescriptionCrawler\Crawler as PageDescriptionCrawler;
use Illuminate\Console\Command;

class UpdateSuggestedLinksDescription extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'suggested-links:update-description';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Update suggested links description from remote link.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @param PageDescriptionCrawler $crawler The page description crawler instance!
     */
    public function handle(PageDescriptionCrawler $crawler)
    {
        echo 'Command is running. This can take few minutes.' . "\n" .'Updating links description ....';

        $suggestedLinks = SuggestedLink::all();

        $suggestedLinks->each(function ($item) use ($crawler) {
            $description = $crawler->getPageDescription($item->url);
            $item->description = $description;

            Link::where('url', $item->url)->get()->each(function ($link) use ($description) {
                $link->description = $description;
                $link->update();
            });

            $item->update();
        });

        echo "\n" . 'Links successfully updated.';
    }
}
