<?php

namespace App\SuggestedLinks;

use App\DashboardCategories\DashboardCategory;
use App\InterestTags\InterestTag;
use App\SuggestedLinks\SuggestedLink\Collection;
use Creitive\Database\Eloquent\Model;
use Creitive\Image\Transformers\Thumbnail;
use Creitive\Models\Traits\CalcFoundRowableTrait;
use Creitive\Models\Traits\ImageableTrait;
use Creitive\Models\Traits\SortableTrait;
use URL;

class SuggestedLink extends Model
{
    use CalcFoundRowableTrait;
    use ImageableTrait;
    use SortableTrait;

    /**
     * Type constants.
     */
    const TYPE_WEBSITE = 'website';
    const TYPE_APP = 'application';

    /**
     * Platform constants.
     */
    const PLATFORM_ANDROID = 'android';
    const PLATFORM_IOS = 'ios';

    /**
     * {@inheritDoc}
     */
    protected $visible = [
        'id',
        'title',
        'url',
        'url_image_main_original',
        'url_image_main_favicon',
        'url_image_main_app_logo',
        'description',
    ];

    /**
     * {@inheritDoc}
     */
    protected $appends = [
        'url_image_main_original',
        'url_image_main_favicon',
        'url_image_main_app_logo',
    ];

    /**
     * {@inheritDoc}
     */
    public function getImageConfiguration()
    {
        return [
            'versions' => [
                'main' => [
                    'original' => [],
                    'favicon' => [
                        [
                            'transformer' => Thumbnail::class,
                            'width' => 16,
                            'height' => 16,
                        ],
                    ],
                    'app_logo' => [
                        [
                            'transformer' => Thumbnail::class,
                            'width' => 175,
                            'height' => 175,
                        ],
                    ],
                ],
            ],
        ];
    }

    /**
     * {@inheritDoc}
     */
    public function newCollection(array $models = [])
    {
        return new Collection($models);
    }

    /**
     * Gets the complete URL to the original main image.
     *
     * @return string
     */
    public function getUrlImageMainOriginalAttribute()
    {
        return URL::to($this->getImage('main', 'original'));
    }

    /**
     * Gets the complete URL to the favicon main image.
     *
     * @return string
     */
    public function getUrlImageMainFaviconAttribute()
    {
        return URL::to($this->getImage('main', 'favicon'));
    }

    /**
     * Gets the complete URL to the top main image.
     *
     * @return string
     */
    public function getUrlImageMainAppLogoAttribute()
    {
        return URL::to($this->getImage('main', 'app_logo'));
    }

    /**
     * Eloquent relationship: Suggested link belongs to many dashboard
     * categories.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function dashboardCategories()
    {
        return $this->belongsToMany(DashboardCategory::class, 'sugg_link_dashboard_cat');
    }

    /**
     * Eloquent relationship: Suggested link belongs to many interest tags.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function interestTags()
    {
        return $this->belongsToMany(InterestTag::class, 'sugg_links_int_tags');
    }
}
