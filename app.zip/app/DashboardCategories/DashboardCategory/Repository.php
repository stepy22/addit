<?php

namespace App\DashboardCategories\DashboardCategory;

use App\DashboardCategories\DashboardCategory;
use App\InterestTags\InterestTag\Repository as InterestTagRepository;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use stdClass;

class Repository
{
    /**
     * A Dashboard category model instance.
     *
     * @var DashboardCategory
     */
    protected $dashboardCategory;

    /**
     * An Interest tag repository instance.
     *
     * @var InterestTagRepository
     */
    protected $interestTagRepository;

    /**
     * @param DashboardCategory     $dashboardCategory     A dashboard category model instance.
     * @param InterestTagRepository $interestTagRepository A interest tag repository instance.
     */
    public function __construct(DashboardCategory $dashboardCategory, InterestTagRepository $interestTagRepository)
    {
        $this->dashboardCategoryModel = $dashboardCategory;
        $this->interestTagRepository = $interestTagRepository;
    }

    /**
     * Gets all dashboard categories.
     *
     * @param array $inputData Input data array.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAll(array $inputData = [])
    {
        $query = $this->dashboardCategoryModel
            ->sorted();

        if (isset($inputData['has_widget_types'])) {
            if ((int)$inputData['has_widget_types'] === 1) {
                $query->whereHas('widgetTypes');
            } else {
                $query->whereHas('widgetTypes', null, '<', 1);
            }
        }

        return $query->get();
    }

    /**
     * Gets basic dashboard categories.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getBasicCategories()
    {
        return $this->dashboardCategoryModel
            ->where('is_basic', true)
            ->get();
    }

    /**
     * Gets dashboard categories by interest tags.
     *
     * @param array $interestTagsIds Interest tags ids.
     * @param bool  $noBasic         Return only
     *
     * @return Collection
     */
    public function getByInterestTags(array $interestTagsIds, $noBasic = true)
    {
        $query = $this->dashboardCategoryModel
            ->whereHas('interestTags', function (Builder $query) use ($interestTagsIds) {
                $query->whereIn('interest_tag_id', $interestTagsIds);
            });

        if ($noBasic) {
            $query->where(['is_basic' => false]);
        }

        return $query->get();
    }

    /**
     * Returns array of dashboard categories for use in select HTML element.
     *
     * @return array
     */
    public function getSelectOptions()
    {
        return $this->getAll()->pluck('name', 'id')->toArray();
    }

    /**
     * Finds the dashboard category by ID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $id The dashboard category ID.
     *
     * @return DashboardCategory|null
     */
    public function find($id)
    {
        return $this->dashboardCategoryModel->find($id);
    }

    /**
     * Finds the dashboard category by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The dashboard category ID.
     *
     * @return DashboardCategory
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->dashboardCategoryModel->findOrFail($id);
    }

    /**
     * Creates a new dashboard category and returns it.
     *
     * @param array $inputData The dashboard category input data.
     *
     * @return DashboardCategory
     */
    public function create(array $inputData)
    {
        return $this->populateAndSave($this->dashboardCategoryModel->newInstance(), $inputData);
    }

    /**
     * Updates the passed dashboard category and returns it.
     *
     * @param DashboardCategory $dashboardCategory The dashboard category to update.
     * @param array             $inputData         The input data for the update.
     *
     * @return DashboardCategory
     */
    public function update(DashboardCategory $dashboardCategory, array $inputData)
    {
        return $this->populateAndSave($dashboardCategory, $inputData);
    }

    /**
     * Deletes the passed dashboard category from the system.
     *
     * @param DashboardCategory $dashboardCategory The dashboard category to delete.
     *
     * @return bool|null
     */
    public function delete(DashboardCategory $dashboardCategory)
    {
        return $dashboardCategory->delete();
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param DashboardCategory $dashboardCategory The dashboard category to populate.
     * @param array             $inputData         The input data for the dashboard category.
     *
     * @return DashboardCategory
     */
    protected function populate(DashboardCategory $dashboardCategory, array $inputData)
    {
        $dashboardCategory->name = array_get($inputData, 'name');

        if (isset($inputData['interest_tags'])) {
            $interestTagsArray = explode(',', $inputData['interest_tags']);
            $interestTags = $this->interestTagRepository->getByTitleAndCreateNonExistent($interestTagsArray);

            $dashboardCategory->interestTags()->sync($interestTags->pluck('id')->toArray());
        }

        return $dashboardCategory;
    }

    /**
     * Sorts dashboard categories in the passed order.
     *
     * @param array $inputData The new sort order.
     *
     * @return bool
     */
    public function sort(array $inputData)
    {
        $newOrder = array_map(
            function ($item) {
                return (int) $item['id'];
            },
            $inputData['items']
        );

        return $this->dashboardCategoryModel->updateSortOrder($newOrder);
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param DashboardCategory $dashboardCategory The dashboard category to populate and save.
     * @param array             $inputData         The input data.
     *
     * @return DashboardCategory
     */
    protected function populateAndSave(DashboardCategory $dashboardCategory, array $inputData)
    {
        $dashboardCategory = $this->populate($dashboardCategory, $inputData);

        $dashboardCategory->save();

        return $dashboardCategory;
    }
}
