<?php

namespace App\DashboardCategories\DashboardCategory;

use App\DashboardCategories\DashboardCategory;
use App\DashboardCategories\DashboardCategory\Repository as DashboardCategoryRepository;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Creitive\Routing\LocaleResolver;
use DaveJamesMiller\Breadcrumbs\Generator as BreadcrumbGenerator;
use DaveJamesMiller\Breadcrumbs\Manager as BreadcrumbManager;
use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Routing\Router;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use URL;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerRoutePatterns($this->app['router'], $this->app);
        $this->registerAdminRoutes($this->app['router']);
        $this->registerAdminApiRoutes($this->app['router']);
        $this->registerFrontApiRoutes($this->app['router']);
        $this->registerAdminBreadcrumbs($this->app['breadcrumbs']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers the route patterns.
     *
     * @param Router    $router    A router.
     * @param Container $container A dependency container.
     *
     * @return void
     */
    protected function registerRoutePatterns(Router $router, Container $container)
    {
        $idRegex = $this->routePatternRegexes['id'];
        $slugRegex = $this->routePatternRegexes['slug'];

        $router->pattern('dashboardCategory', $idRegex);

        $router->bind('dashboardCategory', function ($value) use ($container, $idRegex) {
            $dashboardCategoryRepository = $container->make(DashboardCategoryRepository::class);

            if (preg_match("/^{$idRegex}$/D", $value)) {
                $dashboardCategory = $dashboardCategoryRepository->find($value);

                if ($dashboardCategory !== null) {
                    return $dashboardCategory;
                }
            }
        });
    }

    /**
     * Registers admin panel routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerAdminRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'admin/dashboard-categories',
            'middleware' => ['web', 'auth', 'permissions'],
            'namespace' => 'App\DashboardCategories\Http\Controllers\Admin\DashboardCategory',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('', 'Controller@index');

            $router->get('create', 'Controller@create');
            $router->post('', 'Controller@store');

            $router->get('{dashboardCategory}/edit', 'Controller@edit');
            $router->put('{dashboardCategory}', 'Controller@update');

            $router->get('{dashboardCategory}/delete', 'Controller@confirmDelete');
            $router->delete('{dashboardCategory}', 'Controller@delete');
        });
    }

    /**
     * Registers admin API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerAdminApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1/dashboard-categories',
            'middleware' => ['api', 'auth', 'permissions'],
            'namespace' => 'App\DashboardCategories\Http\Controllers\Api\V1\Admin\DashboardCategory',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->put('sort', 'Controller@sort');
        });
    }

    /**
     * Registers front API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1/dashboard-categories',
            'middleware' => ['api', 'auth'],
            'namespace' => 'App\DashboardCategories\Http\Controllers\Api\V1\Front\DashboardCategory',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('', 'Controller@index');
        });
    }

    /**
     * Registers breadcrumbs for the admin panel.
     *
     * @param BreadcrumbManager $breadcrumbs A breadcrumb manager.
     *
     * @return void
     */
    protected function registerAdminBreadcrumbs(BreadcrumbManager $breadcrumbs)
    {
        $breadcrumbs->register('admin::dashboardCategories', function (BreadcrumbGenerator $breadcrumbs) {
            $breadcrumbs->parent('admin::home');

            $url = URL::action('App\DashboardCategories\Http\Controllers\Admin\DashboardCategory\Controller@index');

            $breadcrumbs->push(trans('admin/navigation.dashboardCategories'), $url);
        });

        $breadcrumbs->register('admin::dashboardCategories.show', function (BreadcrumbGenerator $breadcrumbs, DashboardCategory $dashboardCategory) {
            $breadcrumbs->parent('admin::dashboardCategories');

            $breadcrumbs->push($dashboardCategory->name);
        });

        $breadcrumbs->register('admin::dashboardCategories.create', function (BreadcrumbGenerator $breadcrumbs) {
            $breadcrumbs->parent('admin::dashboardCategories');

            $url = URL::action('App\DashboardCategories\Http\Controllers\Admin\DashboardCategory\Controller@create');

            $breadcrumbs->push(trans('admin/dashboardCategories.titles.create'), $url);
        });

        $breadcrumbs->register('admin::dashboardCategories.edit', function (BreadcrumbGenerator $breadcrumbs, DashboardCategory $dashboardCategory) {
            $breadcrumbs->parent('admin::dashboardCategories.show', $dashboardCategory);

            $url = URL::action('App\DashboardCategories\Http\Controllers\Admin\DashboardCategory\Controller@edit', ['dashboardCategory' => $dashboardCategory->id]);

            $breadcrumbs->push(trans('admin/dashboardCategories.titles.edit'), $url);
        });

        $breadcrumbs->register('admin::dashboardCategories.delete', function (BreadcrumbGenerator $breadcrumbs, DashboardCategory $dashboardCategory) {
            $breadcrumbs->parent('admin::dashboardCategories.show', $dashboardCategory);

            $url = URL::action('App\DashboardCategories\Http\Controllers\Admin\DashboardCategory\Controller@confirmDelete', ['dashboardCategory' => $dashboardCategory->id]);

            $breadcrumbs->push(trans('admin/dashboardCategories.titles.delete'), $url);
        });
    }
}
