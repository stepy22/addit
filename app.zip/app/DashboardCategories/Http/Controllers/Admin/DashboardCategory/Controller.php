<?php

namespace App\DashboardCategories\Http\Controllers\Admin\DashboardCategory;

use App\DashboardCategories\DashboardCategory;
use App\DashboardCategories\DashboardCategory\Repository as DashboardCategoryRepository;
use App\DashboardCategories\Http\Requests\Admin\DashboardCategory\StoreRequest;
use App\DashboardCategories\Http\Requests\Admin\DashboardCategory\UpdateRequest;
use App\Http\Controllers\Admin\Controller as BaseController;
use App\InterestTags\InterestTag\Repository as InterestTagRepository;
use Illuminate\Http\Request;
use Illuminate\Support\MessageBag;
use Redirect;

class Controller extends BaseController
{
    /**
     * A DashboardCategoryRepository instance.
     *
     * @var DashboardCategoryRepository
     */
    protected $dashboardCategoryRepository;

    /**
     * @param DashboardCategoryRepository $dashboardCategoryRepository A dashboardCategory repository instance.
     */
    public function __construct(DashboardCategoryRepository $dashboardCategoryRepository)
    {
        parent::__construct();

        $this->dashboardCategoryRepository = $dashboardCategoryRepository;

        $this->viewData->bodyDataPage = 'admin-dashboardCategories';
        $this->viewData->pageTitle->setPage(trans('admin/dashboardCategories.module'));
        $this->viewData->navigation->get('admin.main')->setActive('dashboard-categories');
    }

    /**
     * Shows all dashboardCategories.
     *
     * @param Request $request The current request.
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $data = [
            'dashboardCategories' => $this->dashboardCategoryRepository->getAll(),
        ];

        return view('admin.dashboard-categories.index', $data);
    }

    /**
     * Displays the create form.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        return view('admin.dashboard-categories.create');
    }

    /**
     * Saves a new dashboard category.
     *
     * @param StoreRequest $request A dashboard category store request.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(StoreRequest $request)
    {
        $dashboardCategory = $this->dashboardCategoryRepository->create($request->all());

        $successMessage = trans('admin/dashboardCategories.successMessages.create');

        return Redirect::action(static::class.'@edit', ['dashboardCategory' => $dashboardCategory->id])
            ->with('successMessages', new MessageBag([$successMessage]));
    }

    /**
     * Shows the specified dashboardCategory's edit page.
     *
     * @param DashboardCategory     $dashboardCategory     The dashboardCategory.
     * @param InterestTagRepository $interestTagRepository Interest tag repository.
     *
     * @return \Illuminate\View\View
     */
    public function edit(DashboardCategory $dashboardCategory, InterestTagRepository $interestTagRepository)
    {
        $data = [
            'dashboardCategory' => $dashboardCategory,
            'interestTags' => $interestTagRepository->getall(),
        ];

        return view('admin.dashboard-categories.edit', $data);
    }

    /**
     * Updates the specified dashboard category.
     *
     * @param UpdateRequest     $request           A dashboard category update request.
     * @param DashboardCategory $dashboardCategory The dashboard category.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(UpdateRequest $request, DashboardCategory $dashboardCategory)
    {
        $this->dashboardCategoryRepository->update($dashboardCategory, $request->all());

        $successMessage = trans('admin/dashboardCategories.successMessages.edit');

        return Redirect::action(static::class.'@edit', ['dashboardCategory' => $dashboardCategory->id])
            ->with('successMessages', new MessageBag([$successMessage]));
    }

    /**
     * Displays the dashboard category deletion confirmation form.
     *
     * @param DashboardCategory $dashboardCategory The dashboard category.
     *
     * @return \Illuminate\View\View
     */
    public function confirmDelete(DashboardCategory $dashboardCategory)
    {
        $data = [
            'dashboardCategory' => $dashboardCategory,
        ];

        return view('admin.dashboard-categories.delete', $data);
    }

    /**
     * Deletes a dashboard category.
     *
     * @param Request           $request           The current request.
     * @param DashboardCategory $dashboardCategory The dashboard category to delete.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function delete(Request $request, DashboardCategory $dashboardCategory)
    {
        if ($request->get('action') !== 'confirm') {
            return Redirect::action(static::class.'@index');
        }

        $this->dashboardCategoryRepository->delete($dashboardCategory);

        $successMessage = trans('admin/dashboardCategories.successMessages.delete', ['title' => $dashboardCategory->title]);

        return Redirect::action(static::class.'@index')
            ->with('successMessages', new MessageBag([$successMessage]));
    }
}
