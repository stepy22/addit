<?php

namespace App\DashboardCategories;

use App\InterestTags\InterestTag;
use App\SuggestedLinks\SuggestedLink;
use App\WidgetTypes\WidgetType;
use Creitive\Database\Eloquent\Model;
use Creitive\Models\Traits\SortableTrait;

class DashboardCategory extends Model
{
    use SortableTrait;

    /**
     * {@inheritDoc}
     */
    protected $casts = [
        'is_basic' => 'bool',
    ];

    /**
     * Eloquent relationship: dashboard category may have many interest tags.
     *
     * @return BelongsToMany
     */
    public function interestTags()
    {
        return $this->belongsToMany(InterestTag::class, 'dashboard_categories_interest_tags');
    }

    /**
     * Eloquent relationship: dashboard category may have many suggested links.
     *
     * @return BelongsToMany
     */
    public function suggestedLinks()
    {
        return $this->belongsToMany(SuggestedLink::class, 'sugg_link_dashboard_cat');
    }

    /**
     * Eloquent relationship: dashboard category may have many default widget
     * types.
     *
     * @return BelongsToMany
     */
    public function defaultWidgetTypes()
    {
        return $this->belongsToMany(WidgetType::class, 'widget_type_dashboard_categories');
    }

    /**
     * Dashboard category repository can have many widget types.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function widgetTypes()
    {
        return $this->hasMany(WidgetType::class);
    }
}
