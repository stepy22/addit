<?php

namespace App\Jobs;

use App\Notifications\Notification\Notifier;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class NotifyUser implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * A notifier service.
     *
     * @var Notifier
     */
    protected $notifier;

    /**
     * Message to send.
     *
     * @var string
     */
    protected $message;

    /**
     * Type of notification.
     *
     * @var string
     */
    protected $type;

    /**
     * Target user/users.
     *
     * @var mixed
     */
    protected $target;

    /**
     * Resource ID.
     *
     * @var mixed
     */
    protected $resourceId;

    /**
     * URL.
     *
     * @var string
     */
    protected $url;

    /**
     * Create a new job instance.
     *
     * @param Notifier $notifier   Notifier instance.
     * @param string   $message    Message instance.
     * @param string   $type       Type of the notification.
     * @param mixed    $target     Target of the notification.
     * @param mixed    $resourceId Notification resource ID.
     * @param string   $url        URL of the notification.
     */
    public function __construct(
        Notifier $notifier,
        $message,
        $type,
        $target = null,
        $resourceId = null,
        $url = null
    ) {
        $this->notifier = $notifier;
        $this->message = $message;
        $this->type = $type;
        $this->target = $target;
        $this->resourceId = $resourceId;
        $this->url = $url;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $this->notifier->notify(
            $this->message,
            $this->type,
            $this->target,
            $this->resourceId,
            $this->url
        );
    }
}
