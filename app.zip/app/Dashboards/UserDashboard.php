<?php

namespace App\Dashboards;

use App\Auth\User;
use App\Dashboards\Dashboard;
use Creitive\Database\Eloquent\Model;
use Creitive\Image\Transformers\Thumbnail;
use Creitive\Models\Traits\ImageableTrait;
use Creitive\Models\Traits\SortableTrait;
use URL;

class UserDashboard extends Model
{
    use ImageableTrait;
    use SortableTrait;

    /**
     * {@inheritDoc}
     */
    protected $table = 'user_dashboards';

    /**
     * {@inheritDoc}
     */
    public $timestamps = false;

    /**
     * {@inheritDoc}
     */
    protected $casts = [
        'is_owner' => 'bool',
        'can_edit' => 'bool',
    ];

    /**
     * {@inheritDoc}
     */
    public function getImageConfiguration()
    {
        return [
            'versions' => [
                'main' => [
                    'original' => [],
                    'large' => [
                        [
                            'transformer' => Thumbnail::class,
                            'width' => 1920,
                            'height' => 870,
                        ],
                    ],
                ],
            ],
        ];
    }

    /**
     * Eloquent relation: User dashboard belongs to a user.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Eloquent relation: User dashboard belongs to a dashboard.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function dashboard()
    {
        return $this->belongsTo(Dashboard::class);
    }

    /**
     * Gets the complete URL to the original main image.
     *
     * @return string
     */
    public function getUrlImageMainOriginalAttribute()
    {
        return URL::to($this->getImage('main', 'original'));
    }

    /**
     * Gets the complete URL to the large main image.
     *
     * @return string
     */
    public function getUrlImageMainLargeAttribute()
    {
        return URL::to($this->getImage('main', 'large'));
    }
}
