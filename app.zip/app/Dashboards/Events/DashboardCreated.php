<?php

namespace App\Dashboards\Events;

use App\Auth\User;
use App\Dashboards\Dashboard;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class DashboardCreated
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    /**
     * User instance.
     *
     * @var User
     */
    public $user;

    /**
     * Dashboard instance.
     *
     * @var Dashboard
     */
    public $dashboard;

    /**
     * Create a new event instance.
     *
     * @param User      $user      User instance.
     * @param Dashboard $dashboard Dashboard instance.
     */
    public function __construct(User $user, Dashboard $dashboard)
    {
        $this->user = $user;
        $this->dashboard = $dashboard;
    }
}
