<?php

namespace App\Dashboards;

use App\Auth\User;
use App\DashboardCategories\DashboardCategory;
use App\Dashboards\UserDashboard;
use App\Widgets\Widget;
use App\WidgetTypes\WidgetType;
use Creitive\Database\Eloquent\Model;

class Dashboard extends Model
{
    const THEME_CLEAN = 'clean';
    const THEME_ARCHITECT = 'architect';
    const THEME_ART = 'art';
    const THEME_GRAY = 'gray';
    const THEME_ZEN = 'zen';
    const THEME_RELAX = 'relax';
    const THEME_NIGHT = 'night';
    const THEME_CUSTOM = 'custom';

    /**
     * {@inheritDoc}
     */
    protected $casts = [
        'is_home' => 'bool',
        'is_shared' => 'bool',
    ];

    /**
     * Eloquent relation: Dashboard belongs to a dashboard category.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function dashboardCategory()
    {
        return $this->belongsTo(DashboardCategory::class);
    }

    /**
     * Eloquent relation: Dashboard can have multiple widgets.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function widgets()
    {
        return $this->belongsToMany(Widget::class, 'user_widgets')
            ->withPivot([
                'user_id',
                'can_edit',
                'is_owner',
                'archived_at',
                'sort',
            ]);
    }

    /**
     * Eloquent relation: Dashboard can have multiple not hidden widgets.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function notHiddenWidgets()
    {
        return $this->belongsToMany(Widget::class, 'user_widgets')
            ->whereHas('widgetType', function ($q) {
                $q->whereHidden(0);
            })
            ->withPivot([
                'user_id',
                'can_edit',
                'is_owner',
                'archived_at',
                'sort',
            ]);
    }

    /**
     * Eloquent relation: Dashboard can belong to many users.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function users()
    {
        return $this->belongsToMany(User::class, 'user_dashboards')
            ->withPivot([
                'id',
                'is_owner',
                'can_edit',
            ]);
    }

    /**
     * Returns an owner of the dashboard.
     *
     * @return \App\Auth\User
     */
    public function owner()
    {
        return $this->users->where('pivot.is_owner', 1)->first();
    }

    /**
     * Eloquent relationship: dashboard may have many user dashboards.
     *
     * This is unconventional relation to pivot table, we need this to take
     * advantage of our image upload system and other stuff that is specific to
     * our CMS and it's not supported on laravel pivots by default (image
     * uploading, sorting...).
     *
     * @return HasMany
     */
    public function userDashboards()
    {
        return $this->hasMany(UserDashboard::class);
    }

    /**
     * Gets shared attribute, showing if dashboard is shared with someone.
     *
     * @return bool
     */
    public function getSharedAttribute()
    {
        return $this->users->unique()->count() > 1;
    }
}
