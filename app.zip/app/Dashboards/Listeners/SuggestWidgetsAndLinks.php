<?php

namespace App\Dashboards\Listeners;

use App\Dashboards\Dashboard\Manager as DashboardManager;
use App\Dashboards\Events\DashboardCreated;
use App\Widgets\Link\Manager as LinkManager;
use App\Widgets\Widget\Manager as WidgetManager;

class SuggestWidgetsAndLinks
{
    /**
     * Widget manager instance.
     *
     * @var WidgetManager
     */
    protected $widgetManager;

    /**
     * Link manager instance.
     *
     * @var LinkManager
     */
    protected $linkManager;

    /**
     * @param WidgetManager $widgetManager Widget manager instance.
     * @param LinkManager   $linkManager   Link manager instance.
     */
    public function __construct(
        WidgetManager $widgetManager,
        LinkManager $linkManager
    ) {
        $this->widgetManager = $widgetManager;
        $this->linkManager = $linkManager;
    }

    /**
     * Handle the event.
     *
     * @param DashboardCreated $event Event instance.
     *
     * @return void
     */
    public function handle(DashboardCreated $event)
    {
        $this->widgetManager->suggestWidgetsForDashboard($event->dashboard, $event->user);
        $this->linkManager->suggestLinksForDashboard($event->dashboard, $event->user);
    }
}
