<?php

namespace App\Dashboards\Http\Controllers\Front\Dashboard;

use App\Http\Controllers\Front\Controller as BaseController;
use Cartalyst\Sentinel\Sentinel;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

class Controller extends BaseController
{
    /**
     * Class constructor.
     */
    public function __construct()
    {
        parent::__construct();

        $this->viewData->pageTitle->setPage(trans('dashboards.title'));
    }

    /**
     * Displays dashboards view (root view for React app).
     *
     * @param Sentinel $sentinel Sentinel instance.
     *
     * @return \Illuminate\View\View
     *
     * @throws AccessDeniedHttpException
     */
    public function index(Sentinel $sentinel)
    {
        $user = $sentinel->getUser();

        if (!$user->profile_completed || $user->inRole('admin')) {
            throw new AccessDeniedHttpException();
        }

        $data = [
          'logoClass' => 'navbar-brand--dark',
          'toggleButtonClass' => 'navbar-toggle--dark',
        ];

        return view('dashboards.index', $data);
    }
}
