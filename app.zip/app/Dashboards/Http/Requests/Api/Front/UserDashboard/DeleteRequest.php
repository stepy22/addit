<?php

namespace App\Dashboards\Http\Requests\Api\Front\UserDashboard;

use App\Http\Requests\Request;
use Cartalyst\Sentinel\Sentinel;

class DeleteRequest extends Request
{
    /**
     * Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * @param Sentinel $sentinel Sentinel instance.
     */
    public function __construct(Sentinel $sentinel)
    {
        $this->sentinel = $sentinel;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $userDashboard = $this->route('userDashboard');

        $user = $this->sentinel->getUser();
        $userDashboard->load('dashboard.users');

        $dashboard = $userDashboard->dashboard;

        // Even though this should never happed, we should check anyway.
        // Dashboard owner can't be deleted.
        if ($userDashboard->is_owner) {
            return false;
        }

        if ($dashboard->owner()->id !== $user->id) {
            if ($userDashboard->user_id === $user->id) {
                return true;
            }

            return false;
        }

        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [];
    }
}
