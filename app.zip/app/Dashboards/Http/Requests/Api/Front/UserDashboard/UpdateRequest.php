<?php

namespace App\Dashboards\Http\Requests\Api\Front\UserDashboard;

use App\Http\Requests\Request;
use Cartalyst\Sentinel\Sentinel;

class UpdateRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $userDashboard = $this->route('userDashboard');

        // Even though this should never happed, we should check anyway.
        // Dashboard owner can't be deleted.
        if ($userDashboard->is_owner) {
            return false;
        }

        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'can_edit' => ['required', 'boolean'],
        ];
    }
}
