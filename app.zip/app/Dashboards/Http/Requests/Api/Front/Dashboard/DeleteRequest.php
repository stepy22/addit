<?php

namespace App\Dashboards\Http\Requests\Api\Front\Dashboard;

use App\Http\Requests\Request;
use Cartalyst\Sentinel\Sentinel;

class DeleteRequest extends Request
{
    /**
     * Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * @param Sentinel $sentinel Sentinel instance.
     */
    public function __construct(Sentinel $sentinel)
    {
        $this->sentinel = $sentinel;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $user = $this->sentinel->getUser();
        $dashboard = $this->route('dashboard');

        $dashboard = $user->dashboards->where('id', $dashboard->id)->first();

        if (!$dashboard->pivot->is_owner) {
            return false;
        }

        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [];
    }
}
