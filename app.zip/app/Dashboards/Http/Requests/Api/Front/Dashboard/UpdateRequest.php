<?php

namespace App\Dashboards\Http\Requests\Api\Front\Dashboard;

use App\Dashboards\Dashboard;
use App\Http\Requests\Request;

class UpdateRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $dashboard = $this->route('dashboard');

        return !$dashboard->is_home && !$dashboard->is_shared;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $themesAvailable = [
            Dashboard::THEME_CLEAN,
            Dashboard::THEME_ARCHITECT,
            Dashboard::THEME_ART,
            Dashboard::THEME_GRAY,
            Dashboard::THEME_ZEN,
            Dashboard::THEME_RELAX,
            Dashboard::THEME_NIGHT,
            Dashboard::THEME_CUSTOM,
        ];

        $rules = [
            'title' => ['required', 'max:100'],
            'theme' => ['required', 'in:'. implode(',', $themesAvailable)],
            'dashboard_category_id' => ['required', 'exists:dashboard_categories,id'],
            'image_main' => ['base_64_encoded_image', 'max:'.(10240 * 1024) / 3 * 4],
        ];

        return $rules;
    }
}
