<?php

namespace App\Dashboards\Http\Middleware;

use App\Auth\User;
use App\Dashboards\Dashboard;
use Cartalyst\Sentinel\Sentinel;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Routing\Redirector;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

class UserDashboardAccess
{
    /**
     * The Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * @param Sentinel $sentinel Sentinel instance.
     */
    public function __construct(Sentinel $sentinel)
    {
        $this->sentinel = $sentinel;
    }

    /**
     * Handle an incoming request.
     *
     * @param Request  $request Request instance.
     * @param \Closure $next    Closure function.
     *
     * @throws AccessDeniedHttpException
     *
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        $user = $this->sentinel->getUser();
        $dashboard = $request->route('dashboard');

        // Check if user has access to a dashboard.
        $usersDashboard = $user->dashboards->where('id', $dashboard->id)->first();

        if (!$usersDashboard) {
            throw new AccessDeniedHttpException;
        }

        // Check if owner of a dashboard has PRO account if accessing shared dashboard.
        if (!$usersDashboard->pivot->is_owner) {
            $owner = $usersDashboard->users->where('pivot.is_owner', true)->first();

            if ($owner->account_plan !== User::ACCOUNT_PLAN_PRO) {
                throw new AccessDeniedHttpException;
            }
        }

        return $next($request);
    }
}
