<?php

namespace App\Dashboards\Http\Middleware;

use Cartalyst\Sentinel\Sentinel;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

class DashboardOwnershipMiddleware
{
    /**
     * The Sentinel instance.
     *
     * @var Sentinel
     */
    protected $sentinel;

    /**
     * @param Sentinel $sentinel Sentinel instance.
     */
    public function __construct(Sentinel $sentinel)
    {
        $this->sentinel = $sentinel;
    }

    /**
     * Handle an incoming request.
     *
     * @param Request  $request Request instance.
     * @param \Closure $next    Closure function.
     *
     * @return mixed
     *
     * @throws AccessDeniedHttpException
     */
    public function handle(Request $request, Closure $next)
    {
        $user = $this->sentinel->getUser();
        $dashboard = $request->route('dashboard');
        if (!$dashboard) {
            $userDashboard = $request->route('userDashboard');
            $dashboard = $userDashboard->dashboard;
        }

        if (!$dashboard) {
            throw new AccessDeniedHttpException();
        }

        $dashboard->load('users');

        if ($dashboard->owner()->id !== $user->id) {
            throw new AccessDeniedHttpException();
        }

        return $next($request);
    }
}
