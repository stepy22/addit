<?php

namespace App\Dashboards\Mail;

use App\Dashboards\Dashboard;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Collection;

class SharedDashboardDeleted extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * The Dashboard instance.
     *
     * @var Dashboard
     */
    public $dashboard;

    /**
     * The Users collection instance.
     *
     * @var Collection
     */
    public $users;

    /**
     * @param Dashboard  $dashboard Dashboard instance.
     * @param Collection $users     Users collection.
     */
    public function __construct(Dashboard $dashboard, Collection $users)
    {
        $this->dashboard = $dashboard;
        $this->users = $users;
    }

    /**
     * {@inheritDoc}
     */
    public function build()
    {
        $message = $this->view('emails.dashboards.deleted')
            ->subject(trans('emails/dashboards/deletion.subject'));

        foreach ($this->users as $user) {
            $message->bcc($user->email, $user->full_name);
        }

        return $message;
    }
}
