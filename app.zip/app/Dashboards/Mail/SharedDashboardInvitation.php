<?php

namespace App\Dashboards\Mail;

use App\Dashboards\Dashboard;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use URL;

class SharedDashboardInvitation extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Dashboard instance.
     *
     * @var Dashboard
     */
    public $dashboard;

    /**
     * Email to which to send invitation.
     *
     * @var string
     */
    public $email;

    /**
     * @param Dashboard $dashboard Dashboard instance.
     * @param string    $email     Email to which to send invitation.
     */
    public function __construct(Dashboard $dashboard, $email)
    {
        $this->dashboard = $dashboard;
        $this->email = $email;
    }

    /**
     * {@inheritDoc}
     */
    public function build()
    {
        return $this->view('emails.dashboards.shared-invitation')
            ->subject(trans('emails/dashboards/sharedInvitation.subject'))
            ->to($this->email)
            ->with([
                'registrationLink' => URL::action(
                    'App\Auth\Http\Controllers\Front\Registration\Controller@index',
                    ['referrer' => $this->dashboard->owner()->id]
                ),
            ]);
    }
}
