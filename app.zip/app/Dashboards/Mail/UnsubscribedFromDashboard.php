<?php

namespace App\Dashboards\Mail;

use App\Dashboards\UserDashboard;
use App\Dashboards\Widget;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class UnsubscribedFromDashboard extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * The UserDashboard instance.
     *
     * @var UserDashboard
     */
    public $userDashboard;

    /**
     * User instance.
     *
     * @var User
     */
    public $user;

    /**
     * Dashboard instance.
     *
     * @var Dashboard
     */
    public $dashboard;

    /**
     * @param UserDashboard $userDashboard UserDashboard instance.
     */
    public function __construct(UserDashboard $userDashboard)
    {
        $this->userDashboard = $userDashboard;
        $this->dashboard = $userDashboard->dashboard;
        $this->user = $userDashboard->user;
    }

    /**
     * {@inheritDoc}
     */
    public function build()
    {
        return $this->view('emails.dashboards.unsubscribed-from-dashboard')
            ->subject(trans('emails/dashboards/unsubscribedFromDashboard.subject'))
            ->to($this->dashboard->owner()->email, $this->dashboard->owner()->full_name);
    }
}
