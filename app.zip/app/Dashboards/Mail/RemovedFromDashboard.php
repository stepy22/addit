<?php

namespace App\Dashboards\Mail;

use App\Dashboards\Dashboard;
use App\Dashboards\UserDashboard;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class RemovedFromDashboard extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * The UserDashboard instance.
     *
     * @var UserDashboard
     */
    public $userDashboard;

    /**
     * The Dashboard instance.
     *
     * @var Dashboard
     */
    public $dashboard;

    /**
     * @param UserDashboard $userDashboard UserDashboard instance.
     */
    public function __construct(UserDashboard $userDashboard)
    {
        $this->userDashboard = $userDashboard;
        $this->dashboard = $userDashboard->dashboard;
    }

    /**
     * {@inheritDoc}
     */
    public function build()
    {
        $email = $this->userDashboard->user ? $this->userDashboard->user->email : $this->userDashboard->email;
        $name = $this->userDashboard->user ? $this->userDashboard->user->name : '';

        return $this->view('emails.dashboards.removed-from-dashboard')
            ->subject(trans('emails/dashboards/removedFromDashboard.subject'))
            ->to($email, $name);
    }
}
