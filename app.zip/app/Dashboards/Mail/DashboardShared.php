<?php

namespace App\Dashboards\Mail;

use App\Auth\User;
use App\Dashboards\Dashboard;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class DashboardShared extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * The Dashboard instance.
     *
     * @var Dashboard
     */
    public $dashboard;

    /**
     * The User instance.
     *
     * @var User
     */
    public $user;

    /**
     * @param Dashboard $dashboard Dashboard instance.
     * @param User      $user      User instance.
     */
    public function __construct(Dashboard $dashboard, User $user)
    {
        $this->dashboard = $dashboard;
        $this->user = $user;
    }

    /**
     * {@inheritDoc}
     */
    public function build()
    {
        return $this->view('emails.dashboards.shared')
            ->subject(trans('emails/dashboards/sharing.subject'))
            ->to($this->user->email, $this->user->full_name);
    }
}
