<?php

namespace App\Dashboards\Mail;

use App\Dashboards\Dashboard;
use App\Dashboards\UserDashboard;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class SharedDashboardPermissionsChanged extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * The UserDashboard instance.
     *
     * @var UserDashboard
     */
    public $userDashboard;

    /**
     * Whether user can or cannot edit shared dashboard.
     *
     * @var bool
     */
    public $canEdit;

    /**
     * Dashboard instance.
     *
     * @var Dashboard
     */
    public $dashboard;

    /**
     * @param UserDashboard $userDashboard UserDashboard instance.
     * @param bool          $canEdit       User instance.
     */
    public function __construct(UserDashboard $userDashboard, $canEdit)
    {
        $this->userDashboard = $userDashboard;
        $this->dashboard = $userDashboard->dashboard;
        $this->canEdit = $canEdit;
    }

    /**
     * {@inheritDoc}
     */
    public function build()
    {
        $email = $this->userDashboard->user ? $this->userDashboard->user->email : $this->userDashboard->email;
        $name = $this->userDashboard->user ? $this->userDashboard->user->name : '';

        return $this->view('emails.dashboards.permissions-change')
            ->subject(trans('emails/dashboards/permissionsChanged.subject'))
            ->to($email, $name);
    }
}
