<?php

namespace App\Dashboards\Dashboard;

use App\Dashboards\Dashboard\Repository as DashboardRepository;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Routing\Router;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerRoutePatterns($this->app['router'], $this->app);
        $this->registerFrontApiRoutes($this->app['router']);
        $this->registerFrontRoutes($this->app['router']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers the route patterns.
     *
     * @param Router    $router    A router.
     * @param Container $container A dependency container.
     *
     * @return void
     */
    protected function registerRoutePatterns(Router $router, Container $container)
    {
        $idRegex = $this->routePatternRegexes['id'];
        $slugRegex = $this->routePatternRegexes['slug'];

        $router->pattern('dashboard', $idRegex);

        $router->bind('dashboard', function ($value) use ($container, $idRegex) {
            $dashboardRepository = $container->make(DashboardRepository::class);

            if (preg_match("/^{$idRegex}$/D", $value)) {
                $dashboard = $dashboardRepository->find($value);

                if ($dashboard !== null) {
                    return $dashboard;
                }
            }
        });
    }

    /**
     * Registers front end routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
           'prefix' => 'api/v1/dashboards',
           'middleware' => ['api', 'auth'],
           'namespace' => 'App\Dashboards\Http\Controllers\Api\V1\Front\Dashboard',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('', 'Controller@index');
            $router->post('', 'Controller@create');
            $router->get('home', 'Controller@showHomeDashboard');
            $router->put('sort', 'Controller@sort');
            $router->get('themes', 'Controller@themes');
        });

        $attributes['middleware'][] = 'dashboard.access';

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('{dashboard}', 'Controller@show');
            $router->get('{dashboard}/archived-widgets', 'Controller@archivedWidgets');
            $router->put('{dashboard}', 'Controller@update');
            $router->delete('{dashboard}', 'Controller@delete');
        });

        $attributes['namespace'] = 'App\Widgets\Http\Controllers\Api\V1\Front\Widget';

        $router->group($attributes, function (RegistrarContract $router) {
            $router->post('{dashboard}/widgets', 'Controller@store');
        });
    }

    /**
     * Registers front end routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontRoutes(RegistrarContract $router)
    {
        $attributes = [
           'prefix' => trans('routes.dashboards'),
           'middleware' => ['web', 'auth.front'],
           'namespace' => 'App\Dashboards\Http\Controllers\Front\Dashboard',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('', 'Controller@index');
        });
    }
}
