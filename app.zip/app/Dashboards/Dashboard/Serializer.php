<?php

namespace App\Dashboards\Dashboard;

use App\Auth\User;
use App\Dashboards\Dashboard;
use App\Widgets\Widget;
use App\Widgets\Widget\Serializer as WidgetSerializer;

class Serializer
{
    const WIDGET_LIST_LINKS_COUNT = 5;

    /**
     * Widget serializer instance.
     *
     * @var WidgetSerializer
     */
    protected $widgetSerializer;

    /**
     * @param WidgetSerializer $widgetSerializer Widget serializer instance.
     */
    public function __construct(WidgetSerializer $widgetSerializer)
    {
        $this->widgetSerializer = $widgetSerializer;
    }

    /**
     * Serializes user's dashboards for @index method in front api controller
     * method.
     *
     * @param User $user User instance.
     *
     * @return array
     */
    public function serializeUsersDashboards(User $user)
    {
        $user->load('dashboards.users');
        $dashboards = $user->dashboards->map(function (Dashboard $dashboard) use ($user) {
            return [
                'id' => $dashboard->id,
                'title' => $dashboard->title,
                'is_home' => $dashboard->is_home,
                'is_shared' => $dashboard->is_shared,
                'dashboard_category_id' => $dashboard->dashboard_category_id,
                'is_owner' => (bool) $dashboard->pivot->is_owner,
                'can_edit' => (bool) $dashboard->pivot->can_edit,
                'sort' => $dashboard->pivot->sort,
                'theme' => $dashboard->pivot->theme,
                'pivot_id' => $dashboard->pivot->id,
                'shared' => $dashboard->users->count() > 1,
                'shared_owner' => $dashboard->owner()->full_name,
                'shared_disabled' => $dashboard->users->count() > 1 ?
                    $dashboard->owner()->account_plan === User::ACCOUNT_PLAN_REGULAR :
                    null,
            ];
        });

        return $dashboards;
    }

    /**
     * Serializes user's home dashboard for @show method in front api controller
     * method.
     *
     * @param Dashboard $dashboard Dashboard instance.
     * @param User      $user      User instance.
     *
     * @return array
     */
    public function serializeSingleDashboard(Dashboard $dashboard, User $user)
    {
        $dashboard->load(
            'notHiddenWidgets.links',
            'notHiddenWidgets.files',
            'notHiddenWidgets.events',
            'notHiddenWidgets.checklists',
            'notHiddenWidgets.galleries',
            'notHiddenWidgets.notes',
            'notHiddenWidgets.birthdays',
            'notHiddenWidgets.contacts',
            'notHiddenWidgets.users',
            'notHiddenWidgets.favouriteForUsers',
            'notHiddenWidgets.widgetType',
            'userDashboards'
        );

        $pivot = $dashboard->userDashboards
           ->where('user_id', $user->id)
           ->first();

        $widgets = $dashboard->notHiddenWidgets->where('pivot.user_id', $user->id)
            ->where('pivot.archived_at', null)
            ->load('files', 'checklists.items', 'galleries.images', 'links', 'events', 'userWidgets')
            ->map(function (Widget $widget) use ($user, $dashboard) {
                return $this->widgetSerializer->serializeForDashboard($widget, $user, $dashboard->id);
            });

        return [
            'id' => $dashboard->id,
            'title' => $dashboard->title,
            'is_home' => $dashboard->is_home,
            'is_shared' => $dashboard->is_shared,
            'dashboard_category_id' => $dashboard->dashboard_category_id,
            'is_owner' => (bool) $pivot->is_owner,
            'can_edit' => (bool) $pivot->can_edit,
            'sort' => $pivot->sort,
            'theme' => $pivot->theme,
            'pivot_id' => $pivot->id,
            'url_image_main_original' => $pivot->url_image_main_original,
            'url_image_main_large' => $pivot->url_image_main_large,
            'shared' => $dashboard->users->count() > 1,
            'shared_owner' => $dashboard->owner()->full_name,
            'shared_disabled' => $dashboard->users->count() > 1 ?
                $dashboard->owner()->account_plan === User::ACCOUNT_PLAN_REGULAR :
                null,
            'widgets' => array_values($widgets->toArray()),
        ];
    }
}
