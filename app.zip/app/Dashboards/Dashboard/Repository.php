<?php

namespace App\Dashboards\Dashboard;

use App\Auth\User;
use App\Dashboards\Dashboard;
use App\Dashboards\UserDashboard;
use App\Dashboards\UserDashboard\Repository as UserDashboardRepository;
use App\Widgets\Widget;
use App\Widgets\Widget\Repository as WidgetRepository;
use App\WidgetTypes\WidgetType;
use Carbon\Carbon;
use Hshn\Base64EncodedFile\HttpFoundation\File\Base64EncodedFile;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\QueryException;
use Illuminate\Http\UploadedFile;
use Log;
use Ramsey\Uuid\Exception\UnsatisfiedDependencyException;
use Ramsey\Uuid\Uuid;

class Repository
{
    /**
     * Number of retires in case of UUID collision, it is highly unlikely to
     * have UUID collisions in a first place, but lets be sure :D
     */
    const UUID_COLLISION_RETRIES = 5;

    /**
     * A Dashboard model instance.
     *
     * @var Dashboard
     */
    protected $dashboard;

    /**
     * A user dashboard repository instance.
     *
     * @var UserDashboardRepository
     */
    protected $userDashboardRepository;

    /**
     * A widget repository instance.
     *
     * @var WidgetRepository
     */
    protected $widgetRepository;

    /**
     * Number of retries to insert dashboards in case of collision.
     *
     * @var integer
     */
    protected $insertRetries = 0;

    /**
     * @param Dashboard               $dashboard               A dashboard model instance.
     * @param UserDashboardRepository $userDashboardRepository A user dashboard repository instance.
     * @param WidgetRepository        $widgetRepository        A widget dashboard repository instance.
     */
    public function __construct(
        Dashboard $dashboard,
        UserDashboardRepository $userDashboardRepository,
        WidgetRepository $widgetRepository
    ) {
        $this->dashboardModel = $dashboard;
        $this->userDashboardRepository = $userDashboardRepository;
        $this->widgetRepository = $widgetRepository;
    }

    /**
     * Gets all dashboards.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAll()
    {
        return $this->dashboardModel->sorted()->get();
    }

    /**
     * Finds the dashboard by ID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $id The dashboard ID.
     *
     * @return Dashboard|null
     */
    public function find($id)
    {
        return $this->dashboardModel->find($id);
    }

    /**
     * Finds the dashboard by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The dashboard ID.
     *
     * @return Dashboard
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->dashboardModel->findOrFail($id);
    }

    /**
     * Creates a new dashboard and returns it.
     *
     * @param User  $user      User instance.
     * @param array $inputData The dashboard input data.
     *
     * @return Dashboard
     *
     * @throws QueryException
     */
    public function create(User $user, array $inputData)
    {
        $dashboard = $this->dashboardModel->newInstance();

        $dashboard->title = $inputData['title'];
        $dashboard->dashboard_category_id = $inputData['dashboard_category_id'];

        try {
            $uuid = Uuid::uuid4();
            $dashboard->uuid = $uuid->toString();
            $uuids[] = $dashboard->uuid;
        } catch (UnsatisfiedDependencyException $e) {
            Log::error('Failed to generate uuid for user dashboard. ' . $e->getMessage() . "\n");
        }

        try {
            $dashboard->save();
        } catch (QueryException $e) {
            // If error is caused by duplicated UUID, try again.
            if ($e->getCode() === "23000" && $this->insertRetries < self::UUID_COLLISION_RETRIES) {
                $this->insertRetries++;
                $this->create($user);
            } else {
                throw $e;
            }
        }

        $this->userDashboardRepository->create([
            'user_id' => $user->id,
            'dashboard_id' => $dashboard->id,
            'is_owner' => true,
            'can_edit' => true,
            'theme' => $inputData['theme'],
            'image_main' => array_get($inputData, 'image_main'),
        ]);

        return $dashboard;
    }

    /**
     * Updates the passed dashboard and returns it.
     *
     * @param Dashboard     $dashboard     The dashboard to update.
     * @param UserDashboard $userDashboard The user dashboard to update.
     * @param array         $inputData     The input data for the update.
     *
     * @return Dashboard
     */
    public function update(Dashboard $dashboard, UserDashboard $userDashboard, array $inputData)
    {
        $dashboard->title = array_get($inputData, 'title', $dashboard->title);
        $dashboard->dashboard_category_id = array_get($inputData, 'dashboard_category_id', $dashboard->dashboard_category_id);

        $dashboard->save();

        $userDashboard->theme = array_get($inputData, 'theme', $userDashboard->theme);

        if (isset($inputData['image_main'])) {
            if ($inputData['image_main'] instanceof UploadedFile) {
                $userDashboard->uploadImage($inputData['image_main'], 'main');
            } else {
                $file = new Base64EncodedFile($inputData['image_main']);
                $userDashboard->uploadImage($file->getPathname(), 'main');
            }
        }

        $userDashboard->save();
    }

    /**
     * Deletes the passed dashboard from the system.
     *
     * @param Dashboard $dashboard The dashboard to delete.
     *
     * @return bool|null
     */
    public function delete(Dashboard $dashboard)
    {
        // TODO: For now we'll just delete all widgets from shared dashboard but
        // this will get a lot more complicated.
        $widgetIds = $dashboard->widgets->pluck('id')->toArray();
        $this->widgetRepository->deleteByIds($widgetIds);

        return $dashboard->delete();
    }

    /**
     * Creates home dashboard for user.
     *
     * @param User $user User instance.
     *
     * @return Dashboard
     *
     * @throws QueryException
     */
    public function createHomeDashboardForUser(User $user)
    {
        $dashboard = $this->dashboardModel->newInstance();

        $dashboard->title = trans('dashboards.homeDashboardTitle');
        $dashboard->is_home = true;

        try {
            $uuid = Uuid::uuid4();
            $dashboard->uuid = $uuid->toString();
            $uuids[] = $dashboard->uuid;
        } catch (UnsatisfiedDependencyException $e) {
            Log::error('Failed to generate uuid for user dashboard. ' . $e->getMessage() . "\n");
        }

        try {
            $dashboard->save();
        } catch (QueryException $e) {
            // If error is caused by duplicated UUID, try again.
            if ($e->getCode() === "23000" && $this->insertRetries < self::UUID_COLLISION_RETRIES) {
                $this->insertRetries++;
                $this->createHomeDashboardForUser($user);
            } else {
                throw $e;
            }
        }

        $this->userDashboardRepository->create([
            'user_id' => $user->id,
            'dashboard_id' => $dashboard->id,
            'is_owner' => true,
            'can_edit' => true,
        ]);

        return $dashboard;
    }

    /**
     * Creates shared dashboard for user.
     *
     * @param User $user User instance.
     *
     * @return Dashboard
     *
     * @throws QueryException
     */
    public function createSharedDashboardForUser(User $user)
    {
        $dashboard = $this->dashboardModel->newInstance();

        $dashboard->title = trans('dashboards.sharedDashboardTitle');
        $dashboard->is_shared = true;

        try {
            $uuid = Uuid::uuid4();
            $dashboard->uuid = $uuid->toString();
            $uuids[] = $dashboard->uuid;
        } catch (UnsatisfiedDependencyException $e) {
            Log::error('Failed to generate uuid for user dashboard. ' . $e->getMessage() . "\n");
        }

        try {
            $dashboard->save();
        } catch (QueryException $e) {
            // If error is caused by duplicated UUID, try again.
            if ($e->getCode() === "23000" && $this->insertRetries < self::UUID_COLLISION_RETRIES) {
                $this->insertRetries++;
                $this->createHomeDashboardForUser($user);
            } else {
                throw $e;
            }
        }

        $this->userDashboardRepository->create([
            'user_id' => $user->id,
            'dashboard_id' => $dashboard->id,
            'is_owner' => true,
            'can_edit' => true,
        ]);

        return $dashboard;
    }

    /**
     * Creates basic dashboards for user.
     *
     * @param User       $user       User instance.
     * @param Collection $categories Categories collection.
     *
     * @return Collection
     *
     * @throws QueryException
     */
    public function createDashboardsForUser(User $user, Collection $categories)
    {
        $dashboards = collect();
        $uuids = [];

        // Creates dashboard for each passed category.
        foreach ($categories as $category) {
            $dashboard = $this->dashboardModel->newInstance();

            try {
                $uuid = Uuid::uuid4();
                $dashboard->uuid = $uuid->toString();
                $uuids[] = $dashboard->uuid;
            } catch (UnsatisfiedDependencyException $e) {
                Log::error('Failed to generate uuid for user dashboard. ' . $e->getMessage() . "\n");
            }

            $dashboard->title = $category->name;
            $dashboard->dashboard_category_id = $category->id;
            $dashboard->created_at = Carbon::now();
            $dashboard->updated_at = Carbon::now();

            $dashboards->push($dashboard);
        }

        // Checks if insert fail because UUID collision, in which case it tries
        // again.
        try {
            $this->dashboardModel->insert($dashboards->toArray());
        } catch (QueryException $e) {
            // If error is caused by duplicated UUID, try again.
            if ($e->getCode() === "23000" && $this->insertRetries < self::UUID_COLLISION_RETRIES) {
                $this->insertRetries++;
                $this->createDashboardsForUser($user, $categories);
            } else {
                throw $e;
            }
        }

        // Fetches created dashboards from database, and creates pivot table
        // records, connecting created dashboard to a user.
        $createdDashboards = $this->dashboardModel
            ->whereIn('uuid', $uuids)
            ->get();

        $pivotsData = [];

        $nextSortValue = $this->userDashboardRepository->getNextSortValue();

        foreach ($createdDashboards as $dashboard) {
            $pivotsData[$dashboard->id] = [
                'is_owner' => true,
                'can_edit' => true,
                'sort' => $nextSortValue++,
            ];
        }

        $user->dashboards()->attach($pivotsData);

        return $createdDashboards;
    }

    /**
     * Shares a dashboard with a user.
     *
     * @param  Dashboard $dashboard Dashboard instance.
     * @param  User      $user      User instance.
     *
     * @return Dashboard
     *
     * @throws RuntimeException
     */
    public function share(Dashboard $dashboard, User $user)
    {
        if ($user->dashboards->isEmpty()) {
            $newSort = $user->dashboards->sortByDesc('pivot.sort')->first()->pivot->sort + 1;
        } else {
            $newSort = 0;
        }

        $dashboard->users()->attach([
            $user->id => [
                'is_owner' => false,
                'can_edit' => false,
                'sort' => $newSort,
            ],
        ]);

        $dashboard->load('widgets.widgetType');

        $ownersWidgets = $dashboard->widgets->where('pivot.is_owner', true);

        $widgetsForAttaching = [];
        $sort = 1;

        foreach ($ownersWidgets as $widget) {
            // Skip if it's default widget or if widget is already shared with a
            // user.
            if ($widget->widgetType->origin === WidgetType::ORIGIN_DEFAULT ||
                $user->widgets->where('id', $widget->id)->count() > 0
            ) {
                continue;
            }

            $widgetsForAttaching[$widget->id] = [
                'is_owner' => false,
                'can_edit' => false,
                'sort' => $sort++,
                'user_id' => $user->id,
            ];
        }

        $dashboard->widgets()->attach($widgetsForAttaching);

        return $dashboard;
    }
}
