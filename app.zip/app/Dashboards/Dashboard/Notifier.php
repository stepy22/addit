<?php

namespace App\Dashboards\Dashboard;

use App\Auth\User;
use App\Dashboards\Dashboard;
use App\Dashboards\Mail\DashboardShared;
use App\Dashboards\Mail\RemovedFromDashboard;
use App\Dashboards\Mail\SharedDashboardDeleted;
use App\Dashboards\Mail\SharedDashboardInvitation;
use App\Dashboards\Mail\SharedDashboardPermissionsChanged;
use App\Dashboards\Mail\UnsubscribedFromDashboard;
use App\Dashboards\UserDashboard;
use App\Jobs\NotifyUser;
use App\Notifications\Notification;
use App\Notifications\Notification\Notifier as BaseNotifier;
use Illuminate\Contracts\Mail\Mailer;
use Illuminate\Support\Collection;
use URL;

class Notifier
{
    /**
     * A Mailer instance.
     *
     * @var Mailer
     */
    protected $mailer;

    /**
     * A base notifier service..
     *
     * @var BaseNotifier
     */
    protected $baseNotifier;

    /**
     * @param Mailer       $mailer       Mailer class instance.
     * @param BaseNotifier $baseNotifier Base notifier instance.
     */
    public function __construct(Mailer $mailer, BaseNotifier $baseNotifier)
    {
        $this->mailer = $mailer;
        $this->baseNotifier = $baseNotifier;
    }

    /**
     * Notifies a user about deleted shared notification.
     *
     * @param Dashboard  $dashboard Dashboard instance.
     * @param Collection $users     Users collection.
     *
     * @return void
     */
    public function notify(Dashboard $dashboard, Collection $users)
    {
        $this->mailer->queue(new SharedDashboardDeleted($dashboard, $users));

        NotifyUser::dispatch(
            $this->baseNotifier,
            trans('dashboards.notifications.'.Notification::TYPE_DASHBOARD_DELETION, [
                'user' => $dashboard->owner()->full_name,
                'dashboard' => $dashboard->title,
            ]),
            Notification::TYPE_DASHBOARD_DELETION,
            $users,
            null,
            URL::action('App\Dashboards\Http\Controllers\Front\Dashboard\Controller@index', [], false)
        );
    }

    /**
     * Notifies a user that dashboard is shared with them.
     *
     * @param Dashboard $dashboard Dashboard instance.
     * @param User      $user      User instance.
     *
     * @return void
     */
    public function notifyShared(Dashboard $dashboard, User $user)
    {
        $dashboard->load('users');

        $this->mailer->queue(new DashboardShared($dashboard, $user));

        NotifyUser::dispatch(
            $this->baseNotifier,
            trans('dashboards.notifications.'.Notification::TYPE_DASHBOARD_SHARING, [
                'user' => $dashboard->owner()->full_name,
                'dashboard' => $dashboard->title,
            ]),
            Notification::TYPE_DASHBOARD_SHARING,
            $user,
            null,
            URL::action('App\Dashboards\Http\Controllers\Front\Dashboard\Controller@index', [], false)
        );
    }

    /**
     * Notifies a user that permission of shared dashboard is changed.
     *
     * @param UserDashboard $userDashboard User dashboard instance.
     * @param bool          $canEdit       Flag that indicates permission settings.
     *
     * @return void
     */
    public function notifySharedPermissionsChange(UserDashboard $userDashboard, $canEdit)
    {
        $userDashboard->load('user', 'dashboard');

        $this->mailer->queue(new SharedDashboardPermissionsChanged($userDashboard, $canEdit));

        if ($userDashboard->user) {
            NotifyUser::dispatch(
                $this->baseNotifier,
                trans('dashboards.notifications.'.Notification::TYPE_DASHBOARD_PERMISSIONS_CHANGED, [
                    'user' => $userDashboard->dashboard->owner()->full_name,
                    'dashboard' => $userDashboard->dashboard->title,
                ]),
                Notification::TYPE_DASHBOARD_PERMISSIONS_CHANGED,
                $userDashboard->user,
                null,
                URL::action('App\Dashboards\Http\Controllers\Front\Dashboard\Controller@index', [], false)
            );
        }
    }

    /**
     * Notifies a user that dashboard is shared with them.
     *
     * @param UserDashboard $userDashboard User dashboard instance.
     *
     * @return void
     */
    public function notifyRemovedFromDashboard(UserDashboard $userDashboard)
    {
        $userDashboard->load('user', 'dashboard');
        $dashboard = $userDashboard->dashboard;

        $this->mailer->queue(new RemovedFromDashboard($userDashboard));

        if ($userDashboard->user) {
            NotifyUser::dispatch(
                $this->baseNotifier,
                trans('dashboards.notifications.'.Notification::TYPE_REMOVED_FROM_DASHBOARD, [
                    'user' => $dashboard->owner()->full_name,
                    'dashboard' => $dashboard->title,
                ]),
                Notification::TYPE_REMOVED_FROM_DASHBOARD,
                $userDashboard->user,
                null,
                URL::action('App\Dashboards\Http\Controllers\Front\Dashboard\Controller@index', [], false)
            );
        }
    }

    /**
     * Notifies a user that user unsubscribed from their dashboard.
     *
     * @param UserDashboard $userDashboard User dashboard instance.
     *
     * @return void
     */
    public function notifyUnsubscribedFromDashboard(UserDashboard $userDashboard)
    {
        $userDashboard->load('user', 'dashboard');
        $user = $userDashboard->user;
        $dashboard = $userDashboard->dashboard;

        $this->mailer->queue(new UnsubscribedFromDashboard($userDashboard));

        NotifyUser::dispatch(
            $this->baseNotifier,
            trans('dashboards.notifications.'.Notification::TYPE_UNSUBSCRIBED_FROM_DASHBOARD, [
                'user' => $user->full_name,
                'dashboard' => $dashboard->title,
            ]),
            Notification::TYPE_UNSUBSCRIBED_FROM_DASHBOARD,
            $dashboard->owner(),
            null,
            URL::action('App\Dashboards\Http\Controllers\Front\Dashboard\Controller@index', [], false)
        );
    }

    /**
     * Sends invitation to a user, to join Add-it and use the dashboard that is
     * shared with them.
     *
     * @param Dashboard $dashboard Dashboard instance.
     * @param string    $email     Email to which to send invitation.
     *
     * @return void
     */
    public function sharedDashboardInvitation(Dashboard $dashboard, $email)
    {
        $dashboard->load('users');

        $this->mailer->queue(new SharedDashboardInvitation($dashboard, $email));
    }
}
