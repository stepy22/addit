<?php

namespace App\Dashboards\Dashboard;

use App\Auth\User;
use App\DashboardCategories\DashboardCategory\Repository as DashboardCategoryRepository;
use App\Dashboards\Dashboard;
use App\Dashboards\Dashboard\Notifier as DashboardNotifier;
use App\Dashboards\Dashboard\Repository as DashboardRepository;
use App\Dashboards\UserDashboard\Repository as UserDashboardRepository;
use Illuminate\Database\Eloquent\Collection;

class Manager
{
    /**
     * A DashboardRepository repository instance.
     *
     * @var DashboardRepository
     */
    protected $dashboardRepository;

    /**
     * A DashboardCategoryRepository repository instance.
     *
     * @var DashboardCategoryRepository
     */
    protected $dashboardCategoryRepository;

    /**
     * @param DashboardRepository         $dashboardRepository         A dashboard repository instance.
     * @param DashboardCategoryRepository $dashboardCategoryRepository A dashboard category repository instance.
     * @param DashboardNotifier           $dashboardNotifier           A dashboard notifier instance.
     * @param UserDashboardRepository     $userDashboardRepository     A user dashboard repository instance.
     */
    public function __construct(
        DashboardRepository $dashboardRepository,
        DashboardCategoryRepository $dashboardCategoryRepository,
        DashboardNotifier $dashboardNotifier,
        UserDashboardRepository $userDashboardRepository
    ) {
        $this->dashboardRepository = $dashboardRepository;
        $this->dashboardCategoryRepository = $dashboardCategoryRepository;
        $this->dashboardNotifier = $dashboardNotifier;
        $this->userDashboardRepository = $userDashboardRepository;
    }

    /**
     * Suggests initial dashboards for newly created user.
     *
     * @param User $user User instance.
     *
     * @return Collection
     */
    public function suggestDashboards(User $user)
    {
        // Creates home dashboard.
        $homeDashboard = $this->dashboardRepository->createHomeDashboardForUser($user);

        // Creates shared dashboard (dashboard for shared widgets).
        $sharedDashboard = $this->dashboardRepository->createSharedDashboardForUser($user);

        // Creates basic dashboards.
        $basicCategories = $this->dashboardCategoryRepository->getBasicCategories();
        $basicDashboards = $this->dashboardRepository->createDashboardsForUser($user, $basicCategories);

        $dashboards = collect();

        $dashboards->push($homeDashboard);
        $dashboards->push($sharedDashboard);
        $dashboards = $dashboards->merge($basicDashboards);

        $user->load('interestTags');

        // Creates dashboards suggested based on interest tags, if user have any.
        if (!$user->interestTags->isEmpty()) {
            // We don't want to get interest tags provided by facebook sign in
            // included in suggesting dashboards.
            $interestTags = $user->interestTags->where('pivot.source_facebook', 0);
            $categories = $this->dashboardCategoryRepository->getByInterestTags(
                $interestTags->pluck('id')->toArray()
            );

            $suggestedDashboards = $this->dashboardRepository->createDashboardsForUser($user, $categories);

            $dashboards = $dashboards->merge($suggestedDashboards);
        }

        return $dashboards;
    }

    /**
     * Shares a dashboard with a user.
     *
     * @param Dashboard $dashboard Dashboard instance.
     * @param User      $user      User instance.
     *
     * @return Dashboard
     */
    public function share(Dashboard $dashboard, User $user)
    {
        $this->dashboardNotifier->notifyShared($dashboard, $user);
        $this->dashboardRepository->share($dashboard, $user);

        return $dashboard;
    }

    /**
     * Creates invitation for shared dashboard.
     *
     * @param Dashboard $dashboard Dashboard instance.
     * @param string    $email     Email of a user.
     *
     * @return Dashboard
     */
    public function createInvitation(Dashboard $dashboard, $email)
    {
        $this->dashboardNotifier->sharedDashboardInvitation($dashboard, $email);
        $this->userDashboardRepository->createDashboardInvitation($dashboard, $email);

        return $dashboard;
    }

    /**
     * Connects dashboard invitations to newly created user.
     *
     * @param User $user User instance.
     *
     * @return void
     */
    public function connectInvitations(User $user)
    {
        $invitations = $this->userDashboardRepository->getInvitations($user->email);
        $dashboards = $user->dashboards;

        if ($dashboards->isEmpty()) {
            $newSort = 1;
        } else {
            $newSort = $dashboards->sortByDesc('pivot.sort')->first()->pivot->sort + 1;
        }

        foreach ($invitations as $invitation) {
            $invitation->email = null;
            $invitation->user_id = $user->id;
            $invitation->sort = $newSort++;

            $invitation->save();
        }
    }
}
