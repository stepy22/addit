<?php

namespace App\Dashboards\UserDashboard;

use App\Dashboards\UserDashboard\Repository as UserDashboardRepository;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Routing\Router;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerRoutePatterns($this->app['router'], $this->app);
        $this->registerFrontApiRoutes($this->app['router']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers the route patterns.
     *
     * @param Router    $router    A router.
     * @param Container $container A dependency container.
     *
     * @return void
     */
    protected function registerRoutePatterns(Router $router, Container $container)
    {
        $idRegex = $this->routePatternRegexes['id'];
        $slugRegex = $this->routePatternRegexes['slug'];

        $router->pattern('userDashboard', $idRegex);

        $router->bind('userDashboard', function ($value) use ($container, $idRegex) {
            $userDashboardRepository = $container->make(UserDashboardRepository::class);

            if (preg_match("/^{$idRegex}$/D", $value)) {
                $userDashboard = $userDashboardRepository->find($value);

                if ($userDashboard !== null) {
                    return $userDashboard;
                }
            }
        });
    }

    /**
     * Registers front API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerFrontApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1/dashboards',
            'middleware' => ['api', 'auth'],
            'namespace' => 'App\Dashboards\Http\Controllers\Api\V1\Front\UserDashboard',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->delete('users/{userDashboard}', 'Controller@delete');
        });

        $attributes['middleware'][] = 'dashboard.ownership';

        $router->group($attributes, function (RegistrarContract $router) {
            $router->put('users/{userDashboard}', 'Controller@update');
            $router->get('{dashboard}/users', 'Controller@index');
            $router->post('{dashboard}/users', 'Controller@store');
        });
    }
}
