<?php

namespace App\Dashboards\UserDashboard;

use App\Dashboards\Dashboard;
use App\Dashboards\UserDashboard;
use Hshn\Base64EncodedFile\HttpFoundation\File\Base64EncodedFile;
use Illuminate\Http\UploadedFile;

class Repository
{
    /**
     * A UserDashboard model instance.
     *
     * @var UserDashboard
     */
    protected $userDashboard;

    /**
     * @param UserDashboard $userDashboard A dashboard model instance.
     */
    public function __construct(UserDashboard $userDashboard)
    {
        $this->userDashboardModel = $userDashboard;
    }

    /**
     * Gets all dashboards.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAll()
    {
        return $this->userDashboardModel->sorted()->get();
    }

    /**
     * Finds the user dashboard by ID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $id The user dashboard ID.
     *
     * @return UserDashboard|null
     */
    public function find($id)
    {
        return $this->userDashboardModel->find($id);
    }

    /**
     * Finds the user dashboard by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The user dashboard ID.
     *
     * @return UserDashboard
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->userDashboardModel->findOrFail($id);
    }

    /**
     * Creates a new user dashboard and returns it.
     *
     * @param array $inputData The user dashboard input data.
     *
     * @return UserDashboard
     */
    public function create(array $inputData)
    {
        return $this->populateAndSave($this->userDashboardModel->newInstance(), $inputData);
    }

    /**
     * Updates the passed user dashboard and returns it.
     *
     * @param UserDashboard $userDashboard The user dashboard to update.
     * @param array         $inputData     The input data for the update.
     *
     * @return UserDashboard
     */
    public function update(UserDashboard $userDashboard, array $inputData)
    {
        return $this->populateAndSave($userDashboard, $inputData);
    }

    /**
     * Deletes the passed dashboard from the system.
     *
     * @param UserDashboard $userDashboard The user dashboard to delete.
     *
     * @return bool|null
     */
    public function delete(UserDashboard $userDashboard)
    {
        return $userDashboard->delete();
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param UserDashboard $userDashboard The user dashboard to populate.
     * @param array         $inputData     The input data for the user dashboard.
     *
     * @return UserDashboard
     */
    protected function populate(UserDashboard $userDashboard, array $inputData)
    {
        $userDashboard->dashboard_id = array_get($inputData, 'dashboard_id');
        $userDashboard->user_id = array_get($inputData, 'user_id');
        $userDashboard->is_owner = array_get($inputData, 'is_owner');
        $userDashboard->can_edit = array_get($inputData, 'can_edit');
        $userDashboard->theme = array_get($inputData, 'theme');

        if (isset($inputData['image_main'])) {
            if ($inputData['image_main'] instanceof UploadedFile) {
                $userDashboard->uploadImage($inputData['image_main'], 'main');
            } else {
                $file = new Base64EncodedFile($inputData['image_main']);
                $userDashboard->uploadImage($file->getPathname(), 'main');
            }
        }

        return $userDashboard;
    }

    /**
     * Sorts user dashboards in the passed order.
     *
     * @param array $inputData The new sort order.
     *
     * @return bool
     */
    public function sort(array $inputData)
    {
        $newOrder = array_map(
            function ($item) {
                return (int) $item['id'];
            },
            $inputData['items']
        );

        return $this->userDashboardModel->updateSortOrder($newOrder);
    }

    /**
     * Return next sort value for a model.
     *
     * @return int
     */
    public function getNextSortValue()
    {
        return $this->userDashboardModel->getNextSortValue();
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param UserDashboard $userDashboard The user dashboard to populate and save.
     * @param array         $inputData     The input data.
     *
     * @return UserDashboard
     */
    protected function populateAndSave(UserDashboard $userDashboard, array $inputData)
    {
        $userDashboard = $this->populate($userDashboard, $inputData);

        $userDashboard->save();

        return $userDashboard;
    }

    /**
     * Creates dashboard invitation.
     *
     * @param Dashboard $dashboard Dashboard instance.
     * @param string    $email     Email to which to assign invitation.
     *
     * @return UserDashboard
     */
    public function createDashboardInvitation(Dashboard $dashboard, $email)
    {
        $userDashboard = $this->userDashboardModel->newInstance();

        $userDashboard->dashboard_id = $dashboard->id;
        $userDashboard->can_edit = false;
        $userDashboard->is_owner = false;
        $userDashboard->email = $email;

        $userDashboard->save();

        return $userDashboard;
    }

    /**
     * Gets invitations for passed email.
     *
     * @param string $email Email.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getInvitations($email)
    {
        return $this->userDashboardModel
            ->where('email', $email)
            ->whereNull('user_id')
            ->get();
    }

    /**
     * Change permissions.
     *
     * @param UserDashboard $userDashboard The user dashboard to archive.
     * @param bool          $canEdit       Flag that indicates user's permission level on dashboard.
     *
     * @return UserDashboard
     */
    public function changePermissions(UserDashboard $userDashboard, $canEdit)
    {
        $userDashboard->can_edit = $canEdit;
        $userDashboard->save();

        return $userDashboard;
    }
}
