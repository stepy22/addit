<?php

namespace App\Dashboards\UserDashboard;

use App\Auth\User;
use App\Auth\User\Repository as UserRepository;
use App\Dashboards\Dashboard;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;

class ValidationService
{
    /**
     * User repository instance.
     *
     * @var UserRepository
     */
    protected $userRepository;

    /**
     * @param UserRepository $userRepository User repository instance.
     */
    public function __construct(UserRepository $userRepository)
    {
        $this->userRepository = $userRepository;
    }

    /**
     * Checks if dashboard can be shared with a user.
     *
     * @param Dashboard $dashboard Dashboard instance.
     * @param User      $owner     Owner of a dashboard.
     * @param string    $email     Email of a target user.
     *
     * @throws BadRequestHttpException
     *
     * @return void
     */
    public function validateStore(Dashboard $dashboard, User $owner, $email)
    {
        $user = $this->userRepository->findByEmail($email);

        if ($user && !$user->profile_completed) {
            throw new BadRequestHttpException('User you\'re trying to share with still hasn\'t completed their profile.');
        }

        if (!$owner->isPro()) {
            throw new BadRequestHttpException('You have to be a PRO user to share a dashboard.');
        }

        // Can't share home or shared dashboard.
        if ($dashboard->is_home || $dashboard->is_shared) {
            throw new BadRequestHttpException('Home and Shared widgets dashboards can\'t be shared.');
        }

        // Check if user with given email is already added to dashboard.
        if ($dashboard->userDashboards->where('email', $email)->count() > 0) {
            throw new BadRequestHttpException('User with given email is already invited to use this dashboard.');
        }

        if ($dashboard->users->where('email', $email)->count() > 0) {
            throw new BadRequestHttpException('Dashboard is already shared with a user with given email.');
        }
    }
}
