<?php

namespace App\Log;

use Creitive\Monolog\Processor\ExtraDataProcessor;
use Illuminate\Contracts\Foundation\Application;
use InvalidArgumentException;
use Monolog\Formatter\LineFormatter;
use Monolog\Handler\LogglyHandler;
use Monolog\Handler\RavenHandler;
use Monolog\Handler\StreamHandler;
use Monolog\Logger;
use Monolog\Processor\GitProcessor;
use Raven_Client;

class Configurator
{
    /**
     * Configures the logging mechanism.
     *
     * @param Logger      $monolog A Monolog Logger instance.
     * @param Application $app     An Application implementation.
     *
     * @return void
     */
    public function configure(Logger $monolog, Application $app)
    {
        $this->addGitProcessor($monolog);
        $this->addExtraDataProcessor($monolog, $app);

        $this->configureSingleHandler($monolog);

        if ($logglyToken = $app['config']->get('loggly.token')) {
            $logglyTag = $app['config']->get('loggly.tag');

            $this->configureLogglyHandler($monolog, $logglyToken, $logglyTag);
        }

        if ($sentryDsn = $app['config']->get('sentry.dsn')) {
            $sentryEnvironment = $app['config']->get('sentry.environment') ?: $app->environment();

            $this->configureSentryHandler($monolog, $sentryDsn, $sentryEnvironment);
        }
    }

    /**
     * Adds a Git processor to the Monolog instance.
     *
     * This adds the current Git branch/commit info to the log.
     *
     * @param Logger $monolog A Monolog logger instance.
     *
     * @return void
     */
    protected function addGitProcessor(Logger $monolog)
    {
        $monolog->pushProcessor(new GitProcessor());
    }

    /**
     * Adds an extra data processor to the Monolog instance.
     *
     * This adds various metadata about the current request and/or execution
     * context.
     *
     * Note that artisan commands will always log the URL configured as the
     * `app.url`, but we can use the `console` entry to identify those.
     *
     * @param Logger      $monolog A Monolog Logger instance.
     * @param Application $app     An application implementation.
     *
     * @return void
     */
    protected function addExtraDataProcessor(Logger $monolog, Application $app)
    {
        // If the ExtraDataProcessor class doesn't exist, go on without it.
        if (!class_exists(ExtraDataProcessor::class)) {
            return;
        }

        $extraDataProcessor = new ExtraDataProcessor([
            'environment' => $app->environment(),
            'console' => $app->runningInConsole(),
            'argv' => $app->runningInConsole() ? $_SERVER['argv'] : null,
        ]);

        $monolog->pushProcessor($extraDataProcessor);

        $app->instance('log.extraDataProcessor', $extraDataProcessor);
    }

    /**
     * Configures a single log file.
     *
     * @param Application $app An application implementation.
     *
     * @return void
     */
    protected function configureSingleHandler(Logger $monolog)
    {
        $handler = new StreamHandler(storage_path('/logs/laravel.log'));
        $handler->setFormatter(new LineFormatter(null, null, true, true));

        $monolog->pushHandler($handler);
    }

    /**
     * Configures the Loggly handler.
     *
     * @param Logger $monolog A Monolog Logger instance.
     * @param string $token   The Loggly token.
     * @param string $tag     The Loggly tag.
     *
     * @return void
     *
     * @throws InvalidArgumentException
     */
    public function configureLogglyHandler(Logger $monolog, $token, $tag)
    {
        if (!$tag) {
            throw new InvalidArgumentException('A Loggly tag must be configured in order to use logging!');
        }

        $handler = new LogglyHandler($token);
        $handler->setTag($tag);

        $monolog->pushHandler($handler);
    }

    /**
     * Configures the Sentry handler.
     *
     * @param Logger $monolog     A Monolog Logger instance.
     * @param string $dsn         The Sentry DSN.
     * @param string $environment The Sentry environment.
     *
     * @return void
     */
    public function configureSentryHandler(Logger $monolog, $dsn, $environment)
    {
        $client = new Raven_Client($dsn);
        $client->setEnvironment($environment);

        $handler = new RavenHandler($client);
        $handler->setFormatter(new LineFormatter("%message% %context% %extra%\n"));

        $monolog->pushHandler($handler);
    }
}
