<?php

namespace App\Log;

use Illuminate\Support\ServiceProvider;

class ExtraDataServiceProvider extends ServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function register()
    {
        // If the ExtraDataProcessor instance isn't registered in the container,
        // just continue without it.
        if (!$this->app->bound('log.extraDataProcessor')) {
            return;
        }

        $request = $this->app['request'];

        $this->app['log.extraDataProcessor']->addExtraData([
            'httpMethod' => $request->method(),
            'url' => $request->url(),
            'clientIps' => $request->getClientIps(),
            'referrer' => $request->server('HTTP_REFERER'),
            'userAgent' => $request->header('User-Agent'),
        ]);
    }
}
