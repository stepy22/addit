<?php

namespace App\MyInsightSubjects\Http\Controllers\Admin\MyInsightSubject;

use App\Http\Controllers\Admin\Controller as BaseController;
use App\MyInsightSubjects\Http\Requests\Admin\MyInsightSubject\StoreRequest;
use App\MyInsightSubjects\Http\Requests\Admin\MyInsightSubject\UpdateRequest;
use App\MyInsightSubjects\MyInsightSubject;
use App\MyInsightSubjects\MyInsightSubject\Repository as MyInsightSubjectRepository;
use Illuminate\Http\Request;
use Illuminate\Support\MessageBag;
use Redirect;

class Controller extends BaseController
{
    /**
     * A MyInsightSubjectRepository instance.
     *
     * @var MyInsightSubjectRepository
     */
    protected $myInsightSubjectRepository;

    /**
     * @param MyInsightSubjectRepository $myInsightSubjectRepository A myInsightSubjectRepository repository instance.
     */
    public function __construct(MyInsightSubjectRepository $myInsightSubjectRepository)
    {
        parent::__construct();

        $this->myInsightSubjectRepository = $myInsightSubjectRepository;

        $this->viewData->bodyDataPage = 'admin-my-insight-subjects';
        $this->viewData->pageTitle->setPage(trans('admin/myInsightSubjects.module'));
        $this->viewData->navigation->get('admin.main')->setActive('my-insight-subjects');
    }

    /**
     * Shows all myInsightSubjects.
     *
     * @param Request $request The current request.
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $data = [
            'myInsightSubjects' => $this->myInsightSubjectRepository->getAll(),
        ];

        return view('admin.my-insight-subjects.index', $data);
    }

    /**
     * Displays the create form.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        return view('admin.my-insight-subjects.create');
    }

    /**
     * Saves a new myInsightSubject.
     *
     * @param StoreRequest $request A myInsightSubject store request.
     *
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function store(StoreRequest $request)
    {
        $myInsightSubject = $this->myInsightSubjectRepository->create($request->all());

        $successMessage = trans('admin/myInsightSubjects.successMessages.create');

        return Redirect::action(static::class.'@edit', ['myInsightSubject' => $myInsightSubject->id])
            ->with('successMessages', new MessageBag([$successMessage]));
    }

    /**
     * Shows the specified myInsightSubject's edit page.
     *
     * @param MyInsightSubject $myInsightSubject The myInsightSubject.
     *
     * @return \Illuminate\View\View
     */
    public function edit(MyInsightSubject $myInsightSubject)
    {
        $data = [
            'myInsightSubject' => $myInsightSubject,
        ];

        return view('admin.my-insight-subjects.edit', $data);
    }

    /**
     * Updates the specified myInsightSubject.
     *
     * @param UpdateRequest    $request          A myInsightSubject update request.
     * @param MyInsightSubject $myInsightSubject The myInsightSubject.
     *
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function update(UpdateRequest $request, MyInsightSubject $myInsightSubject)
    {
        $this->myInsightSubjectRepository->update($myInsightSubject, $request->all());

        $successMessage = trans('admin/myInsightSubjects.successMessages.edit');

        return Redirect::action(static::class.'@edit', ['myInsightSubject' => $myInsightSubject->id])
            ->with('successMessages', new MessageBag([$successMessage]));
    }

    /**
     * Displays the my insight subject deletion confirmation form.
     *
     * @param Request          $request          The request.
     * @param MyInsightSubject $myInsightSubject The my insight subject instance.
     *
     * @return \Illuminate\View\View
     */
    public function confirmDelete(Request $request, MyInsightSubject $myInsightSubject)
    {
        $data = [
            'myInsightSubject' => $myInsightSubject,
        ];

        return view('admin.my-insight-subjects.delete', $data);
    }

    /**
     * Deletes a my insight subject.
     *
     * @param Request          $request          The delete subject request.
     * @param MyInsightSubject $myInsightSubject The myInsightSubject instance.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function delete(Request $request, MyInsightSubject $myInsightSubject)
    {
        if ($request->get('action') !== 'confirm') {
            return Redirect::action(static::class.'@index');
        }

        $this->myInsightSubjectRepository->delete($myInsightSubject);

        $successMessage = trans('admin/myInsightSubjects.successMessages.delete', ['subject' => $myInsightSubject->subject]);

        return Redirect::action(static::class.'@index')
            ->with('successMessages', new MessageBag([$successMessage]));
    }
}
