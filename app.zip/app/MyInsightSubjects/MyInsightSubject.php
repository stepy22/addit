<?php

namespace App\MyInsightSubjects;

use Creitive\Database\Eloquent\Model;
use Creitive\Models\Traits\SortableTrait;

class MyInsightSubject extends Model
{
    use SortableTrait;

    /**
     * {@inheritDoc}
     */
    protected $table = 'my_insight_subjects';

    /**
     * {@inheritDoc}
     */
    protected $visible = [
        'id',
        'subject',
        'description',
        'sort',
    ];

    /**
     * {@inheritDoc}
     */
    public $timestamps = false;
}
