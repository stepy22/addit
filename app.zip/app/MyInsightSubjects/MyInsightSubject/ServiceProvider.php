<?php

namespace App\MyInsightSubjects\MyInsightSubject;

use App\MyInsightSubjects\MyInsightSubject;
use App\MyInsightSubjects\MyInsightSubject\Repository as MyInsightSubjectRepository;
use Creitive\Module\ServiceProvider as BaseServiceProvider;
use DaveJamesMiller\Breadcrumbs\Generator as BreadcrumbGenerator;
use DaveJamesMiller\Breadcrumbs\Manager as BreadcrumbManager;
use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Routing\Registrar as RegistrarContract;
use Illuminate\Routing\Router;
use URL;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * {@inheritDoc}
     */
    public function boot()
    {
        $this->registerAdminRoutes($this->app['router']);
        $this->registerAdminApiRoutes($this->app['router']);
        $this->registerAdminBreadcrumbs($this->app['breadcrumbs']);
    }

    /**
     * {@inheritDoc}
     */
    public function register()
    {
    }

    /**
     * Registers admin panel routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerAdminRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'admin/my-insight-subjects',
            'middleware' => ['web', 'auth', 'permissions'],
            'namespace' => 'App\MyInsightSubjects\Http\Controllers\Admin\MyInsightSubject',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->get('', 'Controller@index');

            $router->get('/create', 'Controller@create');
            $router->post('', 'Controller@store');

            $router->get('{myInsightSubject}/edit', 'Controller@edit');
            $router->put('{myInsightSubject}', 'Controller@update');

            $router->get('{myInsightSubject}/delete', 'Controller@confirmDelete');
            $router->delete('{myInsightSubject}', 'Controller@delete');
        });
    }

    /**
     * Registers admin API routes.
     *
     * @param RegistrarContract $router A route registrar implementation.
     *
     * @return void
     */
    protected function registerAdminApiRoutes(RegistrarContract $router)
    {
        $attributes = [
            'prefix' => 'api/v1/my-insight-subjects',
            'middleware' => ['api', 'auth', 'permissions'],
            'namespace' => 'App\MyInsightSubjects\Http\Controllers\Api\V1\Admin\MyInsightSubject',
        ];

        $router->group($attributes, function (RegistrarContract $router) {
            $router->put('sort', 'Controller@sort');
        });
    }

    /**
     * Registers breadcrumbs for the admin panel.
     *
     * @param BreadcrumbManager $breadcrumbs A breadcrumb manager.
     *
     * @return void
     * @throws \DaveJamesMiller\Breadcrumbs\Exception
     */
    protected function registerAdminBreadcrumbs(BreadcrumbManager $breadcrumbs)
    {
        $breadcrumbs->register('admin::myInsightSubjects', function (BreadcrumbGenerator $breadcrumbs) {
            $breadcrumbs->parent('admin::home');

            $url = URL::action('App\MyInsightSubjects\Http\Controllers\Admin\MyInsightSubject\Controller@index');

            $breadcrumbs->push(trans('admin/navigation.myInsightSubjects'), $url);
        });

        $breadcrumbs->register('admin::myInsightSubjects.edit', function (BreadcrumbGenerator $breadcrumbs, MyInsightSubject $myInsightSubject) {
            $breadcrumbs->parent('admin::myInsightSubjects', $myInsightSubject);

            $url = URL::action('App\MyInsightSubjects\Http\Controllers\Admin\MyInsightSubject\Controller@edit', ['myInsightSubject' => $myInsightSubject->id]);

            $breadcrumbs->push(trans('admin/myInsightSubjects.titles.edit'), $url);
        });

        $breadcrumbs->register('admin::myInsightSubjects.create', function (BreadcrumbGenerator $breadcrumbs) {
            $breadcrumbs->parent('admin::myInsightSubjects');

            $url = URL::action('App\MyInsightSubjects\Http\Controllers\Admin\MyInsightSubject\Controller@create');

            $breadcrumbs->push(trans('admin/myInsightSubjects.titles.create'), $url);
        });

        $breadcrumbs->register('admin::myInsightSubjects.delete', function (BreadcrumbGenerator $breadcrumbs, MyInsightSubject $myInsightSubject) {
            $breadcrumbs->parent('admin::myInsightSubjects');

            $url = URL::action('App\MyInsightSubjects\Http\Controllers\Admin\MyInsightSubject\Controller@confirmDelete', ['myInsightSubject' => $myInsightSubject->id]);

            $breadcrumbs->push(trans('admin/myInsightSubjects.titles.delete'), $url);
        });
    }
}
