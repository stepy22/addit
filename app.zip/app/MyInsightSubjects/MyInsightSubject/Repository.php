<?php

namespace App\MyInsightSubjects\MyInsightSubject;

use App\MyInsightSubjects\MyInsightSubject;

class Repository
{
    /**
     * A MyInsightSubject model instance.
     *
     * @var MyInsightSubject
     */
    protected $myInsightSubjectModel;

    /**
     * @param MyInsightSubject $myInsightSubject A MyInsightSubject model instance.
     */
    public function __construct(MyInsightSubject $myInsightSubject)
    {
        $this->myInsightSubjectModel = $myInsightSubject;
    }

    /**
     * Gets all my insight subjects.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAll()
    {
        $query = $this->myInsightSubjectModel->select('*');

        return $query->get();
    }

    /**
     * Finds the my insight subject by ID, or returns `null` if the ID doesn't exist.
     *
     * @param mixed $id The my insight subject ID.
     *
     * @return MyInsightSubject|null
     */
    public function find($id)
    {
        return $this->myInsightSubjectModel->find($id);
    }

    /**
     * Finds widget my insight subjects by ids.
     *
     * @param array $ids The my insight subject IDs.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getByIds(array $ids)
    {
        return $this->myInsightSubjectModel
            ->whereIn('id', $ids)
            ->get();
    }

    /**
     * Finds the my insight subject by ID, or throws an exception if the ID doesn't exist.
     *
     * @param mixed $id The my insight subject ID.
     *
     * @return MyInsightSubject
     *
     * @throws \Illuminate\Database\Eloquent\ModelNotFoundException
     */
    public function findOrFail($id)
    {
        return $this->myInsightSubjectModel->findOrFail($id);
    }

    /**
     * Updates the passed my insight subject and returns it.
     *
     * @param MyInsightSubject $myInsightSubject The my insight subject to update.
     * @param array            $inputData        The input data for the update.
     *
     * @return MyInsightSubject
     */
    public function update(MyInsightSubject $myInsightSubject, array $inputData)
    {
        return $this->populateAndSave($myInsightSubject, $inputData);
    }

    /**
     * Creates a my insight subject and returns it.
     *
     * @param array $inputData The input data for the update.
     *
     * @return MyInsightSubject
     */
    public function create(array $inputData)
    {
        $myInsightSubject = $this->myInsightSubjectModel->newInstance();

        return $this->populateAndSave($myInsightSubject, $inputData);
    }

    /**
     * Populates the passed instance with the input data.
     *
     * @param MyInsightSubject  $myInsightSubject The my insight subject to populate.
     * @param array             $inputData        The input data for the my insight subject.
     *
     * @return MyInsightSubject
     */
    protected function populate(MyInsightSubject $myInsightSubject, array $inputData)
    {
        $myInsightSubject->subject = array_get($inputData, 'subject', $myInsightSubject->subject);
        $myInsightSubject->description = array_get($inputData, 'description', $myInsightSubject->description);

        return $myInsightSubject;
    }

    /**
     * Deletes a my insight subject.
     *
     * @param MyInsightSubject $myInsightSubject The my insight subject instance.
     *
     * @return Void
     */
    public function delete(MyInsightSubject $myInsightSubject)
    {
        $myInsightSubject->delete();
    }

    /**
     * Sorts my insight subjects in the passed order.
     *
     * @param array $inputData The new sort order.
     *
     * @return bool
     */
    public function sort(array $inputData)
    {
        $newOrder = array_map(
            function ($item) {
                return (int) $item['id'];
            },
            $inputData['items']
        );

        return $this->myInsightSubjectModel->updateSortOrder($newOrder);
    }

    /**
     * Populates the passed instance with the input data, saves it and returns
     * it.
     *
     * @param MyInsightSubject $myInsightSubject The my insight subject to populate and save.
     * @param array            $inputData        The input data.
     *
     * @return MyInsightSubject
     */
    protected function populateAndSave(MyInsightSubject $myInsightSubject, array $inputData)
    {
        $myInsightSubject = $this->populate($myInsightSubject, $inputData);

        $myInsightSubject->save();

        return $myInsightSubject;
    }
}
